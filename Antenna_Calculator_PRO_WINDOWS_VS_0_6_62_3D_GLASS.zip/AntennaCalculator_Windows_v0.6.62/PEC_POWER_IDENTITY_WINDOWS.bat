@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo PEC power identity audit.
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --pec-power-identity > "PEC_POWER_IDENTITY_REPORT.txt" 2>&1
if errorlevel 1 (echo BUILD OR TEST FAILURE. See PEC_POWER_IDENTITY_REPORT.txt) else (echo Done: PEC_POWER_IDENTITY_REPORT.txt)
pause
