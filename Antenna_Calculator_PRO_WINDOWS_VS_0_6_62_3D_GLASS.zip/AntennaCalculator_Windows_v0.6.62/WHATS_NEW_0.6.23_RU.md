# 0.6.23 — optional CUDA volume renderer

* Новый исходник CUDA `Cuda/AntennaCudaVolume64.cu` и `BUILD_CUDA_VOLUME_WIN64.bat`.
* Рендер 3D поля E/H/S выполняется CUDA, если собрана и доступна DLL `AntennaCudaVolume64.dll`.
* В отсутствие NVIDIA/CUDA — прежний CPU-рендер (без отказа программы).
* Полная 6-ступенчатая радуга: синий → голубой → зелёный → жёлтый → красный.
* Плашка `Рендер: CUDA GPU/CPU` сообщает фактически использованный путь.

## Сборка GPU

1. Установить NVIDIA CUDA Toolkit и Visual Studio C++ Build Tools.
2. Открыть **x64 Native Tools Command Prompt for VS**.
3. Запустить `Cuda\BUILD_CUDA_VOLUME_WIN64.bat`.
4. Убедиться, что появился файл `Cuda\bin\AntennaCudaVolume64.dll`.
5. Собрать решение Visual Studio в Release; проект скопирует DLL в папку EXE.

**Важно:** CUDA модуль поставляется в исходном коде и НЕ собран в архиве. Пока DLL не собрана, будет показан режим CPU. CUDA рендер не равен Direct3D 11: GPU выполняет вычисление пикселей, WPF выводит готовую bitmap. Динамика и качество требуют испытания на Windows.
