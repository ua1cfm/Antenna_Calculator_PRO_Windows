@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Running --segmentation-convergence ...
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --segmentation-convergence > "SEGMENTATION_CONVERGENCE_REPORT.txt" 2>&1
type "SEGMENTATION_CONVERGENCE_REPORT.txt"
echo.
echo Report: SEGMENTATION_CONVERGENCE_REPORT.txt
pause
