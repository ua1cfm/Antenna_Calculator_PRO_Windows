@echo off
cd /d "%~dp0"
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "LOG=%~dp0PEC_BOUNDARY_RADIATION_AUDIT_REPORT.txt"
echo PEC BOUNDARY RADIATION AUDIT v0.3.25 > "%LOG%"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --pec-boundary-radiation-audit >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LOG%"
echo.
echo Report: %LOG%
pause
exit /b %RC%
