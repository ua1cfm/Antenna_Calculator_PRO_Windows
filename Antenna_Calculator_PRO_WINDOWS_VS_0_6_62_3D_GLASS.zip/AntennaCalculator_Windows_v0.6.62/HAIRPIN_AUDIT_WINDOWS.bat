@echo off
cd /d "%~dp0"
set "LOG=%~dp0HAIRPIN_AUDIT_REPORT.txt"
echo Hairpin Monopole diagnostic > "%LOG%"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-audit >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LOG%"
echo.
echo Report file: %LOG%
if not "%RC%"=="0" echo DIAGNOSTIC EXECUTION FAILED: %RC%
pause
exit /b %RC%
