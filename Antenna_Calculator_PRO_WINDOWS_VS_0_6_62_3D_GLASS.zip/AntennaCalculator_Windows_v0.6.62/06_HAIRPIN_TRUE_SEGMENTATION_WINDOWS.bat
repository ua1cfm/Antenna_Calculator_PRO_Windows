@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-topology-audit > "HAIRPIN_TRUE_SEGMENTATION_REPORT.txt" 2>&1
if errorlevel 1 (echo TEST FAILED. Read HAIRPIN_TRUE_SEGMENTATION_REPORT.txt) else (echo TEST COMPLETE: HAIRPIN_TRUE_SEGMENTATION_REPORT.txt)
pause
