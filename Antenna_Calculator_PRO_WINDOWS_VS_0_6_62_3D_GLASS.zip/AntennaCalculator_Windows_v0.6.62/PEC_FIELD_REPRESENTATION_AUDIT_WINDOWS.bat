@echo off
setlocal
cd /d "%~dp0"
set DOTNET_CLI_TELEMETRY_OPTOUT=1
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" --configuration Release -- --pec-field-representation-audit > "PEC_FIELD_REPRESENTATION_AUDIT_REPORT.txt" 2>&1
set RESULT=%ERRORLEVEL%
type "PEC_FIELD_REPRESENTATION_AUDIT_REPORT.txt"
echo.
echo Exit code: %RESULT%
pause
exit /b %RESULT%
