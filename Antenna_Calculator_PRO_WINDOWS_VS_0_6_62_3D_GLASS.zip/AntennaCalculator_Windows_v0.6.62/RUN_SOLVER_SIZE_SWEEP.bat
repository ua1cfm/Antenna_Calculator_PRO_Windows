@echo off
cd /d "%~dp0"
dotnet run --project ".\Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --solver-size-sweep --segments 201,401,801 --export-dir ".\solver_sweep_output"
echo.
echo Reports in solver_sweep_output\solver_sweep.txt and solver_sweep.csv
pause
