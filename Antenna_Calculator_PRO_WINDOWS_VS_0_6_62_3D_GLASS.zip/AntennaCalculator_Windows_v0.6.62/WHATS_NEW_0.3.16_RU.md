# v0.3.16 — coherent ground radiation correction (experimental)

Based on Android 1.19.268 `MmanaRadiationPattern.kt`:
- For G=2, use physical complex currents with MININEC v89/h89 ground reflection instead of rendering PEC image currents as a full-sphere pattern.
- Mask radiation below the horizon for grounded models.
- Use the same complex far-field operator for 3D DN and the G=2 E-field visualization planes.
- Retain 2.5-degree angular grid and field animation.
- No change to the MININEC matrix solver or impedance. Numerical MMANA pattern regression and Windows build still required.
