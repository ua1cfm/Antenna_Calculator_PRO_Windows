@echo off
setlocal
cd /d "%~dp0"
set "REPORT=%~dp0HAIRPIN_PHYSICAL_TOPOLOGY_REPORT.txt"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-physical-topology > "%REPORT%" 2>&1
type "%REPORT%"
echo.
echo Report: %REPORT%
pause
