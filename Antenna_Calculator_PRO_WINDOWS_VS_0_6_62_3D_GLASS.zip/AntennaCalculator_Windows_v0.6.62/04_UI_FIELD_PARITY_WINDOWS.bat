@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --ui-field-parity > "UI_FIELD_PARITY_REPORT.txt" 2>&1
if errorlevel 1 (echo TEST FAILED: UI_FIELD_PARITY_REPORT.txt) else (echo TEST COMPLETE: UI_FIELD_PARITY_REPORT.txt)
pause
