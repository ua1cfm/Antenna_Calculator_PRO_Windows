@echo off
setlocal
cd /d "%~dp0"
echo ===== Antenna Calculator Windows 0.3.4 build/test =====
where dotnet >nul 2>nul
if errorlevel 1 (
    echo ERROR: .NET 8 SDK not found. Install .NET 8 SDK and .NET Desktop workload in Visual Studio 2022.
    exit /b 1
)
dotnet --version
dotnet build "Source\AntennaCalculator.Core\AntennaCalculator.Core.csproj" -c Debug -v minimal
if errorlevel 1 exit /b 1
dotnet build "Source\AntennaCalculator.Wpf\AntennaCalculator.Wpf.csproj" -c Debug -v minimal
if errorlevel 1 exit /b 1
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Debug
if errorlevel 1 exit /b 1
echo.
echo SUCCESS: core, WPF and regression tests completed.
endlocal
