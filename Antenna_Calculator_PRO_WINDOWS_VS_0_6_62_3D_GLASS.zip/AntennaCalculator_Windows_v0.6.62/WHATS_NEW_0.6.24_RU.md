# 0.6.24 — CUDA diagnostics and deployment

- При CPU fallback отображается последняя ошибка загрузки CUDA DLL или код CUDA runtime.
- Убрано двойное правило копирования DLL; AntennaCudaVolume64.dll копируется из Cuda/bin в output после сборки и при публикации.
- CUDA runtime cudart включён в перечень библиотек для копирования (если он есть в CUDA Toolkit).
- Скрипт сборки проверяет экспорт antenna_volume_render.

Важно: native DLL нужно собрать на Windows из папки Cuda и затем пересобрать WPF. Без неё GPU путь работать не может. Ошибка -2 означает отсутствие доступного CUDA GPU/драйвера; -3/-4 — CUDA выделение памяти, -5 — выполнение kernel или копирование.
