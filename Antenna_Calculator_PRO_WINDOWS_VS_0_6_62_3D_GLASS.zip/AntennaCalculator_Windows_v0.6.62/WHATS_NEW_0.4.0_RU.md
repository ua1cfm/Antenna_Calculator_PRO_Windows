# Windows 0.4.0 — ядро MMANA

Основа: 0.3.99 (затенение 3D ДН по полусферам).

## Новое: `AntennaCalculator.Core/MmanaReferenceEngine.cs`

Перенос расчётного ядра MMANA (JE3HHT, mininec3.cpp + ComLib.cpp, LGPL) без goto, имена как в оригинале:
сегментация подпроводами (Tei/TeiB/TeiE/TeiAvg, EC, SEG < −10000), комбинированные провода,
соединения и нумерация импульсов MININEC, имена импульсов wNb/wNc/wNe, нагрузки L‖C с Q только
у катушки, потери провода одним резистором на провод по коду материала M (Cu/Al/Fe, провод/трубка),
идеальное зеркало для любого типа земли, матрица в одинарной точности.

Проверка: через идентичный Java-порт против оригинального C-кода на 1987 файлах базы — 1970 совпадают
до 1e-6, 12 дают NaN у обоих, 2 отличаются на 1e-5…1e-6 (округление float).

Использование:

    var (result, error) = MmanaReferenceEngine.SolveText(text, freqMHz: null, galCompat: true);
    // result.R, result.X, result.Pulses, result.Warnings

`galCompat: true` — правило MMANA-GAL «EC не меньше 2»; `false` — оригинальная MMANA.

Самопроверка после сборки: `MmanaReferenceEngine.SelfTest()` должна вернуть `SELF TEST PASSED`
(5 моделей × 2 режима, эталон — оригинальный C-код).

Ограничения: Make Stack и S-нагрузки не поддерживаются (возвращается ошибка); считается импеданс
первого источника. Существующий решатель, ДН, токи и CUDA не менялись; ядро пока не подключено к интерфейсу.

## CUDA

`Cuda/bin/AntennaCuda64.dll` — без изменений, копируется в папку сборки из
`..\..\Cuda\bin\AntennaCuda64.dll` (AntennaCalculator.Wpf.csproj). Пересборка DLL: `Cuda/BUILD_CUDA_WIN64.bat`.
