@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-mesh-quality > "HAIRPIN_MESH_QUALITY_REPORT.txt" 2>&1
if errorlevel 1 (echo TEST FAILED. See HAIRPIN_MESH_QUALITY_REPORT.txt) else (echo TEST COMPLETE. See HAIRPIN_MESH_QUALITY_REPORT.txt)
pause
