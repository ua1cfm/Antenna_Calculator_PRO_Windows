@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-condition > "HAIRPIN_CONDITION_REPORT.txt" 2>&1
if errorlevel 1 (echo FAILED. See HAIRPIN_CONDITION_REPORT.txt) else (echo COMPLETE. See HAIRPIN_CONDITION_REPORT.txt)
pause
