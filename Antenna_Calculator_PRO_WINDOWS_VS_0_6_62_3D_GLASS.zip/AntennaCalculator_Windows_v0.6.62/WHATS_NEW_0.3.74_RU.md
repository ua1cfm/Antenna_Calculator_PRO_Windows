# v0.3.74 — Проверка матрицы и RHS MININEC

Добавлен режим тестового проекта `--mmana-matrix-parity`. Экспортирует реальные коэффициенты комплексной матрицы A и RHS для **конкретного** .maa, без изменения сегментации. Для n<=900 проверяет прямой LU по исходной невязке; при n>360 дополнительно сравнивает FGMRES и LU на одной матрице.

Команда из корня распакованного проекта (PowerShell):

```powershell
dotnet run --project .\Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj -c Release -- --mmana-matrix-parity --model ".\Samples\fixture_PEC_monopole.maa" --export-dir ".\parity_output"
```

В `parity_output/matrix_rhs.csv` — индексы 0-based, A_real,A_imag и RHS (RHS заполняется только при column=0); в `results.txt` — две независимые невязки. Для сравнения с исходным MMANA потребуется отдельный экспорт её коэффициентов при той же сегментации, ориентации и нормировке. **Это ещё НЕ подтверждение совпадения с MMANA и НЕ исправление модели 8648 импульсов.** Из-за ограничения времени/memory прямое LU автоматически НЕ запускается для 8648.

Среда авторства не содержит dotnet, сборка и численные прогоны не подтверждены.
