@echo off
cd /d "%~dp0"
set "LOG=%~dp0WINDOWS_TEST_REPORT_0.3.7.txt"
echo Antenna Calculator PRO Windows 0.3.7 test run > "%LOG%"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" --configuration Release -- %* 1>> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LOG%"
echo.
echo Log: %LOG%
if not "%RC%"=="0" echo TESTS FAILED with exit code %RC%
pause
exit /b %RC%
