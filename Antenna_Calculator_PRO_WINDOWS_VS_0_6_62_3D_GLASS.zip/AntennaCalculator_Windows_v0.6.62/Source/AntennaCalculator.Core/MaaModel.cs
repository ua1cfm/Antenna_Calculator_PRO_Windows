﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AntennaCalculator.Core;

/// <summary>Coordinates and radii in metres, exactly as stored in the .MAA record.</summary>
public sealed record MaaWire(int Number, double X1, double Y1, double Z1,
    double X2, double Y2, double Z2, double RadiusMetres, int Tag)
{
    public double LengthMetres => Math.Sqrt(Math.Pow(X2-X1,2)+Math.Pow(Y2-Y1,2)+Math.Pow(Z2-Z1,2));
    public bool HasTaperReference => RadiusMetres < 0;
}

public sealed record MaaSource(int WireNumber, char Position, int Offset, double PhaseDegrees,
    double RelativeVoltage, string Raw);

public sealed record MaaLoad(int WireNumber, char Position, int Offset, int Kind,
    double V1, double V2, double V3, string Raw);

public sealed class MaaModel
{
    public required string Title { get; init; }
    public required string FilePath { get; init; }
    public required double FrequencyMHz { get; init; }
    public required IReadOnlyList<MaaWire> Wires { get; init; }
    public required IReadOnlyList<MaaSource> Sources { get; init; }
    public required IReadOnlyList<MaaLoad> Loads { get; init; }
    public required IReadOnlyList<string> Warnings { get; init; }
    public int GroundType { get; init; }
    public double AddHeightMetres { get; init; }
    public int MaterialCode { get; init; }
    public double ReferenceOhms { get; init; } = 50;
    public string SegmentationRecord { get; init; } = "";
    public string WireHeaderRecord { get; init; } = "";
    public bool HasCompactStack { get; init; }
    public bool StackExpanded { get; init; }
    public int BaseWireCount { get; init; }
    public int StackHorizontal { get; init; } = 1;
    public int StackVertical { get; init; } = 1;
    public double StackHorizontalSpacingMetres { get; init; }
    public double StackVerticalSpacingMetres { get; init; }
    public int StackPlacementMode { get; init; }
    public bool HasUnexpandedTapers => Wires.Any(w => w.HasTaperReference);
    public double TotalWireLengthMetres => Wires.Sum(w => w.LengthMetres);
    public double WavelengthMetres => FrequencyMHz > 0 ? 299.792458 / FrequencyMHz : double.NaN;
    /// <summary>
    /// Offset from the MAA wire Z to the physical height used by the solvers: with ground (G ≠ 0) the antenna is
    /// raised by H (MMANA core HeightOff, MININEC UnfoldPec); in free space H is ignored. Views that draw wires
    /// together with solver data (field samples, ground plane) must add it.
    /// </summary>
    public double PhysicalZOffset => GroundType != 0 && double.IsFinite(AddHeightMetres) ? AddHeightMetres : 0;
}
