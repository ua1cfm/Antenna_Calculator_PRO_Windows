using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace AntennaCalculator.Core;

/// <summary>
/// Optional cuSOLVER backend for the MMANA impedance matrix (AntennaCudaLu64.dll + CUDA runtime DLLs next to
/// the program). The library is loaded once and keeps its cuSOLVER handle and device buffers until the process
/// exits. The matrix is sent once as an interleaved row-major array: row-major A is column-major Aᵀ, so it is
/// factored as is (Cgetrf) and solved with op = T (Cgetrs). The FP32 solution is refined in double precision
/// against the ORIGINAL MMANA matrix (mixed-precision iterative refinement) and accepted only if the final
/// normwise backward error is small; otherwise the caller uses the CPU LU.
/// </summary>
internal static class MmanaGpuLu
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FactorFn(int n,[In] float[] aInterleavedRowMajor);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int SolveFn(int n,[In] float[] bInterleaved,[Out] float[] xInterleaved);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void ReleaseFn();

    static readonly object Sync=new();
    static bool _loadTried;
    static string _loadMessage="";
    static FactorFn? _factor;
    static SolveFn? _solve;
    static ReleaseFn? _release;

    const int MinPulses=1024, MaxPulses=16000;
    const int MaxRefinementSteps=3;
    const double AcceptBackwardError=1e-6;   // after refinement (FP32 alone is ~1e-7…1e-5)

    static bool EnsureLoaded(out string message)
    {
        lock(Sync)
        {
            if(!_loadTried)
            {
                _loadTried=true;
                // ANTCALC_GPU_LU_DIR: folder with AntennaCudaLu64.dll + CUDA runtime (tests run outside the program folder).
                string dir=Environment.GetEnvironmentVariable("ANTCALC_GPU_LU_DIR") is { Length: >0 } d ? d : AppContext.BaseDirectory;
                string path=Path.Combine(dir,"AntennaCudaLu64.dll");
                if(!File.Exists(path)) _loadMessage="Optional AntennaCudaLu64.dll not installed";
                else if(!NativeLibrary.TryLoad(path,out var lib))
                    _loadMessage="AntennaCudaLu64.dll не загружена: нет библиотек CUDA рядом с программой (cusolver64_*.dll, cublas64_*.dll …) или драйвера NVIDIA";
                else if(!NativeLibrary.TryGetExport(lib,"antenna_cuda_lu_factor",out var f) ||
                        !NativeLibrary.TryGetExport(lib,"antenna_cuda_lu_solve_factored",out var s) ||
                        !NativeLibrary.TryGetExport(lib,"antenna_cuda_lu_release",out var r))
                    _loadMessage="AntennaCudaLu64.dll старой версии — пересоберите Cuda\\BUILD_CUDA_LU_WIN64.bat";
                else
                {
                    _factor=Marshal.GetDelegateForFunctionPointer<FactorFn>(f);
                    _solve=Marshal.GetDelegateForFunctionPointer<SolveFn>(s);
                    _release=Marshal.GetDelegateForFunctionPointer<ReleaseFn>(r);
                    // The library stays loaded; device memory is released once at exit.
                    AppDomain.CurrentDomain.ProcessExit+=(_,_)=>{ try{ lock(Sync) _release?.Invoke(); } catch{ } };
                    _loadMessage="";
                }
            }
            message=_loadMessage;
            return _factor!=null;
        }
    }

    /// <summary>True when the DLL and its CUDA libraries load (does not prove that a GPU solve succeeds).</summary>
    public static bool IsAvailable=>EnsureLoaded(out _);

    /// <summary>
    /// Solves A·x = b, A given by MMANA's 1-based arrays (element (i,j) at i*stride+j). Returns false (with a
    /// reason) when the GPU is not used; the caller then factors on the CPU.
    /// </summary>
    internal static bool TrySolve(int n,int stride,float[] ar,float[] ai,double[] br,double[] bi,CancellationToken ct,
        out double[] xr,out double[] xi,out string message)
    {
        xr=Array.Empty<double>(); xi=Array.Empty<double>();
        message="CUDA LU is not available";
        if(n<MinPulses || n>MaxPulses) return false;
        if(Environment.GetEnvironmentVariable("ANTCALC_GPU_LU")=="0"){ message="GPU LU disabled"; return false; }
        ct.ThrowIfCancellationRequested();
        if(!EnsureLoaded(out message)) return false;
        try
        {
            lock(Sync)      // one device context and one set of factors
            {
                // One interleaved copy of the matrix (re, im), row-major; freed right after the transfer.
                var a=new float[checked(2L*n*n)];
                Parallel.For(0,n,i=>
                {
                    int src=(i+1)*stride+1; long dst=2L*i*n;
                    for(int j=0;j<n;j++){ a[dst+2*j]=ar[src+j]; a[dst+2*j+1]=ai[src+j]; }
                });
                ct.ThrowIfCancellationRequested();
                int status=_factor!(n,a);
                a=null!;
                if(status!=0){ message="cuSOLVER getrf status="+status; return false; }
                ct.ThrowIfCancellationRequested();

                // Mixed-precision refinement: x ← x + A⁻¹(b − A·x), residual in double on the original matrix.
                var x=new double[2*n];
                var rRe=(double[])br.Clone(); var rIm=(double[])bi.Clone();
                var bf=new float[2*n]; var df=new float[2*n];
                double backward=double.PositiveInfinity; int steps=0;
                for(int step=0;step<=MaxRefinementSteps;step++)
                {
                    double rNorm=0;
                    for(int i=0;i<n;i++){ bf[2*i]=(float)rRe[i+1]; bf[2*i+1]=(float)rIm[i+1]; rNorm=Math.Max(rNorm,Math.Abs(rRe[i+1])+Math.Abs(rIm[i+1])); }
                    if(!(rNorm>0)) { backward=0; break; }
                    status=_solve!(n,bf,df);
                    if(status!=0){ message="cuSOLVER getrs status="+status; return false; }
                    for(int i=0;i<2*n;i++) x[i]+=df[i];
                    steps=step+1;
                    backward=Residual(n,stride,ar,ai,br,bi,x,rRe,rIm,ct);
                    if(!double.IsFinite(backward)) break;
                    if(backward<=1e-10) break;
                }
                if(!double.IsFinite(backward) || backward>AcceptBackwardError)
                {
                    message=$"GPU rejected: backward error {backward:G3} after {steps} solves";
                    return false;
                }
                xr=new double[n+1]; xi=new double[n+1];
                for(int i=0;i<n;i++){ xr[i+1]=x[2*i]; xi[i+1]=x[2*i+1]; }
                message=$"GPU cuSOLVER FP32 + refinement: backward error {backward:G3}, {steps} solves";
                return true;
            }
        }
        catch(OperationCanceledException){ throw; }
        catch(Exception e){ message="GPU fallback: "+e.GetType().Name+": "+e.Message; return false; }
    }

    /// <summary>r = b − A·x in double (rows in parallel); returns the normwise backward error ‖r‖/(‖A‖‖x‖+‖b‖).</summary>
    static double Residual(int n,int stride,float[] ar,float[] ai,double[] br,double[] bi,double[] x,double[] rRe,double[] rIm,CancellationToken ct)
    {
        var rowNorm=new double[n];
        Parallel.For(0,n,new ParallelOptions{ CancellationToken=ct },i=>
        {
            int k=(i+1)*stride+1; double yr=0, yi=0, norm=0;
            for(int j=0;j<n;j++)
            {
                double re=ar[k+j], im=ai[k+j], xre=x[2*j], xim=x[2*j+1];
                yr+=re*xre-im*xim; yi+=re*xim+im*xre; norm+=Math.Abs(re)+Math.Abs(im);
            }
            rRe[i+1]=br[i+1]-yr; rIm[i+1]=bi[i+1]-yi; rowNorm[i]=norm;
        });
        double aNorm=0,xNorm=0,bNorm=0,rMax=0;
        for(int i=0;i<n;i++)
        {
            aNorm=Math.Max(aNorm,rowNorm[i]);
            xNorm=Math.Max(xNorm,Math.Abs(x[2*i])+Math.Abs(x[2*i+1]));
            bNorm=Math.Max(bNorm,Math.Abs(br[i+1])+Math.Abs(bi[i+1]));
            rMax=Math.Max(rMax,Math.Abs(rRe[i+1])+Math.Abs(rIm[i+1]));
        }
        return rMax/Math.Max(1e-300,aNorm*xNorm+bNorm);
    }
}
