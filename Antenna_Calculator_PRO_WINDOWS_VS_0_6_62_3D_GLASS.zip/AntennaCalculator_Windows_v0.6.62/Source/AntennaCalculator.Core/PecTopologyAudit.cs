﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AntennaCalculator.Core;

/// <summary>Non-mutating PEC ground-node topology and load/source audit.
/// A diagnostic report is not a validation of Kirchhoff enforcement in the pulse matrix.</summary>
public static class PecTopologyAudit
{
    public static string Report(MaaModel m)
    {
        var sb=new StringBuilder();
        double wavelength=m.FrequencyMHz>0?299.8/m.FrequencyMHz:1;
        double tol=Math.Max(1e-8, wavelength*1e-8);
        var terminals=new List<(int Wire,char End,double X,double Y,double Z)>();
        foreach(var w in m.Wires)
        {
            terminals.Add((w.Number,'b',w.X1,w.Y1,w.Z1+m.AddHeightMetres));
            terminals.Add((w.Number,'e',w.X2,w.Y2,w.Z2+m.AddHeightMetres));
        }
        var groups=new List<List<(int Wire,char End,double X,double Y,double Z)>>();
        foreach(var t in terminals.Where(t=>Math.Abs(t.Z)<=tol))
        {
            var g=groups.FirstOrDefault(g=>Math.Abs(g[0].X-t.X)<=tol && Math.Abs(g[0].Y-t.Y)<=tol);
            if(g==null) {g=new();groups.Add(g);} g.Add(t);
        }
        sb.AppendLine($"PEC ground audit: G={m.GroundType}, f={m.FrequencyMHz:G8} MHz, ground terminal groups={groups.Count}");
        foreach(var g in groups)
        {
            sb.AppendLine($"Ground point ({g[0].X:G9}, {g[0].Y:G9}, 0): {g.Count} physical endpoints: "+
                string.Join(", ",g.Select(t=>$"W{t.Wire}{t.End}")));
            if(g.Count>1)sb.AppendLine($"  Mirror expansion yields {2*g.Count} endpoints at this location; root-star junction approximation requires KCL verification.");
        }
        foreach(var s in m.Sources)
            sb.AppendLine($"SOURCE W{s.WireNumber}{s.Position}{s.Offset:+#;-#;0}: V={s.RelativeVoltage:G9}, phase={s.PhaseDegrees:G9} deg");
        foreach(var l in m.Loads)
        {
            double omega=2*Math.PI*m.FrequencyMHz*1e6;
            double reactance=l.Kind==0&&l.V2>0&&l.V1<=0 ? -1/(omega*l.V2*1e-12) : double.NaN;
            sb.AppendLine($"LOAD W{l.WireNumber}{l.Position}{l.Offset:+#;-#;0}: kind={l.Kind}, L={l.V1:G9} uH, C={l.V2:G9} pF, Xc={reactance:G10} ohm");
        }
        if(m.GroundType!=1) sb.AppendLine("WARNING: model does not use PEC ground.");
        return sb.ToString();
    }
}
