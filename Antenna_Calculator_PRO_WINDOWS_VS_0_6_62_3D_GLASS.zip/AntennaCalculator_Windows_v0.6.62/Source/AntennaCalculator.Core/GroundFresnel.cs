﻿using System;
using System.Numerics;

namespace AntennaCalculator.Core;

/// <summary>
/// Exact TE/TM plane-wave Fresnel reflection at a planar, homogeneous lossy half-space.
/// Eps_r is relative permittivity and sigma in S/m. Incidence angle is measured
/// from the surface normal (zenith). This is NOT the Sommerfeld/Norton near-field
/// Green-function correction and is deliberately NOT applied to Zin or currents.
/// </summary>
public static class GroundFresnel
{
    public const double DefaultEpsR = 13.0;
    public const double DefaultSigma = 0.005;
    private const double Eps0 = 8.8541878128e-12;
    public sealed record Coefficients(Complex TE,Complex TM,Complex RelativePermittivity);

    public static Coefficients Calculate(double frequencyMHz,double epsR,double sigmaSM,double fromNormalDegrees)
    {
        if(!double.IsFinite(frequencyMHz)||frequencyMHz<=0 ||
           !double.IsFinite(epsR)||epsR<1 ||
           !double.IsFinite(sigmaSM)||sigmaSM<0 ||
           !double.IsFinite(fromNormalDegrees)||fromNormalDegrees<0||fromNormalDegrees>=90)
            throw new ArgumentOutOfRangeException(nameof(frequencyMHz),"Требуются f>0, εr>=1, σ>=0, 0<=угол<90 градусов.");
        double omega = 2*Math.PI*frequencyMHz*1e6;
        var eps=new Complex(epsR,-sigmaSM/(omega*Eps0));
        double c=Math.Cos(fromNormalDegrees*Math.PI/180),s=Math.Sin(fromNormalDegrees*Math.PI/180);
        Complex z=Complex.Sqrt(eps-s*s);
        var te=(new Complex(c,0)-z)/(new Complex(c,0)+z);
        var tm=(eps*c-z)/(eps*c+z);
        return new(te,tm,eps);
    }
}
