using System;
using System.Numerics;

namespace AntennaCalculator.Core;

/// <summary>
/// Spectral half-space reflection kernel for a lossy, nonmagnetic earth.
/// Phasor convention exp(+j omega t); epsilon_c=epsilon_r-j sigma/(omega epsilon_0).
/// This is one component of a Sommerfeld dyadic Green function, NOT a
/// complete wire-current matrix or an impedance correction.
/// </summary>
public static class GroundSpectral
{
    private const double C0=299792458.0;
    private const double Eps0=8.8541878128e-12;
    public sealed record Soil(double RelativePermittivity,double ConductivitySiemensPerMetre)
    {
        public void Validate()
        {
            if(!double.IsFinite(RelativePermittivity)||RelativePermittivity<1 ||
               !double.IsFinite(ConductivitySiemensPerMetre)||ConductivitySiemensPerMetre<0)
                throw new ArgumentOutOfRangeException(nameof(RelativePermittivity),"Soil requires eps_r >= 1 and sigma >= 0 S/m.");
        }
    }
    public readonly record struct Reflection(Complex Te,Complex Tm,Complex KzAir,Complex KzSoil);
    public static Complex RelativePermittivity(Soil soil,double frequencyMHz)
    {
        soil.Validate();
        if(!double.IsFinite(frequencyMHz)||frequencyMHz<=0)
            throw new ArgumentOutOfRangeException(nameof(frequencyMHz));
        double omega=2*Math.PI*frequencyMHz*1e6;
        return new Complex(soil.RelativePermittivity,-soil.ConductivitySiemensPerMetre/(omega*Eps0));
    }
    // Outgoing-wave vertical wavenumber: Im(k_z) <= 0 with exp(-j k_z z).
    private static Complex OutgoingRoot(Complex value)
    {
        Complex root=Complex.Sqrt(value);
        return root.Imaginary>0 ? -root : root;
    }
    /// <summary>
    /// Plane-wave spectral TE/TM reflection versus transverse wavenumber k_rho (1/m).
    /// In the Sommerfeld integral the spectral reflection MUST be integrated over
    /// all k_rho with the vector/scalar Green operators; using one angle as an
    /// image multiplier is not a physical substitute.
    /// </summary>
    public static Reflection AtTransverseWavenumber(double frequencyMHz,Soil soil,double kRhoPerMetre)
    {
        if(!double.IsFinite(kRhoPerMetre)||kRhoPerMetre<0)
            throw new ArgumentOutOfRangeException(nameof(kRhoPerMetre));
        Complex eps=RelativePermittivity(soil,frequencyMHz);
        double k0=2*Math.PI*frequencyMHz*1e6/C0;
        Complex kz0=OutgoingRoot(new Complex(k0*k0-kRhoPerMetre*kRhoPerMetre,0));
        Complex kz1=OutgoingRoot(eps*(k0*k0)-kRhoPerMetre*kRhoPerMetre);
        Complex te=(kz0-kz1)/(kz0+kz1);
        Complex tm=(eps*kz0-kz1)/(eps*kz0+kz1);
        return new Reflection(te,tm,kz0,kz1);
    }
}
