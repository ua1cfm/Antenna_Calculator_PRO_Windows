using System;
using System.Numerics;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace AntennaCalculator.Core;

// CUDA DLL is optional. No NVIDIA drivers or Toolkit are needed to run the CPU build.
internal sealed class CudaDenseMatVec : IDisposable
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate IntPtr Create(int n, double[] real, double[] imag);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int Multiply(IntPtr context, double[] input, int n, double[] output);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate void Destroy(IntPtr context);
    private readonly IntPtr module;
    private readonly IntPtr context;
    private readonly Multiply multiply;
    private readonly Destroy destroy;
    private readonly int n;
    private bool disposed;
    private CudaDenseMatVec(IntPtr module, IntPtr context, Multiply multiply, Destroy destroy, int n)
    { this.module=module;this.context=context;this.multiply=multiply;this.destroy=destroy;this.n=n; }

    public static CudaDenseMatVec? TryCreate(double[] ar,double[] ai,int n,out string status)
    {
        status="CUDA: native backend unavailable; CPU mode";
        if (!OperatingSystem.IsWindows() || n<1024)return null;
        // Search the executable folder and parent directories, not the Visual Studio working directory.
        string? path=null;
        var checkedPaths=new System.Collections.Generic.List<string>();
        void Candidate(string candidate)
        {
            checkedPaths.Add(candidate);
            if(path is null && File.Exists(candidate))path=candidate;
        }
        Candidate(Path.Combine(AppContext.BaseDirectory,"AntennaCuda64.dll"));
        DirectoryInfo? dir=new DirectoryInfo(AppContext.BaseDirectory);
        for(int depth=0;dir is not null && depth<9;depth++,dir=dir.Parent)
        {
            Candidate(Path.Combine(dir.FullName,"Cuda","bin","AntennaCuda64.dll"));
        }
        Candidate(Path.Combine(Environment.CurrentDirectory,"Cuda","bin","AntennaCuda64.dll"));
        if(path is null)
        {
            status="CUDA: DLL not found. Searched: "+string.Join(" | ",checkedPaths);
            return null;
        }
        IntPtr handle=IntPtr.Zero;
        IntPtr ctx=IntPtr.Zero;
        Destroy? destroy=null;
        try
        {
            if(!NativeLibrary.TryLoad(path,out handle)) {status="CUDA: DLL load failed: "+path+" (check CUDA runtime dependencies)"; return null;}
            var create=Marshal.GetDelegateForFunctionPointer<Create>(NativeLibrary.GetExport(handle,"antenna_cuda_create"));
            var multiply=Marshal.GetDelegateForFunctionPointer<Multiply>(NativeLibrary.GetExport(handle,"antenna_cuda_matvec"));
            destroy=Marshal.GetDelegateForFunctionPointer<Destroy>(NativeLibrary.GetExport(handle,"antenna_cuda_destroy"));
            ctx=create(n,ar,ai);
            if(ctx==IntPtr.Zero){status="CUDA: GPU init/upload failed: "+path; NativeLibrary.Free(handle); return null;}
            var backend=new CudaDenseMatVec(handle,ctx,multiply,destroy,n);
            status="CUDA: FP64 backend loaded: "+path;
            return backend;
        }
        catch(Exception e)
        {
            if(ctx!=IntPtr.Zero)try{destroy?.Invoke(ctx);}catch{}
            if(handle!=IntPtr.Zero)NativeLibrary.Free(handle);
            status="CUDA: "+e.GetType().Name+": "+e.Message+"; CPU mode";
            return null;
        }
    }

    public bool TryMultiply(Complex[] input,out Complex[] output)
    {
        output=Array.Empty<Complex>();
        if(disposed || input.Length!=n)return false;
        var src=new double[n*2]; var dst=new double[n*2];
        for(int i=0;i<n;i++){src[2*i]=input[i].Real;src[2*i+1]=input[i].Imaginary;}
        try
        {
            if(multiply(context,src,n,dst)!=1)return false;
            output=new Complex[n];
            for(int i=0;i<n;i++)
            {
                if(!double.IsFinite(dst[2*i])||!double.IsFinite(dst[2*i+1]))return false;
                output[i]=new Complex(dst[2*i],dst[2*i+1]);
            }
            return true;
        }
        catch{return false;}
    }

    public void Dispose()
    {
        if(disposed)return;
        disposed=true;
        try{destroy(context);}finally{NativeLibrary.Free(module);}
    }
}
