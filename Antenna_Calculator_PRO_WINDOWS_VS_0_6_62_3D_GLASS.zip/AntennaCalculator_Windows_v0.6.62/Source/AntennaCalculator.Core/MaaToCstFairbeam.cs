﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace AntennaCalculator.Core;

/// <summary>
/// C# port of UA1CFM's converter maa_to_cst2026.py, version 0.3.1-DUAL-EXPORT
/// (github.com/ua1cfm/MAA_to_CST_STUDIO_BAS_converter): parse_file (geometry part), emit (CST Studio
/// Suite 2026 .bas) and fairbeam_design (.design.json). Output text matches the Python converter run on
/// Windows: .bas UTF-8 with BOM, .design.json UTF-8 without BOM, CRLF line ends, numbers formatted like
/// Python ("{:.10g}" in the macro, repr() in JSON), JSON laid out like json.dumps(indent=2).
///
/// Extension: the Python converter refuses models with combined (stepped, negative-radius) wires.
/// Here such wires are split with MMANA's own CombWire (MmanaReferenceEngine.ExpandCombWires) when the
/// model has no stack; models without combined wires produce exactly the converter's output.
/// </summary>
public static class MaaToCstFairbeam
{
    public const string Version="0.3.1-DUAL-EXPORT";
    static readonly CultureInfo Inv=CultureInfo.InvariantCulture;

    public sealed class Wire
    {
        public double AX,AY,AZ,BX,BY,BZ,R; public int Seg; public double SignedRadius;
        public string Comment="";   // extension: comment for combined-wire pieces
    }
    public sealed class Model
    {
        public string Name="", Path=""; public double Freq;
        public List<Wire?> Wires=new();
        public int SourceCount, LoadCount;
        public List<string> Warnings=new();
        public int H=1, V=1, Placement; public double DH, DV;
        public bool HasCombinedWires;
        public int CombinedExpanded;            // extension: number of combined wires split by CombWire
    }

    // ------------------------------------------------------------ parse_file
    static string? Label(string line)
    {
        string raw=line.Trim().Trim('*').Trim().ToLowerInvariant().Replace(" ","").Replace(".","");
        if(raw is "wires" or "провода" or "проводники") return "wires";
        if(raw is "source" or "источ" or "источник" or "источники") return "source";
        if(raw is "load" or "нагрузка" or "нагрузки") return "load";
        return null;
    }
    static double PyFloat(string s)
    {
        s=s.Trim();
        if(!double.TryParse(s,NumberStyles.Float,Inv,out double v)) throw new FormatException($"could not convert string to float: '{s}'");
        return v;
    }

    public static Model Parse(string path,string text)
    {
        var lines=text.Replace("\r","\n").Split('\n').Select(l=>l.Trim()).Where(l=>l.Length>0).ToList();
        var headers=new Dictionary<string,int>();
        for(int i=0;i<lines.Count;i++){ var k=Label(lines[i]); if(k!=null && !headers.ContainsKey(k)) headers[k]=i; }
        if(!headers.ContainsKey("wires")) throw new FormatException("No recognized wires section (*Wires* / *Провода*)");
        int idx=headers["wires"];
        double freq;
        try { freq=PyFloat(lines[idx-1].Replace(',','.')); }
        catch { throw new FormatException("Invalid frequency before wires section"); }
        if(!double.IsFinite(freq) || !(freq>0 && freq<1e6)) throw new FormatException("Invalid frequency");
        var hf=lines[idx+1].Split(',').Select(v=>v.Trim()).ToArray();
        int n=(int)PyFloat(hf[0]);
        var m=new Model{ Path=path, Freq=freq };
        try
        {
            m.H=hf.Length>1?(int)PyFloat(hf[1]):1;
            m.V=hf.Length>2?(int)PyFloat(hf[2]):1;
            m.DH=hf.Length>3?PyFloat(hf[3]):0.0;
            m.DV=hf.Length>4?PyFloat(hf[4]):0.0;
            m.Placement=hf.Length>5?(int)PyFloat(hf[5]):0;
            if(!(1<=m.H && m.H<=8 && 1<=m.V && m.V<=8 && m.H*m.V<=64)) throw new FormatException("invalid MMANA stack copies");
            if(!double.IsFinite(m.DH) || !double.IsFinite(m.DV)) throw new FormatException("invalid stack spacing");
        }
        catch(Exception ex) when(ex is FormatException or IndexOutOfRangeException or OverflowException)
        {
            throw new FormatException("Invalid MAA stack wire header: "+ex.Message);
        }
        var wires=new List<Wire?>();
        for(int j=0;j<n;j++)
        {
            try
            {
                var x=lines[idx+2+j].Split(',').Select(v=>v.Trim()).ToArray();
                if(x.Length<8) throw new FormatException("too few columns");
                var vals=x.Take(7).Select(PyFloat).ToArray();
                int seg=(int)PyFloat(x[7]);
                if(!vals.All(double.IsFinite)) throw new FormatException("nonfinite coordinate or radius");
                double len=Math.Sqrt(Math.Pow(vals[3]-vals[0],2)+Math.Pow(vals[4]-vals[1],2)+Math.Pow(vals[5]-vals[2],2));
                if(len<1e-10) throw new FormatException("zero-length wire");
                if(Math.Abs(vals[6])<1e-12) throw new FormatException("zero radius — not substituted");
                if(vals[6]<0)
                {
                    m.HasCombinedWires=true;
                    string rg=vals[6].ToString("G6",Inv).Replace("E","e");
                    m.Warnings.Add($"Wire {j+1}: signed radius {rg} denotes combined/tapered wire; exact diameter profile NOT IMPLEMENTED, refuse inaccurate solid Wire");
                }
                wires.Add(new Wire{ AX=vals[0],AY=vals[1],AZ=vals[2],BX=vals[3],BY=vals[4],BZ=vals[5],R=Math.Abs(vals[6]),Seg=seg,SignedRadius=vals[6] });
            }
            catch(Exception ex)
            {
                m.Warnings.Add($"Wire {j+1}: NOT EXPORTED: {ex.Message}");
                wires.Add(null);
            }
        }
        m.SourceCount=RecordCount(lines,headers,"source",m.Warnings);
        m.LoadCount=RecordCount(lines,headers,"load",m.Warnings);
        if(m.H*m.V>1)
        {
            if(m.Placement!=0) m.Warnings.Add($"Stack placement mode {m.Placement}: assumed centered; verify against MMANA View");
            var expanded=new List<Wire?>();
            for(int vz=0;vz<m.V;vz++)
            for(int hy=0;hy<m.H;hy++)
            {
                double dy=(hy-(m.H-1)/2.0)*m.DH, dz=(vz-(m.V-1)/2.0)*m.DV;
                foreach(var w in wires)
                {
                    if(w==null){ expanded.Add(null); continue; }
                    expanded.Add(new Wire{ AX=w.AX,AY=w.AY+dy,AZ=w.AZ+dz,BX=w.BX,BY=w.BY+dy,BZ=w.BZ+dz,R=w.R,Seg=w.Seg,SignedRadius=w.SignedRadius });
                }
            }
            wires=expanded;
            m.SourceCount*=m.H*m.V; m.LoadCount*=m.H*m.V;
        }
        m.Wires=wires;
        m.Name=idx>2 ? lines[0] : System.IO.Path.GetFileNameWithoutExtension(path);
        return m;
    }
    static int RecordCount(List<string> lines,Dictionary<string,int> headers,string section,List<string> warnings)
    {
        if(!headers.TryGetValue(section,out int k)) return 0;
        int count;
        try { count=(int)PyFloat(lines[k+1].Split(',')[0].Trim()); }
        catch { warnings.Add($"{section}: invalid record count"); return 0; }
        int ok=0;
        for(int j=0;j<count;j++){ if(k+2+j<lines.Count) ok++; else warnings.Add($"{section} record {j+1}: list index out of range"); }
        return ok;
    }

    /// <summary>Extension: replace combined (stepped) wires by their MMANA CombWire pieces.</summary>
    public static void ExpandCombinedWires(Model m,string text)
    {
        if(!m.HasCombinedWires) return;
        if(m.H*m.V>1) throw new NotSupportedException("Combined (stepped) wires in a Make Stack model are not exported.");
        var em=MmanaReferenceEngine.Parse(text,galCompat:false);
        var pieces=MmanaReferenceEngine.ExpandCombWires(em);
        var result=new List<Wire?>();
        for(int i=0;i<m.Wires.Count;i++)
        {
            var w=m.Wires[i];
            if(w==null){ result.Add(null); continue; }
            if(w.SignedRadius>=0){ result.Add(w); continue; }
            var mine=pieces.Where(p=>p.Wire==i+1).ToList();
            if(mine.Count==0) throw new InvalidOperationException($"Wire {i+1}: combined-wire set not found.");
            for(int k=0;k<mine.Count;k++)
            {
                var p=mine[k];
                result.Add(new Wire{ AX=p.X1,AY=p.Y1,AZ=p.Z1,BX=p.X2,BY=p.Y2,BZ=p.Z2,R=p.Radius,Seg=w.Seg,SignedRadius=p.Radius,
                    Comment=$"MAA wire {i+1}, combined-wire piece {k+1}/{mine.Count} (MMANA CombWire)" });
            }
            m.CombinedExpanded++;
        }
        m.Wires=result;
        m.HasCombinedWires=false;
        m.Warnings.RemoveAll(s=>s.Contains("denotes combined/tapered wire"));
    }

    // ------------------------------------------------------------ number formatting like Python
    /// <summary>Python f"{v:.10g}".</summary>
    public static string PyG(double v)
    {
        if(double.IsNaN(v)) return "nan";
        if(double.IsInfinity(v)) return v>0?"inf":"-inf";
        return v.ToString("G10",Inv).Replace("E","e");
    }
    /// <summary>Python repr(float), as written by json.dumps.</summary>
    public static string PyRepr(double v)
    {
        if(double.IsNaN(v)) return "NaN";
        if(double.IsInfinity(v)) return v>0?"Infinity":"-Infinity";
        if(v==0) return double.IsNegative(v)?"-0.0":"0.0";
        string s=v.ToString("R",Inv);
        bool neg=s.StartsWith("-",StringComparison.Ordinal); if(neg) s=s.Substring(1);
        int exp10=0; string mant=s;
        int ei=s.IndexOfAny(new[]{'E','e'});
        if(ei>=0){ exp10=int.Parse(s.Substring(ei+1),NumberStyles.AllowLeadingSign,Inv); mant=s.Substring(0,ei); }
        int dot=mant.IndexOf('.');
        string intPart=dot>=0?mant.Substring(0,dot):mant, frac=dot>=0?mant.Substring(dot+1):"";
        string intTrim=intPart.TrimStart('0');
        int sciExp;
        if(intTrim.Length>0) sciExp=intTrim.Length-1+exp10;
        else { int z=0; while(z<frac.Length && frac[z]=='0') z++; sciExp=-(z+1)+exp10; }
        string digits=(intPart+frac).TrimStart('0').TrimEnd('0');
        if(digits.Length==0) digits="0";
        string body;
        if(sciExp< -4 || sciExp>=16)
        {
            body=digits.Length==1?digits:digits[0]+"."+digits.Substring(1);
            body+="e"+(sciExp<0?"-":"+")+Math.Abs(sciExp).ToString("00",Inv);
        }
        else if(sciExp>=0)
        {
            body=digits.Length<=sciExp+1 ? digits+new string('0',sciExp+1-digits.Length)+".0"
                                         : digits.Substring(0,sciExp+1)+"."+digits.Substring(sciExp+1);
        }
        else body="0."+new string('0',-sciExp-1)+digits;
        return (neg?"-":"")+body;
    }
    static double PyRound(double v,int digits)=>Math.Round(v,digits,MidpointRounding.ToEven);
    static string VQ(double x,double y,double z)=>"\""+PyG(x)+"\", \""+PyG(y)+"\", \""+PyG(z)+"\"";

    // ------------------------------------------------------------ emit (.bas)
    public static string EmitBas(Model model,double sweepPercent=5.0)
    {
        if(!double.IsFinite(sweepPercent) || !(sweepPercent>0 && sweepPercent<100)) throw new ArgumentException("Sweep percent must be > 0 and < 100");
        double center=model.Freq/1000.0;
        double fmin=center*(1-sweepPercent/100), fmax=center*(1+sweepPercent/100);
        if(model.HasCombinedWires) throw new InvalidOperationException("Exact geometry unavailable: MAA signed radii/combined stepped wires require profile reconstruction. Refusing inaccurate constant-radius export.");
        var L=new List<string>
        {
            "' MAA -> CST Studio Suite 2026 | UA1CFM | 2026",
            "' GEOMETRY ONLY; NO PORTS / NO LOADS / NO CUTS / NO ADJUSTMENTS",
            "' Generator version "+Version,
            "' Source: "+System.IO.Path.GetFileName(model.Path),
            "' MMANA frequency: "+PyG(model.Freq)+" MHz",
            "' Frequency sweep: "+PyG(fmin*1000)+" to "+PyG(fmax*1000)+" MHz",
            "' Original MAA wire endpoints are preserved (meters -> millimeters).",
            "' Manual CST mesh settings; existing project geometry is NOT deleted.",
            "Sub Main()",
            "    With Units",
            "        .Geometry \"mm\"",
            "        .Frequency \"GHz\"",
            "    End With",
            "    Solver.FrequencyRange \""+PyG(fmin)+"\", \""+PyG(fmax)+"\"",
            "",
            "    With FDSolver",
            "        .Reset",
            "        .SetMethod \"Surface\", \"General purpose\"",
            "        .OrderSrf \"First\"",
            "        .Stimulation \"All\", \"All\"",
            "        .SweepMinimumSamples \"10\"",
            "        .SetNumberOfResultDataSamples \"1001\"",
            "        .SetResultDataSamplingMode \"Automatic\"",
            "        .AddSampleInterval \""+PyG(fmin)+"\", \""+PyG(fmax)+"\", \"25\", \"Automatic\", \"False\"",
            "        .AddSampleInterval \""+PyG(center)+"\", \""+PyG(center)+"\", \"1\", \"Single\", \"False\"",
            "    End With",
            ""
        };
        for(int i=1;i<=model.Wires.Count;i++)
        {
            var w=model.Wires[i-1];
            if(w==null) continue;
            string name="W"+i.ToString("0000",Inv);
            L.Add(w.Comment.Length>0 ? $"    ' Wire {i}: {w.Comment}" : $"    ' Wire {i}: complete, unmodified MAA endpoints");
            L.AddRange(new[]{ "    With Polygon3D","        .Reset","        .Version 10",
                $"        .Name \"poly_{name}\"","        .Curve \"MAA_Curves\"",
                "        .Point "+VQ(w.AX*1000,w.AY*1000,w.AZ*1000),
                "        .Point "+VQ(w.BX*1000,w.BY*1000,w.BZ*1000),
                "        .Create","    End With","",
                "    With Wire","        .Reset",$"        .Name \"wire_{name}\"",
                "        .Folder \"MAA_Curves\"",
                "        .Radius \""+PyG(w.R*1000)+"\"",
                "        .Type \"CurveWire\"",$"        .Curve \"MAA_Curves:poly_{name}\"",
                "        .Material \"PEC\"","        .SolidWireModel \"False\"",
                "        .Termination \"Natural\"","        .Mitering \"NewMiter\"",
                "        .AdvancedChainSelection \"True\"","        .Add","    End With","" });
        }
        int count=model.Wires.Count(w=>w!=null);
        L.Add($"    MsgBox \"Created {count} complete Wire objects (geometry only). No ports, loads or cuts.\", vbInformation, \"MAA to CST Geometry Only\"");
        L.Add("End Sub");
        L.Add("");
        return string.Join("\r\n",L);
    }

    // ------------------------------------------------------------ fairbeam_design (.design.json)
    public static string FairbeamJson(Model model,string relative,double sweepPercent=5.0)
    {
        if(model.HasCombinedWires || model.Wires.Any(w=>w==null)) throw new InvalidOperationException("Incomplete geometry: Fairbeam file withheld rather than substituting wires");
        double f=model.Freq/1000;
        foreach(var w in model.Wires)
        {
            double r=PyRound(w!.R*1000,9);
            if(!(r>0)) throw new InvalidOperationException("Invalid wire geometry, Fairbeam export refused");
        }
        string id="maa_"+Convert.ToHexString(SHA1.HashData(Encoding.UTF8.GetBytes(relative))).ToLowerInvariant().Substring(0,12);
        var j=new JsonText();
        j.Open('{');
        j.Key("schema"); j.Str("fairbeam.design/1"); j.Comma();
        j.Key("model"); j.Open('{'); j.Key("id"); j.Str(id); j.Comma(); j.Key("name"); j.Str(model.Name); j.Close('}'); j.Comma();
        j.Key("params"); j.Raw("[]"); j.Comma();
        j.Key("simulation"); j.Open('{');
            j.Key("f_min"); j.Raw(PyRepr(PyRound(f*(1-sweepPercent/100),12))); j.Comma();
            j.Key("f_max"); j.Raw(PyRepr(PyRound(f*(1+sweepPercent/100),12))); j.Comma();
            j.Key("boundaries"); j.Str("MUR"); j.Comma();
            j.Key("end_criteria_db"); j.Raw("-40");
        j.Close('}'); j.Comma();
        j.Key("materials"); j.Open('['); j.Item(); j.Open('{'); j.Key("name"); j.Str("copper"); j.Comma(); j.Key("kind"); j.Str("metal"); j.Close('}'); j.Close(']'); j.Comma();
        j.Key("parts"); j.Open('['); j.Item(); j.Open('{');
            j.Key("name"); j.Str("antenna"); j.Comma();
            j.Key("material"); j.Str("copper"); j.Comma();
            j.Key("primitives"); j.Open('[');
            for(int i=0;i<model.Wires.Count;i++)
            {
                var w=model.Wires[i]!;
                if(i>0) j.Comma();
                j.Item(); j.Open('{');
                j.Key("kind"); j.Str("wire"); j.Comma();
                j.Key("points"); j.Open('[');
                    j.Item(); j.Open('['); j.Item(); j.Raw(PyRepr(PyRound(w.AX*1000,9))); j.Comma(); j.Item(); j.Raw(PyRepr(PyRound(w.AY*1000,9))); j.Comma(); j.Item(); j.Raw(PyRepr(PyRound(w.AZ*1000,9))); j.Close(']'); j.Comma();
                    j.Item(); j.Open('['); j.Item(); j.Raw(PyRepr(PyRound(w.BX*1000,9))); j.Comma(); j.Item(); j.Raw(PyRepr(PyRound(w.BY*1000,9))); j.Comma(); j.Item(); j.Raw(PyRepr(PyRound(w.BZ*1000,9))); j.Close(']');
                j.Close(']'); j.Comma();
                j.Key("radius"); j.Raw(PyRepr(PyRound(w.R*1000,9)));
                j.Close('}');
            }
            j.Close(']');
        j.Close('}'); j.Close(']'); j.Comma();
        j.Key("ports"); j.Raw("[]"); j.Comma();
        j.Key("resistors"); j.Raw("[]"); j.Comma();
        j.Key("mesh"); j.Open('{'); j.Key("mode"); j.Str("auto"); j.Comma(); j.Key("cells_per_wavelength"); j.Raw("20"); j.Close('}'); j.Comma();
        j.Key("far_field"); j.Open('{'); j.Key("enabled"); j.Raw("true"); j.Comma(); j.Key("frequencies"); j.Open('['); j.Item(); j.Raw(PyRepr(PyRound(f,12))); j.Close(']'); j.Close('}');
        j.Close('}');
        return j.ToString().Replace("\n","\r\n");
    }

    /// <summary>Minimal writer producing json.dumps(obj, ensure_ascii=False, indent=2) layout.</summary>
    sealed class JsonText
    {
        readonly StringBuilder sb=new(); int level;
        void NewLine(){ sb.Append('\n').Append(' ',2*level); }
        public void Open(char c){ sb.Append(c); level++; }
        public void Close(char c){ level--; NewLine(); sb.Append(c); }
        public void Item(){ NewLine(); }
        public void Key(string k){ NewLine(); Str(k); sb.Append(": "); }
        public void Comma(){ sb.Append(','); }
        public void Raw(string s){ sb.Append(s); }
        public void Str(string s)
        {
            sb.Append('"');
            foreach(char ch in s)
            {
                switch(ch)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    default:
                        if(ch<0x20) sb.Append("\\u").Append(((int)ch).ToString("x4",Inv));
                        else sb.Append(ch);
                        break;
                }
            }
            sb.Append('"');
        }
        public override string ToString()=>sb.ToString();
    }

    // ------------------------------------------------------------ one-file helpers
    /// <summary>Converter decoding order: UTF-8 (BOM allowed), Windows-1251, Latin-1.</summary>
    public static string Decode(byte[] data)
    {
        try { return new UTF8Encoding(false,true).GetString(data).TrimStart('\ufeff'); }
        catch(DecoderFallbackException) { }
        try { return Cp1251Strict.Value.GetString(data); }
        catch(DecoderFallbackException) { }
        return Encoding.Latin1.GetString(data);
    }
    static readonly Lazy<Encoding> Cp1251Strict=new(()=>
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        return Encoding.GetEncoding(1251,EncoderFallback.ExceptionFallback,DecoderFallback.ExceptionFallback);
    });

    public static (Model Model,string Text) Load(string path,bool expandCombined)
    {
        string text=Decode(File.ReadAllBytes(path));
        var m=Parse(path,text);
        if(expandCombined) ExpandCombinedWires(m,text);
        return (m,text);
    }
}
