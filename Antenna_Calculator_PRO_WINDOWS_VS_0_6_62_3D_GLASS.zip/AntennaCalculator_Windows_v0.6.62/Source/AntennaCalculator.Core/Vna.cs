using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.Json;

namespace AntennaCalculator.Core;

/// <summary>One frequency point of a VNA sweep: S11 and, when measured, S21 (complex, linear).</summary>
public readonly record struct VnaPoint(double FrequencyHz,Complex S11,Complex S21,bool HasS21);

/// <summary>A measured or loaded sweep.</summary>
public sealed class VnaSweep
{
    public List<VnaPoint> Points { get; init; }=new();
    public double ReferenceOhms { get; init; }=50.0;
    public bool Calibrated { get; init; }
    public bool HasS21=>Points.Count>0 && Points.All(p=>p.HasS21);
    public string Source { get; init; }="";
    public List<string> Comments { get; init; }=new();
    public DateTime Time { get; init; }=DateTime.Now;

    public static VnaSweep FromRaw(LiteVnaProtocol.SweepConfig config,IReadOnlyList<LiteVnaProtocol.RawValue> raw,string source)
    {
        var pts=new List<VnaPoint>(raw.Count);
        for(int i=0;i<raw.Count;i++)
        {
            var s11=raw[i].S11(); var s21=raw[i].S21();
            if(!double.IsFinite(s11.Real) || !double.IsFinite(s11.Imaginary)) throw new InvalidOperationException($"Нет опорного сигнала в точке {i}.");
            pts.Add(new VnaPoint(config.FrequencyHz(i),s11,s21,double.IsFinite(s21.Real)&&double.IsFinite(s21.Imaginary)));
        }
        return new VnaSweep{ Points=pts, Source=source, Comments={ "LiteVNA64 USB (SAA2 protocol), RAW wave ratios" } };
    }

    public bool SameGrid(VnaSweep other)
    {
        if(other.Points.Count!=Points.Count) return false;
        for(int i=0;i<Points.Count;i++)
        {
            double a=Points[i].FrequencyHz, b=other.Points[i].FrequencyHz;
            if(Math.Abs(a-b)>Math.Max(1.0,Math.Abs(a)*1e-10)) return false;
        }
        return true;
    }
}

/// <summary>Quantities derived from S-parameters, and marker searches.</summary>
public static class VnaMath
{
    public static Complex Impedance(Complex gamma,double z0)
    {
        var den=Complex.One-gamma;
        return den.Magnitude<1e-15 ? new Complex(double.PositiveInfinity,0) : z0*(Complex.One+gamma)/den;
    }
    public static double Swr(Complex gamma)
    {
        double g=gamma.Magnitude;
        return g<1 ? (1+g)/(1-g) : double.PositiveInfinity;
    }
    public static double ReturnLossDb(Complex gamma)=>-20*Math.Log10(Math.Max(1e-15,gamma.Magnitude));
    public static double Db(Complex s)=>20*Math.Log10(Math.Max(1e-15,s.Magnitude));
    public static double PhaseDeg(Complex s)=>Math.Atan2(s.Imaginary,s.Real)*180/Math.PI;
    /// <summary>Series equivalent at f: inductance (H) for X &gt; 0, capacitance (F) for X &lt; 0.</summary>
    public static (double Henry,double Farad) SeriesLC(Complex z,double frequencyHz)
    {
        double w=2*Math.PI*frequencyHz;
        if(!(w>0) || !double.IsFinite(z.Imaginary)) return (double.NaN,double.NaN);
        return z.Imaginary>=0 ? (z.Imaginary/w,double.NaN) : (double.NaN,-1/(w*z.Imaginary));
    }
    public static double Q(Complex z)=>z.Real>0 ? Math.Abs(z.Imaginary)/z.Real : double.PositiveInfinity;

    /// <summary>Group delay of S21 (s), central difference of the unwrapped phase.</summary>
    public static double GroupDelay(IReadOnlyList<VnaPoint> p,int i)
    {
        if(p.Count<3 || !p[i].HasS21) return double.NaN;
        int a=Math.Max(0,i-1), b=Math.Min(p.Count-1,i+1);
        double pa=Math.Atan2(p[a].S21.Imaginary,p[a].S21.Real), pb=Math.Atan2(p[b].S21.Imaginary,p[b].S21.Real);
        double d=pb-pa;
        while(d>Math.PI) d-=2*Math.PI;
        while(d< -Math.PI) d+=2*Math.PI;
        double dw=2*Math.PI*(p[b].FrequencyHz-p[a].FrequencyHz);
        return dw>0 ? -d/dw : double.NaN;
    }

    public static int IndexOfMinSwr(IReadOnlyList<VnaPoint> p)
    {
        int best=-1; double v=double.PositiveInfinity;
        for(int i=0;i<p.Count;i++){ double s=p[i].S11.Magnitude; if(s<v){ v=s; best=i; } }
        return best;
    }
    public static int IndexOfMaxS21(IReadOnlyList<VnaPoint> p)
    {
        int best=-1; double v=double.NegativeInfinity;
        for(int i=0;i<p.Count;i++) if(p[i].HasS21){ double s=p[i].S21.Magnitude; if(s>v){ v=s; best=i; } }
        return best;
    }
    public static int IndexOfMinS21(IReadOnlyList<VnaPoint> p)
    {
        int best=-1; double v=double.PositiveInfinity;
        for(int i=0;i<p.Count;i++) if(p[i].HasS21){ double s=p[i].S21.Magnitude; if(s<v){ v=s; best=i; } }
        return best;
    }
    /// <summary>Series resonances: points where X changes sign; the point with the smaller |X| is returned.</summary>
    public static List<int> Resonances(IReadOnlyList<VnaPoint> p,double z0)
    {
        var list=new List<int>();
        for(int i=1;i<p.Count;i++)
        {
            double x0=Impedance(p[i-1].S11,z0).Imaginary, x1=Impedance(p[i].S11,z0).Imaginary;
            if(double.IsFinite(x0) && double.IsFinite(x1) && Math.Sign(x0)!=Math.Sign(x1) && x0!=0)
                list.Add(Math.Abs(x0)<Math.Abs(x1)?i-1:i);
        }
        return list;
    }
    /// <summary>Band around <paramref name="center"/> where SWR ≤ limit, with linear interpolation of the edges (Hz).</summary>
    public static (double LowHz,double HighHz)? SwrBand(IReadOnlyList<VnaPoint> p,int center,double limit)
    {
        if(center<0 || center>=p.Count || Swr(p[center].S11)>limit) return null;
        int lo=center, hi=center;
        while(lo>0 && Swr(p[lo-1].S11)<=limit) lo--;
        while(hi<p.Count-1 && Swr(p[hi+1].S11)<=limit) hi++;
        double Edge(int inside,int outside)
        {
            if(outside<0 || outside>=p.Count) return p[inside].FrequencyHz;
            double si=Swr(p[inside].S11), so=Swr(p[outside].S11);
            if(!double.IsFinite(so) || so==si) return p[inside].FrequencyHz;
            double t=(limit-si)/(so-si);
            return p[inside].FrequencyHz+t*(p[outside].FrequencyHz-p[inside].FrequencyHz);
        }
        return (Edge(lo,lo-1),Edge(hi,hi+1));
    }
    public static int NearestIndex(IReadOnlyList<VnaPoint> p,double frequencyHz)
    {
        int best=-1; double d=double.PositiveInfinity;
        for(int i=0;i<p.Count;i++){ double e=Math.Abs(p[i].FrequencyHz-frequencyHz); if(e<d){ d=e; best=i; } }
        return best;
    }
}

/// <summary>Six one-path error terms at one frequency (forward direction of the 12-term model).</summary>
public readonly record struct VnaErrorTerms(double FrequencyHz,Complex Ed,Complex Es,Complex Er,Complex Ex,Complex Et,Complex El);

/// <summary>
/// Full calibration of RAW LiteVNA data (the only mode): one-path two-port "enhanced response".
/// Standards: OPEN, SHORT, LOAD on port 1 (ideal Γ = +1, −1, 0) — LOAD is measured with 50 Ω loads on BOTH
/// ports, which also gives the isolation Ex — and THRU (port 1 to port 2), which gives the port-2 match El and
/// the transmission tracking Et = (S21thru − Ex)·(1 − Es·El).
/// Correction: S11 = q / (Er + Es·q), q = S11m − Ed;  S21 = (S21m − Ex) / Et · (1 − Es·S11).
/// Exact for one-port loads and for two-ports with S12 = 0; for reciprocal two-ports with a mismatched output
/// the residual error is that of any one-path analyzer (no reverse measurement).
/// Optional port extension (one-way delay, ps) moves the reference plane to the end of a cable.
/// The calibration is applied on exactly the same frequency grid or, if allowed, by interpolating the error
/// terms when the sweep lies inside the calibrated range.
/// </summary>
public sealed class VnaCalibration
{
    public const string Format="antcalc-litevna-cal/2";
    VnaSweep? _open,_short,_load,_thru;
    VnaErrorTerms[]? _terms;
    public VnaSweep? Open { get=>_open; set{ _open=value; _terms=null; } }
    public VnaSweep? Short { get=>_short; set{ _short=value; _terms=null; } }
    public VnaSweep? Load { get=>_load; set{ _load=value; _terms=null; } }
    public VnaSweep? Thru { get=>_thru; set{ _thru=value; _terms=null; } }
    public string Name { get; set; }="";
    public string Comment { get; set; }="";
    public string Device { get; set; }="";
    public DateTime Created { get; set; }=DateTime.Now;
    /// <summary>One-way electrical delay of a cable/adapter after the calibration plane, ps (0 = none).</summary>
    public double PortExtensionPs { get; set; }
    public long StartHz { get; set; }
    public long StopHz { get; set; }
    public int Points { get; set; }
    public int Average { get; set; }=1;

    public VnaSweep? Reference=>_open ?? _short ?? _load ?? _thru;
    public int StandardsTaken=>new[]{ _open,_short,_load,_thru }.Count(x=>x!=null);
    /// <summary>All four standards on one frequency grid.</summary>
    public bool IsComplete=>_open!=null && _short!=null && _load!=null && _thru!=null
                            && _open.SameGrid(_short) && _open.SameGrid(_load) && _open.SameGrid(_thru) && _load.HasS21 && _thru.HasS21;
    public bool StandardsOnDifferentGrids
    {
        get
        {
            var list=new[]{ _open,_short,_load,_thru }.Where(x=>x!=null).ToList();
            return list.Count>1 && list.Skip(1).Any(x=>!list[0]!.SameGrid(x!));
        }
    }
    public void Clear(){ Open=Short=Load=Thru=null; Name=""; Comment=""; PortExtensionPs=0; Created=DateTime.Now; }
    public bool MatchesGrid(VnaSweep raw)=>IsComplete && raw.SameGrid(_open!);
    public bool Covers(VnaSweep raw)
    {
        if(!IsComplete || raw.Points.Count==0) return false;
        double lo=_open!.Points[0].FrequencyHz, hi=_open.Points[^1].FrequencyHz;
        return raw.Points[0].FrequencyHz>=lo-1e-6 && raw.Points[^1].FrequencyHz<=hi+1e-6;
    }
    public double AgeDays=>(DateTime.Now-Created).TotalDays;

    public VnaErrorTerms[] Terms()
    {
        if(_terms!=null) return _terms;
        if(!IsComplete) throw new InvalidOperationException("Калибровка неполная: нужны OPEN, SHORT, LOAD и THRU на одной сетке частот.");
        var t=new VnaErrorTerms[_open!.Points.Count];
        for(int i=0;i<t.Length;i++)
            t[i]=ComputeTerms(_open.Points[i].FrequencyHz,_open.Points[i].S11,_short!.Points[i].S11,_load!.Points[i].S11,
                              _load.Points[i].S21,_thru!.Points[i].S11,_thru.Points[i].S21);
        return _terms=t;
    }

    public static VnaErrorTerms ComputeTerms(double f,Complex mOpen,Complex mShort,Complex mLoad,Complex mIsolation,Complex mThru11,Complex mThru21)
    {
        var ed=mLoad; var a=mOpen-ed; var b=mShort-ed; var den=a-b;
        var es=den.Magnitude>1e-15 ? (a+b)/den : Complex.Zero;
        var er=a*(Complex.One-es);
        var ex=double.IsFinite(mIsolation.Real) ? mIsolation : Complex.Zero;
        var q=mThru11-ed; var d2=er+es*q;
        var el=d2.Magnitude>1e-15 ? q/d2 : Complex.Zero;
        var et=(mThru21-ex)*(Complex.One-es*el);
        return new VnaErrorTerms(f,ed,es,er,ex,et,el);
    }

    /// <summary>OSL correction of S11 with ideal standards (three-term part).</summary>
    public static Complex CorrectS11(Complex m,Complex mOpen,Complex mShort,Complex ed)
    {
        var t=ComputeTerms(0,mOpen,mShort,ed,Complex.Zero,ed,Complex.One);
        return CorrectS11(m,t);
    }
    static Complex CorrectS11(Complex m,VnaErrorTerms t)
    {
        var q=m-t.Ed; var den=t.Er+t.Es*q;
        return den.Magnitude>1e-15 ? q/den : m;
    }
    public static (Complex S11,Complex S21) Correct(Complex m11,Complex m21,VnaErrorTerms t,bool hasS21)
    {
        var s11=CorrectS11(m11,t);
        var s21=hasS21 && t.Et.Magnitude>1e-15 ? (m21-t.Ex)/t.Et*(Complex.One-t.Es*s11) : m21;
        return (s11,s21);
    }

    /// <summary>Error terms at frequency f by linear interpolation (real and imaginary parts).</summary>
    public static VnaErrorTerms Interpolate(VnaErrorTerms[] t,double f)
    {
        if(f<=t[0].FrequencyHz) return t[0] with { FrequencyHz=f };
        if(f>=t[^1].FrequencyHz) return t[^1] with { FrequencyHz=f };
        int lo=0, hi=t.Length-1;
        while(hi-lo>1){ int mid=(lo+hi)/2; if(t[mid].FrequencyHz<=f) lo=mid; else hi=mid; }
        double u=(f-t[lo].FrequencyHz)/(t[hi].FrequencyHz-t[lo].FrequencyHz);
        Complex L(Complex a,Complex b)=>a+(b-a)*u;
        return new VnaErrorTerms(f,L(t[lo].Ed,t[hi].Ed),L(t[lo].Es,t[hi].Es),L(t[lo].Er,t[hi].Er),L(t[lo].Ex,t[hi].Ex),L(t[lo].Et,t[hi].Et),L(t[lo].El,t[hi].El));
    }

    public enum ApplyMode { None, Exact, Interpolated }

    /// <summary>Applies the calibration: exact grid, or interpolated (if allowed and the sweep is inside the range).</summary>
    public VnaSweep Apply(VnaSweep raw,bool allowInterpolation,out ApplyMode mode)
    {
        mode=ApplyMode.None;
        if(!IsComplete) return raw;
        var terms=Terms();
        bool exact=raw.SameGrid(_open!);
        if(!exact && !(allowInterpolation && Covers(raw))) return raw;
        mode=exact?ApplyMode.Exact:ApplyMode.Interpolated;
        double tau=PortExtensionPs*1e-12;
        var pts=new List<VnaPoint>(raw.Points.Count);
        for(int i=0;i<raw.Points.Count;i++)
        {
            var p=raw.Points[i];
            var t=exact ? terms[i] : Interpolate(terms,p.FrequencyHz);
            var (s11,s21)=Correct(p.S11,p.S21,t,p.HasS21);
            if(tau!=0)
            {
                double w=2*Math.PI*p.FrequencyHz;
                s11*=Complex.FromPolarCoordinates(1,2*w*tau);
                s21*=Complex.FromPolarCoordinates(1,w*tau);
            }
            pts.Add(p with { S11=s11, S21=s21 });
        }
        var comments=new List<string>(raw.Comments)
        {
            $"Calibration: full one-path (OSL + isolation + THRU, enhanced response){(mode==ApplyMode.Interpolated?", interpolated":"")}"+
            (Name.Length>0?$", profile \"{Name}\"":"")+(PortExtensionPs!=0?$", port extension {PortExtensionPs:0.###} ps":"")
        };
        return new VnaSweep{ Points=pts, ReferenceOhms=raw.ReferenceOhms, Calibrated=true, Source=raw.Source, Comments=comments, Time=raw.Time };
    }

    // ---- files (format v2; v1 files of version 0.5.0 are read too)
    sealed record Dto(double[] F,double[] Re,double[] Im,double[] Re21,double[] Im21);
    sealed record FileDto(string Format,DateTime Saved,Dto? Open,Dto? Short,Dto? Load,Dto? Thru,
        string? Name=null,string? Comment=null,string? Device=null,DateTime? Created=null,double PortExtensionPs=0,
        long StartHz=0,long StopHz=0,int Points=0,int Average=1);
    static readonly JsonSerializerOptions Json=new(){ WriteIndented=false, NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals };
    static Dto? ToDto(VnaSweep? s)=>s==null ? null : new Dto(
        s.Points.Select(p=>p.FrequencyHz).ToArray(),s.Points.Select(p=>p.S11.Real).ToArray(),s.Points.Select(p=>p.S11.Imaginary).ToArray(),
        s.Points.Select(p=>p.S21.Real).ToArray(),s.Points.Select(p=>p.S21.Imaginary).ToArray());
    static VnaSweep? FromDto(Dto? d,string name)
    {
        if(d==null) return null;
        var pts=new List<VnaPoint>(d.F.Length);
        for(int i=0;i<d.F.Length;i++)
        {
            var s21=new Complex(d.Re21[i],d.Im21[i]);
            pts.Add(new VnaPoint(d.F[i],new Complex(d.Re[i],d.Im[i]),s21,double.IsFinite(s21.Real)&&double.IsFinite(s21.Imaginary)));
        }
        return new VnaSweep{ Points=pts, Source=name };
    }
    public void Save(string path)
    {
        var dto=new FileDto(Format,DateTime.Now,ToDto(Open),ToDto(Short),ToDto(Load),ToDto(Thru),
            Name,Comment,Device,Created,PortExtensionPs,StartHz,StopHz,Points,Average);
        File.WriteAllText(path,JsonSerializer.Serialize(dto,Json),new UTF8Encoding(false));
    }
    public static VnaCalibration LoadFile(string path)
    {
        var dto=JsonSerializer.Deserialize<FileDto>(File.ReadAllText(path),Json) ?? throw new InvalidDataException("Пустой файл калибровки.");
        if(dto.Format!=Format && dto.Format!="antcalc-litevna-cal/1") throw new InvalidDataException("Неизвестный формат файла калибровки.");
        var cal=new VnaCalibration
        {
            Open=FromDto(dto.Open,"OPEN"), Short=FromDto(dto.Short,"SHORT"), Load=FromDto(dto.Load,"LOAD"), Thru=FromDto(dto.Thru,"THRU"),
            Name=string.IsNullOrWhiteSpace(dto.Name) ? Path.GetFileNameWithoutExtension(path) : dto.Name!,
            Comment=dto.Comment ?? "", Device=dto.Device ?? "", Created=dto.Created ?? dto.Saved, PortExtensionPs=dto.PortExtensionPs,
            Average=Math.Max(1,dto.Average)
        };
        var r=cal.Reference;
        if(r is {Points.Count: >1})
        {
            cal.StartHz=dto.StartHz>0 ? dto.StartHz : (long)Math.Round(r.Points[0].FrequencyHz);
            cal.StopHz=dto.StopHz>0 ? dto.StopHz : (long)Math.Round(r.Points[^1].FrequencyHz);
            cal.Points=dto.Points>0 ? dto.Points : r.Points.Count;
        }
        return cal;
    }
}

/// <summary>Touchstone 1.x writer (.s1p, .s2p) and reader (S-parameters; RI, MA, DB; Hz…GHz).</summary>
public static class TouchstoneFile
{
    static readonly CultureInfo Inv=CultureInfo.InvariantCulture;
    static string Ascii(string s)=>new string(s.Select(c=>c>=32 && c<127 ? c : '?').ToArray());
    static string N(double v)=>v.ToString("G12",Inv);

    public static string WriteS1p(VnaSweep s,IEnumerable<string> header)
    {
        var sb=new StringBuilder();
        foreach(var h in header) sb.Append("! ").Append(Ascii(h)).Append("\r\n");
        foreach(var c in s.Comments) sb.Append("! ").Append(Ascii(c)).Append("\r\n");
        sb.Append("! ").Append(s.Calibrated?"calibrated":"RAW (not calibrated)").Append("\r\n");
        sb.Append("# HZ S RI R ").Append(s.ReferenceOhms.ToString("0.######",Inv)).Append("\r\n");
        foreach(var p in s.Points)
            sb.Append(p.FrequencyHz.ToString("0.###",Inv)).Append(' ').Append(N(p.S11.Real)).Append(' ').Append(N(p.S11.Imaginary)).Append("\r\n");
        return sb.ToString();
    }

    /// <summary>S11 and S21 measured; LiteVNA has no reverse path, S12 and S22 are written as 0 (stated in the header).</summary>
    public static string WriteS2p(VnaSweep s,IEnumerable<string> header)
    {
        if(!s.HasS21) throw new InvalidOperationException("В развёртке нет S21 — сохраните .s1p.");
        var sb=new StringBuilder();
        foreach(var h in header) sb.Append("! ").Append(Ascii(h)).Append("\r\n");
        foreach(var c in s.Comments) sb.Append("! ").Append(Ascii(c)).Append("\r\n");
        sb.Append("! ").Append(s.Calibrated?"calibrated":"RAW (not calibrated)").Append("\r\n");
        sb.Append("! S12 and S22 are not measured by LiteVNA (one-path); written as 0\r\n");
        sb.Append("# HZ S RI R ").Append(s.ReferenceOhms.ToString("0.######",Inv)).Append("\r\n");
        foreach(var p in s.Points)
            sb.Append(p.FrequencyHz.ToString("0.###",Inv))
              .Append(' ').Append(N(p.S11.Real)).Append(' ').Append(N(p.S11.Imaginary))
              .Append(' ').Append(N(p.S21.Real)).Append(' ').Append(N(p.S21.Imaginary))
              .Append(" 0 0 0 0\r\n");
        return sb.ToString();
    }

    /// <summary>Reads a 1-port or 2-port Touchstone 1.x file (S parameters only).</summary>
    public static VnaSweep Read(string path)
    {
        double scale=1e9; string format="MA"; double z0=50; bool sParams=true;
        var values=new List<double>();
        var comments=new List<string>();
        foreach(var raw in File.ReadAllLines(path))
        {
            string line=raw;
            int bang=line.IndexOf('!');
            if(bang>=0){ var c=line.Substring(bang+1).Trim(); if(c.Length>0) comments.Add(c); line=line.Substring(0,bang); }
            line=line.Trim();
            if(line.Length==0) continue;
            if(line.StartsWith("#",StringComparison.Ordinal))
            {
                var t=line.Substring(1).Split((char[]?)null,StringSplitOptions.RemoveEmptyEntries).Select(x=>x.ToUpperInvariant()).ToArray();
                for(int i=0;i<t.Length;i++)
                {
                    switch(t[i])
                    {
                        case "HZ": scale=1; break;
                        case "KHZ": scale=1e3; break;
                        case "MHZ": scale=1e6; break;
                        case "GHZ": scale=1e9; break;
                        case "S": sParams=true; break;
                        case "Y": case "Z": case "H": case "G": sParams=false; break;
                        case "RI": case "MA": case "DB": format=t[i]; break;
                        case "R": if(i+1<t.Length && double.TryParse(t[i+1],NumberStyles.Float,Inv,out var r)){ z0=r; i++; } break;
                    }
                }
                continue;
            }
            if(line.StartsWith("[",StringComparison.Ordinal)) throw new InvalidDataException("Touchstone 2.0 не поддерживается.");
            foreach(var tok in line.Split((char[]?)null,StringSplitOptions.RemoveEmptyEntries))
                values.Add(double.Parse(tok,NumberStyles.Float,Inv));
        }
        if(!sParams) throw new InvalidDataException("Поддерживаются только S-параметры.");
        bool twoPort=path.EndsWith(".s2p",StringComparison.OrdinalIgnoreCase);
        int perRow=twoPort?9:3;
        if(values.Count%perRow!=0) throw new InvalidDataException("Число значений не соответствует формату файла.");
        Complex C(double a,double b)=>format switch
        {
            "RI" => new Complex(a,b),
            "MA" => Complex.FromPolarCoordinates(a,b*Math.PI/180),
            _ => Complex.FromPolarCoordinates(Math.Pow(10,a/20),b*Math.PI/180)
        };
        var pts=new List<VnaPoint>();
        for(int k=0;k<values.Count;k+=perRow)
        {
            double f=values[k]*scale;
            var s11=C(values[k+1],values[k+2]);
            if(twoPort) pts.Add(new VnaPoint(f,s11,C(values[k+3],values[k+4]),true));
            else pts.Add(new VnaPoint(f,s11,new Complex(double.NaN,double.NaN),false));
        }
        return new VnaSweep{ Points=pts, ReferenceOhms=z0, Calibrated=true, Source=Path.GetFileName(path), Comments=comments };
    }
}
