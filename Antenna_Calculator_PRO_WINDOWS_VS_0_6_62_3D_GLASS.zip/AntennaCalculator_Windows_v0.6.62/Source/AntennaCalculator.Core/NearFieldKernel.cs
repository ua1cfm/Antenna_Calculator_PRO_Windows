using System;
using System.Numerics;

namespace AntennaCalculator.Core;

/// <summary>
/// Near field (E, H) of the thin-wire current elements used by the 2D map, the 3D volume (CPU) and — with the same
/// formulas — the CUDA field kernel. Terms 1/r, 1/r², 1/r³ of an elementary segment (e^{+jωt}, e^{−jkr}).
///
/// Ground: field samples hold the physical pulses (z ≥ 0) and, for G = 1/2, their PEC images (z &lt; 0, moment
/// (−Dx, −Dy, +Dz)). For G = 1 the images are used as they are. For G = 2 every image is weighted by the SAME
/// ground-reflection operator as the 3D radiation pattern (RadiationField: MININEC v89/h89, Fresnel coefficients of
/// the ground εr, σ) for the direction from the image point to the observation point. In the far zone this is
/// identical to the 3D pattern; in the near zone it is the usual reflection-coefficient approximation (not a
/// Sommerfeld solution). Below ground (z &lt; 0) the image construction is not valid: callers must not display it.
/// </summary>
public static class NearFieldKernel
{
    public const double Eta0 = 376.730313668;

    /// <summary>Complex relative permittivity of the ground: εr − j·σ/(ωε0).</summary>
    public static Complex GroundPermittivity(double frequencyMHz, double epsR, double sigma)
        => new(epsR, -sigma / (2 * Math.PI * frequencyMHz * 1e6 * 8.8541878128e-12));

    /// <summary>MININEC v89 / h89 for the unit direction n (as in RadiationField.Direction). PEC: v89 = 1, h89 = 0.</summary>
    public static (Complex V89, Complex H89) Reflection(Complex er, double nx, double ny, double nz)
    {
        double rho = Math.Sqrt(nx * nx + ny * ny), ct = Math.Clamp(nz, 0, 1);
        Complex z45 = Complex.One / Complex.Sqrt(er);
        Complex w67 = Complex.Sqrt(Complex.One - z45 * z45 * rho * rho);
        Complex v89 = (ct - w67 * z45) / (ct + w67 * z45);
        Complex h89 = (w67 - z45 * ct) / (w67 + z45 * ct) - v89;
        return (v89, h89);
    }

    /// <summary>
    /// Adds the field of one sample at (x, y, z). groundType 2: image samples (z &lt; 0, not grounded pulses) are
    /// weighted with the reflection operator of <paramref name="er"/>. Returns true when the sample was an image.
    /// </summary>
    public static bool Add(MininecPulseSolver.FieldSample a, double x, double y, double z, double k, double wavelength,
        int groundType, Complex er,
        ref Complex ex, ref Complex ey, ref Complex ez, ref Complex hx, ref Complex hy, ref Complex hz)
    {
        Complex current = new(a.RealCurrent, a.ImagCurrent);
        double rx = x - a.X, ry = y - a.Y, rz = z - a.Z;
        double dist = Math.Sqrt(rx * rx + ry * ry + rz * rz);
        bool image = groundType != 0 && a.Z < -1e-9;
        Complex mx, my, mz;
        if (image && groundType == 2 && !a.GroundPulse && dist > 0)
        {
            // The physical moment of the PEC image (−Dx, −Dy, +Dz) is (Dx, Dy, Dz) = (−a.Dx, −a.Dy, a.Dz).
            double dxr = -a.Dx, dyr = -a.Dy, dzr = a.Dz;
            double nx = rx / dist, ny = ry / dist, nz = rz / dist;
            var (v89, h89) = Reflection(er, nx, ny, nz);
            double phi = Math.Atan2(ny, nx), px = -Math.Sin(phi), py = Math.Cos(phi);
            double d = px * dxr + py * dyr;
            mx = -current * (v89 * dxr + h89 * d * px);
            my = -current * (v89 * dyr + h89 * d * py);
            mz = current * v89 * dzr;
        }
        else { mx = current * a.Dx; my = current * a.Dy; mz = current * a.Dz; }

        double seg = Math.Sqrt(a.Dx * a.Dx + a.Dy * a.Dy + a.Dz * a.Dz);
        double r = Math.Max(dist, Math.Max(1e-6 * wavelength, 0.25 * seg));
        double ux = rx / r, uy = ry / r, uz = rz / r;
        Complex um = ux * mx + uy * my + uz * mz;
        Complex q = Complex.One / (Complex.ImaginaryOne * k * r);
        Complex fTrans = Complex.One + q + q * q, fRad = 2 * (q + q * q);
        Complex g = Complex.Exp(-Complex.ImaginaryOne * k * r) / (4 * Math.PI * r);
        Complex eFactor = -Complex.ImaginaryOne * Eta0 * k * g;
        ex += eFactor * ((mx - ux * um) * fTrans + ux * um * fRad);
        ey += eFactor * ((my - uy * um) * fTrans + uy * um * fRad);
        ez += eFactor * ((mz - uz * um) * fTrans + uz * um * fRad);
        Complex hFactor = -Complex.ImaginaryOne * k * g * (Complex.One + q);
        hx += hFactor * (uy * mz - uz * my);
        hy += hFactor * (uz * mx - ux * mz);
        hz += hFactor * (ux * my - uy * mx);
        return image;
    }
}
