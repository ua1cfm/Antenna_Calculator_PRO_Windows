﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AntennaCalculator.Core;

/// <summary>
/// Conservative .MAA geometry and metadata reader. No electromagnetic solutions are calculated.
/// MMANA Make Stack arrays are expanded for display; signed radii are preserved, never approximated.
/// </summary>
public static class MaaParser
{
    private static readonly CultureInfo Invariant = CultureInfo.InvariantCulture;
    private static readonly Regex Pulse = new(@"^w\s*(\d+)\s*([bceс])\s*([+-]?\d+)?", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public static MaaModel ParseFile(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("Не выбран файл MAA.");
        var bytes = File.ReadAllBytes(path);
        var contents = DecodeMaa(bytes);
        return Parse(contents, Path.GetFullPath(path));
    }

    public static MaaModel Parse(string contents, string path = "<memory>")
    {
        string[] lines = contents.Replace("\r\n", "\n").Replace('\r','\n').Split('\n');
        var warnings = new List<string>();
        if (lines.Length < 5) throw new FormatException("Файл слишком короткий для MMANA .MAA.");

        int wireHeader = Array.FindIndex(lines, s => IsNamedSection(s, "wires"));
        if (wireHeader < 0) throw new FormatException("Секция проводников MMANA (* Провода * / ***Wires***) не найдена.");
        string title = lines[0].Trim();
        if (title.Length == 0 || title.StartsWith('*') || TryNumber(title, out _))
            title = path == "<memory>" ? "MMANA antenna" : Path.GetFileNameWithoutExtension(path);
        double frequency = 0;
        bool hasFrequency = false;
        foreach (string line in lines.Take(wireHeader))
            if (TryNumber(line.Trim(), out var freq)) { frequency = freq; hasFrequency = true; }
        if (!hasFrequency || !double.IsFinite(frequency) || frequency < 0)
            throw new FormatException("Перед секцией проводников отсутствует корректная частота.");
        if (frequency == 0)
            warnings.Add("В исходном MAA частота 0 МГц: геометрию можно просматривать, но расчёт на этой частоте невозможен.");

        int countRow = NextDataLine(lines, wireHeader + 1);
        if (countRow < 0) throw new FormatException("После Wires отсутствует количество проводников.");
        string countLine = lines[countRow].Trim();
        string[] countParts = Split(countLine);
        if (countParts.Length == 0 || !int.TryParse(countParts[0], NumberStyles.Integer, Invariant, out int count) || count is < 1 or > 100000)
            throw new FormatException("Некорректное количество проводников: " + countLine);
        // MMANA: base wire count, horizontal copies, vertical copies, horizontal spacing [m],
        // vertical spacing [m], vertical arrangement (0=centered, 1=above, 2=below).
        int stackHorizontal = 1, stackVertical = 1, stackMode = 0;
        double stackHSpacing = 0, stackVSpacing = 0;
        if (countParts.Length >= 6)
        {
            if (!int.TryParse(countParts[1], NumberStyles.Integer, Invariant, out stackHorizontal) ||
                !int.TryParse(countParts[2], NumberStyles.Integer, Invariant, out stackVertical) ||
                !TryNumber(countParts[3], out stackHSpacing) ||
                !TryNumber(countParts[4], out stackVSpacing) ||
                !int.TryParse(countParts[5], NumberStyles.Integer, Invariant, out stackMode))
                throw new FormatException("Некорректные параметры Make Stack: " + countLine);
        }
        if (stackHorizontal is < 1 or > 8 || stackVertical is < 1 or > 8 || stackHorizontal * stackVertical > 64 ||
            !double.IsFinite(stackHSpacing) || !double.IsFinite(stackVSpacing) || stackHSpacing < 0 || stackVSpacing < 0)
            throw new FormatException("Некорректные размеры или расстояния Make Stack: " + countLine);
        bool compactStack = stackHorizontal * stackVertical > 1;
        if (compactStack && stackMode is not (0 or 1 or 2))
            warnings.Add($"Make Stack: неизвестный режим {stackMode}. Будет показана только базовая антенна, без предположений о размещении.");

        var wires = new List<MaaWire>(count);
        int row = countRow + 1;
        while (row < lines.Length && wires.Count < count)
        {
            string record = lines[row++].Trim();
            if (record.Length == 0) continue;
            if (IsSection(record)) break;
            string[] fields = Split(record);
            if (fields.Length < 8 || !fields.Take(7).All(f => TryNumber(f, out _)) ||
                !int.TryParse(fields[7], NumberStyles.Integer, Invariant, out var tag))
                throw new FormatException($"Некорректный проводник #{wires.Count + 1}: {record}");
            double[] p = fields.Take(7).Select(ParseNumber).ToArray();
            if (p.Take(6).Any(v => !double.IsFinite(v)) || !double.IsFinite(p[6]))
                throw new FormatException($"Некорректные координаты/радиус в проводнике #{wires.Count + 1}.");
            wires.Add(new MaaWire(wires.Count + 1, p[0],p[1],p[2],p[3],p[4],p[5],p[6],tag));
        }
        if (wires.Count != count) throw new FormatException($"Wires: ожидалось {count}, прочитано {wires.Count}.");
        if (wires.Any(w => w.RadiusMetres == 0))
            warnings.Add($"MMANA: {wires.Count(w => w.RadiusMetres == 0)} проводников R=0 являются изоляторами. Сохраняются в геометрии, но исключаются из расчёта MININEC.");
        if (wires.Any(w => w.HasTaperReference))
            warnings.Add("Есть отрицательные радиусы MMANA (ссылки на CombWire/Taper): ступенчатые провода пока НЕ развёрнуты.");
        if (wires.Any(w => w.LengthMetres <= 0)) warnings.Add("Обнаружены проводники нулевой длины.");

        var sources = new List<MaaSource>();
        var loads = new List<MaaLoad>();
        ParseExcitations(lines, "source", (record, pulse, v) =>
        {
            if (v.Length < 2) { warnings.Add("Источник с неполными данными: " + record); return; }
            sources.Add(new MaaSource(pulse.Wire, pulse.Position, pulse.Offset, v[0], v[1], record));
        }, warnings);
        ParseExcitations(lines, "load", (record, pulse, v) =>
        {
            // MMANA load record formats differ by kind.  Most importantly,
            // kind=1 (series R+jX) has only THREE numeric values after W...:
            //     w3e2, 1, 500.0, 0.0
            // A previous four-value-only check discarded these loads silently.
            if (v.Length < 1 || v[0] != Math.Truncate(v[0]))
            { warnings.Add("Нагрузка: неизвестный тип (kind): " + record); return; }
            int kind = (int)v[0];
            int required = kind switch { 0 => 4, 1 => 3, 2 => 11, _ => int.MaxValue };
            if (v.Length < required)
            {
                warnings.Add($"Нагрузка kind={kind}: ожидалось не менее {required} числовых параметров, получено {v.Length}: {record}");
                return;
            }
            if (kind == 2)
                warnings.Add("Нагрузка MMANA kind=2 (сложная цепь) распознана для просмотра, но численный расчёт Windows пока не поддерживается: " + record);
            // For kind=1, V3 is intentionally absent: it is not a missing load.
            // For kind=2, preserve original Raw and first three parameters;
            // the solver will reject this unsupported kind before using Zin.
            loads.Add(new MaaLoad(pulse.Wire, pulse.Position, pulse.Offset,
                kind, v[1], v[2], v.Length >= 4 ? v[3] : 0.0, record));
        }, warnings);
        foreach (var s in sources.Where(s => s.WireNumber < 1 || s.WireNumber > count)) warnings.Add("Источник вне базовой модели: " + s.Raw);
        foreach (var l in loads.Where(l => l.WireNumber < 1 || l.WireNumber > count)) warnings.Add("Нагрузка вне базовой модели: " + l.Raw);

        // Clone the original antenna's wires, feed pulses and loads in the same order.
        // Exact MMANA Make Stack placement; numerical Tei segmentation occurs later in the solver.
        if (compactStack && stackMode is 0 or 1 or 2)
        {
            int totalCopies = stackHorizontal * stackVertical;
            var expandedWires = new List<MaaWire>(checked(count * totalCopies));
            var expandedSources = new List<MaaSource>(sources.Count * totalCopies);
            var expandedLoads = new List<MaaLoad>(loads.Count * totalCopies);
            for (int vz = 0; vz < stackVertical; vz++)
            {
                double dz = stackMode switch
                {
                    1 => vz * stackVSpacing,                 // original element and above
                    2 => (vz - stackVertical + 1) * stackVSpacing, // original element and below
                    _ => (vz - (stackVertical - 1) / 2.0) * stackVSpacing
                };
                for (int hy = 0; hy < stackHorizontal; hy++)
                {
                    double dy = (hy - (stackHorizontal - 1) / 2.0) * stackHSpacing;
                    int offset = expandedWires.Count;
                    foreach (var w in wires)
                        expandedWires.Add(new MaaWire(offset + w.Number,
                            w.X1, w.Y1 + dy, w.Z1 + dz, w.X2, w.Y2 + dy, w.Z2 + dz,
                            w.RadiusMetres, w.Tag));
                    foreach (var src in sources)
                        expandedSources.Add(src with {
                            WireNumber = src.WireNumber + offset,
                            RelativeVoltage = src.RelativeVoltage / totalCopies,
                            Raw = src.Raw + $" [stack h={hy+1}, v={vz+1}]"
                        });
                    foreach (var load in loads)
                        expandedLoads.Add(load with {
                            WireNumber = load.WireNumber + offset,
                            Raw = load.Raw + $" [stack h={hy+1}, v={vz+1}]"
                        });
                }
            }
            wires = expandedWires;
            sources = expandedSources;
            loads = expandedLoads;
        }

        int ground = 0, material = 0;
        double height = 0, reference = 50;
        for (int i = 0; i < lines.Length - 1; i++)
        {
            string header = lines[i].ToLowerInvariant();
            if (!header.Contains("g/h") && !header.Contains("azel") && !header.Contains("az/el")) continue;
            int p = NextDataLine(lines, i + 1);
            if (p >= 0)
            {
                var g = Split(lines[p]);
                if (g.Length >= 1 && TryNumber(g[0], out var val)) ground = (int)val;
                if (g.Length >= 2 && TryNumber(g[1], out val)) height = val;
                if (g.Length >= 3 && TryNumber(g[2], out val)) material = (int)val;
                if (g.Length >= 4 && TryNumber(g[3], out val) && val > 0) reference = val;
            }
            break;
        }
        string segmentation = ReadSectionFirstData(lines, "segmentation");
        return new MaaModel {
            FilePath = path, Title = title, FrequencyMHz = frequency, Wires = wires,
            Sources = sources, Loads = loads, Warnings = warnings, GroundType = ground,
            AddHeightMetres = height, MaterialCode = material, ReferenceOhms = reference,
            SegmentationRecord = segmentation, WireHeaderRecord = countLine, HasCompactStack = compactStack,
            StackExpanded = compactStack && stackMode is 0 or 1 or 2,
            BaseWireCount = count, StackHorizontal = stackHorizontal, StackVertical = stackVertical,
            StackHorizontalSpacingMetres = stackHSpacing, StackVerticalSpacingMetres = stackVSpacing,
            StackPlacementMode = stackMode
        };
    }

    private static void ParseExcitations(string[] lines, string section, Action<string, (int Wire, char Position, int Offset), double[]> add, List<string> warnings)
    {
        int header = Array.FindIndex(lines, x => IsNamedSection(x, section));
        if (header < 0) return;
        int n = NextDataLine(lines, header+1);
        if (n < 0) return;
        string[] countParts = Split(lines[n]);
        if (countParts.Length == 0 || !int.TryParse(countParts[0], out int expected))
        {
            warnings.Add($"{section}: неизвестное количество записей."); return;
        }
        int found = 0;
        for (int i = n+1; i < lines.Length && found < expected; i++)
        {
            string record = lines[i].Trim();
            if (record.Length == 0) continue;
            if (IsSection(record)) break;
            var match = Pulse.Match(record);
            if (!match.Success) { warnings.Add($"{section}: непонятная строка {record}"); continue; }
            found++;
            int wire = int.Parse(match.Groups[1].Value, Invariant);
            char position = char.ToLowerInvariant(match.Groups[2].Value[0]);
            if (position == 'с') position = 'c'; // Cyrillic MMANA centre pulse
            string offsetText = match.Groups[3].Value;
            int offset = offsetText.Length > 0 ? int.Parse(offsetText, Invariant) : 0;
            string[] components = Split(record[(match.Index+match.Length)..]);
            if (components.Length == 0 || !components.All(x => TryNumber(x, out _)))
            {
                warnings.Add($"{section}: не удалось прочитать значения {record}"); continue;
            }
            add(record, (wire, position, offset), components.Select(ParseNumber).ToArray());
        }
        if (found != expected) warnings.Add($"{section}: заявлено {expected}, разобрано {found} записей.");
    }

    /// <summary>New coordinates and radius of one wire (MAA units: metres).</summary>
    public readonly record struct WireGeometry(double X1, double Y1, double Z1, double X2, double Y2, double Z2, double Radius);

    /// <summary>
    /// Returns the MAA text with the geometry of the given wires (1-based numbers of the wire lines in the file)
    /// replaced: fields 1–7 (X1, Y1, Z1, X2, Y2, Z2, R) are rewritten, segmentation and any further fields are kept,
    /// all other lines are unchanged (line endings preserved). Only wires written in the file can be changed
    /// (for Make Stack: the base antenna). Throws FormatException if the Wires section is not as the parser expects.
    /// </summary>
    public static string ReplaceWireGeometry(string contents, IReadOnlyDictionary<int, WireGeometry> changes)
    {
        if (changes.Count == 0) return contents;
        string[] lines = contents.Split('\n');                      // '\r' stays at the end of a CRLF line
        int wireHeader = Array.FindIndex(lines, l => IsNamedSection(l.TrimEnd('\r'), "wires"));
        if (wireHeader < 0) throw new FormatException("Секция Wires не найдена.");
        int countRow = NextDataLine(lines, wireHeader + 1);
        if (countRow < 0) throw new FormatException("После Wires отсутствует количество проводников.");
        string[] countParts = Split(lines[countRow].TrimEnd('\r'));
        if (countParts.Length == 0 || !int.TryParse(countParts[0], NumberStyles.Integer, Invariant, out int count) || count < 1)
            throw new FormatException("Некорректное количество проводников.");
        int number = 0;
        for (int row = countRow + 1; row < lines.Length && number < count; row++)
        {
            string raw = lines[row];
            bool cr = raw.EndsWith('\r');
            string record = (cr ? raw[..^1] : raw).Trim();
            if (record.Length == 0) continue;
            if (IsSection(record)) break;
            number++;
            if (!changes.TryGetValue(number, out var g)) continue;
            string[] fields = Split(record);
            if (fields.Length < 8) throw new FormatException($"Некорректный проводник #{number}: {record}");
            double[] v = { g.X1, g.Y1, g.Z1, g.X2, g.Y2, g.Z2, g.Radius };
            if (v.Any(x => !double.IsFinite(x))) throw new FormatException($"Проводник #{number}: нечисловое значение.");
            string text = string.Join(", ", v.Select(FormatNumber).Concat(fields.Skip(7)));
            lines[row] = cr ? text + "\r" : text;
        }
        if (changes.Keys.Any(k => k < 1 || k > number))
            throw new FormatException($"Можно менять только проводники 1…{number}, записанные в файле.");
        return string.Join("\n", lines);
    }

    /// <summary>Compact invariant number for MAA (up to 10 significant decimals, no exponent for usual sizes).</summary>
    public static string FormatNumber(double v)
    {
        if (v == 0) return "0.0";
        string s = v.ToString("0.##########", Invariant);
        return s.Contains('.') ? s : s + ".0";
    }

    /// <summary>Bytes for saving an MAA file: Windows-1251 (as MMANA writes) when the text fits, otherwise UTF-8.</summary>
    public static byte[] EncodeForSave(string contents)
    {
        try
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            var cp1251 = Encoding.GetEncoding(1251, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback);
            return cp1251.GetBytes(contents);
        }
        catch (Exception) { return new UTF8Encoding(false).GetBytes(contents); }
    }

    private static bool IsNamedSection(string line, string name)
    {
        string s = line.Trim();
        if (!s.StartsWith('*')) return false;
        s = s.Trim('*', ' ', '.', '\t').ToLowerInvariant().Replace(" ", "");
        return name switch
        {
            "wires" => s is "wires" or "провода" or "проводники",
            "source" => s.Contains("source") || s.Contains("источ") || s.Contains("feed"),
            "load" => s.Contains("load") || s.Contains("нагруз"),
            "segmentation" => s.Contains("segmentation") || s.Contains("автосегм") || s.Contains("сегмент"),
            _ => s.Contains(name)
        };
    }
    private static bool IsSection(string line)
    {
        string s = line.Trim();
        return s.StartsWith('*') || s.StartsWith("$$$") || s.StartsWith("###");
    }
    private static string ReadSectionFirstData(string[] lines, string section)
    {
        int idx = Array.FindIndex(lines, l => IsNamedSection(l, section));
        int n = idx < 0 ? -1 : NextDataLine(lines, idx+1);
        return n >= 0 ? lines[n].Trim() : "";
    }
    private static int NextDataLine(string[] lines, int from)
    {
        for(int i=from; i<lines.Length; i++) if (!string.IsNullOrWhiteSpace(lines[i])) return i;
        return -1;
    }
    private static string[] Split(string s) => s.Split(new[] {',',';','\t',' '}, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
    private static bool TryNumber(string s, out double d) => double.TryParse(s, NumberStyles.Float, Invariant, out d);
    private static double ParseNumber(string s) => double.Parse(s, NumberStyles.Float, Invariant);

    private static string DecodeMaa(byte[] bytes)
    {
        // UTF-8 or UTF-8 BOM; older MMANA files commonly use Cyrillic Windows-1251.
        try { return new UTF8Encoding(false, true).GetString(bytes).TrimStart('\ufeff'); }
        catch (DecoderFallbackException)
        {
            var sb = new StringBuilder(bytes.Length);
            foreach (byte c in bytes)
            {
                if (c < 0x80) sb.Append((char)c);
                else if (c >= 0xC0) sb.Append((char)(0x0410 + c-0xC0));
                else sb.Append(c switch { 0xA8 => 'Ё', 0xB8 => 'ё', 0xB9 => '№', 0x97 => '—', 0x96 => '–', 0xAB => '«', 0xBB => '»', _ => (char)c });
            }
            return sb.ToString();
        }
    }
}
