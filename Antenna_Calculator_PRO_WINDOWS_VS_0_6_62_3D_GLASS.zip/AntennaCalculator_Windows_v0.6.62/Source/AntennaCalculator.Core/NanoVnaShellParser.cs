using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace AntennaCalculator.Core;

/// <summary>
/// Parser of the NanoVNA text shell answer to <c>scan start stop points 7</c>: one row per point,
/// "frequency s11re s11im s21re s21im", followed by the prompt "ch&gt;". No I/O (tested without hardware).
/// </summary>
public static class NanoVnaShellParser
{
    public const string Prompt="ch>";

    public static bool EndsWithPrompt(string text)=>text.TrimEnd().EndsWith(Prompt,StringComparison.Ordinal);

    /// <summary>Numeric rows with exactly five values (the echoed command and the prompt are skipped).</summary>
    public static List<double[]> Rows(string answer)
    {
        var rows=new List<double[]>();
        foreach(var line in answer.Split(new[]{ '\r','\n' },StringSplitOptions.RemoveEmptyEntries))
        {
            var tokens=line.Trim().Split((char[]?)null,StringSplitOptions.RemoveEmptyEntries);
            if(tokens.Length!=5) continue;
            var v=new double[5]; bool ok=true;
            for(int i=0;i<5 && ok;i++) ok=double.TryParse(tokens[i],NumberStyles.Float,CultureInfo.InvariantCulture,out v[i]) && double.IsFinite(v[i]);
            if(ok) rows.Add(v);
        }
        return rows;
    }

    /// <summary>
    /// The first <paramref name="count"/> rows, checked against the requested range: the number of rows and both the
    /// first and the last frequency (Hz, or kHz on some firmwares). Throws <see cref="FormatException"/> otherwise.
    /// </summary>
    public static double[][] ParseScan(string answer,long startHz,long stopHz,int count)
    {
        var rows=Rows(answer);
        if(rows.Count<count)
            throw new FormatException($"scan вернул {rows.Count} точек вместо {count}");
        var data=rows.Take(count).ToArray();
        double first=data[0][0], last=data[^1][0];
        double scale=Math.Abs(first-startHz)<=Math.Abs(first*1000-startHz) ? 1.0 : 1000.0;
        double tolerance=Math.Max(1000.0,1e-3*Math.Max(startHz,stopHz));
        if(Math.Abs(first*scale-startHz)>tolerance || Math.Abs(last*scale-stopHz)>tolerance)
            throw new FormatException($"частоты ответа {first*scale:0}…{last*scale:0} Гц не совпадают с запрошенными {startHz}…{stopHz} Гц");
        return data;
    }
}
