﻿// MMANA impedance core: MININEC-3 as implemented by JE3HHT in MMANA (mininec3.cpp + ComLib.cpp, LGPL).
// Structured (goto-free) port. Verified through an identical Java port against the original C code
// on 1985 antennas of the MMANA database (relative difference < 1e-6). Names follow the original source.
//
// Exactly as MMANA: sub-wire segmentation (Tei/TeiB/TeiE/TeiAvg, EC, SEG<-10000), combined (taper) wires,
// MININEC connections and pulse numbering, pulse names wNb/wNc/wNe, L||C loads with Q on L only,
// wire loss as one lumped resistor per wire (material code M), perfect image for any ground type,
// single-precision impedance matrix. galCompat=true applies the MMANA-GAL rule EC >= 2.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AntennaCalculator.Core;

public sealed class MmanaReferenceEngine
{
    public sealed class WDef { public double X1,Y1,Z1,X2,Y2,Z2,R; public int SEG; public int PNo,PMax; }
    public sealed class WZDef { public double X1,Y1,Z1,X2,Y2,Z2,R; public int SEG; public int Wno; public int SNo,PNo,SMax; }
    public sealed class PDef { public double RR; public int Type; public double[] L=new double[PPMAX+2]; public double[] R=new double[PPMAX+2]; }
    public sealed class CDef { public string PLUS=""; public int PLUSNo; public double EV=1.0, DEG; }
    public sealed class LDef { public string PLUS=""; public int PLUSNo; public int TYPE; public double[] A=new double[SMAX+2]; public double[] B=new double[SMAX+2]; }
    public sealed class Model
    {
        public double fq;
        public int DM1=400, DM2=40; public double SC=2.0; public int EC=1;
        public int groundType;      // 0 free space, 1 perfect, 2 real (impedance uses the perfect image)
        public double antHeight;
        public int wireLoss;        // M: 0 none, 1 Cu wire, 2 Cu pipe, 3 Al wire, 4 Al pipe, 5 Fe wire, 6 Fe pipe
        public List<WDef> wires=new List<WDef>(); public List<PDef> psets=new List<PDef>();
        public List<CDef> sources=new List<CDef>(); public List<LDef> loads=new List<LDef>();
        public bool stack; public bool unsupportedLoad;
        /// <summary>MMANA-GAL: a pulse name wNe means the last pulse of wire N (original MMANA: the pulse after it).</summary>
        public bool GalEndPulse;
        /// <summary>MMANA-GAL: wire ends closer than this (m) are connected (original MMANA: exact equality only).</summary>
        public double ConnectTolerance;
    }
    /// <summary>Progress of one calculation stage (matrix, LU, GPU LU, back substitution).</summary>
    public readonly record struct MmanaProgress(string Stage,int Done,int Total);

    public sealed record Result(double R,double X,double CurrentRe,double CurrentIm,int Pulses,int SubWires,IReadOnlyList<string> Warnings,
        IReadOnlyList<PulseCurrent>? Currents=null,IReadOnlyList<SourceResult>? Sources=null);
    /// <summary>Voltage, current and impedance of one source (MMANA L477), in file order.</summary>
    public sealed record SourceResult(int Index,string Pulse,double VoltageRe,double VoltageIm,
        double CurrentRe,double CurrentIm,double R,double X);
    /// <summary>
    /// One MININEC pulse as used by MMANA's far-field routine S621: centre point, element vector
    /// (sum of both half segments, SGN·S/2 along each wire), segment-midpoint ends and complex current (A for 1 V).
    /// For a grounded pulse only the upper half counts and its image doubles the vertical part.
    /// </summary>
    public sealed record PulseCurrent(double X,double Y,double Z,double Dx,double Dy,double Dz,
        double NegX,double NegY,double NegZ,double PosX,double PosY,double PosZ,
        double CurrentRe,double CurrentIm,bool Ground);

    const int PPMAX=16, SMAX=16;
    const double PAI=3.1415926535897932384626433832795, PAI2=PAI*2.0, DM2DEF=0.85;
    static int[][] Jag(int rows,int cols){ var a=new int[rows][]; for(int i=0;i<rows;i++) a[i]=new int[cols]; return a; }

    // ------------------------------------------------------------ segmentation (ComLib.cpp)
    readonly List<WZDef> wz=new List<WZDef>();
    double RMD; int DM1,DM2,EC; double SC;
    void AddWZ(double x1,double y1,double z1,double x2,double y2,double z2,double R,int SEG,int wno){
        WZDef w=new WZDef(); w.X1=x1;w.Y1=y1;w.Z1=z1;w.X2=x2;w.Y2=y2;w.Z2=z2;w.R=R;w.SEG=SEG;w.Wno=wno; wz.Add(w);
    }
    void TeiAvg(double x1,double y1,double z1,double x2,double y2,double z2,double R,int DM,int wno){
        R=Math.Abs(R);
        double xx=x2-x1, yy=y2-y1, zz=z2-z1, d=Math.Sqrt(xx*xx+yy*yy+zz*zz);
        int N=(int)(d/(RMD/(double)DM));
        N&=0x0000fffe;
        if(N==0) N+=2;
        if((N<=4) && (((d/N)*DM2DEF) > (RMD/DM))) N+=2;
        AddWZ(x1,y1,z1,x2,y2,z2,R,N,wno);
    }
    void Tei(double x1,double y1,double z1,double x2,double y2,double z2,double R,int DM1p,int wno){
        double xx,yy,zz,d,x, dd,xc,yc,zc,xxc,yyc,zzc;
        double dm1=(double)((DM1p==1)?DM1:DM1p);
        double dm2=(double)DM2;
        double dm; int N,NT,NL;
        R=Math.Abs(R);
        xx=x2-x1; yy=y2-y1; zz=z2-z1; d=Math.Sqrt(xx*xx+yy*yy+zz*zz);
        while(dm2<dm1){
            for(NT=0,dm=dm1,x=0.0; dm>dm2; dm/=SC,NT++){
                if(NT==0) x+=((RMD*EC)/dm); else x+=(RMD/dm);
            }
            dd=d-(x*2);
            N=(int)((dd/(RMD/dm2)));
            N&=0x0000fffe;
            if((dd>0) && (N>=2)){
                dd=dd/N;
                xc=x1; yc=y1; zc=z1;
                for(NL=0,dm=dm1; dm>dm2; dm/=SC,NL++){
                    xxc=xc; yyc=yc; zzc=zc;
                    x=RMD*(NL!=0?1:EC)/dm;
                    xc+=(xx*x/d); yc+=(yy*x/d); zc+=(zz*x/d);
                    AddWZ(xxc,yyc,zzc,xc,yc,zc,R,NL!=0?1:EC,wno);
                }
                if(N!=0){
                    xxc=xc; yyc=yc; zzc=zc;
                    xc+=(xx*dd*N)/d; yc+=(yy*dd*N)/d; zc+=(zz*dd*N)/d;
                    if((N<=4) && ((dd/N)*DM2DEF > (RMD/dm2))) N+=2;
                    AddWZ(xxc,yyc,zzc,xc,yc,zc,R,N,wno);
                }
                dm*=SC;
                for(; NL!=0; dm*=SC,NL--){
                    xxc=xc; yyc=yc; zzc=zc;
                    x=RMD/dm;
                    xc+=(xx*x/d); yc+=(yy*x/d); zc+=(zz*x/d);
                    if(NL==1) AddWZ(xxc,yyc,zzc,x2,y2,z2,R,EC,wno);
                    else AddWZ(xxc,yyc,zzc,xc,yc,zc,R,1,wno);
                }
                return;
            }
            dm2*=2;
        }
        TeiAvg(x1,y1,z1,x2,y2,z2,R,(int)dm1,wno);
    }
    void TeiB(double x1,double y1,double z1,double x2,double y2,double z2,double R,int DM1p,int wno){
        double xx,yy,zz,d,x, dd,xc,yc,zc,xxc,yyc,zzc;
        double dm1=(double)((DM1p==1)?DM1:DM1p);
        double dm2=(double)DM2;
        double dm; int N,NT;
        R=Math.Abs(R);
        xx=x2-x1; yy=y2-y1; zz=z2-z1; d=Math.Sqrt(xx*xx+yy*yy+zz*zz);
        while(dm2<dm1){
            for(NT=0,dm=dm1,x=0.0; dm>dm2; dm/=SC,NT++){
                if(NT==0) x+=((RMD*EC)/dm); else x+=(RMD/dm);
            }
            dd=d-x;
            N=(int)((dd/(RMD/dm2)));
            if((dd>0) && (N!=0)){
                xc=x1; yc=y1; zc=z1;
                for(dm=dm1; dm>dm2; dm/=SC){
                    xxc=xc; yyc=yc; zzc=zc;
                    x=RMD*((dm==dm1)?EC:1)/dm;
                    xc+=(xx*x/d); yc+=(yy*x/d); zc+=(zz*x/d);
                    AddWZ(xxc,yyc,zzc,xc,yc,zc,R,(dm==dm1)?EC:1,wno);
                }
                if(((dd/N)*DM2DEF) > (RMD/DM2)) N++;
                AddWZ(xc,yc,zc,x2,y2,z2,R,N,wno);
                return;
            }
            dm2*=1.25;
        }
        TeiAvg(x1,y1,z1,x2,y2,z2,R,(int)dm1,wno);
    }
    void TeiE(double x1,double y1,double z1,double x2,double y2,double z2,double R,int DM1p,int wno){
        double xx,yy,zz,d,x, dd,xc,yc,zc,xxc,yyc,zzc;
        double dm1=(double)((DM1p==1)?DM1:DM1p);
        double dm2=(double)DM2;
        double dm; int N,NT;
        R=Math.Abs(R);
        xx=x2-x1; yy=y2-y1; zz=z2-z1; d=Math.Sqrt(xx*xx+yy*yy+zz*zz);
        while(dm2<dm1){
            for(NT=0,dm=dm1,x=0.0; dm>dm2; dm/=SC,NT++){
                if(NT==0) x+=((RMD*EC)/dm); else x+=(RMD/dm);
            }
            dd=d-x;
            N=(int)((dd/(RMD/dm2)));
            if((dd>0) && (N!=0)){
                xc=x1+(xx*dd/d); yc=y1+(yy*dd/d); zc=z1+(zz*dd/d);
                if(((dd/N)*DM2DEF) > (RMD/DM2)) N++;
                AddWZ(x1,y1,z1,xc,yc,zc,R,N,wno);
                dm*=SC;
                for(; NT!=0; dm*=SC,NT--){
                    xxc=xc; yyc=yc; zzc=zc;
                    x=RMD/dm;
                    xc+=(xx*x/d); yc+=(yy*x/d); zc+=(zz*x/d);
                    if(NT==1) AddWZ(xxc,yyc,zzc,x2,y2,z2,R,EC,wno);
                    else AddWZ(xxc,yyc,zzc,xc,yc,zc,R,1,wno);
                }
                return;
            }
            dm2*=1.25;
        }
        TeiAvg(x1,y1,z1,x2,y2,z2,R,(int)dm1,wno);
    }
    void SetWZ1(int i, WDef wp){
        if(wp.SEG>0){ AddWZ(wp.X1,wp.Y1,wp.Z1,wp.X2,wp.Y2,wp.Z2,wp.R,wp.SEG,i); }
        else if(wp.SEG<0){
            switch(wp.SEG){
                case -2: TeiB(wp.X1,wp.Y1,wp.Z1,wp.X2,wp.Y2,wp.Z2,wp.R,DM1,i); break;
                case -3: TeiE(wp.X1,wp.Y1,wp.Z1,wp.X2,wp.Y2,wp.Z2,wp.R,DM1,i); break;
                default:
                    if(wp.SEG < -10000){
                        int SaveDM2=DM2;
                        DM2=(wp.SEG>>16)&0x00007fff;
                        Tei(wp.X1,wp.Y1,wp.Z1,wp.X2,wp.Y2,wp.Z2,wp.R,wp.SEG&0x00007fff,i);
                        DM2=SaveDM2;
                    } else {
                        Tei(wp.X1,wp.Y1,wp.Z1,wp.X2,wp.Y2,wp.Z2,wp.R,-wp.SEG,i);
                    }
                    break;
            }
        } else {
            TeiAvg(wp.X1,wp.Y1,wp.Z1,wp.X2,wp.Y2,wp.Z2,wp.R,DM2,i);
        }
    }
    static double GetLen(PDef pp,int n){
        double d=pp.L[0];
        for(int i=1;i<=n;i++){
            if(pp.L[i]!=0) d+=pp.L[i]*2; else { d=1.0e20; break; }
        }
        return d;
    }
    static double GetWireLen(WDef wp){ double xx=wp.X2-wp.X1, yy=wp.Y2-wp.Y1, zz=wp.Z2-wp.Z1; return Math.Sqrt(xx*xx+yy*yy+zz*zz); }
    PDef? FindPP(Model m,double r){ foreach(PDef p in m.psets) if(r==p.RR) return p; return null; }
    int CombWire(WDef[] tbl, PDef pp, WDef wp){
        double xx=wp.X2-wp.X1, yy=wp.Y2-wp.Y1, zz=wp.Z2-wp.Z1;
        double d=Math.Sqrt(xx*xx+yy*yy+zz*zz), dd=d, l;
        int i,j,n;
        for(int k=0;k<tbl.Length;k++) tbl[k]=new WDef();
        tbl[0].X1=wp.X1; tbl[0].Y1=wp.Y1; tbl[0].Z1=wp.Z1;
        n=0;
        switch(pp.Type&1){
            case 0:
                for(i=0;(i<PPMAX);i++){ if(d<=GetLen(pp,i)) break; }
                if(i==0) break;
                l=(dd-GetLen(pp,i-1))/2;
                for(j=i-1;j>=0;j--){
                    tbl[n+1].X1=tbl[n].X2=tbl[n].X1+(xx*l)/dd;
                    tbl[n+1].Y1=tbl[n].Y2=tbl[n].Y1+(yy*l)/dd;
                    tbl[n+1].Z1=tbl[n].Z2=tbl[n].Z1+(zz*l)/dd;
                    tbl[n].R=(pp.L[j+1]!=0)?pp.R[j+1]:pp.R[j];
                    if((pp.Type&2)!=0) tbl[n].SEG=(wp.SEG>=0)?wp.SEG:0;
                    else tbl[n].SEG=((wp.SEG==-2)||(wp.SEG==-3))?0:wp.SEG;
                    d-=l; l=pp.L[j]; n++;
                }
                for(j=0;(j<=i)&&(d!=0);j++){
                    l=pp.L[j];
                    if((l==0)||(l>d)) l=d;
                    tbl[n+1].X1=tbl[n].X2=tbl[n].X1+(xx*l)/dd;
                    tbl[n+1].Y1=tbl[n].Y2=tbl[n].Y1+(yy*l)/dd;
                    tbl[n+1].Z1=tbl[n].Z2=tbl[n].Z1+(zz*l)/dd;
                    tbl[n].R=(pp.L[j]!=0)?pp.R[j]:(j!=0?pp.R[j-1]:0.008);
                    if((pp.Type&2)!=0) tbl[n].SEG=(wp.SEG>=0)?wp.SEG:0;
                    else tbl[n].SEG=((wp.SEG==-2)||(wp.SEG==-3))?0:wp.SEG;
                    d-=l; n++;
                }
                break;
            case 1:
                for(i=0;(i<PPMAX)&&(d!=0);i++){
                    l=pp.L[i];
                    if((l==0)||(l>d)) l=d;
                    tbl[n+1].X1=tbl[n].X2=tbl[n].X1+(xx*l)/dd;
                    tbl[n+1].Y1=tbl[n].Y2=tbl[n].Y1+(yy*l)/dd;
                    tbl[n+1].Z1=tbl[n].Z2=tbl[n].Z1+(zz*l)/dd;
                    tbl[n].R=(pp.L[i]!=0)?pp.R[i]:(i!=0?pp.R[i-1]:0.008);
                    if((pp.Type&2)!=0) tbl[n].SEG=(wp.SEG>=0)?wp.SEG:0;
                    else tbl[n].SEG=((wp.SEG==-2)||(wp.SEG==-3))?0:wp.SEG;
                    d-=l; n++;
                }
                break;
        }
        if(n!=0){
            i=n-1;
            tbl[i].X2=wp.X2; tbl[i].Y2=wp.Y2; tbl[i].Z2=wp.Z2;
            double DMLen=(RMD/DM2);
            if(wp.SEG<0){
                switch(wp.SEG){
                    case -2:
                        if(GetWireLen(tbl[0])<DMLen){ tbl[0].SEG=-1; tbl[1].SEG=-2; } else tbl[0].SEG=-2;
                        break;
                    case -3:
                        if((i!=0) && (GetWireLen(tbl[0])<DMLen)){ tbl[i-1].SEG=-3; tbl[i].SEG=-1; } else tbl[i].SEG=-3;
                        break;
                    default:
                        if(i==0){ tbl[0].SEG=wp.SEG; }
                        else if((pp.Type&2)!=0){
                            if(GetWireLen(tbl[0])<DMLen){ tbl[0].SEG=-1; tbl[1].SEG=(n>3)?-2:-1; }
                            else tbl[0].SEG=-2;
                            if((i!=0) && (GetWireLen(tbl[0])<DMLen)){ tbl[i-1].SEG=(n>3)?-3:-1; tbl[i].SEG=-1; }
                            else tbl[i].SEG=-3;
                        }
                        break;
                }
            }
            if(((pp.Type&1)==0) && (n>=3)){
                for(i=0;i<n;i++){
                    if((tbl[i].SEG==0) && (i!=(n/2))){
                        d=GetWireLen(tbl[i]);
                        int N=(int)(d/DMLen);
                        if(N==0) N++;
                        if((N<=4) && (((d/N)*DM2DEF) > DMLen)) N++;
                        tbl[i].SEG=N;
                    }
                }
            }
        } else {
            copyW(tbl[0],wp);
            tbl[0].R=pp.R[0];
            n=1;
        }
        return n;
    }
    static void copyW(WDef t,WDef s){ t.X1=s.X1;t.Y1=s.Y1;t.Z1=s.Z1;t.X2=s.X2;t.Y2=s.Y2;t.Z2=s.Z2;t.R=s.R;t.SEG=s.SEG;t.PNo=s.PNo;t.PMax=s.PMax; }
    bool SetWZall(Model m){
        wz.Clear();
        for(int i=0;i<m.wires.Count;i++){
            WDef wp=m.wires[i];
            wp.PNo=0; wp.PMax=0;
            if(wp.R==0) continue;
            if(wp.R<0.0){
                PDef? pp=FindPP(m,wp.R);
                if(pp!=null){
                    WDef[] temp=new WDef[PPMAX*2+2];
                    int n=CombWire(temp,pp,wp);
                    for(int k=0;k<n;k++) SetWZ1(i,temp[k]);
                } else { SetWZ1(i,wp); return false; }
            } else SetWZ1(i,wp);
        }
        return true;
    }
    static double Teira(double x,double[] p,int n){ double y=p[0]; for(int i=1;i<n;i++) y+=Math.Pow(x,i)*p[i]; return y; }
    double GetWireRoss(Model m,WDef wp,double f){
        if(wp.R<0.0){
            PDef? pp=FindPP(m,wp.R);
            if(pp!=null){
                WDef[] temp=new WDef[PPMAX*2+2];
                int n=CombWire(temp,pp,wp);
                double d=0.0;
                for(int i=0;i<n;i++) d+=GetWireRossF(m.wireLoss,f,temp[i]);
                return d;
            }
        }
        return GetWireRossF(m.wireLoss,f,wp);
    }
    static double GetWireRossF(int WireRoss,double f,WDef wp){
        double xx=wp.X2-wp.X1, yy=wp.Y2-wp.Y1, zz=wp.Z2-wp.Z1;
        double l=Math.Sqrt(xx*xx+yy*yy+zz*zz);
        double s=wp.R*wp.R*PAI;
        double LO=0, US=0;
        switch(WireRoss){
            case 1: case 2: LO=1.8e-8; US=1-0.96e-5; break;
            case 3: case 4: LO=2.8e-8; US=1+2.2e-5; break;
            case 5: case 6: LO=9.4e-8; US=150; break;
        }
        double r,x,t;
        if(((WireRoss-1)&1)!=0){
            t=wp.R*0.9;
            s-=(t*t*PAI);
            r=l*LO/s;
            x=0.1985*wp.R*10*Math.Sqrt(US*f*1e6/(LO*1e8));
            if(x>=4.0) r*=x;
            else if(x>=1.0){
                double[] tt={-4.772531e-01,5.851077e+00,-9.276207e+00,7.476381e+00,-3.116668e+00,7.079749e-01,-8.326961e-02,3.965883e-03};
                r*=Teira(x,tt,8);
            } else if(x>=0.3){
                double[] tt={3.760000e-01,8.423095e+00,-4.696111e+01,1.402500e+02,-2.425694e+02,2.437500e+02,-1.319444e+02,2.976190e+01};
                r*=Teira(x,tt,8);
            }
        } else {
            r=l*LO/s;
            x=28.1*wp.R*Math.Sqrt(US*f*1e6/(LO*1e8));
            if(x>=100.0) r*=x*0.3561;
            else if(x>=10.0){
                double[] tt={-2.120000e+00,1.004767e+00,-7.089785e-02,4.119507e-03,-1.430243e-04,3.112024e-06,-4.280139e-08,3.612087e-10,-1.706349e-12,3.452932e-15};
                r*=Teira(x,tt,10);
            } else if(x>=1.0){
                double[] tt={1.384010e+00,-1.388426e+00,2.087645e+00,-1.712435e+00,8.488221e-01,-2.589923e-01,5.010682e-02,-6.182203e-03,4.721516e-04,-2.036364e-05,3.794671e-07};
                r*=Teira(x,tt,11);
            }
        }
        return r;
    }
    static double[] CalcParaZ(double f,double L,double C,double Q){
        double wl=PAI2*f*L, wc=PAI2*f*C*1.0e-6;
        double r=(Q!=0.0)?wl/Q:0.0;
        double A=r/(r*r+wl*wl), B=wc-wl/(r*r+wl*wl);
        double Y=(A*A)+(B*B);
        if(Y==0.0) return new double[]{double.MaxValue,-double.MaxValue};
        return new double[]{A/Y,-B/Y};
    }
    // pulse name -> pulse number (Str2PlusNo)
    static int Str2PlusNo(Model m,string s){
        string bf=s.ToUpperInvariant();
        int pno;
        if(bf.Length>0 && char.IsDigit(bf[0])){
            int k=0; while(k<bf.Length && char.IsDigit(bf[k])) k++;
            return int.Parse(bf.Substring(0,k),CultureInfo.InvariantCulture);
        }
        if(bf.Length==0 || bf[0]!='W') return 0;
        char c='C'; int p=1;
        while(p<bf.Length && char.IsDigit(bf[p])) p++;
        string wstr=bf.Substring(1,p-1);
        string rest="";
        if(p<bf.Length){ c=bf[p]; rest=bf.Substring(p+1); }
        int n=0;
        if(rest.Length>0){ var mm=Regex.Match(rest,"^\\s*([+-]?\\d+)"); if(mm.Success) n=int.Parse(mm.Groups[1].Value,CultureInfo.InvariantCulture); }
        int w;
        if(wstr.Length>0){ w=int.Parse(wstr,CultureInfo.InvariantCulture); if(w!=0) w--; } else return 0;
        if(w<0 || w>=m.wires.Count) return 0;
        WDef wd=m.wires[w];
        switch(c){
            case 'C': pno=(wd.PMax/2)+wd.PNo; pno+=n; break;
            case 'B': pno=wd.PNo; pno+=n; break;
            case 'E': pno=wd.PNo+wd.PMax-(m.GalEndPulse?1:0); pno-=n; break;
            default: pno=0; break;
        }
        return pno;
    }

    // ------------------------------------------------------------ MININEC globals (mininec3.cpp)
    int pmax; int G; int N,NW,NL,NS,MP;
    int I,I1,I2,I3,I4,I5,I6, J,J1,J2, K, L, N1, P4i, Gi;
    double A2,B,B1,C0,C1,C2,C3,C4,C5,C6,C7,C8,C9,CRd,CI,D,D0,D1,D2,D3,F,F2,F3,F4,F5,F6,F7,F8,FLG,FVS,
           I6f,LI,LR,M,P,P0,P1,P2,P3,S,S0,S1,S4,SRM,T,T1,T2,T3,T4,T5,T6,T7,U1,U2,U3,U4,U5,U6,V0,V1,V2,V3,
           VM,VP,W,W0,W1,W2,X,X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3,HeightOff;
    double[] aQ=new double[15];
    double[] aX=Array.Empty<double>(),aY=Array.Empty<double>(),aZ=Array.Empty<double>(),aA=Array.Empty<double>(),aCA=Array.Empty<double>(),aCB=Array.Empty<double>(),aCG=Array.Empty<double>(),aS=Array.Empty<double>(),aCI=Array.Empty<double>(),aCR=Array.Empty<double>(),aEf=Array.Empty<double>(),aL=Array.Empty<double>(),aM=Array.Empty<double>();
    int[] aJ1=Array.Empty<int>(),aPi=Array.Empty<int>(),aWi=Array.Empty<int>(),aEi=Array.Empty<int>(),aLP=Array.Empty<int>(),aLS=Array.Empty<int>();
    int[][] aJ2=new int[0][],aN=new int[0][];
    int[] aCi=Array.Empty<int>(); float[] aZR=Array.Empty<float>(),aZI=Array.Empty<float>();
    double[][][] aLA=new double[0][][];
    int REFACI(int a,int b){ return aCi[a*3+b]; }
    void SETACI(int a,int b,int v){ aCi[a*3+b]=v; }
    int GETREF(int a,int b){ return pmax*a+b; }
    static int INT(double c){ return (c<0)?((int)(c-1)):((int)c); }
    static double SGN(double c){ return (c<0)?-1:((c>0)?1:0); }
    static int SGNi(int c){ return (c<0)?-1:((c>0)?1:0); }

    void S28(){
        if(K<0){ X3=V1+T*(X2-V1); Y3=V2+T*(Y2-V2); Z3=V3+T*(Z2-V3); }
        else { X3=X2+T*(V1-X2); Y3=Y2+T*(V2-Y2); Z3=Z2+T*(V3-Z2); }
        D3=X3*X3+Y3*Y3+Z3*Z3;
        if(aA[P4i]<=SRM){ D=Math.Sqrt(D3); }
        else {
            D=D3+A2;
            if(D>0.0) D=Math.Sqrt(D);
            if(I6f!=0){
                B=D3/(D3+4*A2);
                W0=C0+B*(C1+B*(C2+B*(C3+B*C4)));
                W1=C5+B*(C6+B*(C7+B*(C8+B*C9)));
                V0=(W0-W1*Math.Log(B))*Math.Sqrt(1-B);
                T3=T3+(V0+Math.Log(D3/(64*A2))/2)/P/aA[P4i]-1/D;
            }
        }
        B1=D*W;
        T3=T3+Math.Cos(B1)/D;
        T4=T4-Math.Sin(B1)/D;
    }
    void S87(){
        FVS=1;
        if(K>=1){
            if(aA[P4i]<=SRM){
                if(((P3==(P2+1)) && (P1==((P2+P3)/2)))){
                    T1=2*Math.Log(aS[P4i]/aA[P4i]); T2=-W*aS[P4i]; return;
                }
            }
        }
        I4=INT(P1); I5=I4+1;
        X1=(aX[I4]+aX[I5])/2; Y1=(aY[I4]+aY[I5])/2; Z1=(aZ[I4]+aZ[I5])/2;
        L113();
    }
    void S102(){
        FVS=0;
        if(K>=1){
            if(aA[P4i]<SRM){
                if((I==J) && (P3==(P2+.5))){
                    T1=Math.Log(aS[P4i]/aA[P4i]); T2=-W*aS[P4i]/2; return;
                }
            }
        }
        int P1i=(int)P1;
        X1=aX[P1i]; Y1=aY[P1i]; Z1=aZ[P1i];
        L113();
    }
    void L113(){
        I4=INT(P2);
        if(((double)I4)==P2){ X2=aX[I4]-X1; Y2=aY[I4]-Y1; Z2=K*aZ[I4]-Z1; }
        else { I5=I4+1; X2=(aX[I4]+aX[I5])/2-X1; Y2=(aY[I4]+aY[I5])/2-Y1; Z2=K*(aZ[I4]+aZ[I5])/2-Z1; }
        I4=INT(P3);
        if(((double)I4)==P3){ V1=aX[I4]-X1; V2=aY[I4]-Y1; V3=K*aZ[I4]-Z1; }
        else { I5=I4+1; V1=(aX[I4]+aX[I5])/2-X1; V2=(aY[I4]+aY[I5])/2-Y1; V3=K*(aZ[I4]+aZ[I5])/2-Z1; }
        L135();
    }
    void L135(){
        D0=X2*X2+Y2*Y2+Z2*Z2;
        if(D0>0) D0=Math.Sqrt(D0);
        D3=V1*V1+V2*V2+V3*V3;
        if(D3>0) D3=Math.Sqrt(D3);
        A2=aA[P4i]*aA[P4i];
        S4=(P3-P2)*aS[P4i];
        T1=0; T2=0; I6f=0; F2=1; L=7;
        T=(D0+D3)/aS[P4i];
        bool exactPath=false;
        if(!(T>1.1) && !(FVS==-1)){
            int i=aWi[I], j=aWi[J];
            if((aJ2[i][1]==aJ2[j][1]) || (aJ2[i][1]==aJ2[j][2]) || (aJ2[i][2]==aJ2[j][1]) || (aJ2[i][2]==aJ2[j][2])){
                if(aA[P4i]>SRM){
                    F2=2*(P3-P2);
                    I6f=(1-Math.Log(S4/F2/8/aA[P4i]))/P/aA[P4i];
                    exactPath=true;                  // goto L167 (keep L=7)
                } else {
                    if(FVS==1){ T1=2*Math.Log(aS[P4i]/aA[P4i]); T2=-W*aS[P4i]; }
                    else { T1=Math.Log(aS[P4i]/aA[P4i]); T2=-W*aS[P4i]/2; }
                    return;
                }
            }
        }
        if(!exactPath){            // L165
            if(T>6) L=3;
            if(T>10) L=1;
        }
        I5=L+L;                    // L167
        do {                       // L168
            T3=0; T4=0;
            T=(aQ[L]+.5)/F2; S28();
            T=(.5-aQ[L])/F2; S28();
            L=L+1;
            T1=T1+aQ[L]*T3;
            T2=T2+aQ[L]*T4;
            L=L+1;
        } while(L<I5);
        T1=S4*(T1+I6f);
        T2=S4*T2;
    }
    double _connTol;
    bool Eq(double a,double b)=>_connTol<=0 ? a==b : Math.Abs(a-b)<=_connTol;

    void S1299(){
        aEf[I]=X1; aL[I]=Y1; aM[I]=Z1;
        aEf[I+NW]=X2; aL[I+NW]=Y2; aM[I+NW]=Z2;
        Gi=0; I1=0; I2=0; aJ1[I]=0; aJ2[I][1]=-I; aJ2[I][2]=-I;
        bool skipEnd1=false;
        if(G!=1){
            if(Z1==0){ I1=-I; aJ1[I]=-1; skipEnd1=true; }
            else if(Z2==0){ I2=-I; aJ1[I]=1; Gi=1; }
        }
        if(!skipEnd1){
            if(I==1) return;
            for(J=1;J<I;J++){
                if(Eq(X1,aEf[J]) && Eq(Y1,aL[J]) && Eq(Z1,aM[J])){
                    I1=-J; aJ2[I][1]=J; if(aJ2[J][1]==-J) aJ2[J][1]=J; break;
                }
                if(Eq(X1,aEf[J+NW]) && Eq(Y1,aL[J+NW]) && Eq(Z1,aM[J+NW])){
                    I1=J; aJ2[I][1]=J; if(aJ2[J][2]==-J) aJ2[J][2]=J; break;
                }
            }
        }
        if(Gi==1) return;
        if(I==1) return;
        for(J=1;J<I;J++){
            if(Eq(X2,aEf[J+NW]) && Eq(Y2,aL[J+NW]) && Eq(Z2,aM[J+NW])){
                I2=-J; aJ2[I][2]=J; if(aJ2[J][2]==-J) aJ2[J][2]=J; return;
            }
            if(Eq(X2,aEf[J]) && Eq(Y2,aL[J]) && Eq(Z2,aM[J])){
                I2=J; aJ2[I][2]=J; if(aJ2[J][1]==-J) aJ2[J][1]=J; return;
            }
        }
    }

    // ------------------------------------------------------------ InitAntData
    public string? error;
    public readonly List<string> warnings=new List<string>();
    bool InitAntData(Model m, double freq){
        double[] CQ={0,.288675135,.5,.430568156,.173927423,.169990522,.326072577,.480144928,.050614268,.398333239,.111190517,.262766205,.156853323,.091717321,.181341892};
        Array.Copy(CQ,0,aQ,0,15);
        P=4*Math.Atan(1); P0=P/180;
        C0=1.38629436112; C1=0.09666344259; C2=0.03590092383; C3=0.03742563713; C4=0.01451196212;
        C5=0.5; C6=0.12498593397; C7=0.06880248576; C8=0.0332835346; C9=0.00441787012;
        F=freq; if(F==0) F=299.8;
        W=299.8/F; S0=0.001*W; M=4.77783352*W; SRM=0.0001*W;
        RMD=W; DM1=m.DM1; DM2=m.DM2; SC=m.SC; EC=m.EC;
        _connTol=m.ConnectTolerance;
        W=2*P/W; W2=W*W/2; FLG=0;
        if(!SetWZall(m)){ error="comb wire set not found"; return false; }
        G=(m.groundType!=0)?-1:1;
        NW=wz.Count; N=0;
        HeightOff=(m.groundType!=0)?m.antHeight:0.0;
        // pulse upper bound: sum of segments + junction pulses
        int segs=0; foreach(WZDef z in wz) segs+=Math.Max(z.SEG,1);
        MP=segs+NW+4;
        int amax=MP+2;
        aX=new double[2*NW+amax+4]; aY=new double[2*NW+amax+4]; aZ=new double[2*NW+amax+4];
        aCi=new int[amax*3+3]; aCI=new double[amax]; aCR=new double[amax]; aPi=new int[amax]; aWi=new int[amax];
        aEi=new int[NW+amax+m.sources.Count+4]; aEf=new double[2*NW+amax+4]; aL=new double[2*NW+amax+m.sources.Count+4]; aM=new double[2*NW+amax+m.sources.Count+4];
        aA=new double[NW+2]; aCA=new double[NW+2]; aCB=new double[NW+2]; aCG=new double[NW+2]; aS=new double[NW+2];
        aJ1=new int[NW+2]; aJ2=Jag(NW+2,3); aN=Jag(NW+3,3);
        for(I=1;I<=NW;I++){
            WZDef z=wz[I-1];
            S1=z.SEG;
            X1=z.X1; Y1=z.Y1; Z1=z.Z1+HeightOff;
            X2=z.X2; Y2=z.Y2; Z2=z.Z2+HeightOff;
            aA[I]=z.R;
            if((X1==X2) && (Y1==Y2) && (Z1==Z2)){ error="zero length wire"; return false; }
            S1299();
            X3=X2-X1; Y3=Y2-Y1; Z3=Z2-Z1;
            D=Math.Sqrt(X3*X3+Y3*Y3+Z3*Z3);
            aCA[I]=X3/D; aCB[I]=Y3/D; aCG[I]=Z3/D;
            aS[I]=D/S1;
            N1=N+1;
            aN[I][1]=N1;
            if((S1==1) && (I1==0)) aN[I][1]=0;
            N=(int)(N1+S1);
            if(I1==0) N=N-1;
            if(I2==0) N=N-1;
            if(N>MP){ error="pulse number exceeds dimension"; return false; }
            aN[I][2]=N;
            if((S1==1) && (I2==0)) aN[I][2]=0;
            if(N<N1){
                I1=N1+2*(I-1);
                aX[I1]=X1; aY[I1]=Y1; aZ[I1]=Z1;
                I1=I1+1;
                aX[I1]=X2; aY[I1]=Y2; aZ[I1]=Z2;
            } else {
                for(J=N1;J<=N;J++){ SETACI(J,1,I); SETACI(J,2,I); aWi[J]=I; }
                SETACI(N1,1,I1);
                SETACI(N,2,I2);
                I1=N1+2*(I-1);
                I3=I1;
                aX[I1]=X1; aY[I1]=Y1; aZ[I1]=Z1;
                if(REFACI(N1,1)!=0){
                    I2=Math.Abs(REFACI(N1,1));
                    F3=SGNi(REFACI(N1,1))*aS[I2];
                    aX[I1]=aX[I1]-F3*aCA[I2];
                    aY[I1]=aY[I1]-F3*aCB[I2];
                    if(REFACI(N1,1)==-I) F3=-F3;
                    aZ[I1]=aZ[I1]-F3*aCG[I2];
                    I3=I3+1;
                }
                I6=N+2*I;
                for(I4=I1+1;I4<=I6;I4++){
                    J=I4-I3;
                    aX[I4]=X1+J*X3/S1; aY[I4]=Y1+J*Y3/S1; aZ[I4]=Z1+J*Z3/S1;
                }
                if(REFACI(N,2)!=0){
                    I2=Math.Abs(REFACI(N,2));
                    F3=SGNi(REFACI(N,2))*aS[I2];
                    I3=I6-1;
                    aX[I6]=aX[I3]+F3*aCA[I2];
                    aY[I6]=aY[I3]+F3*aCB[I2];
                    if(I==-REFACI(N,2)) F3=-F3;
                    aZ[I6]=aZ[I3]+F3*aCG[I2];
                }
            }
        }
        if(N<=0){ error="number of pulses is zero"; return false; }
        // pulse/wire bookkeeping (labels L1264..L1286)
        K=1; J=0;
        for(I=1;I<=N;I++){
            I1=2*aWi[I]-1+I;
            bool toBody=(K>NW)||(K==J);
            while(true){
                if(!toBody){                       // L1270
                    bool reached=false;
                    while(true){
                        J=K;
                        if((aN[K][1]!=0)||(aN[K][2]!=0)){ reached=true; break; }
                        K=K+1;
                        if(K>NW) break;
                    }
                    if(!reached) break;            // goto L1286
                }
                int i=K-1;                         // L1279
                if(i<wz.Count){
                    WZDef z=wz[i];
                    if(z.PNo==0) z.PNo=I;
                    if(z.SNo==0) z.SNo=I1;
                    z.SMax=I1;
                }
                if((I==aN[K][2])||(aN[K][1]==aN[K][2])||(REFACI(I,2)==0)) K=K+1;
                if(REFACI(I,1)==0) SETACI(I,1,aWi[I]);
                if(REFACI(I,2)==0) SETACI(I,2,aWi[I]);
                if((K==NW)&&(aN[K][1]==0)&&(aN[K][2]==0)){ toBody=false; continue; }
                if((I==N)&&(K<NW)){ toBody=false; continue; }
                break;
            }
        }
        pmax=N;
        // AdjPlusNo
        foreach(WZDef z in wz){
            if(z.PNo!=0){
                WDef wp=m.wires[z.Wno];
                if(wp.PNo==0) wp.PNo=z.PNo;
                wp.PMax+=(z.SMax-z.SNo)+1;
            }
        }
        foreach(CDef c in m.sources) c.PLUSNo=Str2PlusNo(m,c.PLUS);
        foreach(LDef l in m.loads) l.PLUSNo=Str2PlusNo(m,l.PLUS);
        // loads
        int nWireLoss=0; if(m.wireLoss!=0) foreach(WDef w in m.wires) if(w.R!=0) nWireLoss++;
        int maxL=m.loads.Count+nWireLoss+2;
        aLA=new double[3][][]; for(int q=0;q<3;q++){ aLA[q]=new double[maxL+1][]; for(int r2=0;r2<=maxL;r2++) aLA[q][r2]=new double[SMAX+2]; } aLP=new int[maxL+1]; aLS=new int[maxL+1];
        NL=m.loads.Count;
        for(I=1;I<=NL;I++){
            LDef ld=m.loads[I-1];
            aLS[I]=0; aLP[I]=ld.PLUSNo;
            if(aLP[I]>N){ error="load pulse number exceeds number of pulses"; return false; }
            if(aLP[I]<1){ warnings.Add("load "+ld.PLUS+" refers to no pulse and is ignored (as in MMANA)"); aLP[I]=0; }
            switch(ld.TYPE){
                case 0:
                    if(ld.A[0]!=0 && ld.B[0]!=0){ double[] z=CalcParaZ(freq,ld.A[0],ld.B[0],ld.A[1]); aLA[1][I][1]=z[0]; aLA[2][I][1]=z[1]; }
                    else if(ld.A[0]!=0){
                        aLA[2][I][1]=freq*PAI2*ld.A[0];
                        aLA[1][I][1]=(ld.A[1]!=0)?aLA[2][I][1]/ld.A[1]:0;
                    } else {
                        aLA[2][I][1]=-1.0/(freq*PAI2*ld.B[0]*1.0e-6);
                        aLA[1][I][1]=(ld.A[1]!=0)?-(aLA[2][I][1]/ld.A[1]):0;
                    }
                    break;
                case 1:
                    aLA[1][I][1]=ld.A[0]; aLA[2][I][1]=ld.B[0]; break;
                default:
                    error="S-domain loads not supported"; return false;
            }
        }
        if(m.wireLoss!=0){
            foreach(WDef w in m.wires){
                if(w.R!=0){
                    aLS[I]=0;
                    aLP[I]=w.PNo+(w.PMax/2);
                    aLA[1][I][1]=GetWireRoss(m,w,freq);
                    aLA[2][I][1]=0.0;
                    I++; NL++;
                }
            }
        }
        // sources
        NS=m.sources.Count; if(NS<1){ error="no source"; return false; }
        for(I=1;I<=NS;I++){
            CDef c=m.sources[I-1];
            aEi[I]=c.PLUSNo; VM=c.EV; VP=c.DEG;
            if(aEi[I]>N || aEi[I]<1){ error="source pulse number out of range"; return false; }
            aL[I]=VM*Math.Cos(VP*P0); aM[I]=VM*Math.Sin(VP*P0);
        }
        FLG=0;
        return true;
    }

    // ------------------------------------------------------------ S196: matrix, loads, factor, solve
    void S196(){
        aZR=new float[(pmax+1)*(pmax+1)+pmax+2]; aZI=new float[(pmax+1)*(pmax+1)+pmax+2];
        for(I=1;I<=N;I++){
            _ct.ThrowIfCancellationRequested();
            NotifyProgress("матрица",I,N);
            I1=Math.Abs(REFACI(I,1)); I2=Math.Abs(REFACI(I,2));
            F4=SGNi(REFACI(I,1))*aS[I1];
            F5=SGNi(REFACI(I,2))*aS[I2];
            T5=F4*aCA[I1]+F5*aCA[I2];
            T6=F4*aCB[I1]+F5*aCB[I2];
            T7=F4*aCG[I1]+F5*aCG[I2];
            if(REFACI(I,1)==-REFACI(I,2)) T7=aS[I1]*(aCG[I1]+aCG[I2]);
            for(J=1;J<=N;J++){
                J1=Math.Abs(REFACI(J,1)); J2=Math.Abs(REFACI(J,2));
                F4=SGNi(REFACI(J,1)); F5=SGNi(REFACI(J,2));
                F6=1; F7=1;
                for(K=1;K>=G;K-=2){
                    if(REFACI(J,1)==-REFACI(J,2)){
                        if(K<0) continue;          // goto L332
                        F6=F4; F7=F5;
                    }
                    F8=0;                          // L235
                    bool compute;
                    if(K<0) compute=true;          // goto L248
                    else {
                        if(I1==I2 && (((aCA[I1]+aCB[I1])==0) || (REFACI(I,1)==REFACI(I,2)))
                           && J1==J2 && (((aCA[J1]+aCB[J1])==0) || (REFACI(J,1)==REFACI(J,2)))){
                            if(I1==J1) F8=1;
                            if(I==J) F8=2;
                        }
                        compute=(aZR[GETREF(I,J)]==0);   // L246
                    }
                    if(compute){                   // L248
                        P1=2*aWi[I]+I-1;
                        P2=2*aWi[J]+J-1;
                        P3=P2+.5;
                        P4i=J2;
                        S102();
                        U1=F5*T1; U2=F5*T2;
                        P3=P2; P2=P2-.5; P4i=J1;
                        if(F8<2) S102();
                        V1=F4*T1; V2=F4*T2;
                        X3=U1*aCA[J2]+V1*aCA[J1];
                        Y3=U1*aCB[J2]+V1*aCB[J1];
                        Z3=(F7*U1*aCG[J2]+F6*V1*aCG[J1])*K;
                        D1=W2*(X3*T5+Y3*T6+Z3*T7);
                        X3=U2*aCA[J2]+V2*aCA[J1];
                        Y3=U2*aCB[J2]+V2*aCB[J1];
                        Z3=(F7*U2*aCG[J2]+F6*V2*aCG[J1])*K;
                        D2=W2*(X3*T5+Y3*T6+Z3*T7);
                        P1=P1+.5;
                        if(F8==2) P1=P1-1;
                        P2=P3; P3=P3+1; P4i=J2;
                        bool toL314=false;
                        if(F8!=1){
                            S87();                 // L283
                            if(F8>=2){
                                U1=(2*T1-4*U1*F5)/aS[J1];
                                U2=(2*T2-4*U2*F5)/aS[J1];
                                toL314=true;
                            } else { U5=T1; U6=T2; }   // L288
                        } else { U5=F5*U1+T1; U6=F5*U2+T2; }
                        if(!toL314){
                            P1=P1-1; S87();        // L291
                            U1=(T1-U5)/aS[J2]; U2=(T2-U6)/aS[J2];
                            P1=P1+1; P3=P2; P2=P2-1; P4i=J1;
                            S87();
                            U3=T1; U4=T2;
                            if(F8>=1){ T1=U5; T2=U6; }
                            else { P1=P1-1; S87(); }   // L308
                            U1=U1+(U3-T1)/aS[J1];      // L311
                            U2=U2+(U4-T2)/aS[J1];
                        }
                        int ix=GETREF(I,J);        // L314
                        aZR[ix]=(float)(aZR[ix]+K*(D1+U1));
                        aZI[ix]=(float)(aZI[ix]+K*(D2+U2));
                    }
                    // L317
                    if(J<I) continue;
                    if(F8==0) continue;
                    aZR[GETREF(J,I)]=aZR[GETREF(I,J)];
                    aZI[GETREF(J,I)]=aZI[GETREF(I,J)];
                    P1=J+1;
                    if(P1>N) continue;
                    int P1i=(int)P1;
                    if(REFACI(P1i,1)!=REFACI(P1i,2)) continue;
                    if(REFACI(P1i,2)!=REFACI(J,2)){
                        if(REFACI(P1i,2)!=-REFACI(J,2)) continue;
                        if((aCA[J2]+aCB[J2])!=0) continue;
                    }
                    P2=I+1;                        // L328
                    if(P2>N) continue;
                    int P2i=(int)P2;
                    aZR[GETREF(P1i,P2i)]=aZR[GETREF(I,J)];
                    aZI[GETREF(P1i,P2i)]=aZI[GETREF(I,J)];
                }
            }
        }
        // ---- loads
        F5=2*P*F*1000000;
        for(I=1;I<=NL;I++){
            if(aLS[I]>=1){ error="S-domain"; return; }
            LR=aLA[1][I][1]; LI=aLA[2][I][1]; J=aLP[I];
            F2=1/M;
            if(REFACI(J,1)==-REFACI(J,2)){ if(K<0) F2=2/M; }
            if(J<1) continue;              // MMANA writes such a load into unused cell 0
            int ix=GETREF(J,J);
            aZR[ix]=(float)(aZR[ix]+F2*LI);
            aZI[ix]=(float)(aZI[ix]-F2*LR);
        }
        // Optional GPU LU: real cuSOLVER Cgetrf/Cgetrs, same FP32 as MMANA.
        // Form the ORIGINAL RHS before destructive factorization, then validate A*x.
        if(N>=1024)
        {
            var rhsR=new double[N+1];var rhsI=new double[N+1];
            for(int source=1;source<=NS;source++)
            {
                int pulse=aEi[source];
                double scale=1/M;
                if(REFACI(pulse,1)==-REFACI(pulse,2)) scale=2/M;
                rhsR[pulse]=scale*aM[source];
                rhsI[pulse]=-scale*aL[source];
            }
            _ct.ThrowIfCancellationRequested();
            _calculationProgress?.Report(new MmanaProgress("GPU LU",0,1));
            if(MmanaGpuLu.TrySolve(N,pmax,aZR,aZI,rhsR,rhsI,_ct,out var gpuRe,out var gpuIm,out string gpuStatus))
            {
                for(int pulse=1;pulse<=N;pulse++){aCR[pulse]=gpuRe[pulse];aCI[pulse]=gpuIm[pulse];}
                warnings.Add(gpuStatus);
                _calculationProgress?.Report(new MmanaProgress("GPU LU",1,1));
                return;
            }
            if(gpuStatus!="Optional AntennaCudaLu64.dll not installed" && gpuStatus!="GPU LU disabled")
                warnings.Add(gpuStatus+"; CPU LU fallback");
        }
        // ---- factor (single precision matrix, as in MMANA)
        for(K=1;K<N;K++){
            if((K&15)==0) _ct.ThrowIfCancellationRequested();
            NotifyProgress("LU",K,N-1);
            int ix1=GETREF(K,K);
            T=aZR[ix1]*aZR[ix1]+aZI[ix1]*aZI[ix1];
            I1=K;
            for(I=K+1;I<=N;I++){
                ix1=GETREF(I,K);
                T1=aZR[ix1]*aZR[ix1]+aZI[ix1]*aZI[ix1];
                if(T1>=T){ I1=I; T=T1; }
            }
            if(I1!=K){
                int a=GETREF(K,1), b=GETREF(I1,1);
                for(J=1;J<=N;J++){
                    float t1=aZR[a], t2=aZI[a];
                    aZR[a]=aZR[b]; aZI[a]=aZI[b]; aZR[b]=t1; aZI[b]=t2; a++; b++;
                }
            }
            aPi[K]=I1;
            // Each row below the pivot is independent for this elimination step.
            // Preserve the original single-precision arithmetic and pivot order.
            // Only the row updates are parallel; the pivot search and swaps remain sequential.
            int pivotRow = K;
            int pivotIndex = GETREF(pivotRow,pivotRow);
            double pivotNorm = T;
            float pivotRe = aZR[pivotIndex], pivotIm = aZI[pivotIndex];
            if(!(pivotNorm>0) || double.IsNaN(pivotNorm) || double.IsInfinity(pivotNorm))
                throw new ArithmeticException($"MMANA LU: singular/non-finite pivot at {pivotRow}/{N}");
            void EliminateRow(int row)
            {
                _ct.ThrowIfCancellationRequested();
                int ia=GETREF(row,pivotRow);
                double t1=(aZR[ia]*pivotRe+aZI[ia]*pivotIm)/pivotNorm;
                double t2=(aZI[ia]*pivotRe-aZR[ia]*pivotIm)/pivotNorm;
                aZR[ia]=(float)t1; aZI[ia]=(float)t2;
                int a=GETREF(row,pivotRow+1), b=GETREF(pivotRow,pivotRow+1);
                for(int col=pivotRow+1;col<=N;col++)
                {
                    if((col&1023)==0) _ct.ThrowIfCancellationRequested();
                    aZR[a]=(float)(aZR[a]-(aZR[b]*t1-aZI[b]*t2));
                    aZI[a]=(float)(aZI[a]-(aZR[b]*t2+aZI[b]*t1));
                    a++; b++;
                }
            }
            if(ParallelLu && N>=384 && N-pivotRow>=32 && Environment.ProcessorCount>1)
            {
                var options=new ParallelOptions {
                    CancellationToken=_ct,
                    MaxDegreeOfParallelism=Environment.ProcessorCount
                };
                Parallel.For(pivotRow+1,N+1,options,EliminateRow);
            }
            else for(int row=pivotRow+1;row<=N;row++) EliminateRow(row);
        }
        _calculationProgress?.Report(new MmanaProgress("обратный ход",1,1));
        // ---- right hand side
        for(I=1;I<=N;I++){ aCR[I]=0; aCI[I]=0; }
        for(J=1;J<=NS;J++){
            F2=1/M;
            if(REFACI(aEi[J],1)==-REFACI(aEi[J],2)) F2=2/M;
            aCR[aEi[J]]=F2*aM[J];
            aCI[aEi[J]]=-F2*aL[J];
        }
        for(K=1;K<N;K++){
            I1=aPi[K];
            if(I1!=K){ T1=aCR[K]; T2=aCI[K]; aCR[K]=aCR[I1]; aCI[K]=aCI[I1]; aCR[I1]=T1; aCI[I1]=T2; }
        }
        for(I=2;I<=N;I++){
            T1=0; T2=0; int a=GETREF(I,1);
            for(J=1;J<I;J++){
                T1=T1+aZR[a]*aCR[J]-aZI[a]*aCI[J];
                T2=T2+aZR[a]*aCI[J]+aZI[a]*aCR[J];
                a++;
            }
            aCR[I]=aCR[I]-T1; aCI[I]=aCI[I]-T2;
        }
        for(I=N;I>=1;I--){
            T1=0; T2=0;
            if(I!=N){
                int a=GETREF(I,I+1);
                for(J=I+1;J<=N;J++){
                    T1=T1+aZR[a]*aCR[J]-aZI[a]*aCI[J];
                    T2=T2+aZR[a]*aCI[J]+aZI[a]*aCR[J];
                    a++;
                }
            }
            int d=GETREF(I,I);
            T=aZR[d]*aZR[d]+aZI[d]*aZI[d];
            T1=aCR[I]-T1; T2=aCI[I]-T2;
            aCR[I]=(T1*aZR[d]+T2*aZI[d])/T;
            aCI[I]=(T2*aZR[d]-T1*aZI[d])/T;
        }
    }



    /// <summary>One physical conductor after MMANA CombWire expansion: original wire number (1-based),
    /// end points and radius in metres.</summary>
    public sealed record PhysicalWire(int Wire,double X1,double Y1,double Z1,double X2,double Y2,double Z2,double Radius);

    /// <summary>
    /// Geometry only: every MAA wire as physical conductors. A combined (stepped) wire with a negative
    /// radius is split into its pieces exactly as MMANA does (ComLib CombWire); wires with R = 0 are
    /// skipped, as in MMANA. Throws if a negative radius has no matching combined-wire set.
    /// </summary>
    public static List<PhysicalWire> ExpandCombWires(Model m)
    {
        var e=new MmanaReferenceEngine();
        e.RMD=m.fq>0?299.8/m.fq:1.0; e.DM1=m.DM1; e.DM2=m.DM2; e.SC=m.SC; e.EC=m.EC;
        var list=new List<PhysicalWire>();
        for(int i=0;i<m.wires.Count;i++)
        {
            var w=m.wires[i];
            if(w.R==0) continue;
            if(w.R<0)
            {
                PDef? pp=e.FindPP(m,w.R);
                if(pp==null) throw new FormatException($"Провод {i+1}: нет набора комбинированного провода для радиуса {w.R.ToString(CultureInfo.InvariantCulture)}.");
                var temp=new WDef[PPMAX*2+2];
                int n=e.CombWire(temp,pp,w);
                for(int k=0;k<n;k++)
                    list.Add(new PhysicalWire(i+1,temp[k].X1,temp[k].Y1,temp[k].Z1,temp[k].X2,temp[k].Y2,temp[k].Z2,Math.Abs(temp[k].R)));
            }
            else list.Add(new PhysicalWire(i+1,w.X1,w.Y1,w.Z1,w.X2,w.Y2,w.Z2,w.R));
        }
        return list;
    }

    /// <summary>Solves the model at freqMHz. Returns null and sets <see cref="error"/> on failure.</summary>
    System.Threading.CancellationToken _ct;
    IProgress<MmanaProgress>? _calculationProgress;
    void NotifyProgress(string phase,int current,int total)
    {
        if(total>0 && (current==1 || current==total || (current % Math.Max(1,total/100))==0))
            _calculationProgress?.Report(new MmanaProgress(phase,current,total));
    }

    /// <summary>
    /// Row updates of the LU factorization run in parallel (same arithmetic and pivot order as the
    /// sequential loop). Tests switch it off to check that both give identical results.
    /// </summary>
    public static bool ParallelLu { get; set; }=true;

    public Result? Solve(Model m,double freqMHz,System.Threading.CancellationToken ct=default,IProgress<MmanaProgress>? progress=null)
    {
        _ct=ct;
        _calculationProgress=progress;
        error=null; warnings.Clear();
        foreach(WDef w in m.wires){ w.PNo=0; w.PMax=0; }
        if(!InitAntData(m,freqMHz)) return null;
        S196();
        CRd=aCR[aEi[1]]; CI=aCI[aEi[1]];
        T=CRd*CRd+CI*CI;
        double r=(aL[1]*CRd+aM[1]*CI)/T;
        double x=(aM[1]*CRd-aL[1]*CI)/T;
        var currents=new List<PulseCurrent>(N);
        for(int p=1;p<=N;p++)
        {
            int jp=2*aWi[p]-1+p;
            bool ground=REFACI(p,1)==-REFACI(p,2);
            double dx=0,dy=0,dz=0;
            for(int e=1;e<=2;e++)
            {
                int c=REFACI(p,e); int lw=Math.Abs(c); double f=SGNi(c)*aS[lw]/2;
                if(ground && f<0) continue;              // S621: only the upper half of a grounded end
                dx+=f*aCA[lw]; dy+=f*aCB[lw]; dz+=f*aCG[lw];
            }
            if(ground){ dx=0; dy=0; dz*=2; }             // S621 L742: the image doubles the vertical part
            currents.Add(new PulseCurrent(aX[jp],aY[jp],aZ[jp],dx,dy,dz,
                (aX[jp-1]+aX[jp])/2,(aY[jp-1]+aY[jp])/2,(aZ[jp-1]+aZ[jp])/2,
                (aX[jp]+aX[jp+1])/2,(aY[jp]+aY[jp+1])/2,(aZ[jp]+aZ[jp+1])/2,
                aCR[p],aCI[p],ground));
        }
        var sources=new List<SourceResult>(NS);
        for(int s=1;s<=NS;s++)
        {
            double cr=aCR[aEi[s]], ci=aCI[aEi[s]], t=cr*cr+ci*ci;
            double rs=t>0?(aL[s]*cr+aM[s]*ci)/t:double.NaN;
            double xs=t>0?(aM[s]*cr-aL[s]*ci)/t:double.NaN;
            sources.Add(new SourceResult(s,m.sources[s-1].PLUS,aL[s],aM[s],cr,ci,rs,xs));
        }
        return new Result(r,x,CRd,CI,N,NW,warnings.ToArray(),currents,sources);
    }

    // Keep the exact MMANA pulse-location spelling after stack cloning.
    private static string PulseName(int wire,char position,int offset)
    {
        char pos=char.ToLowerInvariant(position);
        if(pos is not ('b' or 'c' or 'e'))throw new FormatException("Invalid pulse position: "+position);
        return "w"+wire.ToString(CultureInfo.InvariantCulture)+pos+
            (offset==0?"":offset>0?"+"+offset.ToString(CultureInfo.InvariantCulture):offset.ToString(CultureInfo.InvariantCulture));
    }

    /// <summary>Parses MAA text and solves at the file frequency (or freqMHz).</summary>
    public static (Result? Result,string? Error) SolveText(string text,double? freqMHz=null,bool galCompat=true,
        System.Threading.CancellationToken ct=default,IProgress<MmanaProgress>? progress=null)
    {
        Model m;
        try { m=Parse(text,galCompat); } catch(Exception ex) { return (null,ex.Message); }
        // A compact MMANA Make Stack must be expanded BEFORE Tei segmentation and
        // MININEC pulse resolution. Previously this returned an error and the UI
        // silently fell back to a different solver, changing Zin and radiation.
        if(m.stack)
        {
            try
            {
                MaaModel expanded=MaaParser.Parse(text);
                if(!expanded.StackExpanded || expanded.HasUnexpandedTapers)
                    return (null,"Make Stack expansion unavailable (or combined wires require special handling)");
                var full=new Model {
                    fq=m.fq, DM1=m.DM1, DM2=m.DM2, SC=m.SC, EC=m.EC,
                    groundType=m.groundType, antHeight=m.antHeight,
                    wireLoss=m.wireLoss, GalEndPulse=m.GalEndPulse,
                    ConnectTolerance=m.ConnectTolerance,
                    stack=false, unsupportedLoad=m.unsupportedLoad
                };
                foreach(var w in expanded.Wires)
                    full.wires.Add(new WDef { X1=w.X1,Y1=w.Y1,Z1=w.Z1,
                        X2=w.X2,Y2=w.Y2,Z2=w.Z2,R=w.RadiusMetres,SEG=w.Tag });
                foreach(var x in expanded.Sources)
                    full.sources.Add(new CDef { PLUS=PulseName(x.WireNumber,x.Position,x.Offset),
                        DEG=x.PhaseDegrees,EV=x.RelativeVoltage });
                foreach(var x in expanded.Loads)
                {
                    var ld=new LDef { PLUS=PulseName(x.WireNumber,x.Position,x.Offset),TYPE=x.Kind };
                    if(x.Kind==0) { ld.A[0]=x.V1;ld.B[0]=x.V2;ld.A[1]=x.V3; }
                    else if(x.Kind==1) { ld.A[0]=x.V1;ld.B[0]=x.V2; }
                    else return (null,$"Unsupported load type {x.Kind} in Make Stack");
                    full.loads.Add(ld);
                }
                m=full;
            }
            catch(OperationCanceledException) { throw; }
            catch(Exception ex) { return (null,"Make Stack conversion: "+ex.Message); }
        }
        if(m.unsupportedLoad) return (null,"S-domain loads are not supported by the MMANA core");
        var e=new MmanaReferenceEngine();
        var r=e.Solve(m,freqMHz ?? m.fq,ct,progress);
        return (r,e.error);
    }

    public static string Decode(byte[] bytes)
    {
        try { return new UTF8Encoding(false,true).GetString(bytes).TrimStart('\ufeff'); }
        catch(DecoderFallbackException)
        {
            var sb=new StringBuilder(bytes.Length);
            foreach(byte c in bytes)
            {
                if(c<0x80) sb.Append((char)c);
                else if(c>=0xC0) sb.Append((char)(0x0410+c-0xC0));
                else sb.Append(c switch { 0xA8=>'Ё', 0xB8=>'ё', 0xB9=>'№', 0x97=>'—', 0x96=>'–', 0xAB=>'«', 0xBB=>'»', _=>(char)c });
            }
            return sb.ToString();
        }
    }

    static readonly Regex NumRx=new Regex("^[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?$",RegexOptions.CultureInvariant);
    static double? Num(string s)
    {
        string t=s.Trim(); if(t.Length==0) return null;
        t=t.Replace('D','E').Replace('d','e');
        if(NumRx.IsMatch(t)) return double.Parse(t,NumberStyles.Float,CultureInfo.InvariantCulture);
        string t2=t.Replace(',','.');
        if(NumRx.IsMatch(t2)) return double.Parse(t2,NumberStyles.Float,CultureInfo.InvariantCulture);
        return null;
    }
    static List<double> Nums(string s)
    {
        var o=new List<double>();
        foreach(string x in Regex.Split(s.Trim(),"[,; \\t]+")){ var v=Num(x); if(v.HasValue) o.Add(v.Value); }
        return o;
    }
    static bool IsSection(string l){ string s=l.Trim(); return s.StartsWith("*")||s.StartsWith("$$$")||s.StartsWith("###"); }
    static bool Named(string l,params string[] keys)
    {
        string s=l.Trim().ToLowerInvariant();
        if(!IsSection(s)) return false;
        foreach(string k in keys) if(s.Contains(k)) return true;
        return false;
    }
    static int NextData(string[] L,int i){ while(i<L.Length && L[i].Trim().Length==0) i++; return i; }
    static string LatinPulse(string s)
    {
        var b=new StringBuilder();
        foreach(char ch in s)
        {
            if(char.IsWhiteSpace(ch)) continue;
            switch(ch){ case 'в': case 'В': b.Append('b'); break; case 'с': case 'С': b.Append('c'); break; case 'е': case 'Е': b.Append('e'); break; default: b.Append(ch); break; }
        }
        return b.ToString();
    }
    static readonly Regex PulseRx=new Regex("^\\s*(w\\s*\\d+\\s*[bceвсеВСЕ]\\s*[+-]?\\d*)",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);

    /// <summary>MAA reader. galCompat: MMANA-GAL uses at least 2 edge cells (EC) for tapered wires.</summary>
    public static Model Parse(string text,bool galCompat)
    {
        string[] L=text.Replace("\r\n","\n").Replace('\r','\n').Split('\n');
        var m=new Model();
        int wh=-1;
        for(int i=0;i<L.Length;i++) if(Named(L[i],"wire","провод")){ wh=i; break; }
        if(wh<0) throw new FormatException("wires section not found");
        for(int i=0;i<wh;i++){ var v=Num(L[i]); if(v.HasValue) m.fq=v.Value; }
        int c=NextData(L,wh+1);
        if(c>=L.Length) throw new FormatException("wire count missing");
        var cnt=Nums(L[c]);
        if(cnt.Count==0) throw new FormatException("wire count missing");
        int nw=(int)Math.Round(cnt[0]);
        if(cnt.Count>=6 && Math.Round(cnt[1])*Math.Round(cnt[2])>1) m.stack=true;
        int ii=c+1;
        while(m.wires.Count<nw && ii<L.Length)
        {
            string s=L[ii++].Trim();
            if(s.Length==0) continue;
            if(IsSection(s)) break;
            var v=Nums(s);
            if(v.Count<7) continue;
            var w=new WDef{ X1=v[0],Y1=v[1],Z1=v[2],X2=v[3],Y2=v[4],Z2=v[5],R=v[6] };
            w.SEG=v.Count>=8?(int)Math.Round(v[7]):-1;
            m.wires.Add(w);
        }
        if(m.wires.Count!=nw) throw new FormatException("wire count mismatch");
        for(int k=0;k<L.Length;k++)
        {
            if(Named(L[k],"segment","сегм"))
            {
                int q=NextData(L,k+1);
                var v=q<L.Length?Nums(L[q]):new List<double>();
                if(v.Count>=4){ m.DM1=(int)Math.Round(v[0]); m.DM2=(int)Math.Round(v[1]); m.SC=v[2]; m.EC=(int)Math.Round(v[3]); }
                break;
            }
        }
        if(galCompat && m.EC<2) m.EC=2;
        if(galCompat){ m.GalEndPulse=true; m.ConnectTolerance=1e-5; }
        for(int k=0;k<L.Length;k++)
        {
            string t=L[k].ToLowerInvariant();
            if(t.Contains("g/h")||t.Contains("azel")||t.Contains("az/el"))
            {
                int q=NextData(L,k+1);
                var v=q<L.Length?Nums(L[q]):new List<double>();
                if(v.Count>=1) m.groundType=(int)Math.Round(v[0]);
                if(v.Count>=2) m.antHeight=v[1];
                if(v.Count>=3) m.wireLoss=(int)Math.Round(v[2]);
                break;
            }
        }
        for(int k=0;k<L.Length;k++)
        {
            string t=L[k].ToLowerInvariant();
            if(t.Contains("taper wire set")||(t.Contains("комб")&&t.Contains("пров")))
            {
                int a=NextData(L,k+1);
                var h=a<L.Length?Nums(L[a]):new List<double>();
                int n=h.Count==0?0:(int)Math.Round(h[0]);
                int j=a+1;
                for(int q=0;q<n;q++)
                {
                    j=NextData(L,j);
                    if(j>=L.Length) break;
                    var v=Nums(L[j]); j++;
                    if(v.Count<2) continue;
                    var p=new PDef{ RR=v[0], Type=(int)Math.Round(v[1]) };
                    for(int r=2,idx=0; r+1<v.Count && idx<PPMAX; r+=2,idx++){ p.L[idx]=v[r]; p.R[idx]=v[r+1]; }
                    m.psets.Add(p);
                }
                break;
            }
        }
        int sh=-1; for(int k=0;k<L.Length;k++) if(Named(L[k],"source","источ","feed","generator")){ sh=k; break; }
        if(sh>=0)
        {
            for(int j=sh+1;j<L.Length && !IsSection(L[j]);j++)
            {
                var mm=PulseRx.Match(L[j]);
                if(!mm.Success) continue;
                var cd=new CDef{ PLUS=LatinPulse(mm.Groups[1].Value) };
                var v=Nums(L[j].Substring(mm.Index+mm.Length));
                cd.DEG=v.Count>0?v[0]:0.0; cd.EV=v.Count>1?v[1]:1.0;
                m.sources.Add(cd);
            }
        }
        int lh=-1; for(int k=0;k<L.Length;k++) if(Named(L[k],"load","нагруз")){ lh=k; break; }
        if(lh>=0)
        {
            for(int j=lh+1;j<L.Length && !IsSection(L[j]);j++)
            {
                var mm=PulseRx.Match(L[j]);
                if(!mm.Success) continue;
                var v=Nums(L[j].Substring(mm.Index+mm.Length));
                if(v.Count==0) continue;
                var ld=new LDef{ PLUS=LatinPulse(mm.Groups[1].Value), TYPE=(int)Math.Round(v[0]) };
                if(ld.TYPE==0){ ld.A[0]=v.Count>1?v[1]:0; ld.B[0]=v.Count>2?v[2]:0; ld.A[1]=v.Count>3?v[3]:0; }
                else if(ld.TYPE==1){ ld.A[0]=v.Count>1?v[1]:0; ld.B[0]=v.Count>2?v[2]:0; }
                else m.unsupportedLoad=true;
                m.loads.Add(ld);
            }
        }
        return m;
    }
    // ------------------------------------------------------------ self test
    // Reference values: original MMANA C code (mininec3.cpp + ComLib.cpp) compiled from source.
    const string SelfTest_DP20 = """
Dipole 20 m
*
14.05
* Провода *
1
0.0,	-5.17,	0.0,	0.0,	5.17,	0.0,	0.001,	-1
*** Источ. ***
1,	1
w1c,	0.0,	1.0
*** Нагрузка ***
0,	1
*** Автосегм ***
400,	40,	2.0,	1
*G/H/M/R/AzEl/X*
0,	20.0,	0,	50.0,	120,	60,	0
""";
    const string SelfTest_3EL20 = """
Rele 20m (30mm/25mm/20mm Pipe)
*
14.15
* Провода *
3
0.0,	-5.245,	0.0,	0.0,	5.245,	0.0,	-0.001,	-1
2.6,	-5.0,	0.0,	2.6,	5.0,	0.0,	-0.001,	-1
-2.6,	-5.45,	0.0,	-2.6,	5.45,	0.0,	-0.001,	-1
*** Источ. ***
1,	1
w1c,	0.0,	1.0
*** Нагрузка ***
0,	1
*** Автосегм ***
400,	50,	2.0,	1
*G/H/M/R/AzEl/X*
2,	20.0,	0,	50.0,	120,	60,	0
$$$ Установки комб. пров. $$$ 
1
-0.001,	2,	1.8,	0.015,	1.8,	0.0125,	99999.9,	0.01
""";
    const string SelfTest_INVERTED_GP = """
inverted GP
*
14.15
***Wires***
5
0.0,	0.0,	0.0,	0.0,	0.0,	7.6,	0.015,	-1
0.0,	0.0,	7.6,	4.31,	0.0,	4.7,	0.001,	-1
0.0,	0.0,	7.6,	-4.31,	0.0,	4.7,	0.001,	-1
0.0,	0.0,	7.6,	0.0,	4.31,	4.7,	0.001,	-1
0.0,	0.0,	7.6,	0.0,	-4.31,	4.7,	0.001,	-1
*** Source ***
1,	1
w1e,	0.0,	1.0
*** Load ***
1,	1
w1e,	0,	3.6,	0.0,	0.0
*** Segmentation ***
400,	40,	2.0,	1
*** G/H/M/R/AzEl/X ***
2,	0.0,	0,	50.0,	60,	20,	0.0
""";
    const string SelfTest_TRAP_14_21_GP = """
 Vertical 14 -21 MHz. 
*
14.15
* Провода *
2
0.0,	0.0,	3.7,	0.0,	0.0,	5.2,	0.006,	-1
0.0,	0.0,	0.0,	0.0,	0.0,	3.7,	0.006,	-1
*** Источ. ***
1,	1
w2b,	0.0,	1.0
*** Нагрузка ***
2,	1
w1b,	0,	1.408992,	40.0,	300.0
w2b,	0,	0.0,	140.0,	0.0
*** Автосегм ***
400,	40,	2.0,	1
*G/H/M/R/AzEl/X*
2,	0.0,	0,	50.0,	120,	60,	0
### Коммент. ###
Two bahd vertical with trap/ feeder 50Ohm.
In the feeding point is tuning capacitor 140 pF.
El lenght in both bans - 0.28 lambda. 
 by DL2KQ

""";
    const string SelfTest_COIL_VERTICAL = """
Coil vertical
*
7.02
***Wires***
15
0.0,	0.0,	0.03,	0.0,	0.0,	2.05,	8.000e-04,	-1
0.0,	0.0,	2.05,	0.02,	0.0,	2.05,	8.000e-04,	-1
0.02,	0.0,	2.05,	0.02,	0.0,	0.1,	8.000e-04,	-1
0.02,	0.0,	0.1,	-0.02,	0.0,	0.1,	8.000e-04,	-1
-0.02,	0.0,	0.1,	-0.02,	0.0,	2.07,	8.000e-04,	-1
0.0,	0.0,	0.03,	0.04,	0.0,	0.08,	8.000e-04,	-1
-0.02,	0.0,	2.07,	0.04,	0.0,	2.07,	8.000e-04,	-1
0.04,	0.0,	2.07,	0.04,	0.0,	0.08,	8.000e-04,	-1
0.04,	0.0,	0.08,	-0.04,	0.0,	0.08,	8.000e-04,	-1
-0.04,	0.0,	0.08,	-0.04,	0.0,	2.09,	8.000e-04,	-1
-0.04,	0.0,	2.09,	0.06,	0.0,	2.09,	8.000e-04,	-1
0.06,	0.0,	2.09,	0.06,	0.0,	0.06,	8.000e-04,	-1
0.06,	0.0,	0.06,	-0.06,	0.0,	0.06,	8.000e-04,	-1
-0.06,	0.0,	0.06,	-0.06,	0.0,	0.7,	8.000e-04,	-1
0.0,	0.0,	0.0,	0.0,	0.0,	0.03,	8.000e-04,	-1
*** Source ***
1,	1
w6b,	0.0,	1.0
*** Load ***
2,	1
w6c,	0,	0.0,	17.6,	0.0
w15c,	1,	10.0,	0.0
*** Segmentation ***
800,	80,	2.0,	4
*** G/H/M/R/AzEl/X ***
2,	0.0,	1,	50.0,	120,	60,	0.0
### Comment ###
Load 2 - GND loss
""";
    /// <summary>name -> R, X, pulses (EC from file) followed by R, X, pulses (galCompat: EC &gt;= 2).</summary>
    static readonly Dictionary<string,(string Text,double[] Expected)> SelfTestCases=new Dictionary<string,(string,double[])>
    {
        ["DP20"]=(SelfTest_DP20,new double[]{71.4915401, -1.95278360, 23, 71.5074962, -1.91562566, 25}),
        ["3EL20"]=(SelfTest_3EL20,new double[]{17.0018217, 0.297844769, 79, 17.0569299, 0.163103663, 85}),
        ["INVERTED_GP"]=(SelfTest_INVERTED_GP,new double[]{59.0488699, 291.346617, 74, 51.5466573, 0.00222115733, 84}),
        ["TRAP_14_21_GP"]=(SelfTest_TRAP_14_21_GP,new double[]{52.5797289, 1.29257169, 18, 52.7731969, 1.82948916, 22}),
        ["COIL_VERTICAL"]=(SelfTest_COIL_VERTICAL,new double[]{47.2709319, -48.7309651, 111, 47.2709319, -48.7309651, 111})
    };

    /// <summary>Runs the embedded models in both modes and compares with the original C code.</summary>
    public static string SelfTest()
    {
        var sb=new StringBuilder();
        int failures=0;
        foreach(var kv in SelfTestCases)
        {
            for(int mode=0;mode<2;mode++)
            {
                var (r,err)=SolveText(kv.Value.Text,null,mode==1);
                double eR=kv.Value.Expected[mode*3], eX=kv.Value.Expected[mode*3+1]; int eN=(int)kv.Value.Expected[mode*3+2];
                if(r==null){ failures++; sb.Append($"{kv.Key} gal={mode==1}: ERROR {err}\n"); continue; }
                double d=Math.Sqrt((r.R-eR)*(r.R-eR)+(r.X-eX)*(r.X-eX))/Math.Max(1e-9,Math.Sqrt(eR*eR+eX*eX));
                bool ok=d<1e-6 && r.Pulses==eN;
                if(!ok) failures++;
                sb.Append(string.Format(CultureInfo.InvariantCulture,"{0} gal={1}: {2}  {3:F7}{4:+0.0000000;-0.0000000}j ({5})  expected {6:F7}{7:+0.0000000;-0.0000000}j ({8})\n",
                    kv.Key,mode==1,ok?"OK":"FAIL",r.R,r.X,r.Pulses,eR,eX,eN));
            }
        }
        sb.Append(failures==0?"SELF TEST PASSED\n":$"SELF TEST FAILED: {failures}\n");
        return sb.ToString();
    }
}
