﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;

namespace AntennaCalculator.Core;

/// <summary>
/// Experimental, REAL pulse-matrix MININEC physics ported from Android
/// MmanaMininecSolver.kt 1.19.268. It forms/solves complex mutual coupling
/// matrix, rather than fitting R/X to expected impedances.
/// Preview physical image expansion for MMANA PEC (G=1) and Tei segmentation for Make Stack.
/// G=2 is supported ONLY through an explicit user opt-in PEC-current approximation.
/// This is the MMANA/MININEC current/Z convention, NOT a rigorous finite-earth impedance solution.
/// Signed CombWire/Taper radii remain strictly unsupported.
/// Unsupported models throw and NEVER return estimated impedances.
/// </summary>
public static class MininecPulseSolver
{
    public enum RealEarthMode { Strict, MmanaPecCurrentApproximation }
    public enum PecJunctionMode { LegacyStar, MirroredBalancedTree }
    // Explicit conductor choice: never infer metal from unverified MMANA M-code.
    public enum ConductorMaterial { Pec, Copper, Aluminum, Silver, Brass, StainlessSteel }
    public static double Conductivity(ConductorMaterial material) => material switch
    {
        ConductorMaterial.Copper => 5.8e7,
        ConductorMaterial.Aluminum => 3.5e7,
        ConductorMaterial.Silver => 6.3e7,
        ConductorMaterial.Brass => 1.5e7,
        ConductorMaterial.StainlessSteel => 1.4e6,
        _ => double.PositiveInfinity
    };
    public static Complex SkinImpedancePerMetre(double frequencyMHz, double radiusMetres, ConductorMaterial material)
    {
        if(material==ConductorMaterial.Pec) return Complex.Zero;
        if(radiusMetres<=0 || frequencyMHz<=0) throw new ArgumentOutOfRangeException(nameof(radiusMetres));
        double sigma=Conductivity(material), omega=2*Math.PI*frequencyMHz*1e6;
        // Surface-impedance approximation for a good nonmagnetic conductor, thick vs skin depth.
        // Peak phasor convention: Zs=(1+j)*sqrt(omega*mu0/(2*sigma)).
        const double mu0=4e-7*Math.PI;
        double skinDepth=Math.Sqrt(2/(omega*mu0*sigma));
        if(radiusMetres < 3*skinDepth)
            throw new NotSupportedException($"Радиус {radiusMetres:G5} м слишком мал относительно скин-слоя {skinDepth:G5} м для приближения толстого проводника ({material}).");
        double resistance=Math.Sqrt(omega*mu0/(2*sigma))/(2*Math.PI*radiusMetres);
        return new Complex(resistance,resistance);
    }

    private const double Cmhz=299.8;
    private const int DirectSolveLimit=360; // proven preview route: scaled pivoted Gaussian elimination
    private const int MaxPulses=10000; // large dense-matrix route; governed by 64-bit process and runtime memory budget
    private const int DirectFallbackLimit=2600; // avoid an extra ~N² copy and O(N³) LU on large systems
    private static void CheckLargeMatrixBudget(int n)
    {
        long elements=checked((long)n*n);
        long matrixBytes=checked(elements*2*sizeof(double));
        if(!Environment.Is64BitProcess)
            throw new NotSupportedException($"MININEC: {n} импульсов требуют 64-битную сборку приложения (win-x64). Без изменения сегментации.");
        // Matrix has two double[N*N] arrays. Allow workspace, allocations, and UI headroom.
        long headroom=checked(matrixBytes+Math.Max(384L*1024*1024,matrixBytes/2));
        var info=GC.GetGCMemoryInfo();
        long available=info.TotalAvailableMemoryBytes;
        if(available>0 && info.MemoryLoadBytes>0)
            available=Math.Min(available, Math.Max(0,available-info.MemoryLoadBytes));
        if(available>0 && available<headroom)
            throw new NotSupportedException($"MININEC: {n} импульсов требуют около {headroom/1048576.0:0} МиБ свободной памяти (матрица {matrixBytes/1048576.0:0} МиБ). Доступно по оценке GC {available/1048576.0:0} МиБ. Расчёт остановлен до выделения матрицы, геометрия не менялась.");
    }
    private readonly record struct V(double X,double Y,double Z)
    {
        public static V operator +(V a,V b)=>new(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static V operator -(V a,V b)=>new(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
        public static V operator *(V a,double s)=>new(a.X*s,a.Y*s,a.Z*s);
        public double Dot(V b)=>X*b.X+Y*b.Y+Z*b.Z;
        public double Norm()=>Math.Sqrt(Dot(this));
    }
    private sealed record Segment(int Wire,int Id,V A,V B,double Length,V Dir,double Radius);
    private sealed record EndRef(int Wire,bool AtStart,V Point,Segment Segment);
    private readonly record struct PulseRef(int Index,double Sign);
    private sealed record Pulse(int Local,V Point,V EndNeg,V EndPos,double LenNeg,double LenPos,
        V DirNeg,V DirPos,double RadNeg,double RadPos,int WireNeg,int WirePos)
    {
        public double Len(int side)=>side==0?LenNeg:LenPos;
        public V End(int side)=>side==0?EndNeg:EndPos;
        public V Dir(int side)=>side==0?DirNeg:DirPos;
        public double Rad(int side)=>side==0?RadNeg:RadPos;
        public int Wire(int side)=>side==0?WireNeg:WirePos;
        public V EndSeg(double ds)=>Point+(ds>0?EndPos-Point:EndNeg-Point)*Math.Abs(ds);
        public (V A,V B) DVecs(double ds)=>ds<0?(EndSeg(ds),Point):(Point,EndSeg(ds));
        public bool SimpleInternal=>WireNeg==WirePos;
    }
    // All voltages and powers use the relative MMANA excitation amplitudes, not calibrated watts.
    public sealed record PortResult(int PortNumber,int WireNumber,char Position,int Offset,
        double PhaseDegrees,double VoltageMagnitude,double CurrentMagnitude,double CurrentPhaseDegrees,
        double ROhm,double XOhm,double ActivePower,double ReactivePower)
    {
        public double Swr50 { get {
            Complex z=new Complex(ROhm,XOhm);
            if(!double.IsFinite(ROhm)||!double.IsFinite(XOhm)||ROhm<=0)return double.NaN;
            double gamma=Complex.Abs((z-50.0)/(z+50.0));
            return gamma<1.0?(1.0+gamma)/(1.0-gamma):double.NaN;
        }}
    }

    public static (IReadOnlyList<PortResult> Ports,double ActivePower,double ReactivePower) DiagnosePorts(
        IReadOnlyList<MaaSource> sources,IReadOnlyList<Complex> voltages,IReadOnlyList<Complex> orientedCurrents)
    {
        if(sources.Count!=voltages.Count||sources.Count!=orientedCurrents.Count)
            throw new ArgumentException("Разное количество фазированных источников и токов.");
        var output=new List<PortResult>(sources.Count);
        double sumActive=0,sumReactive=0;
        for(int i=0;i<sources.Count;i++)
        {
            var v=voltages[i];var current=orientedCurrents[i];
            Complex z=current.Magnitude>1e-18?v/current:new Complex(double.NaN,double.NaN);
            Complex p=0.5*v*Complex.Conjugate(current);
            sumActive+=p.Real;sumReactive+=p.Imaginary;
            var src=sources[i];
            output.Add(new PortResult(i+1,src.WireNumber,src.Position,src.Offset,src.PhaseDegrees,
                v.Magnitude,current.Magnitude,Math.Atan2(current.Imaginary,current.Real)*180.0/Math.PI,
                z.Real,z.Imaginary,p.Real,p.Imaginary));
        }
        return (output,sumActive,sumReactive);
    }

    // Complex pulse currents from the simultaneous multi-source solution; never inferred from port impedances.
    // Diagnostic records reflect the ACTUAL stamped pulse and solved complex current.
    public sealed record LoadStampAudit(int WireNumber, char Position, int Offset, int PulseIndex,
        double PulseSign, bool AtGround, bool CoincidesWithSource,
        double ROhm, double XOhm, double MatrixDeltaReal, double MatrixDeltaImag,
        double CurrentReal, double CurrentImag, double LoadPowerReal, double LoadPowerReactive);

    public sealed record FieldSample(double X,double Y,double Z,double Dx,double Dy,double Dz,
        double RealCurrent,double ImagCurrent,int WireNeg=0,int WirePos=0,
        double NegX=double.NaN,double NegY=double.NaN,double NegZ=double.NaN,
        double PosX=double.NaN,double PosY=double.NaN,double PosZ=double.NaN,
        bool GroundPulse=false);

    public sealed record Result(double FrequencyMHz,double ROhm,double XOhm,int PulseCount,double RelativeResidual,
        int JunctionCount,int SourceCount,int LoadCount,string GroundMethod = "", string LinearSolver = "", int Iterations = 0,
        IReadOnlyList<PortResult>? Ports = null,double TotalActivePower = double.NaN,double TotalReactivePower = double.NaN, IReadOnlyList<FieldSample>? FieldSamples = null, IReadOnlyList<LoadStampAudit>? LoadStamps = null, double PhysicalConductorLossPower = 0, double MatrixConductorLossPower = 0, int PhysicalConductorHalves = 0)
    {
        public double Swr(double z0)
        {
            if(z0<=0)throw new ArgumentOutOfRangeException(nameof(z0));
            Complex gamma=(new Complex(ROhm,XOhm)-z0)/(new Complex(ROhm,XOhm)+z0);
            double g=gamma.Magnitude;return g>=1?double.PositiveInfinity:(1+g)/(1-g);
        }
        public Complex Reflection(double z0)=> (new Complex(ROhm,XOhm)-z0)/(new Complex(ROhm,XOhm)+z0);
    }
    // Raw matrix coefficients use the internal MININEC normalization, NOT ohms.
    // Capture BEFORE destructive Gaussian elimination; diagnostic opt-in only.
    public sealed record MatrixEnergyAudit(int Size,
        double KernelTransposeRelative,double KernelAdjointRelative,
        double LoadedTransposeRelative,double LoadedAdjointRelative,
        double SourceQuadraticReal,double SourceQuadraticImag,
        double MatrixQuadraticReal,double MatrixQuadraticImag,
        double QuadraticDifferenceRelative,double PortActivePower,
        double StampedLoadsActivePower,double StampedConductorPower,
        double MinimumHermitianDiagonalReal,double MaxOffDiagonalAsymmetry,
        int MaxAsymmetryRow,int MaxAsymmetryColumn,double DirectSourceVoltageNorm,
        double MatrixRadiationQuadraticReal,double MatrixRadiationQuadraticImag);
    private static (double Transpose,double Adjoint,double MaxOff,int Row,int Column,double MinHermDiag)
        MatrixSymmetry(double[] re,double[] im,int n)
    {
        double t=0,h=0,norm=0,max=0;int mr=-1,mc=-1;
        double minDiag=double.PositiveInfinity;
        for(int i=0;i<n;i++)
        {
            minDiag=Math.Min(minDiag,re[i*n+i]);
            for(int j=0;j<n;j++)
            {
                int ij=i*n+j,ji=j*n+i;
                double ar=re[ij],ai=im[ij],br=re[ji],bi=im[ji];
                norm+=ar*ar+ai*ai;
                double d=(ar-br)*(ar-br)+(ai-bi)*(ai-bi);
                t+=d;h+=(ar-br)*(ar-br)+(ai+bi)*(ai+bi);
                if(d>max){max=d;mr=i;mc=j;}
            }
        }
        double scale=Math.Max(Math.Sqrt(norm),1e-200);
        return (Math.Sqrt(t)/scale,Math.Sqrt(h)/scale,Math.Sqrt(max)/scale,mr,mc,minDiag);
    }
    // Raw mutually coupled coefficients and their exact pulse geometry.
    // A is an internally normalized collocation matrix, not an impedance in ohms.
    public sealed record MutualPulseGeometry(int Index,int WireNegative,int WirePositive,
        double X,double Y,double Z,double NegX,double NegY,double NegZ,
        double PosX,double PosY,double PosZ,double LenNegative,double LenPositive,
        double RadiusNegative,double RadiusPositive,double DirNegX,double DirNegY,double DirNegZ,
        double DirPosX,double DirPosY,double DirPosZ,bool Junction);
    public sealed record MutualPairEntry(int I,int J,double AijReal,double AijImag,
        double AjiReal,double AjiImag,double RelativeDifference,double SignFlipRelativeDifference,
        double GeometricScaleRelativeDifference,
        MutualPulseGeometry Row,MutualPulseGeometry Column);
    public sealed record MutualPairAudit(int Size,double TransposeRelative,
        int MaxRow,int MaxColumn,IReadOnlyList<MutualPairEntry> Pairs);
    private static MutualPulseGeometry DescribePulse(Pulse p,int index)=>new(index,
        p.WireNeg,p.WirePos,p.Point.X,p.Point.Y,p.Point.Z,
        p.EndNeg.X,p.EndNeg.Y,p.EndNeg.Z,p.EndPos.X,p.EndPos.Y,p.EndPos.Z,
        p.LenNeg,p.LenPos,p.RadNeg,p.RadPos,
        p.DirNeg.X,p.DirNeg.Y,p.DirNeg.Z,p.DirPos.X,p.DirPos.Y,p.DirPos.Z,
        !p.SimpleInternal);
    private static MutualPairAudit InspectMutualPairs(Topology topo,double[] ar,double[] ai,int n)
    {
        var asym=MatrixSymmetry(ar,ai,n);
        var candidates=new List<(double Dist,int I,int J)>();
        for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)
        {
            double dr=ar[i*n+j]-ar[j*n+i],di=ai[i*n+j]-ai[j*n+i];
            candidates.Add((dr*dr+di*di,i,j));
        }
        // Force inclusion of (0,106), the pair flagged by v0.3.33.
        var selected=candidates.OrderByDescending(p=>p.Dist).Take(12).ToList();
        if(n>106 && !selected.Any(p=>p.I==0 && p.J==106))
            selected.Add(candidates.First(p=>p.I==0 && p.J==106));
        var entries=new List<MutualPairEntry>();
        foreach(var (_,i,j) in selected)
        {
            Complex a=new(ar[i*n+j],ai[i*n+j]), b=new(ar[j*n+i],ai[j*n+i]);
            double scale=Math.Max(1e-30,Math.Max(a.Magnitude,b.Magnitude));
            // Candidate sign and length weighting are diagnostics, NOT proof of reciprocity.
            var pi=topo.Pulses[i];var pj=topo.Pulses[j];
            double li=pi.LenNeg+pi.LenPos,lj=pj.LenNeg+pj.LenPos;
            entries.Add(new(i,j,a.Real,a.Imaginary,b.Real,b.Imaginary,
                (a-b).Magnitude/scale,(a+b).Magnitude/scale,
                (a*li-b*lj).Magnitude/Math.Max(1e-30,Math.Max(a.Magnitude*li,b.Magnitude*lj)),
                DescribePulse(pi,i),DescribePulse(pj,j)));
        }
        return new(n,asym.Transpose,asym.Row,asym.Column,entries);
    }
    // Pulse topology inspection only.  Coincident coordinates do NOT prove a
    // duplicate unknown: multiple legitimate junction pulses can share a node.
    // 1 nm coordinate quantization is diagnostic and never changes geometry.
    private static string AuditPulseTopology(Topology topo,int n,CancellationToken ct)
    {
        if(n<=2600)return string.Empty;
        const double coordinateGrid=1e-9;
        static (long,long,long) PointKey(V v)=>(
            (long)Math.Round(v.X/coordinateGrid),
            (long)Math.Round(v.Y/coordinateGrid),
            (long)Math.Round(v.Z/coordinateGrid));
        var groups=new Dictionary<(long,long,long),List<int>>();
        for(int i=0;i<n;i++)
        {
            if((i&255)==0)ct.ThrowIfCancellationRequested();
            var k=PointKey(topo.Pulses[i].Point);
            if(!groups.TryGetValue(k,out var ids))groups[k]=ids=new List<int>();
            ids.Add(i);
        }
        int groupsMany=0,additionalPulses=0,junctionGroups=0,internalGroups=0;
        int crossWireGroups=0,nearDuplicateSupports=0,maximumMultiplicity=0;
        var examples=new List<string>();
        bool SamePoint(V a,V b)=>PointKey(a)==PointKey(b);
        bool SameSupport(Pulse a,Pulse b)=>
            (SamePoint(a.EndNeg,b.EndNeg)&&SamePoint(a.EndPos,b.EndPos))||
            (SamePoint(a.EndNeg,b.EndPos)&&SamePoint(a.EndPos,b.EndNeg));
        foreach(var ids in groups.Values)
        {
            if(ids.Count<2)continue;
            groupsMany++;additionalPulses+=ids.Count-1;
            maximumMultiplicity=Math.Max(maximumMultiplicity,ids.Count);
            bool junction=ids.Any(id=>!topo.Pulses[id].SimpleInternal);
            if(junction)junctionGroups++;else internalGroups++;
            bool crossWire=ids.SelectMany(id=>new[]{topo.Pulses[id].WireNeg,topo.Pulses[id].WirePos})
                .Distinct().Skip(1).Any();
            if(crossWire)crossWireGroups++;
            int duplicatesHere=0;
            // Pair comparison limited to each coincident-node group, not N^2.
            for(int a=0;a<ids.Count;a++)for(int b=a+1;b<ids.Count;b++)
                if(SameSupport(topo.Pulses[ids[a]],topo.Pulses[ids[b]]))
                {nearDuplicateSupports++;duplicatesHere++;}
            if(examples.Count<6)
            {
                var wires=ids.SelectMany(id=>new[]{topo.Pulses[id].WireNeg+1,topo.Pulses[id].WirePos+1})
                    .Distinct().OrderBy(x=>x).Take(6);
                examples.Add($"#{ids[0]+1}:n={ids.Count},W={string.Join("/",wires)},"+
                    $"узел={(junction?1:0)},подобные={duplicatesHere}");
            }
        }
        return $"Топология (сетка координат 1 нм): совпадающих узлов={groupsMany}, " +
               $"доп. импульсов в них={additionalPulses}, максимум в узле={maximumMultiplicity}, " +
               $"с junction={junctionGroups}, только внутренние={internalGroups}, " +
               $"разные W={crossWireGroups}, пары с похожими опорами={nearDuplicateSupports}; " +
               $"примеры: {string.Join("; " ,examples)}. " +
               "Совпадение центров/опор НЕ доказывает избыточность токовой неизвестной; " +
               "изменений топологии нет.";
    }

    // Matrix-only inspection: no modification to A, b or the antenna geometry.
    // Sampled off-diagonal diagnostics avoid extra O(N^2) storage.
    private static string AuditLargeMatrix(double[] ar,double[] ai,Topology topo,int n,CancellationToken ct)
    {
        if(n<=2600)return string.Empty;
        double maxDiag=0,minDiag=double.PositiveInfinity,minRatio=double.PositiveInfinity;
        int weak=0,nonFinite=0,zero=0,strong=0,nearCoincident=0;
        int weakest=-1, strongestRow=-1,strongestCol=-1;
        double strongest=0;
        // At most 128 off-diagonal entries per row; deterministic stride.
        int stride=Math.Max(1,(n-1)/128);
        for(int i=0;i<n;i++)
        {
            if((i&127)==0)ct.ThrowIfCancellationRequested();
            int off=i*n+i;
            double d=Math.Sqrt(ar[off]*ar[off]+ai[off]*ai[off]);
            if(!double.IsFinite(d)){nonFinite++;continue;}
            if(d==0)zero++;
            maxDiag=Math.Max(maxDiag,d);minDiag=Math.Min(minDiag,d);
            double rowMax=0;
            for(int j=(i+1)%stride;j<n;j+=stride)
            {
                if(j==i)continue;
                int k=i*n+j;
                double z=Math.Sqrt(ar[k]*ar[k]+ai[k]*ai[k]);
                if(!double.IsFinite(z)){nonFinite++;continue;}
                if(z>rowMax)rowMax=z;
                if(z>strongest){strongest=z;strongestRow=i;strongestCol=j;}
            }
            double ratio=d/Math.Max(rowMax,1e-300);
            if(ratio<minRatio){minRatio=ratio;weakest=i;}
            if(ratio<0.1)weak++;
            if(rowMax>d*10)strong++;
            // Adjacent numerical indices only: topology may be ordered differently.
            if(i>0)
            {
                var a=topo.Pulses[i].Point;var b=topo.Pulses[i-1].Point;
                double dx=a.X-b.X,dy=a.Y-b.Y,dz=a.Z-b.Z;
                if(dx*dx+dy*dy+dz*dz<1e-24)nearCoincident++;
            }
        }
        return $"Матрица: |Aii| min={minDiag:E2} max={maxDiag:E2}; " +
               $"min diag/выборка offdiag={minRatio:E2} (имп.{weakest+1}); " +
               $"слабые диагонали={weak}, offdiag>10*diag={strong}, " +
               $"нулевые диагонали={zero}, NaN/Inf={nonFinite}; " +
               $"макс. выборка |Aij|={strongest:E2} ({strongestRow+1},{strongestCol+1}), " +
               $"совпад. соседние центры={nearCoincident}. " +
               "Offdiag проверен выборочно; эта диагностика НЕ доказывает обусловленность.";
    }

    private sealed class Topology
    {
        public readonly List<Pulse> Pulses=new();
        public readonly List<List<PulseRef>> Refs=new();
        public readonly HashSet<long> ConnectedPairs=new();
        public int JunctionCount;
    }
    public sealed record MatrixSnapshot(int Size,double[] Real,double[] Imag,double[] RhsReal,double[] RhsImag);
    public sealed record FullCoefficientCheck(int Row,int Column,int Steps,double BaseReal,double BaseImag,double IndependentReal,double IndependentImag,double VectorReal,double VectorImag,double ScalarReal,double ScalarImag);
    // Diagnostic-only, opt-in perturbation of one UNLOADED matrix coefficient.
    // Do not enable from the production UI.
    public sealed record MatrixElementProbe(int Row,int Column,double RelativeReal,double RelativeImag);
    public static Result Solve(MaaModel model,CancellationToken ct=default,double? segmentationReferenceMHz=null,double? frequencyMHzOverride=null,RealEarthMode realEarthMode=RealEarthMode.Strict,IProgress<string>? progress=null,PecJunctionMode pecJunctionMode=PecJunctionMode.MirroredBalancedTree,ConductorMaterial conductor=ConductorMaterial.Pec,Action<MatrixEnergyAudit>? matrixEnergyObserver=null,Action<MutualPairAudit>? mutualPairObserver=null,MatrixElementProbe? matrixElementProbe=null,Action<MatrixSnapshot>? matrixSnapshotObserver=null, Action<FullCoefficientCheck>? fullCoefficientObserver=null)
    {
        double operatingMHz=frequencyMHzOverride??model.FrequencyMHz;
        if(operatingMHz<=0||!double.IsFinite(operatingMHz))throw new NotSupportedException("Для расчёта нужна положительная частота MAA.");
        bool realEarth = model.GroundType is 2 or -1;
        if(realEarth && realEarthMode == RealEarthMode.Strict)
            throw new NotSupportedException("G=2: точная модель конечнопроводящей земли для Zin ещё не реализована. Чтобы испытать MMANA-совместимое приближение токов PEC, явно разреши его в настройках грунта. εr и σ на импеданс этого приближения НЕ влияют.");
        if(model.GroundType is not (0 or 1 or 2 or -1))throw new NotSupportedException($"Неизвестный тип земли MMANA G={model.GroundType}.");
        if(model.HasCompactStack && !model.StackExpanded)throw new NotSupportedException("Make Stack: геометрия не развёрнута из-за неизвестного режима размещения.");
        if(model.Wires.Any(w=>w.HasTaperReference))throw new NotSupportedException("CombWire/Taper: отрицательные радиусы требуют точной развёртки. Расчёт заблокирован.");
        // MMANA-GAL R=0: an INSULATING construction wire, excluded from the
        // EM system. Do not give it a fictitious finite conductor radius.
        // Compact active indices are required by PEC image expansion and source mapping.
        model=ExcludeMmanaInsulators(model);
        if(model.Sources.Count==0)throw new NotSupportedException("В модели нет действующего источника питания.");
        if(model.Sources.Any(s=>s.WireNumber<1||s.WireNumber>model.Wires.Count) || model.Loads.Any(l=>l.WireNumber<1||l.WireNumber>model.Wires.Count))
            throw new NotSupportedException("Источник или нагрузка находятся вне диапазона проводников.");
        if(model.SegmentationRecord.Length==0)throw new NotSupportedException("Не найдены параметры сегментации MMANA (DM1,DM2,SC,EC).");
        // Negative taper tags are handled by the same normal GalSegmentation path as Android.
        double lambda=Cmhz/operatingMHz;
        double referenceLambda=segmentationReferenceMHz is double f&&double.IsFinite(f)&&f>0?Cmhz/f:lambda;
        // PEC (MMANA G=1): explicitly unfold antenna plus reflected/reversed wires
        // as Android 1.19.268 does. The already expanded array is the physical model.
        // Image copies are NOT exposed to the UI or saved to the MAA geometry.
        int physicalWireCount=model.Wires.Count;
        // Android 1.19.268: for real earth, currents/Z use PEC imaging;
        // finite-earth eps/sigma enter only the separate radiation-pattern ground model.
        // For this preview we explicitly unfold BOTH PEC and opt-in G=2,
        // never label the G=2 result as a finite-soil impedance prediction.
        bool unfolded=model.GroundType==1 || realEarth;
        MaaModel workModel=unfolded?UnfoldPec(model,referenceLambda):model;
        Topology topo=Build(workModel,referenceLambda,ct,!unfolded,pecJunctionMode,unfolded?physicalWireCount:0);
        int n=topo.Pulses.Count;
        if(n<1||n>MaxPulses)throw new NotSupportedException($"MININEC: {n} импульсов; предел плотного решателя {MaxPulses}. Геометрия и сегментация не изменены.");
        if(n>DirectFallbackLimit)CheckLargeMatrixBudget(n);
        double matrixMiB=16.0*n*n/(1024.0*1024.0);
        progress?.Report($"MININEC: {n} импульсов; матрица {matrixMiB:0.#} МиБ; формирование коэффициентов…");
        PulseRef Resolve(int wire,char pos,int offset)
        {
            var refs=topo.Refs[wire-1];
            if(refs.Count==0)throw new NotSupportedException($"W{wire}: отсутствует проводящий импульс.");
            return refs[MininecSegmentation.PulseIndex(pos,refs.Count,offset)];
        }
        var resolved=workModel.Sources.Select(s=>(Source:s,Ref:Resolve(s.WireNumber,s.Position,s.Offset),
            Voltage:Complex.FromPolarCoordinates(s.RelativeVoltage,s.PhaseDegrees*Math.PI/180.0))).ToArray();
        var primary=resolved[0];
        var (ar,ai)=Matrix(topo,operatingMHz,ct,progress,fullCoefficientObserver);
        if(mutualPairObserver!=null)mutualPairObserver(InspectMutualPairs(topo,ar,ai,n));
        if(matrixElementProbe is not null)
        {
            if(matrixElementProbe.Row<0||matrixElementProbe.Row>=n||matrixElementProbe.Column<0||matrixElementProbe.Column>=n ||
               !double.IsFinite(matrixElementProbe.RelativeReal)||!double.IsFinite(matrixElementProbe.RelativeImag))
                throw new ArgumentOutOfRangeException(nameof(matrixElementProbe));
            int idx=matrixElementProbe.Row*n+matrixElementProbe.Column;
            // Relative complex scale: delta A = (relativeReal+j*relativeImag)*A_ij.
            double x=ar[idx],y=ai[idx];
            ar[idx]+=matrixElementProbe.RelativeReal*x-matrixElementProbe.RelativeImag*y;
            ai[idx]+=matrixElementProbe.RelativeReal*y+matrixElementProbe.RelativeImag*x;
        }

        var kernelSym=matrixEnergyObserver==null?default:MatrixSymmetry(ar,ai,n);
        double[]? kernelRe=matrixEnergyObserver==null?null:(double[])ar.Clone();
        double[]? kernelIm=matrixEnergyObserver==null?null:(double[])ai.Clone();
        double invM=1.0/(4.77783352*lambda);
        bool GroundPulse(int pulseId)
        {
            if(!unfolded)return false;
            Pulse p=topo.Pulses[pulseId];
            double tol=Math.Max(1e-8,lambda*1e-8);
            if(Math.Abs(p.Point.Z)>tol)return false;
            int a=p.WireNeg,b=p.WirePos;
            return (a>=0&&a<physicalWireCount&&b==a+physicalWireCount) ||
                (b>=0&&b<physicalWireCount&&a==b+physicalWireCount);
        }
        // Store each EXACT stamped conductor impedance; do not reconstruct wire
        // lengths using field display vectors or nearest-wire projection.
        var conductorStamps = new Complex[n];
        var physicalHalfResistances = new double[n];
        int physicalConductorHalves = 0;
        // Distributed conductor surface impedance. For a rooftop pulse each half
        // spans the pulse center to the outer half-segment endpoint. Their lengths
        // and radii can differ at a junction. The PEC ground image is stamped too,
        // because it is an unknown of the unfolded physical-equivalent matrix;
        // never count it again when reporting dissipation in the real antenna.
        if(conductor!=ConductorMaterial.Pec)
        {
            for(int pi=0;pi<n;pi++)
            {
                Pulse pulse=topo.Pulses[pi];
                Complex zNeg=SkinImpedancePerMetre(operatingMHz,pulse.RadNeg,conductor)*pulse.LenNeg*0.5;
                Complex zPos=SkinImpedancePerMetre(operatingMHz,pulse.RadPos,conductor)*pulse.LenPos*0.5;
                Complex zWire=zNeg+zPos;
                conductorStamps[pi]=zWire;
                // The unfolded image exists only to apply PEC boundary conditions.
                // In free space every half is real; above PEC use original wire IDs.
                bool realNeg=!unfolded || (pulse.WireNeg>=0 && pulse.WireNeg<physicalWireCount);
                bool realPos=!unfolded || (pulse.WirePos>=0 && pulse.WirePos<physicalWireCount);
                if(realNeg) { physicalHalfResistances[pi]+=zNeg.Real; physicalConductorHalves++; }
                if(realPos) { physicalHalfResistances[pi]+=zPos.Real; physicalConductorHalves++; }
                // Same voltage-normalized kernel convention as concentrated series loads.
                // Same voltage-normalized kernel convention as concentrated series loads.
                int diagonal=pi*n+pi;
                ar[diagonal]+=zWire.Imaginary*invM;
                ai[diagonal]-=zWire.Real*invM;
            }
        }
        var loadStampAudit = new List<LoadStampAudit>();
        foreach(var load in workModel.Loads)
        {
            PulseRef r=Resolve(load.WireNumber,load.Position,load.Offset);
            bool atGround=GroundPulse(r.Index);
            if(atGround&&load.WireNumber>physicalWireCount)continue;
            Complex z=LoadImpedance(load,operatingMHz);
            double stamp=(atGround?2.0:1.0)*invM;
            int idx=r.Index*n+r.Index;
            ar[idx]+=z.Imaginary*stamp;
            ai[idx]-=z.Real*stamp;
            if(!unfolded || load.WireNumber<=physicalWireCount)
                loadStampAudit.Add(new LoadStampAudit(load.WireNumber,load.Position,load.Offset,r.Index,r.Sign,
                    atGround,resolved.Any(src=>src.Ref.Index==r.Index && (!unfolded || src.Source.WireNumber<=physicalWireCount)),
                    z.Real,z.Imaginary,z.Imaginary*stamp,-z.Real*stamp,0,0,0,0));
        }
        var br=new double[n];var bi=new double[n];
        foreach(var s in resolved)
        {
            bool atGround=GroundPulse(s.Ref.Index);
            if(atGround&&s.Source.WireNumber>physicalWireCount)continue;
            Complex signed=s.Voltage*s.Ref.Sign;
            double stamp=(atGround?2.0:1.0)*invM;
            br[s.Ref.Index]+=signed.Imaginary*stamp;
            bi[s.Ref.Index]-=signed.Real*stamp;
        }
        if(matrixSnapshotObserver!=null)
            matrixSnapshotObserver(new MatrixSnapshot(n,(double[])ar.Clone(),(double[])ai.Clone(),(double[])br.Clone(),(double[])bi.Clone()));
        ct.ThrowIfCancellationRequested();
        var loadedSym=matrixEnergyObserver==null?default:MatrixSymmetry(ar,ai,n);
        string matrixAudit=AuditLargeMatrix(ar,ai,topo,n,ct);
        string topologyAudit=AuditPulseTopology(topo,n,ct);
        if(topologyAudit.Length>0)progress?.Report("MININEC: "+topologyAudit);
        if(matrixAudit.Length>0)progress?.Report("MININEC: "+matrixAudit);
        int iterations=0;
        string linearSolver;
        double[] ir,ii;
        if(n<=DirectSolveLimit)
        {
            linearSolver="Pivoted Gaussian";
            progress?.Report($"MININEC: прямое решение матрицы {n}×{n}…");
            (ir,ii)=GaussianSolve(ar,ai,br,bi,n,ct);
        }
        else
        {
            // Experimental iterative route must NEVER publish unconverged R+jX.
            // v0.3.6: if restarted GMRES is unable to solve the original system,
            // attempt a fully independent, pivoted direct LU solve.  This fallback
            // consumes extra memory and can take minutes for ~2000 pulses.
            // Importantly, the matrix, source, loads and pulse topology do not change.
            linearSolver="FGMRES(96) right preconditioned + parallel MatVec + overlapping LU";
            progress?.Report($"MININEC: FGMRES(96) для матрицы {n}×{n}; параллельное умножение, контроль истинной невязки…");
            try
            {
                (ir,ii,iterations)=GmresSolve(ar,ai,br,bi,n,ct,progress);
            }
            catch (GmresConvergenceException ex)
            {
                ct.ThrowIfCancellationRequested();
                if(n>DirectFallbackLimit)
                    throw new NotSupportedException($"MININEC: {n} импульсов, GMRES не сошёлся за {ex.Iterations} итераций; истинная невязка {ex.Residual:E3}. {ex.Diagnostics} {matrixAudit} {topologyAudit} Прямой LU для большой матрицы отключён во избежание зависания и нехватки памяти. Значение R+jX НЕ выдаётся.",ex);
                progress?.Report($"MININEC: GMRES не сошёлся (невязка {ex.Residual:E3}, {ex.Iterations} ит.). Прямой LU: потребуется дополнительная память ~{16.0*n*n/(1024*1024):0} МиБ. Стоп работает.");
                (ir,ii)=GaussianSolve(ar,ai,br,bi,n,ct,progress);
                linearSolver="GMRES stagnated → Pivoted Direct LU (fallback)";
                iterations=ex.Iterations;
            }
        }
        // Peak-phasor dissipation: P=1/2 * sum |I_p|^2 Re(Z_p).
        // The first sum uses every unfolded matrix unknown (for diagnostics only).
        // The second includes ONLY original physical conductor halves.
        double matrixConductorLossPower=0, physicalConductorLossPower=0;
        for(int pi=0;pi<n;pi++)
        {
            double iSquared=ir[pi]*ir[pi]+ii[pi]*ii[pi];
            matrixConductorLossPower+=0.5*iSquared*conductorStamps[pi].Real;
            physicalConductorLossPower+=0.5*iSquared*physicalHalfResistances[pi];
        }
        loadStampAudit = loadStampAudit.Select(a => {
            Complex currentAtPulse=new(ir[a.PulseIndex],ii[a.PulseIndex]);
            Complex physicalCurrent=currentAtPulse*a.PulseSign;
            Complex loadPower=0.5*new Complex(a.ROhm,a.XOhm)*physicalCurrent.Magnitude*physicalCurrent.Magnitude;
            return a with { CurrentReal=physicalCurrent.Real, CurrentImag=physicalCurrent.Imaginary,
                LoadPowerReal=loadPower.Real, LoadPowerReactive=loadPower.Imaginary };
        }).ToList();
        Complex current=new(ir[primary.Ref.Index],ii[primary.Ref.Index]);
        if(current.Magnitude<1e-18)throw new ArithmeticException("MININEC: ток источника близок к нулю.");
        // Each port has its own V/I under simultaneous excitation.
        // Individual negative R is possible for a passive multiport: a port can absorb
        // power from another source. Check SUM of active power, never flip R's sign.
        int physicalSources=model.Sources.Count;
        var orientedCurrents=resolved.Take(physicalSources)
            .Select(rs=>new Complex(ir[rs.Ref.Index],ii[rs.Ref.Index])*rs.Ref.Sign).ToArray();
        var physicalVoltages=resolved.Take(physicalSources).Select(rs=>rs.Voltage).ToArray();
        var (ports,totalActive,totalReactive)=DiagnosePorts(model.Sources,physicalVoltages,orientedCurrents);
        Complex zin;
        if(physicalSources<=1)
        {
            zin=ports.Count>0?new Complex(ports[0].ROhm,ports[0].XOhm):Complex.Zero;
            if(!double.IsFinite(zin.Real)||!double.IsFinite(zin.Imaginary))throw new ArithmeticException("MININEC: ток первого источника близок к нулю; Z первого порта не определён.");
        }
        else
        {
            // Multi-source MMANA-style scalar equivalent for the ACTUAL excitation vector.
            // This is not any single port impedance. It reduces exactly to V/I for one source.
            double vNorm2=0;Complex denom=Complex.Zero;
            for(int i=0;i<physicalVoltages.Length;i++)
            {
                var vk=physicalVoltages[i];var ik=orientedCurrents[i];
                vNorm2+=vk.Magnitude*vk.Magnitude;
                denom+=Complex.Conjugate(vk)*ik;
            }
            if(vNorm2<=1e-18||denom.Magnitude<=1e-18)
                throw new ArithmeticException("MININEC: эквивалентный Z фазированной системы не определён (нулевая суммарная проводимость возбуждения).");
            zin=new Complex(vNorm2,0)/denom;
        }
        double residual=Residual(ar,ai,ir,ii,br,bi,n);
        progress?.Report($"MININEC: решение проверено по исходной матрице, невязка {residual:E3}.");
        if(!double.IsFinite(residual) || residual>1e-5)
            throw new ArithmeticException($"MININEC: невязка матрицы {residual:G6} недопустимо велика; результат R+jX не публикуется.");
        double powerScale=Math.Max(1e-12,ports.Sum(p=>Math.Abs(p.ActivePower)));
        if(!double.IsFinite(totalActive)||!double.IsFinite(totalReactive))
            throw new ArithmeticException("MININEC: нечисловой баланс мощности фазированных источников.");
        if(totalActive < -1e-5*powerScale)
            throw new ArithmeticException($"MININEC: суммарная активная мощность источников ОТРИЦАТЕЛЬНА ({totalActive:G6} относительных единиц). " +
                "Это несовместимо с пассивной антенной; проверь полярность источников, ориентации токов и матрицу. R+jX не публикуется.");
        if(matrixEnergyObserver!=null && kernelRe!=null && kernelIm!=null)
        {
            // I^H b = I^H A I. This is an algebraic identity in internal kernel
            // units; compare it to V/I power ONLY after a justified normalization.
            Complex lhs=Complex.Zero,rhs=Complex.Zero,radKernel=Complex.Zero;
            double loadActive=0;
            for(int i=0;i<n;i++)
            {
                Complex ci=new(ir[i],ii[i]);
                lhs+=Complex.Conjugate(ci)*new Complex(br[i],bi[i]);
                Complex row=Complex.Zero,radRow=Complex.Zero;
                int offset=i*n;
                for(int j=0;j<n;j++)
                {
                    Complex cj=new(ir[j],ii[j]);
                    row+=new Complex(ar[offset+j],ai[offset+j])*cj;
                    radRow+=new Complex(kernelRe[offset+j],kernelIm[offset+j])*cj;
                }
                rhs+=Complex.Conjugate(ci)*row;
                radKernel+=Complex.Conjugate(ci)*radRow;
            }
            foreach(var stamp in loadStampAudit)
                loadActive+=stamp.LoadPowerReal;
            double mismatch=(lhs-rhs).Magnitude/Math.Max(1e-25,lhs.Magnitude);
            matrixEnergyObserver(new MatrixEnergyAudit(n,
                kernelSym.Transpose,kernelSym.Adjoint,loadedSym.Transpose,loadedSym.Adjoint,
                lhs.Real,lhs.Imaginary,rhs.Real,rhs.Imaginary,mismatch,totalActive,
                loadActive,physicalConductorLossPower,loadedSym.MinHermDiag,
                loadedSym.MaxOff,loadedSym.Row,loadedSym.Column,
                Math.Sqrt(br.Sum(x=>x*x)+bi.Sum(x=>x*x)),
                radKernel.Real,radKernel.Imaginary));
        }
        // Retain physical pulse geometry and complex currents for coherent field visualization.
        // Image pulses (PEC) are included when present. No additional numerical solve.
        var fieldSamples=topo.Pulses.Select((pulse,i)=>new FieldSample(
            pulse.Point.X,pulse.Point.Y,pulse.Point.Z,
            (pulse.EndPos.X-pulse.EndNeg.X)*0.5,
            (pulse.EndPos.Y-pulse.EndNeg.Y)*0.5,
            (pulse.EndPos.Z-pulse.EndNeg.Z)*0.5,ir[i],ii[i],pulse.WireNeg,pulse.WirePos,
            pulse.EndNeg.X,pulse.EndNeg.Y,pulse.EndNeg.Z,
            pulse.EndPos.X,pulse.EndPos.Y,pulse.EndPos.Z)).ToArray();
        return new(operatingMHz,zin.Real,zin.Imaginary,n,residual,topo.JunctionCount,model.Sources.Count,model.Loads.Count,
            realEarth ? "G=2: ПРИБЛИЖЕНИЕ MMANA: PEC токи / Zin, конечная σ НЕ учтена в матрице" :
            unfolded ? "G=1: PEC зеркальная модель" : "G=0: свободное пространство",linearSolver,iterations,
            ports,totalActive,totalReactive,fieldSamples,loadStampAudit,
            physicalConductorLossPower,matrixConductorLossPower,physicalConductorHalves);
    }
    private static MaaModel ExcludeMmanaInsulators(MaaModel model)
    {
        if(!model.Wires.Any(w=>w.RadiusMetres==0))
        {
            if(model.Wires.Any(w=>w.LengthMetres<=1e-12 || !double.IsFinite(w.RadiusMetres)))
                throw new NotSupportedException("Проводник нулевой длины или с нечисловым радиусом.");
            return model;
        }
        var active=model.Wires.Where(w=>w.RadiusMetres>0 && w.LengthMetres>1e-12 && double.IsFinite(w.RadiusMetres)).ToArray();
        if(model.Wires.Any(w=>w.RadiusMetres!=0 && (w.LengthMetres<=1e-12 || !double.IsFinite(w.RadiusMetres))))
            throw new NotSupportedException("Проводник нулевой длины или с нечисловым радиусом.");
        if(active.Length==0)throw new NotSupportedException("MMANA: после исключения R=0 не осталось проводящих элементов.");
        var index=active.Select((w,i)=>(w.Number,NewNumber:i+1)).ToDictionary(x=>x.Number,x=>x.NewNumber);
        foreach(var src in model.Sources)
            if(!index.ContainsKey(src.WireNumber))
                throw new NotSupportedException($"MMANA: источник w{src.WireNumber} установлен на изоляторе R=0.");
        foreach(var load in model.Loads)
            if(!index.ContainsKey(load.WireNumber))
                throw new NotSupportedException($"MMANA: нагрузка w{load.WireNumber} установлена на изоляторе R=0.");
        int removed=model.Wires.Count-active.Length;
        return new MaaModel {
            Title=model.Title, FilePath=model.FilePath, FrequencyMHz=model.FrequencyMHz,
            Wires=active.Select((w,i)=>w with { Number=i+1 }).ToArray(),
            Sources=model.Sources.Select(x=>x with {WireNumber=index[x.WireNumber]}).ToArray(),
            Loads=model.Loads.Select(x=>x with {WireNumber=index[x.WireNumber]}).ToArray(),
            Warnings=model.Warnings.Concat(new []{$"MMANA: {removed} изолирующих проводников R=0 исключено только из расчёта; геометрия исходного файла не изменена."}).ToArray(),
            GroundType=model.GroundType, AddHeightMetres=model.AddHeightMetres,
            MaterialCode=model.MaterialCode, ReferenceOhms=model.ReferenceOhms,
            SegmentationRecord=model.SegmentationRecord, WireHeaderRecord=model.WireHeaderRecord,
            HasCompactStack=model.HasCompactStack, StackExpanded=model.StackExpanded,
            BaseWireCount=active.Length, StackHorizontal=model.StackHorizontal,
            StackVertical=model.StackVertical,
            StackHorizontalSpacingMetres=model.StackHorizontalSpacingMetres,
            StackVerticalSpacingMetres=model.StackVerticalSpacingMetres,
            StackPlacementMode=model.StackPlacementMode
        };
    }
    private static MaaModel UnfoldPec(MaaModel model,double referenceLambda)
    {
        double h=model.AddHeightMetres;
        double tol=Math.Max(1e-8,referenceLambda*1e-8);
        if(!double.IsFinite(h))throw new NotSupportedException("PEC: высота H должна быть конечной.");
        var upper=model.Wires.Select(w=>w with {Z1=w.Z1+h,Z2=w.Z2+h}).ToArray();
        // PEC reflection relies on each physical conductor staying entirely in z>=0,
        // except for endpoints touching the boundary. Antennas in the PEC plane
        // create duplicate coincident image wires: reject rather than conceal it.
        if(upper.Any(w=>w.Z1 < -tol || w.Z2 < -tol))
            throw new NotSupportedException("PEC: проводник ниже плоскости z=0 или пересекает землю. Проверь G/H и координаты.");
        if(upper.Any(w=>Math.Abs(w.Z1)<=tol&&Math.Abs(w.Z2)<=tol))
            throw new NotSupportedException("PEC: проводник лежит в плоскости земли z=0. Совпадающий зеркальный провод пока не поддерживается.");
        // Multiple physical wire endpoints may meet on the PEC plane. Their mirrored
        // endpoints form a common multi-branch node handled by Build's junction graph.
        // Such a node is safe to expand only if NO source or lumped load is applied
        // directly at that terminal: a grounded voltage gap needs a separate half-
        // space excitation and port normalization that this preview has not validated.
        var groundedEnds=upper.SelectMany((w,i)=>new[]{
            (Wire:i+1,AtStart:true,X:w.X1,Y:w.Y1,Z:w.Z1),
            (Wire:i+1,AtStart:false,X:w.X2,Y:w.Y2,Z:w.Z2)})
            .Where(pt=>Math.Abs(pt.Z)<=tol).ToArray();
        foreach(var p in groundedEnds)
        {
            bool HasAtGround(int wire,char end) =>
                model.Sources.Any(q=>q.WireNumber==wire && char.ToLowerInvariant(q.Position)==end && q.Offset==0) ||
                model.Loads.Any(q=>q.WireNumber==wire && char.ToLowerInvariant(q.Position)==end && q.Offset==0);
            bool shared=groundedEnds.Any(q=>q.Wire!=p.Wire &&
                Math.Abs(p.X-q.X)<=tol && Math.Abs(p.Y-q.Y)<=tol);
            if(shared && HasAtGround(p.Wire,p.AtStart?'b':'e'))
                throw new NotSupportedException("PEC: источник или нагрузка непосредственно в общем узле земли. Специальная нормировка портов в таком узле пока не проверена.");
        }
        int count=upper.Length;
        var reflected=upper.Select((w,i)=>new MaaWire(count+i+1,
            w.X2,w.Y2,-w.Z2,w.X1,w.Y1,-w.Z1,w.RadiusMetres,w.Tag)).ToArray();
        char Mirror(char pos)=>char.ToLowerInvariant(pos) switch {'b'=>'e','e'=>'b',_=>'c'};
        var sources=model.Sources.Concat(model.Sources.Select(s=>s with{
            WireNumber=s.WireNumber+count,Position=Mirror(s.Position),Offset=-s.Offset,Raw=s.Raw+" [PEC image]"})).ToArray();
        var loads=model.Loads.Concat(model.Loads.Select(l=>l with{
            WireNumber=l.WireNumber+count,Position=Mirror(l.Position),Offset=-l.Offset,Raw=l.Raw+" [PEC image]"})).ToArray();
        return new MaaModel {
            Title=model.Title,FilePath=model.FilePath,FrequencyMHz=model.FrequencyMHz,
            Wires=upper.Concat(reflected).ToArray(),Sources=sources,Loads=loads,Warnings=model.Warnings,
            GroundType=0,AddHeightMetres=0,MaterialCode=model.MaterialCode,ReferenceOhms=model.ReferenceOhms,
            SegmentationRecord=model.SegmentationRecord,WireHeaderRecord=model.WireHeaderRecord,
            HasCompactStack=model.HasCompactStack,StackExpanded=model.StackExpanded,BaseWireCount=model.BaseWireCount,
            StackHorizontal=model.StackHorizontal,StackVertical=model.StackVertical,
            StackHorizontalSpacingMetres=model.StackHorizontalSpacingMetres,StackVerticalSpacingMetres=model.StackVerticalSpacingMetres,
            StackPlacementMode=model.StackPlacementMode
        };
    }

    private static Topology Build(MaaModel model,double lambda,CancellationToken ct,bool allowCompactShortTaper,PecJunctionMode pecJunctionMode,int physicalWireCount)
    {
        var p=MininecSegmentation.Parse(model.SegmentationRecord);
        int shortTagged=model.Wires.Count(w=>w.Tag is >= -3 and <= -1 &&
            w.LengthMetres>1e-12&&w.LengthMetres<=lambda*0.035);
        bool denseShortTaper=allowCompactShortTaper&&model.GroundType==0&&!model.HasUnexpandedTapers&&
            model.Loads.Count==0&&model.Wires.Count>=20&&shortTagged*3>=model.Wires.Count*2;
        var topo=new Topology();var ends=new List<EndRef>();
        foreach(var wire in model.Wires)
        {
            ct.ThrowIfCancellationRequested();
            int wi=wire.Number-1;
            if(wi!=topo.Refs.Count)throw new FormatException("MAA: проводники должны быть пронумерованы подряд.");
            bool useTei=model.StackExpanded || (denseShortTaper && p.Ec<=1 && wire.Tag is >= -3 and <= -1);
            var spans=useTei
                ? MininecStackSegmentation.Spans(wire.LengthMetres,lambda,wire.Tag,p)
                : MininecSegmentation.Spans(wire.LengthMetres,lambda,wire.Tag,p);
            if(spans.Count<2)spans=MininecSegmentation.Uniform(2);
            V start=new(wire.X1,wire.Y1,wire.Z1),end=new(wire.X2,wire.Y2,wire.Z2);
            V delta=end-start,dir=delta*(1.0/wire.LengthMetres);
            var segs=new List<Segment>();
            foreach(var sp in spans)
            {
                V a=start+delta*sp.F0,b=start+delta*sp.F1;
                segs.Add(new(wi,segs.Count,a,b,(b-a).Norm(),dir,Math.Abs(wire.RadiusMetres)));
            }
            var refs=new List<PulseRef>();
            for(int k=0;k<segs.Count-1;k++)
            {
                var a=segs[k];var b=segs[k+1];int id=topo.Pulses.Count;
                topo.Pulses.Add(new(k,a.B,a.A,b.B,a.Length,b.Length,a.Dir,b.Dir,a.Radius,b.Radius,wi,wi));
                refs.Add(new(id,1));
            }
            topo.Refs.Add(refs);
            ends.Add(new(wi,true,segs[0].A,segs[0]));
            ends.Add(new(wi,false,segs[^1].B,segs[^1]));
        }
        double eps=Math.Max(1e-8,lambda*1e-8);double eps2=eps*eps;
        var used=new bool[ends.Count];
        void AddRef(EndRef e,PulseRef r) { if(e.AtStart)topo.Refs[e.Wire].Insert(0,r);else topo.Refs[e.Wire].Add(r); }
        void AddJunction(EndRef a,EndRef b,bool mapA,bool mapB)
        {
            V aFar=a.AtStart?a.Segment.B:a.Segment.A,bFar=b.AtStart?b.Segment.B:b.Segment.A;
            double asgn=a.AtStart?-1:1,bsgn=b.AtStart?1:-1;
            int id=topo.Pulses.Count;
            topo.Pulses.Add(new(-1,a.Point,aFar,bFar,a.Segment.Length,b.Segment.Length,
                a.Segment.Dir*asgn,b.Segment.Dir*bsgn,a.Segment.Radius,b.Segment.Radius,a.Wire,b.Wire));
            if(mapA)AddRef(a,new(id,asgn));if(mapB)AddRef(b,new(id,bsgn));
            if(a.Wire!=b.Wire)topo.ConnectedPairs.Add(Key(a.Wire,b.Wire));
            topo.JunctionCount++;
        }
        bool HasEndpointExcitation(EndRef e)
        {
            char pos=e.AtStart?'b':'e';
            return model.Sources.Any(s=>s.WireNumber==e.Wire+1&&char.ToLowerInvariant(s.Position)==pos&&s.Offset==0)
                ||model.Loads.Any(l=>l.WireNumber==e.Wire+1&&char.ToLowerInvariant(l.Position)==pos&&l.Offset==0);
        }
        for(int i=0;i<ends.Count;i++)
        {
            if(used[i])continue;
            var group=new List<int>{i};
            for(int j=i+1;j<ends.Count;j++)if((ends[i].Point-ends[j].Point).Dot(ends[i].Point-ends[j].Point)<=eps2)group.Add(j);
            foreach(int j in group)used[j]=true;
            if(group.Count<2)continue;
            foreach(int ga in group)foreach(int gb in group)if(ga<gb&&ends[ga].Wire!=ends[gb].Wire)
                topo.ConnectedPairs.Add(Key(ends[ga].Wire,ends[gb].Wire));
            if(group.Count==2&&ends[group[0]].Wire==ends[group[1]].Wire)
            {
                AddJunction(ends[group[0]],ends[group[1]],true,false);continue;
            }
            // Ground node with exactly two physical and two PEC mirror terminals.
            // Preserve mirror symmetry in the graph: pair each conductor with its
            // image and connect the two physical branches through one bridge.
            // This is still an experimental pulse topology, not an MMANA proof.
            if(pecJunctionMode==PecJunctionMode.MirroredBalancedTree && physicalWireCount>0 && group.Count==4 &&
               Math.Abs(ends[group[0]].Point.Z)<=eps &&
               group.Count(gi=>ends[gi].Wire<physicalWireCount)==2 &&
               group.All(gi=>!HasEndpointExcitation(ends[gi])))
            {
                var physical=group.Where(gi=>ends[gi].Wire<physicalWireCount)
                    .OrderBy(gi=>ends[gi].Wire).ToArray();
                int FindImage(int g)=>group.FirstOrDefault(gi=>ends[gi].Wire==ends[g].Wire+physicalWireCount,-1);
                int imageA=FindImage(physical[0]),imageB=FindImage(physical[1]);
                if(imageA>=0&&imageB>=0)
                {
                    // Every graph edge is a genuine junction pulse; no artificial
                    // impedances or source phases are introduced.
                    AddJunction(ends[physical[0]],ends[imageA],true,true);
                    AddJunction(ends[physical[1]],ends[imageB],true,true);
                    AddJunction(ends[physical[0]],ends[physical[1]],false,false);
                    continue;
                }
            }
            int root=group.Count>=3?group.FirstOrDefault(gi=>!HasEndpointExcitation(ends[gi]),-1):-1;
            if(root<0)root=group.Count>=3?group[^1]:group[0];
            bool mapped=false;
            foreach(int gi in group)
            {
                if(gi==root)continue;
                AddJunction(ends[root],ends[gi],!mapped,true);mapped=true;
            }
        }
        return topo;
    }
    private static long Key(int a,int b)=>((long)Math.Min(a,b)<<32)|(uint)Math.Max(a,b);
    private static Complex LoadImpedance(MaaLoad ld,double mhz)
    {
        double omega=2*Math.PI*mhz*1e6;
        if(ld.Kind==1)return new(ld.V1,ld.V2);
        if(ld.Kind!=0)throw new NotSupportedException($"Нагрузка MMANA kind={ld.Kind} пока не поддерживается.");
        double l=ld.V1*1e-6,c=ld.V2*1e-12,q=ld.V3;
        if(l<=0&&c<=0)return Complex.Zero;
        if(l>0&&c<=0){double x=omega*l;return new(q>0?Math.Abs(x)/q:0,x);}
        if(l<=0&&c>0){double x=-1/Math.Max(omega*c,1e-30);return new(q>0?Math.Abs(x)/q:0,x);}
        double xl=omega*l,xc=-1/Math.Max(omega*c,1e-30);
        Complex zl=new(q>0?Math.Abs(xl)/q:0,xl),zc=new(q>0?Math.Abs(xc)/q:0,xc);
        return (zl+zc).Magnitude<1e-20?new Complex(1e12,0):zl*zc/(zl+zc);
    }
    private static (double[] Real,double[] Imag) Matrix(Topology topo,double mhz,CancellationToken ct,IProgress<string>? progress,Action<FullCoefficientCheck>? fullCoefficientObserver)
    {
        var pp=topo.Pulses;int n=pp.Count;
        var ar=new double[n*n];var ai=new double[n*n];
        double lambda=Cmhz/mhz,srm=0.0001*lambda,wave=2*Math.PI/lambda,wave2=wave*wave/2;
        double[] x2={-0.28867513459481287,0.28867513459481287},w2={0.5,0.5};
        double[] x4={-0.4305681557970263,-0.16999052179242813,0.16999052179242813,0.4305681557970263};
        double[] w4={0.17392742256872679,0.3260725774312732,0.3260725774312732,0.17392742256872679};
        double[] x8={-0.4801449282487681,-0.39833323870681336,-0.2627662049581645,-0.09171732124782489,0.09171732124782489,0.2627662049581645,0.39833323870681336,0.4801449282487681};
        double[] w8={0.05061426814518853,0.11119051722668721,0.15685332293894344,0.18134189168918083,0.18134189168918083,0.15685332293894344,0.11119051722668721,0.05061426814518853};
        double EllipticK(double m)
        {
            if(m<=0)return Math.PI*0.5;
            double a=1,b=Math.Sqrt(Math.Max(1-m,1e-30));
            for(int i=0;i<32;i++)
            {
                double an=(a+b)*0.5,bn=Math.Sqrt(a*b);
                if(Math.Abs(an-bn)<=1e-15*Math.Max(1,an))return Math.PI/(2*an);
                a=an;b=bn;
            }
            return Math.PI/(2*a);
        }
        Complex Integral(double t,V v2,V vv,double radius,bool exact)
        {
            V q=v2+(vv-v2)*t;
            double d0=Math.Max(q.Norm(),1e-15),d=d0,corr=0;
            if(radius>srm)
            {
                double a2=radius*radius,d2=d0*d0;
                d=Math.Sqrt(a2+d2);
                if(exact)
                {
                    double b=d2/(d2+4*a2),mm=Math.Clamp(1-b,0,1-1e-15);
                    double v0=EllipticK(mm)*Math.Sqrt(mm);
                    double lr=0.5*Math.Log(Math.Max(d2/(64*a2),1e-300));
                    corr=(v0+lr)/(Math.PI*radius)-1/d;
                }
            }
            double a=wave*d;
            return new(Math.Cos(a)/d+corr,-Math.Sin(a)/d);
        }
        int midpointSteps=0;
        Complex Quad(double bound,V v2,V vv,double radius,bool exact,int order)
        {
            if(midpointSteps>0)
            {
                double midpointRealSum=0,midpointImagSum=0;
                for(int i=0;i<midpointSteps;i++)
                {
                    double t=(i+0.5)*bound/midpointSteps;
                    var z=Integral(t,v2,vv,radius,exact);
                    midpointRealSum+=z.Real;midpointImagSum+=z.Imaginary;
                }
                return new Complex(midpointRealSum/midpointSteps,midpointImagSum/midpointSteps);
            }
            var xs=order==2?x2:order==4?x4:x8;
            var ws=order==2?w2:order==4?w4:w8;
            double sr=0,si=0;
            for(int i=0;i<xs.Length;i++)
            {
                double t=(xs[i]+0.5)*bound;
                var q=Integral(t,v2,vv,radius,exact);
                sr+=ws[i]*q.Real;si+=ws[i]*q.Imaginary;
            }
            return new(sr,si);
        }
        Complex Psi(V v2,V vv,double scale,double radius,double segLen,bool exact,bool scalar)
        {
            double d0=v2.Norm(),d3=vv.Norm();
            double s4=Math.Abs(scale)*segLen,t=(d0+d3)/segLen;
            bool useExact=exact&&t<=1.1;
            double f2=useExact?2*Math.Abs(scale):1;
            double fvs=scalar?2:1;
            if(useExact&&radius<=srm)
                return new(fvs*Math.Log(segLen/radius),-0.5*fvs*wave*segLen);
            int order=useExact?8:t>10?2:t>6?4:8;
            var result=Quad(1/f2,v2,vv,radius,useExact,order);
            if(useExact&&radius>srm)
            {
                double i6=(1+Math.Log(16*radius/segLen))/(Math.PI*radius);
                result+=new Complex(i6,0);
            }
            return result*s4;
        }
        bool Connected(Pulse a,Pulse b)
        {
            int[] aw={a.Wire(0),a.Wire(1)},bw={b.Wire(0),b.Wire(1)};
            foreach(int x in aw)foreach(int y in bw)
                if(x==y||topo.ConnectedPairs.Contains(Key(x,y)))return true;
            return false;
        }
        Complex VectorPotential(int row,int col,double ds)
        {
            var pr=pp[row];var pc=pp[col];int side=ds>0?1:0;
            double radius=pc.Rad(side),segLen=pc.Len(side);
            if(row==col&&radius<srm)
                return new(Math.Log(segLen/radius),-wave*segLen/2);
            var (a,b)=pc.DVecs(ds);
            return Psi(a-pr.Point,b-pr.Point,ds,radius,segLen,Connected(pr,pc),false);
        }
        Complex ScalarPotential(int row,int col,double ds1,double ds2)
        {
            var pr=pp[row];var pc=pp[col];int side=ds2>0?1:0;
            double radius=pc.Rad(side),segLen=pc.Len(side);
            if(pr.SimpleInternal&&pc.SimpleInternal&&pr.Wire(0)==pc.Wire(0)&&
                Math.Abs((pr.Local+ds1)-(pc.Local+ds2/2))<1e-12&&radius<srm)
                return new(2*Math.Log(segLen/radius),-wave*segLen);
            var obs=pr.EndSeg(ds1);var (a,b)=pc.DVecs(ds2);
            return Psi(a-obs,b-obs,ds2,radius,segLen,Connected(pr,pc),true);
        }
        int rowsDone=0;
        void ComputeMatrixRow(int row)
        {
            ct.ThrowIfCancellationRequested();
            var pr=pp[row];
            V zzz=pr.Dir(0)*pr.LenNeg+pr.Dir(1)*pr.LenPos;
            for(int col=0;col<n;col++)
            {
                if((col&127)==0)ct.ThrowIfCancellationRequested();
                var pc=pp[col];
                Complex u=VectorPotential(row,col,+0.5),v=VectorPotential(row,col,-0.5);
                V vecRe=pc.Dir(1)*u.Real+pc.Dir(0)*v.Real;
                V vecIm=pc.Dir(1)*u.Imaginary+pc.Dir(0)*v.Imaginary;
                Complex d=new(wave2*vecRe.Dot(zzz),wave2*vecIm.Dot(zzz));
                bool equalRow=Math.Abs(pr.LenNeg-pr.LenPos)<=1e-11*Math.Max(pr.LenNeg,pr.LenPos);
                bool equalCol=Math.Abs(pc.LenNeg-pc.LenPos)<=1e-11*Math.Max(pc.LenNeg,pc.LenPos);
                bool same=pr.SimpleInternal&&pc.SimpleInternal&&pr.Wire(0)==pc.Wire(0)&&equalRow&&equalCol;
                int f8=same?(row==col?2:1):0;
                Complex scalar;
                if(f8<2)
                {
                    Complex u56=f8==1?u+VectorPotential(row,col,-0.5):ScalarPotential(row,col,+0.5,+1);
                    Complex sp1=ScalarPotential(row,col,-0.5,+1);
                    scalar=(sp1-u56)*(1.0/pc.LenPos);
                    Complex u34=ScalarPotential(row,col,+0.5,-1);
                    Complex sp2=f8==1?u56:ScalarPotential(row,col,-0.5,-1);
                    scalar+=(u34-sp2)*(1.0/pc.LenNeg);
                }
                else
                {
                    Complex sp=ScalarPotential(row,col,-0.5,+1);
                    scalar=(sp*2-u*4)*(1.0/pc.LenPos);
                }
                var z=d+scalar;
                ar[row*n+col]=z.Real;ai[row*n+col]=z.Imaginary;
            }
            int done=Interlocked.Increment(ref rowsDone);
            if((done&63)==0||done==n)
                progress?.Report($"MININEC: матрица {done}/{n} строк ({100.0*done/n:0.#}%). Кнопка Стоп активна.");
        }
        // Each row writes a disjoint slice. All geometry and quadrature data
        // are read-only, so parallel evaluation cannot change MININEC physics.
        if(n>500)
        {
            var options=new ParallelOptions { CancellationToken=ct,
                MaxDegreeOfParallelism=Math.Clamp(Environment.ProcessorCount-1,1,8) };
            Parallel.For(0,n,options,ComputeMatrixRow);
        }
        else for(int row=0;row<n;row++)ComputeMatrixRow(row);
        // Independent composite-midpoint quadrature of ALL integral terms composing A_ij.
        // The underlying physical kernel and potential algebra are intentionally the same;
        // this verifies integration accuracy, not validity of the physical approximation.
        if(fullCoefficientObserver!=null)
        {
            (Complex Total,Complex Vector,Complex Scalar) Evaluate(int row,int col)
            {
                var pr=pp[row];var pc=pp[col];
                Complex u=VectorPotential(row,col,+0.5),v=VectorPotential(row,col,-0.5);
                V vecRe=pc.Dir(1)*u.Real+pc.Dir(0)*v.Real;
                V vecIm=pc.Dir(1)*u.Imaginary+pc.Dir(0)*v.Imaginary;
                V zzz=pr.Dir(0)*pr.LenNeg+pr.Dir(1)*pr.LenPos;
                Complex vector=new Complex(wave2*vecRe.Dot(zzz),wave2*vecIm.Dot(zzz));
                bool equalRow=Math.Abs(pr.LenNeg-pr.LenPos)<=1e-11*Math.Max(pr.LenNeg,pr.LenPos);
                bool equalCol=Math.Abs(pc.LenNeg-pc.LenPos)<=1e-11*Math.Max(pc.LenNeg,pc.LenPos);
                bool same=pr.SimpleInternal&&pc.SimpleInternal&&pr.Wire(0)==pc.Wire(0)&&equalRow&&equalCol;
                int f8=same?(row==col?2:1):0;
                Complex scalar;
                if(f8<2)
                {
                    Complex u56=f8==1?u+VectorPotential(row,col,-0.5):ScalarPotential(row,col,+0.5,+1);
                    Complex sp1=ScalarPotential(row,col,-0.5,+1);
                    scalar=(sp1-u56)/pc.LenPos;
                    Complex u34=ScalarPotential(row,col,+0.5,-1);
                    Complex sp2=f8==1?u56:ScalarPotential(row,col,-0.5,-1);
                    scalar+=(u34-sp2)/pc.LenNeg;
                }
                else
                {
                    Complex sp=ScalarPotential(row,col,-0.5,+1);
                    scalar=(2*sp-4*u)/pc.LenPos;
                }
                return (vector+scalar,vector,scalar);
            }
            var pairs=n==232?new[]{(0,106),(54,224),(107,108),(106,0),(224,54)}:
                      n==224?new[]{(0,214),(211,222),(214,0)}:
                      n==134?new[]{(29,125),(59,60),(125,29)}:
                      new[]{(0,Math.Min(n-1,1))};
            foreach(var (row,col) in pairs)
            {
                ct.ThrowIfCancellationRequested();
                var baseCoefficient=new Complex(ar[row*n+col],ai[row*n+col]);
                foreach(int steps in new[]{64,256,1024})
                {
                    midpointSteps=steps;
                    var val=Evaluate(row,col);
                    midpointSteps=0;
                    fullCoefficientObserver(new FullCoefficientCheck(row,col,steps,
                        baseCoefficient.Real,baseCoefficient.Imaginary,
                        val.Total.Real,val.Total.Imaginary,
                        val.Vector.Real,val.Vector.Imaginary,val.Scalar.Real,val.Scalar.Imaginary));
                }
            }
        }
        return(ar,ai);
    }
    // v0.3.5: Block-Jacobi left preconditioner for dense MININEC systems.
    // This changes only the *numerical solution algorithm*. The original antenna
    // matrix A, excitations, segment counts and physical loads remain unchanged.
    // Each 64-by-64 diagonal block is factorized with row pivoting. Within blocks
    // we resolve strong nearest-neighbor current coupling that diagonal Jacobi
    // cannot remove. A singular block falls back to scalar Jacobi (no guessed Z).
    private sealed class BlockJacobi
    {
        private sealed class Block
        {
            public readonly int Start, Size;
            public readonly Complex[] Lu, InverseDiagonal;
            public readonly int[] Pivots;
            public readonly bool HasLu;
            public Block(int start,int size,Complex[] lu,Complex[] inverseDiagonal,int[] pivots,bool hasLu)
            { Start=start;Size=size;Lu=lu;InverseDiagonal=inverseDiagonal;Pivots=pivots;HasLu=hasLu; }
        }
        private readonly int count;
        private readonly Block[] blocks;
        private readonly int[] coverage;
        public int FallbackBlocks { get; }

        public BlockJacobi(double[] ar,double[] ai,int n,int blockSize,CancellationToken ct,int overlap=0)
        {
            count=n;
            if(overlap<0||overlap>=blockSize)throw new ArgumentOutOfRangeException(nameof(overlap));
            int stride=blockSize-overlap;
            coverage=new int[n];
            var list=new List<Block>();
            int fallback=0;
            for(int start=0;start<n;start+=stride)
            {
                ct.ThrowIfCancellationRequested();
                int m=Math.Min(blockSize,n-start);
                for(int i=0;i<m;i++)coverage[start+i]++;
                var lu=new Complex[m*m];
                var inverseDiagonal=new Complex[m];
                var pivot=new int[m];
                double scale=0;
                for(int i=0;i<m;i++)
                {
                    for(int j=0;j<m;j++)
                    {
                        Complex a=new(ar[(start+i)*n+start+j],ai[(start+i)*n+start+j]);
                        lu[i*m+j]=a;
                        scale=Math.Max(scale,a.Magnitude);
                    }
                    Complex d=lu[i*m+i];
                    if(!double.IsFinite(d.Real)||!double.IsFinite(d.Imaginary)||d.Magnitude<1e-18)
                        throw new ArithmeticException($"MININEC: нулевая диагональ матрицы в импульсе {start+i}.");
                    inverseDiagonal[i]=Complex.One/d;
                }
                bool factorOk=double.IsFinite(scale)&&scale>0;
                if(factorOk)
                    for(int k=0;k<m;k++)
                    {
                        int p=k;double best=0;
                        for(int i=k;i<m;i++)
                        {
                            double z=lu[i*m+k].Magnitude;
                            if(z>best){best=z;p=i;}
                        }
                        if(!double.IsFinite(best)||best<1e-14*scale){factorOk=false;break;}
                        pivot[k]=p;
                        if(p!=k)
                            for(int j=0;j<m;j++)
                                (lu[k*m+j],lu[p*m+j])=(lu[p*m+j],lu[k*m+j]);
                        Complex d=lu[k*m+k];
                        for(int i=k+1;i<m;i++)
                        {
                            Complex alpha=lu[i*m+k]/d;
                            lu[i*m+k]=alpha;
                            for(int j=k+1;j<m;j++)lu[i*m+j]-=alpha*lu[k*m+j];
                        }
                    }
                if(!factorOk)fallback++;
                list.Add(new Block(start,m,lu,inverseDiagonal,pivot,factorOk));
            }
            blocks=list.ToArray();FallbackBlocks=fallback;
        }
        public Complex[] Apply(Complex[] v)
        {
            if(v.Length!=count)throw new ArgumentException("Предобусловливание: неверный размер вектора.");
            var output=new Complex[count];
            foreach(var b in blocks)
            {
                int m=b.Size,off=b.Start;
                if(!b.HasLu)
                {
                    for(int i=0;i<m;i++)output[off+i]+=b.InverseDiagonal[i]*v[off+i];
                    continue;
                }
                var local=new Complex[m];
                for(int i=0;i<m;i++)local[i]=v[off+i];
                for(int k=0;k<m;k++)
                {
                    int p=b.Pivots[k];
                    if(p!=k)(local[k],local[p])=(local[p],local[k]);
                }
                for(int i=1;i<m;i++)
                {
                    Complex t=local[i];
                    for(int j=0;j<i;j++)t-=b.Lu[i*m+j]*local[j];
                    local[i]=t;
                }
                for(int i=m-1;i>=0;i--)
                {
                    Complex t=local[i];
                    for(int j=i+1;j<m;j++)t-=b.Lu[i*m+j]*local[j];
                    local[i]=t/b.Lu[i*m+i];
                }
                for(int i=0;i<m;i++)output[off+i]+=local[i];
            }
            for(int i=0;i<count;i++)output[i]/=coverage[i];
            return output;
        }
    }

    // Only a non-convergence outcome activates direct fallback. Numeric breakdown,
    // invalid geometry, cancellation and nonfinite matrices remain actual errors.
    private sealed class GmresConvergenceException : ArithmeticException
    {
        public double Residual { get; }
        public int Iterations { get; }
        public string Diagnostics { get; }
        public GmresConvergenceException(int iterations,double residual,string diagnostics="")
            : base($"FGMRES: после {iterations} итераций невязка {residual:E3}. {diagnostics}")
        { Iterations=iterations; Residual=residual; Diagnostics=diagnostics; }
    }

    // Right-preconditioned flexible GMRES: A M^-1 y = b, x = M^-1 y.
    // Unlike left GMRES, the Arnoldi least-squares problem minimizes the
    // residual of ORIGINAL A*x=b. This also allows changing M between steps.
    // Independent original-system residual is checked after every restart.
    internal static (double[] Real,double[] Imag,int Iterations) GmresSolve(
        double[] ar,double[] ai,double[] br,double[] bi,int n,
        CancellationToken ct,IProgress<string>? progress=null)
    {
        if(n<=0||ar.Length!=n*n||ai.Length!=n*n||br.Length!=n||bi.Length!=n)
            throw new ArgumentException("FGMRES: неверные размеры матрицы.");
        const int restart=96;
        // Large systems start with the proven 7680 iteration budget.
        // Only well-progressing solves may extend up to 30720 steps.
        const int extensionBlock=960;
        const int absoluteMaxIterations=30720;
        int maxIterations=n>2600?7680:384;
        const double requestedResidual=2e-7;
        int blockSize=n>2600?96:64;
        int overlap=n>2600?32:0;
        var preconditioner=new BlockJacobi(ar,ai,n,blockSize,ct,overlap);
        string cudaMode=(Environment.GetEnvironmentVariable("ANTENNA_CUDA_MODE")??"AUTO").Trim().ToUpperInvariant();
        if(cudaMode!="CPU" && cudaMode!="AUTO" && cudaMode!="GPU_TEST")cudaMode="AUTO";
        using var cuda=cudaMode=="CPU"?null:CudaDenseMatVec.TryCreate(ar,ai,n,out _);
        string cudaStatus=cudaMode=="CPU"?"CUDA: CPU ONLY requested":
            cuda is null?"CUDA: backend unavailable (check DLL, drivers and dependencies)":"CUDA: backend loaded";
        // Capture detailed initialization errors for the final MININEC failure report.
        if(cudaMode!="CPU" && cuda is null)
        {
            using var retry=CudaDenseMatVec.TryCreate(ar,ai,n,out string detailedStatus);
            cudaStatus=detailedStatus;
        }
        // Profiling uses monotonic Stopwatch ticks; it does not change floating-point operations.
        long profileMatVecTicks=0, profilePreconditionTicks=0,
             profileOrthogonalTicks=0, profileRecycleTicks=0;
        long profileCpuMatVecTicks=0, profileGpuMatVecTicks=0;
        long profileMatVecCalls=0, profileCpuCalls=0, profileGpuCalls=0;
        var profileTotalClock=System.Diagnostics.Stopwatch.StartNew();
        double ProfileMs(long ticks)=>ticks*1000.0/System.Diagnostics.Stopwatch.Frequency;
        string PerformanceProfile()=>
            $"PERF: total={profileTotalClock.Elapsed.TotalSeconds:F1}s; " +
            $"MatVec={ProfileMs(profileMatVecTicks):F0}ms ({profileMatVecCalls} выз.), " +
            $"GPU={ProfileMs(profileGpuMatVecTicks):F0}ms ({profileGpuCalls} выз.), " +
            $"CPU={ProfileMs(profileCpuMatVecTicks):F0}ms ({profileCpuCalls} выз.); " +
            $"LU apply={ProfileMs(profilePreconditionTicks):F0}ms; " +
            $"Arnoldi={ProfileMs(profileOrthogonalTicks):F0}ms; " +
            $"recycle={ProfileMs(profileRecycleTicks):F0}ms. " +
            "Профиль не включает сборку матрицы и построение LU.";
        bool cudaEnabled=false;
        progress?.Report(cudaStatus);
        progress?.Report($"MININEC: FGMRES({restart}), {maxIterations} итераций, LU-блок {blockSize}, перекрытие {overlap}; fallback {preconditioner.FallbackBlocks}.");
        var rhs=new Complex[n];
        for(int i=0;i<n;i++)rhs[i]=new Complex(br[i],bi[i]);
        double bnorm=Norm(rhs);
        if(!double.IsFinite(bnorm)||bnorm<1e-30)
            throw new ArithmeticException("MININEC FGMRES: отсутствует возбуждение.");
        var x=new Complex[n];
        var v=new Complex[restart+1][];
        var z=new Complex[restart][];
        for(int j=0;j<=restart;j++)v[j]=new Complex[n];
        var h=new Complex[restart+1,restart];
        var cosine=new double[restart];
        var sine=new Complex[restart];
        var g=new Complex[restart+1];
        int total=0;
        double original=double.PositiveInfinity;
        double maxOrthDefect=0;
        int correctivePasses=0;
        // Production solver diagnostics: genuine residuals of ORIGINAL A*x=b,
        // sampled at restart boundaries. Never use estimated Arnoldi residual
        // to report a converged antenna impedance.
        // Recycle a small number of completed correction directions across restarts.
        // Maintain A*dx vectors in orthonormal form, with matching dx transformations.
        // Unlike a full GCRO-DR harmonic-Ritz extraction, this is bounded
        // minimum-residual correction recycling and does not alter matrix physics.
        const int recycleMax=12;
        var recycleQ=new System.Collections.Generic.List<Complex[]>();
        var recycleD=new System.Collections.Generic.List<Complex[]>();
        int recycleApplied=0;
        void StoreCorrection(Complex[] delta)
        {
            var image=MatVec(delta);
            double initial=Norm(image);
            if(!double.IsFinite(initial)||initial<1e-25)return;
            for(int pass=0;pass<2;pass++)
                for(int k=0;k<recycleQ.Count;k++)
                {
                    Complex coeff=Complex.Zero;
                    for(int i=0;i<n;i++)coeff+=Complex.Conjugate(recycleQ[k][i])*image[i];
                    for(int i=0;i<n;i++) {image[i]-=coeff*recycleQ[k][i];delta[i]-=coeff*recycleD[k][i];}
                }
            double length=Norm(image);
            if(!double.IsFinite(length)||length<initial*1e-9)return;
            for(int i=0;i<n;i++){image[i]/=length;delta[i]/=length;}
            if(recycleQ.Count==recycleMax){recycleQ.RemoveAt(0);recycleD.RemoveAt(0);}
            recycleQ.Add(image);recycleD.Add(delta);
        }
        void ApplyRecycling(Complex[] residual)
        {
            for(int k=0;k<recycleQ.Count;k++)
            {
                Complex alpha=Complex.Zero;
                for(int i=0;i<n;i++)alpha+=Complex.Conjugate(recycleQ[k][i])*residual[i];
                for(int i=0;i<n;i++){x[i]+=alpha*recycleD[k][i];residual[i]-=alpha*recycleQ[k][i];}
            }
            if(recycleQ.Count>0)recycleApplied++;
        }
        var restartHistory=new System.Collections.Generic.List<(int Step,double Residual)>();
        double bestTrueResidual=double.PositiveInfinity;
        int bestTrueStep=0;
        // Conservative stagnation detector: eight full restarts without a
        // meaningful improvement. It never accepts an inaccurate solution.
        int stagnantRestarts=0;
        const int stagnantRestartLimit=8;
        const double meaningfulImprovement=0.002; // at least 0.2% per restart
        string ResidualHistory()
        {
            if(restartHistory.Count==0)return "no completed restarts";
            var recent=restartHistory.Skip(Math.Max(0,restartHistory.Count-8))
                .Select(e=>$"{e.Step}:{e.Residual:E3}");
            double last=restartHistory[restartHistory.Count-1].Residual;
            double oldest=restartHistory[Math.Max(0,restartHistory.Count-4)].Residual;
            double ratio=oldest>0?last/oldest:double.NaN;
            return $"best={bestTrueResidual:E3}@{bestTrueStep}; last restarts=[{string.Join(", ",recent)}]; " +
                   $"ratio(last/previous3)={ratio:E3}";
        }

        Complex[] CpuMatVec(Complex[] input)
        {
            var output=new Complex[n];
            void MultiplyRow(int i)
            {
                ct.ThrowIfCancellationRequested();
                int offset=i*n;
                double rr=0,ii=0;
                for(int j=0;j<n;j++)
                {
                    double vr=input[j].Real,vi=input[j].Imaginary;
                    rr+=ar[offset+j]*vr-ai[offset+j]*vi;
                    ii+=ar[offset+j]*vi+ai[offset+j]*vr;
                }
                output[i]=new Complex(rr,ii);
            }
            if(n>=512)
            {
                var options=new ParallelOptions { CancellationToken=ct,
                    MaxDegreeOfParallelism=Math.Max(1,Environment.ProcessorCount) };
                Parallel.For(0,n,options,MultiplyRow);
            }
            else for(int i=0;i<n;i++)MultiplyRow(i);
            return output;
        }

        // Check both numerical parity and speed before enabling GPU.
        // GeForce FP64 may be slower than optimized multicore CPU.
        if(cuda is not null)
        {
            var check=new Complex[n];
            for(int i=0;i<n;i++)check[i]=new Complex(Math.Sin(i*.173),Math.Cos(i*.107));
            var cpuClock=System.Diagnostics.Stopwatch.StartNew();
            var cpuCheck=CpuMatVec(check);cpuClock.Stop();
            var gpuClock=System.Diagnostics.Stopwatch.StartNew();
            if(cuda.TryMultiply(check,out var gpuCheck))
            {
                gpuClock.Stop();
                var delta=new Complex[n];
                for(int i=0;i<n;i++)delta[i]=gpuCheck[i]-cpuCheck[i];
                double discrepancy=Norm(delta)/Math.Max(Norm(cpuCheck),1e-30);
                // Benchmark several operations to amortize startup and copy variance.
                double cpuMs=cpuClock.Elapsed.TotalMilliseconds;
                double gpuMs=gpuClock.Elapsed.TotalMilliseconds;
                if(discrepancy<=1e-10)
                {
                    var sw=System.Diagnostics.Stopwatch.StartNew();
                    for(int k=0;k<3;k++)CpuMatVec(check);
                    sw.Stop();cpuMs=sw.Elapsed.TotalMilliseconds/3.0;
                    sw.Restart();
                    bool ok=true;
                    for(int k=0;k<3;k++)if(!cuda.TryMultiply(check,out _)){ok=false;break;}
                    sw.Stop();gpuMs=sw.Elapsed.TotalMilliseconds/3.0;
                    cudaEnabled=ok && gpuMs<cpuMs*0.90;
                }
                string reason=discrepancy>1e-10?"parity failed":cudaEnabled?"GPU faster >=10%":
                    cudaMode=="GPU_TEST"?"GPU_TEST completed; CPU used for production":
                    "GPU not >=10% faster (or benchmark failed)";
                if(cudaMode=="GPU_TEST")cudaEnabled=false;
                cudaStatus=$"CUDA: mode={cudaMode}; parity={discrepancy:E3}; CPU={cpuMs:F1} ms; GPU={gpuMs:F1} ms; selected={(cudaEnabled?"GPU":"CPU")}; reason={reason}";
                progress?.Report(cudaStatus);
            }
            else {cudaStatus="CUDA: first GPU MatVec failed; CPU fallback";progress?.Report(cudaStatus);}
        }
        Complex[] MatVec(Complex[] input)
        {
            long start=System.Diagnostics.Stopwatch.GetTimestamp();
            if(cudaEnabled && cuda is not null)
            {
                ct.ThrowIfCancellationRequested();
                if(cuda.TryMultiply(input,out var gpuOutput))
                {
                    long elapsed=System.Diagnostics.Stopwatch.GetTimestamp()-start;
                    profileMatVecTicks+=elapsed;profileGpuMatVecTicks+=elapsed;
                    profileMatVecCalls++;profileGpuCalls++;
                    return gpuOutput;
                }
                cudaEnabled=false;
                cudaStatus="CUDA: GPU MatVec failed during solve; CPU fallback";progress?.Report(cudaStatus);
            }
            long cpuStart=System.Diagnostics.Stopwatch.GetTimestamp();
            var cpuOutput=CpuMatVec(input);
            long cpuElapsed=System.Diagnostics.Stopwatch.GetTimestamp()-cpuStart;
            profileCpuMatVecTicks+=cpuElapsed;profileCpuCalls++;
            profileMatVecTicks+=System.Diagnostics.Stopwatch.GetTimestamp()-start;profileMatVecCalls++;
            return cpuOutput;
        }

        // Probe: a single application of M^{-1} to the actual RHS.
        // This is a diagnostic, NOT a convergence test or a condition number:
        // even an effective iterative preconditioner need not solve b in one step.
        double preconditionerProbe=double.NaN;
        {
            var probe=preconditioner.Apply(rhs);
            var applied=MatVec(probe);
            var difference=new Complex[n];
            for(int i=0;i<n;i++)difference[i]=rhs[i]-applied[i];
            preconditionerProbe=Norm(difference)/bnorm;
            progress?.Report($"MININEC FGMRES: probe ||b-A*M^-1*b||/||b||={preconditionerProbe:E3}; LU fallback={preconditioner.FallbackBlocks}; блок {blockSize}, overlap {overlap}.");
        }
        string GetDiagnostics()=>
            $"LU fallback={preconditioner.FallbackBlocks}; probe ||b-A*M^-1*b||/||b||={preconditionerProbe:E3}; " +
            $"max ортог.={maxOrthDefect:E3}; доп. MGS={correctivePasses}; " +
            $"LU блок={blockSize}, перекрытие={overlap}; recycle={recycleQ.Count}, projections={recycleApplied}; MatVec={(cudaEnabled?"CUDA":"CPU")}; {cudaStatus}. " + PerformanceProfile();

        while(total<maxIterations)
        {
            ct.ThrowIfCancellationRequested();
            var ax=MatVec(x);
            var r=new Complex[n];
            for(int i=0;i<n;i++)r[i]=rhs[i]-ax[i];
            if(total>0 && recycleQ.Count>0)
            {
                long recycleStart=System.Diagnostics.Stopwatch.GetTimestamp();
                ApplyRecycling(r);
                profileRecycleTicks+=System.Diagnostics.Stopwatch.GetTimestamp()-recycleStart;
                // Recompute with the original dense matrix to avoid treating an
                // accumulated projection residual as verified convergence.
                ax=MatVec(x);
                for(int i=0;i<n;i++)r[i]=rhs[i]-ax[i];
            }
            double beta=Norm(r);
            original=beta/bnorm;
            restartHistory.Add((total,original));
            if(original<bestTrueResidual){bestTrueResidual=original;bestTrueStep=total;}
            if(restartHistory.Count>1)
            {
                double before=restartHistory[restartHistory.Count-2].Residual;
                double factor=before>0?original/before:double.NaN;
                progress?.Report($"MININEC FGMRES диагностика: итерации={total}; true={original:E3}; " +
                    $"best={bestTrueResidual:E3}@{bestTrueStep}; изменение за цикл={factor:E3}. " +
                    (restartHistory.Count>=4 && original>restartHistory[restartHistory.Count-4].Residual*0.98
                        ? "Возможный застой: за три цикла невязка снизилась менее чем на 2%." : ""));
            }
            if(!double.IsFinite(original))
                throw new ArithmeticException("MININEC FGMRES: нечисловая невязка.");
            if(total>0 && restartHistory.Count>=2)
            {
                double previous=restartHistory[restartHistory.Count-2].Residual;
                stagnantRestarts=(previous>0 && original>=previous*(1-meaningfulImprovement))
                    ? stagnantRestarts+1 : 0;
            }
            if(n>2600 && total>0 && total%960==0)
                progress?.Report(PerformanceProfile());
            if(n>2600 && (total==960 || total==1920 || total==3840 || total==5760 || total==7680 || total==15360 || total==23040 || total==30720))
                progress?.Report($"MININEC FGMRES CHECKPOINT {total}/{maxIterations}: true={original:E6}, " +
                    $"best={bestTrueResidual:E6}@{bestTrueStep}, stagnant={stagnantRestarts}/{stagnantRestartLimit}; MatVec={(cudaEnabled?"CUDA":"CPU")}.");
            if(total>=960 && stagnantRestarts>=stagnantRestartLimit && original>requestedResidual)
                throw new GmresConvergenceException(total,original,GetDiagnostics()+
                    $" | СТОП: {stagnantRestartLimit} рестартов подряд без снижения >=0.2% за цикл. " +
                    "FGMRES trend: "+ResidualHistory());
            progress?.Report($"MININEC FGMRES: {total}/{maxIterations} ит.; истинная невязка {original:E3}; max |Vᴴw|/|w|={maxOrthDefect:E2}; доп. MGS={correctivePasses}; потоков до {Environment.ProcessorCount}.");
            if(original<=requestedResidual)
            {
                progress?.Report(PerformanceProfile());
                var xr=new double[n]; var xi=new double[n];
                for(int i=0;i<n;i++){xr[i]=x[i].Real;xi[i]=x[i].Imaginary;}
                return (xr,xi,total);
            }
            for(int i=0;i<n;i++)v[0][i]=r[i]/beta;
            Array.Clear(g,0,g.Length);
            Array.Clear(h,0,h.Length);
            g[0]=new Complex(beta,0);
            int used=0;
            for(int j=0;j<restart&&total<maxIterations;j++)
            {
                ct.ThrowIfCancellationRequested();
                // FGMRES stores the PRECONDITIONED basis explicitly.
                long preStart=System.Diagnostics.Stopwatch.GetTimestamp();
                z[j]=preconditioner.Apply(v[j]);
                profilePreconditionTicks+=System.Diagnostics.Stopwatch.GetTimestamp()-preStart;
                var w=MatVec(z[j]);
                long orthStart=System.Diagnostics.Stopwatch.GetTimestamp();
                // Two-pass Modified Gram-Schmidt is the baseline (present since 0.3.68).
                // Measure the remaining Arnoldi orthogonality error; an extra
                // corrective pass is performed only when the defect is significant.
                // h[k,j] accumulates projections from *every* pass.
                for(int pass=0;pass<2;pass++)
                    for(int k=0;k<=j;k++)
                    {
                        Complex dot=Complex.Zero;
                        for(int i=0;i<n;i++)dot+=Complex.Conjugate(v[k][i])*w[i];
                        h[k,j]+=dot;
                        for(int i=0;i<n;i++)w[i]-=dot*v[k][i];
                    }
                double orthDefect=0;
                double tentativeNorm=Norm(w);
                if(tentativeNorm>1e-30)
                {
                    for(int k=0;k<=j;k++)
                    {
                        Complex dot=Complex.Zero;
                        for(int i=0;i<n;i++)dot+=Complex.Conjugate(v[k][i])*w[i];
                        orthDefect=Math.Max(orthDefect,dot.Magnitude/tentativeNorm);
                    }
                    maxOrthDefect=Math.Max(maxOrthDefect,orthDefect);
                    if(orthDefect>1e-10)
                    {
                        correctivePasses++;
                        for(int k=0;k<=j;k++)
                        {
                            Complex dot=Complex.Zero;
                            for(int i=0;i<n;i++)dot+=Complex.Conjugate(v[k][i])*w[i];
                            h[k,j]+=dot;
                            for(int i=0;i<n;i++)w[i]-=dot*v[k][i];
                        }
                    }
                }
                double wnorm=Norm(w);
                if(!double.IsFinite(wnorm))
                    throw new ArithmeticException("MININEC FGMRES: нечисловой базис Арнольди.");
                profileOrthogonalTicks+=System.Diagnostics.Stopwatch.GetTimestamp()-orthStart;
                h[j+1,j]=new Complex(wnorm,0);
                if(wnorm>1e-30)
                    for(int i=0;i<n;i++)v[j+1][i]=w[i]/wnorm;
                for(int k=0;k<j;k++)
                {
                    var a=h[k,j]; var b=h[k+1,j];
                    h[k,j]=cosine[k]*a+sine[k]*b;
                    h[k+1,j]=-Complex.Conjugate(sine[k])*a+cosine[k]*b;
                }
                Complex aa=h[j,j],bb=h[j+1,j];
                double amag=aa.Magnitude,bmag=bb.Magnitude;
                double rho=Math.Sqrt(amag*amag+bmag*bmag);
                if(!double.IsFinite(rho)||rho<1e-30)
                    throw new ArithmeticException("MININEC FGMRES: вырожденное вращение Гивенса.");
                cosine[j]=amag/rho;
                sine[j]=amag>1e-30?(aa/amag)*Complex.Conjugate(bb)/rho:Complex.Conjugate(bb)/rho;
                h[j,j]=cosine[j]*aa+sine[j]*bb;
                h[j+1,j]=Complex.Zero;
                g[j+1]=-Complex.Conjugate(sine[j])*g[j];
                g[j]=cosine[j]*g[j];
                used=j+1; total++;
                if(total%48==0)
                    progress?.Report($"MININEC FGMRES: {total} ит.; оценка невязки {g[j+1].Magnitude/bnorm:E3}; дефект ортог. {maxOrthDefect:E2}; доп. MGS={correctivePasses}");
                if(g[j+1].Magnitude/bnorm<=requestedResidual||wnorm<=1e-30)break;
            }
            if(used<1)throw new ArithmeticException("MININEC FGMRES: отсутствует шаг итерации.");
            var y=new Complex[used];
            for(int i=used-1;i>=0;i--)
            {
                Complex value=g[i];
                for(int j=i+1;j<used;j++)value-=h[i,j]*y[j];
                if(h[i,i].Magnitude<1e-22)
                    throw new ArithmeticException("MININEC FGMRES: вырожденная малая задача.");
                y[i]=value/h[i,i];
            }
            // Correct the ORIGINAL unknown using the right-preconditioned basis.
            // Retain the direction and its image for future minimum-residual
            // projections; never use it to declare convergence without true r.
            var cycleDelta=new Complex[n];
            for(int j=0;j<used;j++)
                for(int i=0;i<n;i++)cycleDelta[i]+=y[j]*z[j][i];
            for(int i=0;i<n;i++)x[i]+=cycleDelta[i];
            if(n>2600)
            {
                long recycleStart=System.Diagnostics.Stopwatch.GetTimestamp();
                StoreCorrection(cycleDelta);
                profileRecycleTicks+=System.Diagnostics.Stopwatch.GetTimestamp()-recycleStart;
            }
            // The last Arnoldi step can exactly consume the iteration budget.
            // Decide extension HERE, before the enclosing while(total<maxIterations)
            // condition would otherwise terminate the solve.
            if(n>2600 && total>=maxIterations && maxIterations<absoluteMaxIterations)
            {
                var checkAx=MatVec(x);
                var checkR=new Complex[n];
                for(int i=0;i<n;i++)checkR[i]=rhs[i]-checkAx[i];
                double checkResidual=Norm(checkR)/bnorm;
                if(!double.IsFinite(checkResidual))
                    throw new ArithmeticException("MININEC FGMRES: нечисловая невязка на границе лимита.");
                double older=restartHistory[Math.Max(0,restartHistory.Count-10)].Residual;
                double previous=restartHistory.Count>0?restartHistory[^1].Residual:double.PositiveInfinity;
                bool trending=checkResidual<=requestedResidual ||
                    (older>0 && checkResidual<older*0.97) ||
                    (previous>0 && checkResidual<previous*0.998);
                if(checkResidual>requestedResidual && trending && stagnantRestarts<stagnantRestartLimit)
                {
                    int oldLimit=maxIterations;
                    maxIterations=Math.Min(absoluteMaxIterations,maxIterations+extensionBlock);
                    progress?.Report($"MININEC FGMRES АВТОПРОДЛЕНИЕ: {total}/{maxIterations} ит.; " +
                        $"предыдущий лимит={oldLimit}; истинная невязка {checkResidual:E6}; " +
                        $"цель={requestedResidual:E3}; предел={absoluteMaxIterations}.");
                }
                else if(checkResidual>requestedResidual)
                    progress?.Report($"MININEC FGMRES: автопродление прекращено: итераций {total}; невязка {checkResidual:E6}; нет улучшения.");
            }
        }
        var lastAx=MatVec(x);
        var lastR=new Complex[n];
        for(int i=0;i<n;i++)lastR[i]=rhs[i]-lastAx[i];
        original=Norm(lastR)/bnorm;
        restartHistory.Add((total,original));
        if(double.IsFinite(original)&&original<bestTrueResidual){bestTrueResidual=original;bestTrueStep=total;}
        if(double.IsFinite(original)&&original<=requestedResidual)
        {
            progress?.Report(PerformanceProfile());
            var xr=new double[n]; var xi=new double[n];
            for(int i=0;i<n;i++){xr[i]=x[i].Real;xi[i]=x[i].Imaginary;}
            return (xr,xi,total);
        }
        throw new GmresConvergenceException(total,original,GetDiagnostics()+" | FGMRES trend: "+ResidualHistory());
    }
    private static double Norm(Complex[] x)
    {
        double v=0;
        foreach(var c in x) v+=c.Real*c.Real+c.Imaginary*c.Imaginary;
        return Math.Sqrt(v);
    }

    internal static (double[] Real,double[] Imag) GaussianSolve(double[] ar0,double[] ai0,double[] br0,double[] bi0,int n,CancellationToken ct,IProgress<string>? progress=null)
    {
        double[] ar=(double[])ar0.Clone(),ai=(double[])ai0.Clone(),br=(double[])br0.Clone(),bi=(double[])bi0.Clone();
        int Id(int i,int j)=>i*n+j;
        for(int i=0;i<n;i++)
        {
            double mx=0;for(int j=0;j<n;j++)mx=Math.Max(mx,Math.Sqrt(ar[Id(i,j)]*ar[Id(i,j)]+ai[Id(i,j)]*ai[Id(i,j)]));
            if(!double.IsFinite(mx)||mx<=1e-300)throw new ArithmeticException($"MININEC: пустая строка матрицы {i}");
            double inv=1/mx;
            for(int j=0;j<n;j++){int q=Id(i,j);ar[q]*=inv;ai[q]*=inv;}
            br[i]*=inv;bi[i]*=inv;
        }
        for(int k=0;k<n;k++)
        {
            if((k&3)==0)ct.ThrowIfCancellationRequested();
            if(progress!=null && (k%32==0 || k==n-1))
                progress.Report($"MININEC: прямой LU {k+1}/{n} ({100.0*(k+1)/n:0.0}%). Стоп работает.");
            int piv=k;double best=-1;
            for(int i=k;i<n;i++)
            {
                double z=Math.Sqrt(ar[Id(i,k)]*ar[Id(i,k)]+ai[Id(i,k)]*ai[Id(i,k)]);
                if(z>best){best=z;piv=i;}
            }
            if(!double.IsFinite(best)||best<1e-12)throw new ArithmeticException($"MININEC: плохо обусловленный опорный элемент {k}");
            if(piv!=k)
            {
                for(int j=0;j<n;j++)
                {
                    int a=Id(k,j),b=Id(piv,j);(ar[a],ar[b])=(ar[b],ar[a]);(ai[a],ai[b])=(ai[b],ai[a]);
                }
                (br[k],br[piv])=(br[piv],br[k]);(bi[k],bi[piv])=(bi[piv],bi[k]);
            }
            double akr=ar[Id(k,k)],aki=ai[Id(k,k)],den=akr*akr+aki*aki;
            for(int i=k+1;i<n;i++)
            {
                int q=Id(i,k);double xr=ar[q],xi=ai[q];
                double fr=(xr*akr+xi*aki)/den,fi=(xi*akr-xr*aki)/den;
                ar[q]=0;ai[q]=0;
                for(int j=k+1;j<n;j++)
                {
                    int ij=Id(i,j),kj=Id(k,j);
                    ar[ij]-=fr*ar[kj]-fi*ai[kj];ai[ij]-=fr*ai[kj]+fi*ar[kj];
                }
                br[i]-=fr*br[k]-fi*bi[k];bi[i]-=fr*bi[k]+fi*br[k];
            }
        }
        var xrOut=new double[n];var xiOut=new double[n];
        for(int i=n-1;i>=0;i--)
        {
            double sr=br[i],si=bi[i];
            for(int j=i+1;j<n;j++)
            {
                int q=Id(i,j);sr-=ar[q]*xrOut[j]-ai[q]*xiOut[j];si-=ar[q]*xiOut[j]+ai[q]*xrOut[j];
            }
            double dr=ar[Id(i,i)],di=ai[Id(i,i)],den=dr*dr+di*di;
            xrOut[i]=(sr*dr+si*di)/den;xiOut[i]=(si*dr-sr*di)/den;
        }
        return(xrOut,xiOut);
    }
    private static double Residual(double[] ar,double[] ai,double[] xr,double[] xi,double[] br,double[] bi,int n)
    {
        double num=0,den=0;
        for(int i=0;i<n;i++)
        {
            double rr=-br[i],ri=-bi[i];
            for(int j=0;j<n;j++)
            {
                int q=i*n+j;rr+=ar[q]*xr[j]-ai[q]*xi[j];ri+=ar[q]*xi[j]+ai[q]*xr[j];
            }
            num+=rr*rr+ri*ri;den+=br[i]*br[i]+bi[i]*bi[i];
        }
        return Math.Sqrt(num/Math.Max(den,1e-300));
    }
}
