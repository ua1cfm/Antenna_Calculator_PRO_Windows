﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace AntennaCalculator.Core;

// A literal C# port of the baseline MmanaGalSegmentation physical-span rules
// from Android 1.19.268, for ordinary wires (no special Tei/stack path).
public static class MininecSegmentation
{
    internal readonly record struct Span(double F0, double F1);
    public readonly record struct Parameters(int Dm1, int Dm2, double Sc, int Ec);
    public static Parameters Parse(string? record)
    {
        var matches=Regex.Matches(record??"", @"[-+]?\d+(?:[.,]\d+)?");
        if(matches.Count<4)return new(200,20,2,1);
        double Num(int i)=>double.Parse(matches[i].Value.Replace(',','.'),CultureInfo.InvariantCulture);
        int d1=(int)Math.Round(Num(0),MidpointRounding.AwayFromZero),d2=(int)Math.Round(Num(1),MidpointRounding.AwayFromZero);
        if(d1<=0)d1=200;if(d2<=0)d2=20;if(d1<d2)(d1,d2)=(d2,d1);
        return new(d1,d2,Math.Clamp(Num(2),1.01,3),Math.Max(1,(int)Math.Round(Num(3),MidpointRounding.AwayFromZero)));
    }
    internal static List<Span> Uniform(int n)
    {
        n=Math.Max(1,n);var spans=new List<Span>(n);
        for(int i=0;i<n;i++)spans.Add(new((double)i/n,(double)(i+1)/n));
        return spans;
    }
    internal static List<Span> Spans(double length,double lambda,int tag,Parameters p)
    {
        if(length<=1e-15||lambda<=1e-15)return Uniform(1);
        if(tag>0)return Uniform(tag);
        double fine=Math.Max(lambda/p.Dm1,lambda*0.001);
        double coarse=Math.Max(lambda/p.Dm2,fine);
        if(tag==0||tag < -3)return Uniform(Math.Max(1,(int)Math.Ceiling(length/coarse)));
        var end=new List<double>{fine};double s=fine*p.Sc;
        for(int guard=0;s<coarse-1e-12&&guard<64;guard++,s*=p.Sc)end.Add(s);
        int ends=tag==-1?2:1;
        if(end.Sum()*ends>=length-1e-12)return Uniform(Math.Max(1,(int)Math.Ceiling(length/fine)));
        double remain=Math.Max(0,length-end.Sum()*ends);
        int middle=remain>1e-12?Math.Max(1,(int)Math.Ceiling(remain/coarse)):0;
        var lengths=new List<double>();
        if(tag==-1||tag==-2)lengths.AddRange(end);
        for(int i=0;i<middle;i++)lengths.Add(remain/middle);
        if(tag==-1||tag==-3)lengths.AddRange(end.AsEnumerable().Reverse());
        if(lengths.Count==0)return Uniform(1);
        var result=new List<Span>(lengths.Count);double accumulated=0;
        for(int i=0;i<lengths.Count;i++)
        {
            double start=Math.Clamp(accumulated/length,0,1);accumulated+=lengths[i];
            double stop=i==lengths.Count-1?1:Math.Clamp(accumulated/length,start,1);
            if(stop>start+1e-15)result.Add(new(start,stop));
        }
        return result.Count==0?Uniform(1):result;
    }
    internal static int PulseIndex(char position,int count,int offset)
    {
        if(count<1)throw new ArgumentOutOfRangeException(nameof(count));
        int i=char.ToLowerInvariant(position) switch {'b'=>0,'e'=>count-1,_=>(count-1)/2};
        return Math.Clamp(i+offset,0,count-1);
    }
}
