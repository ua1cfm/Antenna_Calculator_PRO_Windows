﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("AntennaCalculator.Tests")]
