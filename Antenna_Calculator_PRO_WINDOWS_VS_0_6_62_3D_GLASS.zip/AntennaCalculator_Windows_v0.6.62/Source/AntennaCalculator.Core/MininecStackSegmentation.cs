﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AntennaCalculator.Core;

/// <summary>
/// MMANA-GAL ComLib TeiAvg / Tei / TeiB / TeiE physical segmentation.
/// Literal algorithm port of Android MmanaStackSegmentation.kt 1.19.268.
/// Used for expanded Make Stack arrays and dense short-wire Tei regime.
/// No impedance calibration or arbitrary geometry edits.
/// </summary>
internal static class MininecStackSegmentation
{
    private const double Dm2Def = 0.85;
    internal static List<MininecSegmentation.Span> Spans(double length,double lambda,int mode,MininecSegmentation.Parameters p)
    {
        if(length<=1e-15 || lambda<=1e-15) return new(){new(0,1)};
        if(mode>0)return MininecSegmentation.Uniform(mode);
        return mode switch {
            0 => UniformTei(length,lambda,p.Dm2),
            -1 => Taper(length,lambda,p,0),
            -2 => Taper(length,lambda,p,-1),
            -3 => Taper(length,lambda,p,+1),
            _ => Taper(length,lambda,p,0,-mode)
        };
    }
    private static List<MininecSegmentation.Span> UniformTei(double length,double lambda,int dm)
    {
        double d=Math.Max(1,dm);
        int n=(int)(length/(lambda/d));
        n &= 0x0000fffe;
        if(n==0)n+=2;
        if(n<=4 && ((length/n)*Dm2Def>lambda/d))n+=2;
        return MininecSegmentation.Uniform(Math.Max(2,n));
    }
    private static List<MininecSegmentation.Span> Taper(double length,double lambda,MininecSegmentation.Parameters p,int side,int? dm1Override=null)
    {
        double dm1=Math.Max(1,(dm1Override>1?dm1Override.Value:p.Dm1));
        double dm2=Math.Max(1,p.Dm2);
        double sc=Math.Max(1.0000001,p.Sc);
        int ec=Math.Max(1,p.Ec);
        while(dm2<dm1)
        {
            double dm=dm1,tt=0;
            int nt=0;
            while(dm>dm2&&nt<256)
            {
                tt+=lambda*(nt==0?ec:1)/dm;
                dm/=sc;nt++;
            }
            int ends=side==0?2:1;
            double remaining=length-tt*ends;
            int n=(int)(remaining/(lambda/dm2));
            if(side==0)n &= 0x0000fffe;
            bool acceptable=side==0?remaining>0&&n>=2:remaining>0&&n!=0;
            if(acceptable)
            {
                List<double> StartTaper()
                {
                    var list=new List<double>();double dmx=dm1;int k=0;
                    while(dmx>dm2&&k<256)
                    {
                        if(k==0)for(int e=0;e<ec;e++)list.Add(lambda/dmx);
                        else list.Add(lambda/dmx);
                        dmx/=sc;k++;
                    }
                    return list;
                }
                var lengths=new List<double>();
                if(side<=0)lengths.AddRange(StartTaper());
                int middleN=n;
                if(side==0)
                {
                    double middleEach=remaining/middleN;
                    if(middleN<=4 && ((middleEach/middleN)*Dm2Def>lambda/dm2))middleN+=2;
                }
                else if ((remaining/middleN)*Dm2Def>lambda/Math.Max(1,p.Dm2))middleN++;
                for(int i=0;i<middleN;i++)lengths.Add(remaining/middleN);
                if(side>=0)lengths.AddRange(StartTaper().AsEnumerable().Reverse());
                return ToSpans(lengths,length);
            }
            dm2*=side==0?2.0:1.25;
        }
        return UniformTei(length,lambda,(int)dm1);
    }
    private static List<MininecSegmentation.Span> ToSpans(List<double> initial,double total)
    {
        var lengths=initial.Where(x=>x>1e-15).ToArray();
        if(lengths.Length==0)return new(){new(0,1)};
        double sum=lengths.Sum(),scale=sum>1e-15?total/sum:1;
        double acc=0;var output=new List<MininecSegmentation.Span>();
        for(int i=0;i<lengths.Length;i++)
        {
            double f0=Math.Clamp(acc/total,0,1);
            acc+=lengths[i]*scale;
            double f1=i==lengths.Length-1?1:Math.Clamp(acc/total,f0,1);
            if(f1>f0+1e-15)output.Add(new(f0,f1));
        }
        return output.Count>0?output:new(){new(0,1)};
    }
}
