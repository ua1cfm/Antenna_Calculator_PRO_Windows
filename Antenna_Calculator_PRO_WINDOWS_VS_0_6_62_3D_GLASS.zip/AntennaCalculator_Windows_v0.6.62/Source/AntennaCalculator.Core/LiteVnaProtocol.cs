using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Numerics;

namespace AntennaCalculator.Core;

/// <summary>
/// LiteVNA64 / SAA2 (NanoVNA V2 family) binary USB protocol, little-endian.
/// Port of the Android implementation (LiteVnaProtocol.kt / LiteVnaUsb.kt) that is used with the real
/// instrument. No I/O here: command encoders, FIFO record decoder and a sweep assembler that can be tested
/// without hardware.
/// </summary>
public static class LiteVnaProtocol
{
    public const byte OpNop=0x00, OpIndicate=0x0d, OpRead=0x10, OpRead2=0x11, OpRead4=0x12, OpReadFifo=0x18,
                      OpWrite=0x20, OpWrite2=0x21, OpWrite4=0x22, OpWrite8=0x23;
    public const byte RegSweepStartHz=0x00, RegSweepStepHz=0x10, RegSweepPoints=0x20, RegValuesPerFrequency=0x22,
                      RegRawSamplesMode=0x26, RegValuesFifo=0x30, RegAverage=0x40, RegChannelSelect=0x44,
                      RegDeviceVariant=0xf0, RegProtocolVersion=0xf1, RegHardwareRevision=0xf2,
                      RegFirmwareMajor=0xf3, RegFirmwareMinor=0xf4;
    public const int FifoRecordBytes=32;
    public const byte IndicateReply=0x32;      // '2'
    public const int LiteVnaVariant=2;
    public const long MinFrequencyHz=50_000L, MaxFrequencyHz=6_300_000_000L;

    public sealed class SweepConfig
    {
        public long StartHz { get; }
        public long StopHz { get; }
        public int Points { get; }
        public int Average { get; }
        public long StepHz { get; }
        public SweepConfig(long startHz,long stopHz,int points,int average=1)
        {
            if(startHz<MinFrequencyHz) throw new ArgumentException("Начальная частота должна быть не меньше 50 кГц.");
            if(stopHz<=startHz) throw new ArgumentException("Конечная частота должна быть больше начальной.");
            if(stopHz>MaxFrequencyHz) throw new ArgumentException("Конечная частота LiteVNA64 — не больше 6,3 ГГц.");
            if(points<2 || points>65535) throw new ArgumentException("Число точек: 2…65535.");
            if(average<1 || average>80) throw new ArgumentException("Усреднение: 1…80.");
            StartHz=startHz; StopHz=stopHz; Points=points; Average=average;
            StepHz=Math.Max(1L,(long)Math.Round((stopHz-startHz)/(double)(points-1),MidpointRounding.AwayFromZero));
        }
        public double FrequencyHz(int index)=>StartHz+(double)StepHz*index;
        public long ActualStopHz=>StartHz+StepHz*(Points-1L);
        public bool SameGrid(SweepConfig other)=>other.StartHz==StartHz && other.StepHz==StepHz && other.Points==Points;
        /// <summary>Same grid and averaging: the instrument does not need to be configured again.</summary>
        public bool SameSettings(SweepConfig? other)=>other!=null && SameGrid(other) && other.Average==Average;
    }

    public readonly record struct RawValue(int Fwd0Re,int Fwd0Im,int Rev0Re,int Rev0Im,int Rev1Re,int Rev1Im,int FrequencyIndex)
    {
        public Complex S11()=>Divide(new Complex(Rev0Re,Rev0Im),new Complex(Fwd0Re,Fwd0Im));
        public Complex S21()=>Divide(new Complex(Rev1Re,Rev1Im),new Complex(Fwd0Re,Fwd0Im));
    }

    static Complex Divide(Complex a,Complex b)
    {
        double d=b.Real*b.Real+b.Imaginary*b.Imaginary;
        if(!(d>1e-30) || !double.IsFinite(d)) return new Complex(double.NaN,double.NaN);
        return new Complex((a.Real*b.Real+a.Imaginary*b.Imaginary)/d,(a.Imaginary*b.Real-a.Real*b.Imaginary)/d);
    }

    public static byte[] Indicate()=>new[]{ OpIndicate };
    public static byte[] Nops(int count=8)=>new byte[count];
    public static byte[] ReadByte(byte address)=>new[]{ OpRead, address };
    public static byte[] ReadFifo(int count)
    {
        if(count<1 || count>255) throw new ArgumentOutOfRangeException(nameof(count));
        return new[]{ OpReadFifo, RegValuesFifo, (byte)count };
    }
    public static byte[] WriteByte(byte address,int value)=>new[]{ OpWrite, address, (byte)value };
    public static byte[] Write2(byte address,int value)
    {
        if(value<0 || value>0xffff) throw new ArgumentOutOfRangeException(nameof(value));
        return new[]{ OpWrite2, address, (byte)(value&0xff), (byte)((value>>8)&0xff) };
    }
    public static byte[] Write8(byte address,long value)
    {
        if(value<0) throw new ArgumentOutOfRangeException(nameof(value));
        var b=new byte[10]; b[0]=OpWrite8; b[1]=address;
        for(int i=0;i<8;i++) b[2+i]=(byte)((value>>(8*i))&0xff);
        return b;
    }

    /// <summary>
    /// Commands that start USB sweep mode with the given grid (same order as the Android app).
    /// The averaging (0x40) and channel-select (0x44) registers exist on LiteVNA (deviceVariant 2) only;
    /// for other V2-family instruments they are not written.
    /// </summary>
    public static byte[][] ConfigureSweep(SweepConfig c,bool liteVnaRegisters=true)
    {
        var list=new List<byte[]>
        {
            WriteByte(RegValuesFifo,0),                 // clear stale FIFO
            Write8(RegSweepStartHz,c.StartHz),
            Write8(RegSweepStepHz,c.StepHz),
            Write2(RegSweepPoints,c.Points),
            Write2(RegValuesPerFrequency,1)
        };
        if(liteVnaRegisters) list.Add(WriteByte(RegAverage,c.Average));
        list.Add(WriteByte(RegRawSamplesMode,0));       // USB data mode
        if(liteVnaRegisters) list.Add(WriteByte(RegChannelSelect,0));   // S11 + S21
        list.Add(WriteByte(RegValuesFifo,0));           // fresh data only
        return list.ToArray();
    }

    public static RawValue ParseRawValue(ReadOnlySpan<byte> b)
    {
        if(b.Length<FifoRecordBytes) throw new ArgumentException("FIFO record is shorter than 32 bytes.");
        return new RawValue(
            BinaryPrimitives.ReadInt32LittleEndian(b.Slice(0,4)),
            BinaryPrimitives.ReadInt32LittleEndian(b.Slice(4,4)),
            BinaryPrimitives.ReadInt32LittleEndian(b.Slice(8,4)),
            BinaryPrimitives.ReadInt32LittleEndian(b.Slice(12,4)),
            BinaryPrimitives.ReadInt32LittleEndian(b.Slice(16,4)),
            BinaryPrimitives.ReadInt32LittleEndian(b.Slice(20,4)),
            BinaryPrimitives.ReadUInt16LittleEndian(b.Slice(24,2)));
    }

    /// <summary>
    /// Collects one coherent sweep from the continuously running FIFO: synchronizes on frequency
    /// index 0 and restarts if a new index 0 arrives before completion (never mixes two sweeps).
    /// </summary>
    public sealed class SweepAssembler
    {
        readonly RawValue?[] _values;
        bool _synced;
        public int Received { get; private set; }
        public int Points=>_values.Length;
        public SweepAssembler(int points){ _values=new RawValue?[points]; }
        public bool Complete=>Received>=_values.Length;
        /// <summary>Returns true when the sweep is complete.</summary>
        public bool Feed(RawValue v)
        {
            int idx=v.FrequencyIndex;
            if(idx<0 || idx>=_values.Length) return Complete;
            if(!_synced)
            {
                if(idx!=0) return false;
                Array.Clear(_values); _values[0]=v; Received=1; _synced=true;
                return Complete;
            }
            if(idx==0 && Received<_values.Length)
            {
                Array.Clear(_values); _values[0]=v; Received=1;
                return Complete;
            }
            if(_values[idx]==null){ _values[idx]=v; Received++; }
            else _values[idx]=v;
            return Complete;
        }
        public RawValue[] Result()
        {
            if(!Complete) throw new InvalidOperationException("Развёртка не собрана полностью.");
            var r=new RawValue[_values.Length];
            for(int i=0;i<r.Length;i++) r[i]=_values[i]!.Value;
            return r;
        }
    }
}
