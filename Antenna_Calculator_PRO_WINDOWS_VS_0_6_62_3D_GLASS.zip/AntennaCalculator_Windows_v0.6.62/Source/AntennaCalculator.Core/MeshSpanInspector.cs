﻿using System;
using System.Linq;

namespace AntennaCalculator.Core;

/// <summary>Observes the same ordinary-wire segmentation used by Build; no solver modification.</summary>
public static class MeshSpanInspector
{
    public readonly record struct SpanInfo(int Wire, int Spans, double MinLengthMm, double MaxLengthMm,
        double MinOverDiameter, double MaxOverDiameter, int BelowDiameter, int BelowTwoDiameters);

    public static SpanInfo Inspect(MaaModel model, MaaWire wire, double referenceFrequencyMHz)
    {
        const double cMHz=299.792458;
        var p=MininecSegmentation.Parse(model.SegmentationRecord);
        var spans=MininecSegmentation.Spans(wire.LengthMetres,cMHz/referenceFrequencyMHz,wire.Tag,p);
        if(spans.Count<2)spans=MininecSegmentation.Uniform(2);
        double d=2*wire.RadiusMetres;
        var lengths=spans.Select(s=>(s.F1-s.F0)*wire.LengthMetres).ToArray();
        return new(wire.Number,lengths.Length,lengths.Min()*1000,lengths.Max()*1000,
            lengths.Min()/d,lengths.Max()/d,lengths.Count(x=>x<d),lengths.Count(x=>x<2*d));
    }
}
