using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace AntennaCalculator.Wpf;

/// <summary>
/// Full-screen mode of the EM field view (2D map and 3D volume). The field host (FieldHost: both views) is moved
/// into a borderless window that covers the screen of the main window and moved back on exit, so the computed field,
/// the animation, rotation and zoom are kept. Enter: button «⛶» or F11 on the EM FIELD tab. Exit: Esc, F11 or «Выйти».
/// Space toggles the phase animation in full screen.
/// </summary>
public partial class MainWindow
{
    private Window? _fieldFullscreen;

    private void FieldFullscreen_Click(object sender, RoutedEventArgs e) => ToggleFieldFullscreen();

    private void ToggleFieldFullscreen()
    {
        if (_fieldFullscreen != null) ExitFieldFullscreen(); else EnterFieldFullscreen();
    }

    private void EnterFieldFullscreen()
    {
        if (_fieldFullscreen != null || FieldHost.Parent != FieldHostBorder) return;
        FieldHostBorder.Child = null;

        var root = new Grid { Background = Brushes.Black };
        root.Children.Add(FieldHost);
        var exit = new Button
        {
            Content = "✕  Выйти · Esc",
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Top,
            Margin = new Thickness(0, 12, 14, 0),
            Padding = new Thickness(12, 5, 12, 5),
            Opacity = 0.8,
            Foreground = Brushes.White,
            Background = new SolidColorBrush(Color.FromArgb(150, 40, 46, 54)),
            BorderBrush = new SolidColorBrush(Color.FromArgb(160, 120, 130, 140)),
            Cursor = Cursors.Hand,
            ToolTip = "Выйти из полноэкранного режима (Esc или F11)",
            Focusable = false
        };
        exit.MouseEnter += (_, __) => exit.Opacity = 1;
        exit.MouseLeave += (_, __) => exit.Opacity = 0.8;
        exit.Click += (_, __) => ExitFieldFullscreen();
        root.Children.Add(exit);

        var window = new Window
        {
            Title = Title + " — ЭМ поле",
            Content = root,
            Owner = this,
            WindowStyle = WindowStyle.None,
            ResizeMode = ResizeMode.NoResize,
            Background = Brushes.Black,
            ShowInTaskbar = false,
            WindowStartupLocation = WindowStartupLocation.Manual,
            // Start on the screen of the main window; maximizing a borderless window covers that whole screen.
            Left = Left + 40, Top = Top + 40,
            Width = Math.Max(480, ActualWidth - 80), Height = Math.Max(360, ActualHeight - 80)
        };
        window.Loaded += (_, __) => { window.WindowState = WindowState.Maximized; window.Activate(); };
        window.PreviewKeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape || e.Key == Key.F11) { ExitFieldFullscreen(); e.Handled = true; }
            else if (e.Key == Key.Space) { FieldPlayButton_Click(FieldPlayButton, new RoutedEventArgs()); e.Handled = true; }
        };
        window.Closed += (_, __) => RestoreFieldHost();
        _fieldFullscreen = window;
        FieldFullscreenButton.IsEnabled = false;
        window.Show();
    }

    private void ExitFieldFullscreen() => _fieldFullscreen?.Close();     // Closed puts the views back

    private void RestoreFieldHost()
    {
        if (_fieldFullscreen == null) return;
        if (FieldHost.Parent is Panel panel) panel.Children.Remove(FieldHost);
        else if (FieldHost.Parent is ContentControl content) content.Content = null;
        FieldHostBorder.Child = FieldHost;
        _fieldFullscreen = null;
        FieldFullscreenButton.IsEnabled = true;
        FieldMap.InvalidateVisual();
        FieldVolume.InvalidateVisual();
        Activate();
    }
}
