﻿using System;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>Normalized pattern cuts from the same coherent vector field as the 3D view.</summary>
public sealed class Pattern2DView : FrameworkElement
{
    private MininecPulseSolver.Result? _result;
    private int _groundType;
    private double _eps=13, _sigma=0.005;
    private double[] _az=Array.Empty<double>(), _el=Array.Empty<double>();
    private double _azPeak, _elPeak, _elCutPeak, _fb, _gainEstimate, _azHpbw, _elHpbw;
    private bool _valid;
    private double _zoom=1.0;
    private const double _angleStep=2.0;
    public void SetZoom(double zoom){_zoom=Math.Clamp(zoom,0.6,3.0);InvalidateVisual();}
    public void SetAngleStep(double step){ /* Fixed 2° sampling for 2D and 3D patterns. */ }
    private int _revision;
    public void SetResult(MininecPulseSolver.Result? result,int groundType,double eps=13,double sigma=0.005)
    {
        _result=result;_groundType=groundType;_eps=eps;_sigma=sigma;
        Recalculate();
    }
    private void Recalculate()
    {
        _valid=false;InvalidateVisual();
        int revision=Interlocked.Increment(ref _revision);
        var samples=_result?.FieldSamples;
        if(samples==null||samples.Count==0)return;
        var result=_result!;
        int ground=_groundType;
        double eps=_eps,sigma=_sigma,step=_angleStep;
        _=Task.Run(() => CalculateCuts(samples,result.FrequencyMHz,ground,eps,sigma,step))
          .ContinueWith(t => Dispatcher.BeginInvoke(new Action(() =>
          {
              if(revision!=_revision||t.IsFaulted||t.IsCanceled||t.Result==null)return;
              var cuts=t.Result;
              _az=cuts.Az;_el=cuts.El;_azPeak=cuts.AzPeak;_elPeak=cuts.ElPeak;_elCutPeak=cuts.ElCutPeak;_fb=cuts.Fb;_gainEstimate=cuts.GainEstimate;_azHpbw=cuts.AzHpbw;_elHpbw=cuts.ElHpbw;
              _valid=true;InvalidateVisual();
          })),TaskScheduler.Default);
    }
    private sealed record Cuts(double[] Az,double[] El,double AzPeak,double ElPeak,double ElCutPeak,double Fb,double GainEstimate,double AzHpbw,double ElHpbw);
    private static Cuts? CalculateCuts(System.Collections.Generic.IReadOnlyList<MininecPulseSolver.FieldSample> samples,
        double frequency,int ground,double eps,double sigma,double step)
    {
        int azN=(int)Math.Round(360/step),elN=(int)Math.Round((ground==0?180:90)/step);
        double elMin=ground==0?-90:0, elMax=90;
        double maximum=-1;int maxAz=0,maxEl=0;double integratedPower=0;
        double[,] power=new double[elN+1,azN];
        for(int ie=0;ie<=elN;ie++)
        {
            double elevation=(elMin+(elMax-elMin)*ie/elN)*Math.PI/180;
            double h=Math.Cos(elevation),z=Math.Sin(elevation);
            for(int ia=0;ia<azN;ia++)
            {
                double az=ia*2*Math.PI/azN;
                var e=RadiationField.Direction(samples,frequency,ground,h*Math.Cos(az),h*Math.Sin(az),z,eps,sigma);
                double v=e.Power;power[ie,ia]=v;
                if(double.IsFinite(v)&&v>=0)
                {
                    double edgeWeight=(ie==0||ie==elN)?0.5:1.0;
                    integratedPower+=v*Math.Max(0,Math.Cos(elevation))*edgeWeight;
                }
                if(double.IsFinite(v)&&v>maximum){maximum=v;maxAz=ia;maxEl=ie;}
            }
        }
        if(maximum<=0)return null;
        double azPeak=maxAz*360.0/azN,elPeak=elMin+(elMax-elMin)*maxEl/elN;
        var azValues=new double[azN+1];
        for(int i=0;i<azN;i++)azValues[i]=10*Math.Log10(Math.Max(1e-30,power[maxEl,i]/maximum));
        azValues[azN]=azValues[0];
        // Full vertical great-circle cut: +X (chosen azimuth) to zenith,
        // across to -X (opposite azimuth), and, in free space, around nadir.
        // Do NOT mirror the forward curve: the back hemisphere is sampled.
        int verticalN=(int)Math.Round((ground==0?360.0:180.0)/step);
        var elValues=new double[verticalN+1];
        double peakAzRadians=azPeak*Math.PI/180.0;
        double ax=Math.Cos(peakAzRadians), ay=Math.Sin(peakAzRadians);
        for(int i=0;i<=verticalN;i++)
        {
            double a=i*step*Math.PI/180.0;
            double forward=Math.Cos(a), height=Math.Sin(a);
            var field=RadiationField.Direction(samples,frequency,ground,
                forward*ax,forward*ay,height,eps,sigma);
            elValues[i]=10*Math.Log10(Math.Max(1e-30,field.Power/maximum));
        }
        if(ground==0)elValues[verticalN]=elValues[0];
        int peakInCut=Array.IndexOf(elValues,elValues.Max());
        // 0° on the right-hand polar plot is the forward horizon.
        // First quarter is forward elevation, second is rear elevation.
        double cutSweep=peakInCut*step;
        double elevationOfCutPeak=ground==0 ?
            (cutSweep<=90?cutSweep:cutSweep<=270?180-cutSweep:cutSweep-360) :
            (cutSweep<=90?cutSweep:180-cutSweep);
        double back=power[maxEl,(maxAz+azN/2)%azN];
        // Integrate radiation intensity over the observable solid angle.
        // This is directivity, i.e. an upper-bound estimate of gain before losses,
        // NOT a measured/realized antenna gain.
        double dOmega=(2*Math.PI/azN)*((elMax-elMin)*Math.PI/180/elN);
        double directivity=4*Math.PI*maximum/Math.Max(integratedPower*dOmega,1e-30);
        double azWidth=HalfPowerWidth(azValues,Array.IndexOf(azValues,azValues.Max()),step,true);
        double elWidth=HalfPowerWidth(elValues,peakInCut,step,ground==0);
        return new Cuts(azValues,elValues,azPeak,elPeak,elevationOfCutPeak,
            10*Math.Log10(maximum/Math.Max(back,1e-30)),10*Math.Log10(directivity),azWidth,elWidth);
    }
    // Width of the contiguous main lobe measured at -3 dB relative to its own peak.
    // Linear interpolation avoids rounding the crossing to the 2-degree sampling grid.
    // Returns NaN when the -3 dB crossings cannot be found on both sides.
    private static double HalfPowerWidth(double[] values,int peak,double step,bool cyclic)
    {
        int count=cyclic?values.Length-1:values.Length;
        if(count<3||peak<0||peak>=count)return double.NaN;
        double level=values[peak]-3.0;
        double left=double.NaN,right=double.NaN;
        for(int direction=-1;direction<=1;direction+=2)
        {
            double prev=values[peak];
            int limit=cyclic?count/2:count-1;
            for(int d=1;d<=limit;d++)
            {
                int index=peak+direction*d;
                if(!cyclic&&(index<0||index>=count))break;
                index=(index%count+count)%count;
                double current=values[index];
                if(current<=level)
                {
                    double fraction=Math.Abs(prev-current)>1e-12?(prev-level)/(prev-current):0;
                    double crossing=(d-1+Math.Clamp(fraction,0,1))*step;
                    if(direction<0)left=crossing;else right=crossing;
                    break;
                }
                prev=current;
            }
        }
        return double.IsFinite(left)&&double.IsFinite(right)?left+right:double.NaN;
    }
    private static string WidthLabel(double width)=>double.IsFinite(width)?$"{width:0.#}°":"н/д";
    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);double w=ActualWidth,h=ActualHeight;
        dc.DrawRectangle(Brushes.White,null,new Rect(0,0,w,h));
        if(!_valid){Text(dc,"Рассчитайте антенну для построения 2D ДН",new Point(20,22),14,Brushes.SlateGray);return;}
        Text(dc,$"Gain ≈ {_gainEstimate:0.##} dBi (оценка D, без потерь)    F/B = {_fb:0.##} dB    Лепесток −3 dB: AZ {WidthLabel(_azHpbw)}, EL {WidthLabel(_elHpbw)}",new Point(12,7),13,Brushes.DarkSlateBlue);
        Text(dc,$"Максимум: Az {_azPeak:0.#}°, El {_elPeak:0.#}°    |    Шаг 2°",new Point(12,26),12,Brushes.SlateGray);
        double top=75,roomH=Math.Max(100,h-top-42),r=Math.Min((w-36)/4,roomH/2)*0.87*_zoom;
        if(r<25)return;
        dc.PushClip(new RectangleGeometry(new Rect(0,top,w*.5,roomH)));
        DrawPolar(dc,new Point(w*.25,top+roomH*.5),r,_az,true,$"Азимут · эл. {_elPeak:0.#}°",_azPeak,_groundType==0?-90:0,90);
        dc.Pop();
        dc.PushClip(new RectangleGeometry(new Rect(w*.5,top,w*.5,roomH)));
        DrawPolar(dc,new Point(w*.75,top+roomH*.5),r,_el,false,$"Элевация · пик {_elCutPeak:0.#}° · аз. {_azPeak:0.#}°",_elCutPeak,_groundType==0?-90:0,90);
        dc.Pop();
        Text(dc,"HPBW: ширина по уровню −3 dB (не по нулям); Gain≈D — без учёта потерь; F/B — противоположный азимут",new Point(12,h-27),11,Brushes.SlateGray);
    }
    private static void DrawPolar(DrawingContext dc,Point c,double r,double[] values,bool azimuth,string title,double peakAngle,double elevationMin,double elevationMax)
    {
        var grid=new Pen(new SolidColorBrush(Color.FromRgb(211,222,232)),1);
        for(int db=0;db<=40;db+=10)dc.DrawEllipse(null,grid,c,r*(1-db/45.0),r*(1-db/45.0));
        for(int a=0;a<360;a+=30)
        {
            double ang=a*Math.PI/180;
            dc.DrawLine(grid,c,new Point(c.X+r*Math.Sin(ang),c.Y-r*Math.Cos(ang)));
        }
        Text(dc,title,new Point(c.X-r,c.Y-r-30),13,Brushes.SteelBlue);
        Point PointAt(int i)
        {
            double angle;
            if(azimuth)
            {
                angle=i*2*Math.PI/(values.Length-1);
            }
            else
            {
                // Forward horizon -> top (+Z) -> rear horizon; optional lower hemisphere.
                double sweepDegrees=elevationMin<0?360.0:180.0;
                double cutAngle=i*sweepDegrees/(values.Length-1);
                angle=(90.0-cutAngle)*Math.PI/180.0;
            }
            double radius=r*Math.Max(0,1+Math.Max(-45,values[i])/45);
            return new Point(c.X+radius*Math.Sin(angle),c.Y-radius*Math.Cos(angle));
        }
        var geo=new StreamGeometry();using(var ctx=geo.Open())
        {
            ctx.BeginFigure(PointAt(0),false,azimuth);
            for(int i=1;i<values.Length;i++)ctx.LineTo(PointAt(i),true,false);
        }
        geo.Freeze();dc.DrawGeometry(null,new Pen(Brushes.RoyalBlue,2.2),geo);
        int peakIndex=azimuth?(int)Math.Round(peakAngle*(values.Length-1)/360.0):(int)Math.Round((peakAngle+90)*(values.Length-1)/180.0);
        // Elevation range can be 0..90° for ground models; global peak index is the max in the cut.
        if(!azimuth)peakIndex=Array.IndexOf(values,values.Max());
        peakIndex=Math.Clamp(peakIndex,0,values.Length-1);
        Point p=PointAt(peakIndex);
        dc.DrawEllipse(Brushes.OrangeRed,new Pen(Brushes.White,1.2),p,5,5);
        dc.DrawLine(new Pen(Brushes.OrangeRed,1),c,p);
        Text(dc,"0 dB",new Point(c.X+3,c.Y-r-17),10,Brushes.SlateGray);
    }
    private static void Text(DrawingContext dc,string s,Point at,double size,Brush brush)
    {
        var ft=new FormattedText(s,System.Globalization.CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,new Typeface("Segoe UI"),size,brush,1.0);
        dc.DrawText(ft,at);
    }
}
