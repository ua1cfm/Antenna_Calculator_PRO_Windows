using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading.Tasks;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>
/// "Radiated field (as the pattern)": E(P) = −j·η·k/(4π) · g(n) · e^{−jkr}/r, H = n × E / η, where g(n) is the
/// transverse current moment of the 3D radiation pattern (RadiationField.Direction — the same operator and ground
/// as the 3D pattern) and r, n are taken from the origin O: the ground point below the antenna centre over ground,
/// the antenna centre in free space. Consequences: no field below the horizon (pattern is zero there), the field
/// near the ground fades like the pattern, and with 1/r compensation every point shows the pattern in dBi.
/// The near field of the conductors is NOT included (that is the "full near field" mode).
/// g(n) is tabulated every 1° in θ and φ (phase referred to O) and interpolated bilinearly.
/// </summary>
internal sealed class RadiatedFieldTable
{
    private const int NTheta = 181, NPhi = 361;           // 0…180°, 0…360° (last column = first)
    private readonly Complex[] _gx = new Complex[NTheta * NPhi], _gy = new Complex[NTheta * NPhi], _gz = new Complex[NTheta * NPhi];
    private readonly double _k, _wavelength;
    public double OriginX { get; }
    public double OriginY { get; }
    public double OriginZ { get; }

    public RadiatedFieldTable(IReadOnlyList<MininecPulseSolver.FieldSample> samples, double frequencyMHz, int groundType,
        double ox, double oy, double oz)
    {
        _wavelength = 299.792458 / frequencyMHz;
        _k = 2 * Math.PI / _wavelength;
        OriginX = ox; OriginY = oy; OriginZ = oz;
        double k = _k;
        Parallel.For(0, NTheta, it =>
        {
            double theta = it * Math.PI / 180, st = Math.Sin(theta), ct = Math.Cos(theta);
            for (int ip = 0; ip < NPhi; ip++)
            {
                double phi = (ip % 360) * Math.PI / 180;
                double nx = st * Math.Cos(phi), ny = st * Math.Sin(phi), nz = ct;
                var v = RadiationField.Direction(samples, frequencyMHz, groundType, nx, ny, nz);
                // RadiationField uses the phase reference of the coordinate origin; refer it to O.
                Complex shift = Complex.FromPolarCoordinates(1, -k * (nx * ox + ny * oy + nz * oz));
                int i = it * NPhi + ip;
                _gx[i] = v.X * shift; _gy[i] = v.Y * shift; _gz[i] = v.Z * shift;
            }
        });
    }

    /// <summary>Radiated E and H at (x, y, z); r is limited at 0.05 λ near the origin.</summary>
    public void Field(double x, double y, double z,
        out Complex ex, out Complex ey, out Complex ez, out Complex hx, out Complex hy, out Complex hz)
    {
        double dx = x - OriginX, dy = y - OriginY, dz = z - OriginZ;
        double r = Math.Sqrt(dx * dx + dy * dy + dz * dz);
        if (!(r > 1e-12)) { ex = ey = ez = hx = hy = hz = Complex.Zero; return; }
        double nx = dx / r, ny = dy / r, nz = dz / r;
        double theta = Math.Acos(Math.Clamp(nz, -1, 1)) * 180 / Math.PI;
        double phi = Math.Atan2(ny, nx) * 180 / Math.PI; if (phi < 0) phi += 360;
        int it = Math.Min(NTheta - 2, (int)theta), ip = Math.Min(NPhi - 2, (int)phi);
        double wt = theta - it, wp = phi - ip;
        int i00 = it * NPhi + ip, i01 = i00 + 1, i10 = i00 + NPhi, i11 = i10 + 1;
        Complex Interp(Complex[] a) => (a[i00] * (1 - wp) + a[i01] * wp) * (1 - wt) + (a[i10] * (1 - wp) + a[i11] * wp) * wt;
        Complex gx = Interp(_gx), gy = Interp(_gy), gz = Interp(_gz);
        double rr = Math.Max(r, 0.05 * _wavelength);
        Complex c = -Complex.ImaginaryOne * NearFieldKernel.Eta0 * _k / (4 * Math.PI) * Complex.Exp(-Complex.ImaginaryOne * _k * r) / rr;
        ex = c * gx; ey = c * gy; ez = c * gz;
        hx = (ny * ez - nz * ey) / NearFieldKernel.Eta0;
        hy = (nz * ex - nx * ez) / NearFieldKernel.Eta0;
        hz = (nx * ey - ny * ex) / NearFieldKernel.Eta0;
    }
}
