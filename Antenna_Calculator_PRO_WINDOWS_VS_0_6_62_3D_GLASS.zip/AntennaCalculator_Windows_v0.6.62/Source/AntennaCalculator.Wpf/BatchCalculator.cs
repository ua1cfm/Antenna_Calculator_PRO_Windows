﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>
/// Batch calculation of every MAA file in a folder tree: one CSV row per file, written and flushed
/// immediately. Column names follow the MMANA batch CSV so both tables can be joined by relative_path.
///
/// Single-source models: impedance, currents and pattern from the MMANA core (as in the main window).
/// Gain_dBi is the absolute gain G = 4·π·U/Pin with U = k²·η0·|M|²/(32·π²) from the MMANA currents
/// and Pin = ½·R·|I|² at the source (includes wire/load losses; for G=2 the ground reflection of the
/// pattern operator). Multi-source models: application solver; only directivity is reported.
/// </summary>
internal static class BatchCalculator
{
    const double Eta0=376.730313668;
    static readonly CultureInfo Inv=CultureInfo.InvariantCulture;

    internal static readonly string Header=string.Join(",",new[]{
        "file","relative_path","status","R_ohm","X_ohm","SWR","Gain_dBd","Gain_dBi","FB_dB","Az_deg","El_deg",
        "frequency_MHz","Ground","Height_m","PWR_W","wavelength_m","calc_points","Directivity_dBi",
        "engine","sources","loads","ground_eps","ground_sigma","calc_s","title","error"});

    internal sealed record Row(string File,string RelativePath,string Status,double R,double X,double Swr,
        double GainDbd,double GainDbi,double FbDb,double AzDeg,double ElDeg,double FrequencyMHz,int Ground,double HeightM,
        double PowerW,double WavelengthM,int Pulses,double DirectivityDbi,string Engine,int Sources,int Loads,
        double Eps,double Sigma,double Seconds,string Title,string Error)
    {
        public string ToCsv()=>string.Join(",",new[]{
            Q(File),Q(RelativePath),Q(Status),Num(R,4),Num(X,4),Num(Swr,3),Num(GainDbd,2),Num(GainDbi,2),Num(FbDb,2),
            Num(AzDeg,1),Num(ElDeg,1),Num(FrequencyMHz,6),Ground.ToString(Inv),Num(HeightM,3),Num(PowerW,8),
            Num(WavelengthM,4),Pulses.ToString(Inv),Num(DirectivityDbi,2),Q(Engine),Sources.ToString(Inv),
            Loads.ToString(Inv),Num(Eps,3),Num(Sigma,5),Num(Seconds,2),Q(Title),Q(Error)});
    }

    static string Num(double v,int digits)=>double.IsFinite(v)?Math.Round(v,digits).ToString(Inv):"";
    static string Q(string? s){ s??=""; return "\""+s.Replace("\"","\"\"").Replace("\r"," ").Replace("\n"," ")+"\""; }

    internal static List<string> FindMaaFiles(string root)
    {
        var options=new EnumerationOptions{ RecurseSubdirectories=true, IgnoreInaccessible=true,
            MatchCasing=MatchCasing.CaseInsensitive, MatchType=MatchType.Simple };
        return Directory.EnumerateFiles(root,"*.maa",options)
            .Where(p=>string.Equals(Path.GetExtension(p),".maa",StringComparison.OrdinalIgnoreCase))
            .OrderBy(p=>p,StringComparer.OrdinalIgnoreCase).ToList();
    }

    /// <summary>Field samples from MMANA pulse currents (same convention as the main window).</summary>
    internal static IReadOnlyList<MininecPulseSolver.FieldSample> BuildMmanaSamples(
        IReadOnlyList<MmanaReferenceEngine.PulseCurrent> currents,int groundType)
    {
        var list=new List<MininecPulseSolver.FieldSample>(currents.Count*2);
        foreach(var c in currents)
        {
            list.Add(new MininecPulseSolver.FieldSample(c.X,c.Y,c.Z,c.Dx*0.5,c.Dy*0.5,c.Dz*0.5,
                c.CurrentRe,c.CurrentIm,0,0,c.NegX,c.NegY,c.NegZ,c.PosX,c.PosY,c.PosZ,c.Ground));
            if(groundType!=0 && !c.Ground)
                list.Add(new MininecPulseSolver.FieldSample(c.X,c.Y,-c.Z,-c.Dx*0.5,-c.Dy*0.5,c.Dz*0.5,
                    c.CurrentRe,c.CurrentIm,0,0,c.NegX,c.NegY,-c.NegZ,c.PosX,c.PosY,-c.PosZ,false));
        }
        return list;
    }

    /// <summary>
    /// Application result built from the MMANA core: ports (V, I, Z, power per source), the system
    /// equivalent Zeq = Σ|V|² / Σ V*·I (the old solver's definition; V/I for one source), total power
    /// and field samples from the MMANA currents. With <paramref name="baseResult"/> (old solver result)
    /// its other fields are kept; without it a complete result is created from the core alone.
    /// </summary>
    internal static MininecPulseSolver.Result? FromCore(MaaModel model,MmanaReferenceEngine.Result z,double frequency,
        MininecPulseSolver.Result? baseResult)
    {
        if(!double.IsFinite(z.R) || !double.IsFinite(z.X)) return null;
        var samples=z.Currents is {Count: >0} cur ? BuildMmanaSamples(cur,model.GroundType) : baseResult?.FieldSamples;
        double zeqR=z.R, zeqX=z.X, pAct=double.NaN, pReact=double.NaN;
        IReadOnlyList<MininecPulseSolver.PortResult>? ports=baseResult?.Ports;
        if(z.Sources is {Count: >0} src)
        {
            double vNorm2=0; var denom=System.Numerics.Complex.Zero; pAct=0; pReact=0;
            var list=new List<MininecPulseSolver.PortResult>(src.Count);
            for(int i=0;i<src.Count;i++)
            {
                var s=src[i];
                var v=new System.Numerics.Complex(s.VoltageRe,s.VoltageIm);
                var c=new System.Numerics.Complex(s.CurrentRe,s.CurrentIm);
                var p=0.5*v*System.Numerics.Complex.Conjugate(c);
                vNorm2+=v.Magnitude*v.Magnitude; denom+=System.Numerics.Complex.Conjugate(v)*c;
                pAct+=p.Real; pReact+=p.Imaginary;
                var m=i<model.Sources.Count ? model.Sources[i] : null;
                list.Add(new MininecPulseSolver.PortResult(i+1,m?.WireNumber??0,m?.Position??'?',m?.Offset??0,
                    m?.PhaseDegrees??Math.Atan2(s.VoltageIm,s.VoltageRe)*180/Math.PI,v.Magnitude,c.Magnitude,
                    Math.Atan2(c.Imaginary,c.Real)*180/Math.PI,s.R,s.X,p.Real,p.Imaginary));
            }
            ports=list;
            if(src.Count>1 && denom.Magnitude>1e-18)
            {
                var zeq=new System.Numerics.Complex(vNorm2,0)/denom;
                zeqR=zeq.Real; zeqX=zeq.Imaginary;
            }
        }
        if(baseResult!=null)
            return baseResult with { ROhm=zeqR, XOhm=zeqX, Ports=ports, TotalActivePower=pAct, TotalReactivePower=pReact, FieldSamples=samples };
        string ground=model.GroundType switch
        {
            0 => "Свободное пространство",
            1 => "Идеальная земля (зеркало)",
            _ => "G=2: импеданс с идеальным зеркалом, как в MMANA"
        };
        return new MininecPulseSolver.Result(frequency,zeqR,zeqX,z.Pulses,0.0,0,model.Sources.Count,model.Loads.Count,
            ground,"LU (ядро MMANA)",0,ports,pAct,pReact,samples);
    }

    internal sealed record PatternSummary(double MaxPower,double AzDeg,double ElDeg,double FbDb,double DirectivityDbi);

    /// <summary>
    /// Same grid, directivity integral and F/B definition as the 2D pattern view (2°), plus a
    /// 0.25° refinement of the maximum. F/B: opposite azimuth at the elevation of the maximum.
    /// </summary>
    internal static PatternSummary? Pattern(IReadOnlyList<MininecPulseSolver.FieldSample> samples,
        double frequency,int ground,double eps,double sigma,CancellationToken ct)
    {
        const double step=2.0;
        int azN=(int)Math.Round(360/step), elN=(int)Math.Round((ground==0?180:90)/step);
        double elMin=ground==0?-90:0, elMax=90;
        double maximum=-1, integrated=0; int maxAz=0, maxEl=0;
        var power=new double[elN+1,azN];
        for(int ie=0;ie<=elN;ie++)
        {
            ct.ThrowIfCancellationRequested();
            double el=(elMin+(elMax-elMin)*ie/elN)*Math.PI/180, h=Math.Cos(el), z=Math.Sin(el);
            for(int ia=0;ia<azN;ia++)
            {
                double az=ia*2*Math.PI/azN;
                double v=RadiationField.Direction(samples,frequency,ground,h*Math.Cos(az),h*Math.Sin(az),z,eps,sigma).Power;
                power[ie,ia]=v;
                if(double.IsFinite(v)&&v>=0) integrated+=v*Math.Max(0,Math.Cos(el))*((ie==0||ie==elN)?0.5:1.0);
                if(double.IsFinite(v)&&v>maximum){ maximum=v; maxAz=ia; maxEl=ie; }
            }
        }
        if(maximum<=0) return null;
        double dOmega=(2*Math.PI/azN)*((elMax-elMin)*Math.PI/180/elN);
        double directivity=4*Math.PI*maximum/Math.Max(integrated*dOmega,1e-30);
        double back=power[maxEl,(maxAz+azN/2)%azN];
        double fb=10*Math.Log10(maximum/Math.Max(back,1e-30));
        double azPeak=maxAz*360.0/azN, elPeak=elMin+(elMax-elMin)*maxEl/elN;
        double best=maximum, bestAz=azPeak, bestEl=elPeak;
        for(double dEl=-step;dEl<=step+1e-9;dEl+=0.25)
        for(double dAz=-step;dAz<=step+1e-9;dAz+=0.25)
        {
            double e=elPeak+dEl; if(e<elMin||e>elMax) continue;
            double a=azPeak+dAz, er=e*Math.PI/180, ar=a*Math.PI/180;
            double v=RadiationField.Direction(samples,frequency,ground,Math.Cos(er)*Math.Cos(ar),Math.Cos(er)*Math.Sin(ar),Math.Sin(er),eps,sigma).Power;
            if(double.IsFinite(v)&&v>best){ best=v; bestAz=a; bestEl=e; }
        }
        directivity*=best/maximum;
        return new PatternSummary(best,(bestAz%360+360)%360,bestEl,fb,10*Math.Log10(directivity));
    }

    static double Swr(double r,double x,double z0)
    {
        if(!double.IsFinite(r)||!double.IsFinite(x)||r<=0||z0<=0) return double.NaN;
        var z=new System.Numerics.Complex(r,x);
        double g=System.Numerics.Complex.Abs((z-z0)/(z+z0));
        return g<1?(1+g)/(1-g):double.NaN;
    }

    internal static Row CalculateFile(string path,string root,MininecPulseSolver.RealEarthMode mode,
        double eps,double sigma,CancellationToken ct)
    {
        var watch=System.Diagnostics.Stopwatch.StartNew();
        string rel=Path.GetRelativePath(root,path);
        MaaModel? model=null;
        Row Fail(string status,string message)=>new Row(path,rel,status,double.NaN,double.NaN,double.NaN,double.NaN,double.NaN,
            double.NaN,double.NaN,double.NaN,model?.FrequencyMHz??double.NaN,model?.GroundType??0,model?.AddHeightMetres??double.NaN,
            double.NaN,model?.WavelengthMetres??double.NaN,0,double.NaN,"",model?.Sources.Count??0,model?.Loads.Count??0,
            eps,sigma,watch.Elapsed.TotalSeconds,model?.Title??"",message);
        try
        {
            model=MaaParser.ParseFile(path);
            // No per-file time limit: heavy models with iterative convergence may need several minutes.
            // Only the user's "Стоп" (ct) interrupts the calculation.
            var token=ct;
            double f=model.FrequencyMHz;
            double r,x,pin=double.NaN; int pulses; string engine;
            IReadOnlyList<MininecPulseSolver.FieldSample>? samples;
            MmanaReferenceEngine.Result? core=null;
            string note="";
            {
                string text=MmanaReferenceEngine.Decode(File.ReadAllBytes(path));
                var (z,err)=MmanaReferenceEngine.SolveText(text,null,true,token);
                if(z!=null && double.IsFinite(z.R) && double.IsFinite(z.X) && z.Currents is {Count: >0}) core=z;
                else note="ядро MMANA: "+(err??"нет результата");
            }
            if(core!=null)
            {
                engine="MMANA";
                // R/X of source 1, as reported by MMANA; input power summed over all sources.
                r=core.R; x=core.X; pulses=core.Pulses;
                samples=BuildMmanaSamples(core.Currents!,model.GroundType);
                if(core.Sources is {Count: >1} srcs)
                {
                    pin=0;
                    foreach(var s in srcs) pin+=0.5*(s.VoltageRe*s.CurrentRe+s.VoltageIm*s.CurrentIm);
                    note=$"источников {srcs.Count}: R/X источника 1";
                }
                else pin=0.5*r*(core.CurrentRe*core.CurrentRe+core.CurrentIm*core.CurrentIm);
            }
            else
            {
                engine=model.Sources.Count>1?"MININEC (несколько источников)":"MININEC";
                var res=MininecPulseSolver.Solve(model,token,realEarthMode:mode);
                r=res.ROhm; x=res.XOhm; pulses=res.PulseCount; samples=res.FieldSamples;
            }
            var pattern=samples is {Count: >0} ? Pattern(samples,f,model.GroundType,eps,sigma,token) : null;
            double k=2*Math.PI*f/299.792458;
            double gainDbi=pattern!=null && pin>0 ? 10*Math.Log10(k*k*Eta0*pattern.MaxPower/(2*Math.PI*pin)) : double.NaN;
            double gainDbd=model.GroundType==0 && double.IsFinite(gainDbi) ? gainDbi-2.15 : double.NaN;
            return new Row(path,rel,"OK",r,x,Swr(r,x,model.ReferenceOhms),gainDbd,gainDbi,
                pattern?.FbDb??double.NaN,pattern?.AzDeg??double.NaN,pattern?.ElDeg??double.NaN,
                f,model.GroundType,model.AddHeightMetres,double.IsFinite(pin)?2*pin:double.NaN,model.WavelengthMetres,
                pulses,pattern?.DirectivityDbi??double.NaN,engine,model.Sources.Count,model.Loads.Count,
                eps,sigma,watch.Elapsed.TotalSeconds,model.Title,note);
        }
        catch(OperationCanceledException) when(ct.IsCancellationRequested){ throw; }
        catch(Exception ex)
        {
            return Fail("ERROR",ex.Message);
        }
    }
}
