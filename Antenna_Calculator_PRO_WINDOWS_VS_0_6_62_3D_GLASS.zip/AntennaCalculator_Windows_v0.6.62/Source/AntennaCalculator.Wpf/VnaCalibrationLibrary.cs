using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>Calibration profiles: %LOCALAPPDATA%\UA1CFM\LiteVNA\Calibrations\*.vnacal; last used profile is remembered.</summary>
internal static class VnaCalibrationLibrary
{
    public sealed record Entry(string Path,string Name,DateTime Created,long StartHz,long StopHz,int Points,int Average,bool Complete,string Device="")
    {
        public override string ToString()=>
            $"{Name} · {StartHz/1e6:0.###}–{StopHz/1e6:0.###} МГц · {Points} т. · {Created:dd.MM.yyyy}"+(Complete?"":" · неполная");
    }

    public static string Folder
    {
        get
        {
            var dir=System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"UA1CFM","LiteVNA","Calibrations");
            Directory.CreateDirectory(dir);
            return dir;
        }
    }
    static string LastFile=>System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Folder)!,"last_calibration.txt");

    public static List<Entry> List()
    {
        var list=new List<Entry>();
        foreach(var path in Directory.EnumerateFiles(Folder,"*.vnacal"))
        {
            try
            {
                var c=VnaCalibration.LoadFile(path);
                list.Add(new Entry(path,c.Name,c.Created,c.StartHz,c.StopHz,c.Points,c.Average,c.IsComplete,c.Device));
            }
            catch { /* unreadable file: not listed */ }
        }
        return list.OrderBy(e=>e.StartHz).ThenBy(e=>e.Points).ThenByDescending(e=>e.Created).ToList();
    }

    /// <summary>Saves into the library under a file name derived from the profile name (overwrites the same name).</summary>
    public static string PathFor(string name)
    {
        string safe=new string(name.Select(ch=>System.IO.Path.GetInvalidFileNameChars().Contains(ch)?'_':ch).ToArray()).Trim();
        if(safe.Length==0) safe="calibration_"+DateTime.Now.ToString("yyyyMMdd_HHmm",CultureInfo.InvariantCulture);
        return System.IO.Path.Combine(Folder,safe+".vnacal");
    }
    public static string Save(VnaCalibration cal)
    {
        string path=PathFor(cal.Name);
        cal.Save(path);
        RememberLast(path);
        return path;
    }
    public static void RememberLast(string? path){ try{ File.WriteAllText(LastFile,path ?? ""); } catch{ } }
    public static string? LastUsed()
    {
        try{ var p=File.Exists(LastFile)?File.ReadAllText(LastFile).Trim():""; return p.Length>0 && File.Exists(p) ? p : null; }
        catch{ return null; }
    }
    /// <summary>A complete profile on exactly this grid (start, stop, points), newest first.</summary>
    public static Entry? FindExact(long startHz,long stopHz,int points,string? device=null)=>
        List().Where(e=>e.Complete && e.StartHz==startHz && e.StopHz==stopHz && e.Points==points && DevicesCompatible(e.Device,device))
              .OrderByDescending(e=>e.Created).FirstOrDefault();

    /// <summary>
    /// Instrument family of a connection or calibration description: LiteVNA / V2 binary (with deviceVariant) or the
    /// NanoVNA text shell. Profiles of version 0.5.x ("LiteVNA · COM…") are LiteVNA. Null = unknown (accepted).
    /// </summary>
    public static string? DeviceKind(string? description)
    {
        if(string.IsNullOrWhiteSpace(description)) return null;
        string d=description.Trim();
        if(d.StartsWith("NanoVNA Shell",StringComparison.OrdinalIgnoreCase)) return "NanoVNA Shell";
        if(d.StartsWith("V2 Binary",StringComparison.OrdinalIgnoreCase))
        {
            var m=System.Text.RegularExpressions.Regex.Match(d,@"variant\s+(\d+)");
            return m.Success ? "V2 variant "+m.Groups[1].Value : "V2";
        }
        if(d.StartsWith("LiteVNA",StringComparison.OrdinalIgnoreCase)) return "V2 variant "+LiteVnaProtocol.LiteVnaVariant;
        return null;
    }
    /// <summary>A calibration may be applied only to data of the same instrument family.</summary>
    public static bool DevicesCompatible(string? calibrationDevice,string? connectionDevice)
    {
        var a=DeviceKind(calibrationDevice); var b=DeviceKind(connectionDevice);
        return a==null || b==null || a==b;
    }
}

/// <summary>Small dialog: profile name and comment.</summary>
internal sealed class CalibrationNameDialog : Window
{
    readonly TextBox _name=new(){ Height=28, VerticalContentAlignment=VerticalAlignment.Center };
    readonly TextBox _comment=new(){ Height=28, VerticalContentAlignment=VerticalAlignment.Center };
    public string ProfileName=>_name.Text.Trim();
    public string Comment=>_comment.Text.Trim();

    public CalibrationNameDialog(string title,string name,string comment)
    {
        Title=title; Width=480; SizeToContent=SizeToContent.Height; ResizeMode=ResizeMode.NoResize;
        WindowStartupLocation=WindowStartupLocation.CenterOwner;
        _name.Text=name; _comment.Text=comment;
        var ok=new Button{ Content="Сохранить", Width=110, IsDefault=true };
        ok.Click+=(_,_)=>{ if(ProfileName.Length==0){ MessageBox.Show(this,"Введите имя калибровки."); return; } DialogResult=true; };
        var cancel=new Button{ Content="Отмена", Width=96, IsCancel=true };
        var buttons=new StackPanel{ Orientation=Orientation.Horizontal, HorizontalAlignment=HorizontalAlignment.Right, Margin=new Thickness(0,14,0,0) };
        buttons.Children.Add(ok); buttons.Children.Add(cancel);
        var panel=new StackPanel{ Margin=new Thickness(16) };
        panel.Children.Add(new TextBlock{ Text="Имя калибровки", Margin=new Thickness(0,0,0,4) });
        panel.Children.Add(_name);
        panel.Children.Add(new TextBlock{ Text="Комментарий (кабель, адаптер, переход…)", Margin=new Thickness(0,10,0,4) });
        panel.Children.Add(_comment);
        panel.Children.Add(buttons);
        Content=panel;
        Loaded+=(_,_)=>{ _name.Focus(); _name.SelectAll(); };
    }
}
