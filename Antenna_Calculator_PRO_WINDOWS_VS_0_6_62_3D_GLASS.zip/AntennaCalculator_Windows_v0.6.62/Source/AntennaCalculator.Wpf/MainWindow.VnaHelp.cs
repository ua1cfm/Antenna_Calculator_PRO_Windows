﻿using AntennaCalculator.Core;
using Microsoft.Win32;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Controls;

namespace AntennaCalculator.Wpf;

/// <summary>Main window: VNA workspace, help (F1, «?» menu) and About.</summary>
public partial class MainWindow
{
    // ------------------------------------------------------------ dedicated full-window VNA workspace
    private bool _instrumentMode;
    private void VnaMode_Click(object sender,RoutedEventArgs e)=>SetInstrumentMode(true);
    private void VnaBack_Click(object sender,RoutedEventArgs e)=>SetInstrumentMode(false);
    private void SetInstrumentMode(bool on)
    {
        if(on==_instrumentMode)return;
        _instrumentMode=on;
        VnaWorkspace.Visibility=on?Visibility.Visible:Visibility.Collapsed;
        StatusText.Text=on?"VNA: режим измерений":"Обычный вид";
    }

    // ------------------------------------------------------------ help and About
    private HelpWindow? _help;

    /// <summary>Help chapter for the selected view tab (ids of help_ru.xml / help_en.xml).</summary>
    private string ContextHelpSection() => _instrumentMode ? "s12" : MainViews.SelectedIndex switch
    {
        0 => "s7",      // 3D wires + pattern
        1 => "s8",      // 2D pattern
        2 => "s6",      // Smith chart
        3 => "s6",      // R / X / SWR
        4 => "s9",      // EM field
        _ => "s3"
    };

    private void OpenHelp(string? sectionId)
    {
        if(_help==null || !_help.IsLoaded)
        {
            _help=new HelpWindow();
            _help.Closed+=(_,__)=>_help=null;
            _help.Show();
        }
        else
        {
            if(_help.WindowState==WindowState.Minimized) _help.WindowState=WindowState.Normal;
            _help.Activate();
        }
        if(sectionId!=null) _help.ShowSection(sectionId);
    }
    private void HelpMenu_Click(object sender,RoutedEventArgs e)=>OpenHelp(null);
    private void HelpContext_Click(object sender,RoutedEventArgs e)=>OpenHelp(ContextHelpSection());
    private void HelpPdf_Click(object sender,RoutedEventArgs e)
    {
        string lang=_help?.HelpLanguage=="en" ? "EN" : "RU";
        string path=Path.Combine(AppContext.BaseDirectory,"Docs",$"AntennaCalculator_Windows_Manual_{lang}.pdf");
        if(!File.Exists(path)){ MessageBox.Show(this,"Руководство не найдено: "+path,"Справка"); return; }
        try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(path){ UseShellExecute=true }); }
        catch(Exception ex){ MessageBox.Show(this,ex.Message,"Справка"); }
    }
    private void About_Click(object sender,RoutedEventArgs e)=>new AboutWindow{ Owner=this }.ShowDialog();
    private void AboutLabel_MouseUp(object sender,System.Windows.Input.MouseButtonEventArgs e)=>new AboutWindow{ Owner=this }.ShowDialog();
}
