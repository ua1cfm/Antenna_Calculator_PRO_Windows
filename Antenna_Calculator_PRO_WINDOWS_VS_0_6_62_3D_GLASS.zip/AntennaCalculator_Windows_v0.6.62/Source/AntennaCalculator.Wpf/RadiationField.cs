﻿using System;
using System.Linq;
using System.Numerics;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>
/// Shared scalar-current radiation operator. Android 1.19.268 MmanaRadiationPattern:
/// coherent current vectors, spatial phase +k*n.r, and for G=2 the MININEC
/// v89/h89 ground-reflection operator. Field samples already include PEC image
/// pulses, so they MUST NOT be reused for the G=2 reflected contribution.
/// Only an experimental visualization, not a validated ground-loss solver.
/// </summary>
internal static class RadiationField
{
    internal readonly record struct Vec(Complex X, Complex Y, Complex Z)
    {
        public double Power => X.Magnitude*X.Magnitude+Y.Magnitude*Y.Magnitude+Z.Magnitude*Z.Magnitude;
    }
    static Complex Sqrt(Complex c)=>Complex.Sqrt(c);
    internal static Vec Direction(System.Collections.Generic.IReadOnlyList<MininecPulseSolver.FieldSample> samples,
        double frequencyMHz, int groundType, double nx, double ny, double nz,
        double eps=13.0, double sigma=0.005)
    {
        if(frequencyMHz<=0) return default;
        if(groundType!=0 && nz < -1e-10) return default;
        double k=2*Math.PI*frequencyMHz/299.792458;
        bool realGround=groundType is 2 or -1;
        // For G=1 image pulses are already in the solver's current array.
        // For G=2 keep physical positive-z samples ONLY and apply v89/h89 once.
        Complex gx=0,gy=0,gz=0;
        double rho=Math.Sqrt(nx*nx+ny*ny);
        double ctheta=Math.Clamp(nz,0,1);
        double phi=Math.Atan2(ny,nx);
        double px=-Math.Sin(phi),py=Math.Cos(phi);
        Complex v89=Complex.Zero,h89=Complex.Zero;
        if(realGround)
        {
            double omega=2*Math.PI*frequencyMHz*1e6;
            Complex er=new(eps,-sigma/(omega*8.8541878128e-12));
            Complex z45=Complex.One/Sqrt(er);
            Complex w67=Sqrt(Complex.One-z45*z45*rho*rho);
            v89=(ctheta-w67*z45)/(ctheta+w67*z45);
            h89=(w67-z45*ctheta)/(w67+z45*ctheta)-v89;
        }
        foreach(var s in samples)
        {
            if(realGround && s.Z < -1e-7)continue;
            Complex current=new(s.RealCurrent,s.ImagCurrent);
            // s.D is the half pulse effective current length, same coefficient as original view.
            Complex phase=Complex.FromPolarCoordinates(1,k*(nx*s.X+ny*s.Y+nz*s.Z));
            Complex a=current*phase;
            gx+=a*s.Dx;gy+=a*s.Dy;gz+=a*s.Dz;
            // MMANA S621 grounded end: D already holds the upper half doubled by its image;
            // MMANA adds no reflected term for such a pulse.
            if(s.GroundPulse) continue;
            if(realGround)
            {
                Complex img=current*Complex.FromPolarCoordinates(1,k*(nx*s.X+ny*s.Y-nz*s.Z));
                double d=px*s.Dx+py*s.Dy;
                gx-=img*(v89*s.Dx+h89*d*px);
                gy-=img*(v89*s.Dy+h89*d*py);
                gz+=img*v89*s.Dz;
            }
        }
        // Transverse vector: n x (J x n)
        Complex dot=nx*gx+ny*gy+nz*gz;
        return new(gx-nx*dot,gy-ny*dot,gz-nz*dot);
    }
}
