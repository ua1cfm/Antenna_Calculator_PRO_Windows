using System;
using System.Runtime.InteropServices;

namespace AntennaCalculator.Wpf;

/// <summary>
/// Optional NVIDIA CUDA ray caster (AntennaCudaVolume64.dll, export antenna_volume_render_ex since 0.6.39).
/// Device buffers persist between frames; the volume is uploaded only when its revision changes.
/// Returns null when the library, the new export or the device is unavailable — the caller renders on the CPU.
/// </summary>
internal static class CudaVolumeRenderer
{
    private static readonly object Sync = new();
    internal static string LastStatus { get; private set; } = "CUDA: ещё не проверена";
    private static bool unavailable;

    [DllImport("AntennaCudaVolume64.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "antenna_volume_render_ex")]
    private static extern int NativeRenderEx([In] float[] volume, int n, int revision, float az, float el, float zoom,
        int size, int steps, int mode, int db, float dbFactor, float density, float gradRef, [Out] byte[] outputBGRA);

    [DllImport("AntennaCudaVolume64.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "antenna_volume_style_version")]
    private static extern int NativeStyleVersion();
    private const int RequiredStyleVersion = 657;
    private static bool versionChecked;

    [DllImport("AntennaCudaVolume64.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "antenna_cuda_error_string")]
    private static extern IntPtr NativeErrorString(int code);

    [DllImport("AntennaCudaVolume64.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "antenna_cuda_last_error")]
    private static extern IntPtr NativeLastError();

    /// <param name="normalized">Field divided by P96 (n³ values).</param>
    /// <param name="revision">Changes whenever <paramref name="normalized"/> changes (upload cache key).</param>
    internal static byte[]? TryRender(float[] normalized, int n, int revision, FieldVolumeView.VolumeStyle style,
        double az, double el, double zoom, int size, int steps)
    {
        if (unavailable) return null;
        if (normalized.Length != n * n * n) { LastStatus = "CUDA: неверные параметры сетки"; return null; }
        lock (Sync)
        {
            if (unavailable) return null;
            try
            {
                if (!versionChecked)
                {
                    versionChecked = true;
                    int version = 0;
                    try { version = NativeStyleVersion(); } catch (EntryPointNotFoundException) { }
                    if (version < RequiredStyleVersion)
                    {
                        // An older kernel would draw the previous (greenish) palette: use the CPU, same palette as the legend.
                        unavailable = true;
                        LastStatus = "AntennaCudaVolume64.dll старой версии (прежняя палитра) — пересоберите Cuda\\BUILD_CUDA_VOLUME_WIN64.bat (сейчас CPU)";
                        return null;
                    }
                }
                var bgra = new byte[size * size * 4];
                int error = NativeRenderEx(normalized, n, revision & int.MaxValue, (float)az, (float)el, (float)zoom, size, steps,
                    style.Mode, style.Db ? 1 : 0, (float)style.DbFactor, (float)style.Density, (float)style.GradRef, bgra);
                if (error == 0) { LastStatus = "CUDA GPU: OK"; return bgra; }
                string stage = error switch { -1 => "arguments", -2 => "GPU/driver", -3 => "volume allocation", -4 => "pixel allocation", -5 => "upload to GPU", -6 => "kernel launch", -7 => "kernel execution", -8 => "download from GPU", _ => "unknown" };
                try { stage = Marshal.PtrToStringAnsi(NativeErrorString(error)) ?? stage; } catch (EntryPointNotFoundException) { }
                try { var details = Marshal.PtrToStringAnsi(NativeLastError()); if (!string.IsNullOrWhiteSpace(details) && details != "none") stage += " | " + details; }
                catch (EntryPointNotFoundException) { }
                LastStatus = $"CUDA: {error} — {stage}";
                return null;
            }
            catch (DllNotFoundException ex) { unavailable = true; LastStatus = "CUDA: DLL или зависимая библиотека отсутствует — " + ex.Message; }
            catch (BadImageFormatException ex) { unavailable = true; LastStatus = "CUDA: неверная разрядность DLL — " + ex.Message; }
            catch (EntryPointNotFoundException)
            {
                // A DLL of 0.6.23–0.6.38 marches the rays from the far side; do not use it.
                unavailable = true;
                LastStatus = "AntennaCudaVolume64.dll старой версии — пересоберите Cuda\\BUILD_CUDA_VOLUME_WIN64.bat (сейчас CPU)";
            }
            catch (Exception ex) { LastStatus = "CUDA: " + ex.GetType().Name + ": " + ex.Message; }
            return null;
        }
    }
}
