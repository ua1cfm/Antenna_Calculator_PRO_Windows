﻿using AntennaCalculator.Core;
using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace AntennaCalculator.Wpf;

/// <summary>Fast orthographic 2D drawing of the 3D MAA geometry, without external packages.</summary>
public sealed class WirePreview : FrameworkElement
{
    private MaaModel? _model;
    private MininecPulseSolver.Result? _patternResult;
    private int _projection;
    private double _zoom = 1.0;
    private double _azimuth = Math.PI / 4;
    private double _elevation = 0.55;
    private Point? _drag;
    private bool _showPattern = true;
    private (double X,double Y,double Z,double Amp)[,]? _cachedPattern;
    private double _cachedMaxAmp;
    private double _cachedDmaxDbi=double.NaN;
    private double _patternScale=1.0;
    // Angular step of the computed pattern: 1° when the 1° grid is selected, otherwise 2° (as before 0.6.60).
    // _cachedStep is the step of the pattern actually in _cachedPattern (the drawing uses it, not the request).
    private double PatternStepFor(int meshStepDegrees) => meshStepDegrees <= 1 ? 1.0 : 2.0;
    private double _cachedStep=2.0;
    // 0=smooth, 1=flat coloured faces, 2=flat coloured faces with grid.
    private int _patchMode = 2;
    private bool _showMesh = true;
    public void SetPatchMode(int mode) { _patchMode=Math.Clamp(mode,0,2); InvalidateVisual(); }
    private bool _showAntennaOnPattern = true;
    private bool _showSphere = true;
    public void SetAntennaOverlay(bool value) { _showAntennaOnPattern=value; InvalidateVisual(); }
    public void SetSphereVisible(bool value) { _showSphere=value; InvalidateVisual(); }
    private int _meshStepDegrees = 2;
    // Transparency is applied to rasterized surface pixels, not to the antenna overlay.
    private byte _patternAlpha = 166;
    public void SetPatternOpacity(double value) { _patternAlpha=(byte)Math.Round(Math.Clamp(value,0.2,1.0)*255); InvalidateVisual(); }
    // Translucent ("glass") pattern: every surface layer is blended back to front, so rear lobes and the
    // far side of the main lobe stay visible. Opacity follows the surface normal (Fresnel-like):
    // faces turned to the viewer are clear, silhouettes are dense; a soft headlight highlight adds volume.
    private bool _translucent;
    public void SetTranslucent(bool value) { _translucent=value; InvalidateVisual(); }
    // Axis labels: X-Y-Z (false) or spherical angles θ (from the zenith, +Z) and φ (from +X towards +Y).
    private bool _angleAxes;
    public void SetAngleAxes(bool value) { _angleAxes=value; InvalidateVisual(); }
    public void SetMeshVisible(bool visible) { _showMesh=visible; InvalidateVisual(); }
    public void SetMeshStep(int degrees)
    {
        int old=_meshStepDegrees;
        _meshStepDegrees=Math.Clamp(degrees,1,15);
        // 1° needs a finer computed pattern (before 0.6.60 the pattern was always 2°, so 1° looked like 2°).
        if(PatternStepFor(old)!=PatternStepFor(_meshStepDegrees) && _patternResult!=null) RebuildPattern();
        else InvalidateVisual();
    }
    private int _patternGeneration;
    private (double X,double Y,double Z) _cachedCenter;
    private bool _placeAtFeed = true;
    public bool PlacePatternAtFeed
    {
        get => _placeAtFeed;
        set { _placeAtFeed=value; InvalidateVisual(); }
    }
    // This is a display anchor, NOT a computed electromagnetic phase centre.
    private (double X,double Y,double Z) PatternAnchor()
    {
        if (_placeAtFeed && _model is { Sources.Count: > 0 } model)
        {
            var source=model.Sources[0];
            var wire=model.Wires.ElementAtOrDefault(source.WireNumber-1);
            if (wire != null) return PulseLocation(wire,source.Position);
        }
        if (_placeAtFeed && _model is { Wires.Count: > 0 } geometry)
        {
            // Midpoint of geometry bounds rather than field-sample centroid.
            return ((geometry.Wires.Min(w=>Math.Min(w.X1,w.X2))+geometry.Wires.Max(w=>Math.Max(w.X1,w.X2)))*0.5,
                    (geometry.Wires.Min(w=>Math.Min(w.Y1,w.Y2))+geometry.Wires.Max(w=>Math.Max(w.Y1,w.Y2)))*0.5,
                    (geometry.Wires.Min(w=>Math.Min(w.Z1,w.Z2))+geometry.Wires.Max(w=>Math.Max(w.Z1,w.Z2)))*0.5);
        }
        return _cachedCenter;
    }

    public MaaModel? Model { get => _model; set { _model = value; RebuildPattern(); } }
    public MininecPulseSolver.Result? PatternResult { get => _patternResult; set { _patternResult = value; RebuildPattern(); } }
    public void SetPatternScale(double scale) { _patternScale=Math.Clamp(scale,0.1,5); InvalidateVisual(); }
    private async void RebuildPattern()
    {
        int generation=++_patternGeneration;
        _cachedPattern=null;
        _cachedDmaxDbi=double.NaN;
        InvalidateVisual();
        var result=_patternResult;
        var model=_model;
        if(result?.FieldSamples is not {Count: >0} samples || model==null || result.FrequencyMHz<=0)return;
        double f=result.FrequencyMHz, step=PatternStepFor(_meshStepDegrees);
        int nt=(int)Math.Round(180/step),np=(int)Math.Round(360/step);
        var directions=await Task.Run(()=>
        {
            var values=new (double X,double Y,double Z,double Amp)[nt+1,np+1];
            double maximum=1e-30;
            double radiationIntegral=0.0;
            double deltaTheta=Math.PI/nt,deltaPhi=2*Math.PI/np;
            for(int it=0;it<=nt;it++)
            {
                if(model.GroundType!=0 && it>nt/2)break;
                double theta=Math.PI*it/nt,st=Math.Sin(theta),ct=Math.Cos(theta);
                for(int ip=0;ip<=np;ip++)
                {
                    double phi=2*Math.PI*ip/np;
                    double ux=st*Math.Cos(phi),uy=st*Math.Sin(phi),uz=ct;
                    var field=RadiationField.Direction(samples,f,model.GroundType,ux,uy,uz);
                    double amplitude=Math.Sqrt(Math.Max(0,field.Power));
                    values[it,ip]=(ux,uy,uz,amplitude);
                    if(double.IsFinite(amplitude))
                    {
                        maximum=Math.Max(maximum,amplitude);
                        // Directional power density integrates over solid angle.
                        // Endpoint half weights prevent duplicate seam/poles in the integral.
                        if(ip<np)
                        {
                            double thetaWeight=(it==0 || it==nt)?0.5:1.0;
                            radiationIntegral+=field.Power*Math.Sin(theta)*deltaTheta*deltaPhi*thetaWeight;
                        }
                    }
                }
            }
            double directivity= radiationIntegral>1e-30 ? 4*Math.PI*maximum*maximum/radiationIntegral : double.NaN;
            double dmaxDbi=double.IsFinite(directivity)&&directivity>0 ? 10*Math.Log10(directivity) : double.NaN;
            return (values,maximum,dmaxDbi);
        });
        if(generation!=_patternGeneration || !ReferenceEquals(result,_patternResult))return;
        _cachedPattern=directions.values;
        _cachedStep=step;
        _cachedMaxAmp=directions.maximum;
        _cachedDmaxDbi=directions.dmaxDbi;
        _cachedCenter=(samples.Average(q=>q.X),samples.Average(q=>q.Y),samples.Average(q=>q.Z));
        InvalidateVisual();
    }
    public bool ShowPattern { get => _showPattern; set { _showPattern = value; InvalidateVisual(); } }
    public int Projection { get => _projection; set { _projection = Math.Clamp(value,0,3); InvalidateVisual(); } }
    // Fit the CURRENT radiation-pattern projection into the viewport. Preserve the camera angle.
    // The slider controls _patternScale separately from the mouse-wheel _zoom, so both must be considered.
    public void ResetViewAndFit()
    {
        _projection = 0;
        _azimuth = Math.PI / 4;
        _elevation = 0.55;
        _drag = null;
        Fit();
    }

    public void Fit()
    {
        if (_showPattern && _cachedPattern is { } directions && ActualWidth > 100 && ActualHeight > 100 && _cachedMaxAmp > 0)
        {
            double maxX = _showSphere ? 1.0 : 0.01;
            double maxY = _showSphere ? 1.0 : 0.01;
            int nt = directions.GetLength(0) - 1;
            int np = directions.GetLength(1) - 1;
            int thetaLimit = _model?.GroundType != 0 ? nt / 2 : nt;
            for (int it = 0; it <= thetaLimit; it++)
            for (int ip = 0; ip <= np; ip++)
            {
                var q = directions[it, ip];
                if (!double.IsFinite(q.Amp)) continue;
                double a = Math.Clamp(q.Amp / _cachedMaxAmp, 0, 1);
                double r = 0.045 + 0.955 * a;
                var p = Project(q.X * r, q.Y * r, q.Z * r);
                maxX = Math.Max(maxX, Math.Abs(p.X));
                maxY = Math.Max(maxY, Math.Abs(p.Y));
            }
            // Sphere and antenna overlay share the radiation-pattern projection; when visible,
            // the unit sphere sets a guaranteed safe bound for both.
            if (_showAntennaOnPattern) { maxX = Math.Max(maxX, 0.85); maxY = Math.Max(maxY, 0.85); }
            // DrawPattern uses this exact pixel-radius formula and normalized viewport centre.
            double baseRadius = Math.Max(10, Math.Min(ActualWidth * 0.39, ActualHeight * 0.42));
            double horizontal = Math.Max(10, ActualWidth * 0.43 - 22) / (baseRadius * maxX);
            double vertical = Math.Max(10, ActualHeight * 0.46 - 22) / (baseRadius * maxY);
            _zoom = Math.Clamp(Math.Min(horizontal, vertical) / Math.Max(0.1, _patternScale), 0.02, 100);
        }
        else
        {
            _zoom = 1.0 / Math.Max(0.1, _patternScale);
        }
        InvalidateVisual();
    }

    public WirePreview() { Focusable=true; SnapsToDevicePixels=true; }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        var background = new SolidColorBrush(Color.FromRgb(252,253,254));
        dc.DrawRectangle(background, null, new Rect(0,0,ActualWidth, ActualHeight));
        if (_model == null || ActualWidth < 10 || ActualHeight < 10)
        {
            DrawLabel(dc,"Откройте проект MMANA для просмотра геометрии", new Point(20,25), 15, Brushes.SlateGray);
            return;
        }
        double minU=double.PositiveInfinity, minV=double.PositiveInfinity, maxU=double.NegativeInfinity, maxV=double.NegativeInfinity;
        foreach(var w in _model.Wires)
        {
            Take(w.X1,w.Y1,w.Z1); Take(w.X2,w.Y2,w.Z2);
        }
        void Take(double x,double y,double z)
        {
            var p=Project(x,y,z);
            minU=Math.Min(minU,p.X); maxU=Math.Max(maxU,p.X);
            minV=Math.Min(minV,p.Y); maxV=Math.Max(maxV,p.Y);
        }
        if (!double.IsFinite(minU)) return;
        double spanU=Math.Max(1e-6,maxU-minU), spanV=Math.Max(1e-6,maxV-minV);
        double margin=36;
        double scale=Math.Min(Math.Max(10,ActualWidth-2*margin)/spanU, Math.Max(10,ActualHeight-2*margin)/spanV)*0.95*_zoom;
        scale=Math.Clamp(scale,1e-6,1e10);
        double cx=(maxU+minU)*.5, cy=(maxV+minV)*.5;
        Point Screen(double x,double y,double z)
        {
            var p=Project(x,y,z);
            return new Point(ActualWidth*.5+(p.X-cx)*scale,ActualHeight*.5-(p.Y-cy)*scale);
        }
        if(_showPattern && _cachedPattern != null) DrawPattern(dc, Screen, ((minU+maxU)*0.5,(minV+maxV)*0.5), Math.Max(spanU,spanV));
        int wirePreviewStep=Math.Max(1,(_model.Wires.Count+14999)/15000);
        if (!_showPattern || _cachedPattern == null)
        {
        var pen = new Pen(new SolidColorBrush(Color.FromRgb(44,105,214)), 1.35);
        pen.Freeze();
        // Display subsampling DOES NOT change the underlying wire list or exported coordinates.
        for(int i=0; i<_model.Wires.Count; i+=wirePreviewStep)
        {
            var w=_model.Wires[i];
            dc.DrawLine(pen,Screen(w.X1,w.Y1,w.Z1),Screen(w.X2,w.Y2,w.Z2));
        }
        var sourceBrush = new SolidColorBrush(Color.FromRgb(224,79,59)); sourceBrush.Freeze();
        var loadBrush = new SolidColorBrush(Color.FromRgb(245,166,35)); loadBrush.Freeze();
        foreach(var s in _model.Sources)
        {
            var w = _model.Wires.ElementAtOrDefault(s.WireNumber-1);
            if(w==null)continue;
            var pos=PulseLocation(w,s.Position); var p=Screen(pos.X,pos.Y,pos.Z);
            dc.DrawEllipse(sourceBrush,new Pen(Brushes.White,1.2),p,5.5,5.5);
        }
        foreach(var l in _model.Loads)
        {
            var w = _model.Wires.ElementAtOrDefault(l.WireNumber-1);
            if(w==null)continue;
            var pos=PulseLocation(w,l.Position); var p=Screen(pos.X,pos.Y,pos.Z);
            dc.DrawEllipse(loadBrush,new Pen(Brushes.White,1.2),p,4.6,4.6);
        }
        }
        if(wirePreviewStep>1 && (!_showPattern || _cachedPattern == null)) DrawLabel(dc,$"Предпросмотр: каждый {wirePreviewStep}-й провод; полный список сохранён",new Point(14,ActualHeight-26),11,Brushes.DarkGoldenrod);
        DrawLabel(dc,_projection switch {1=>"XY",2=>"XZ",3=>"YZ",_=>"ISO"},new Point(15,12),12,Brushes.SlateGray);
        DrawLabel(dc,$"{_model.Wires.Count} wires · zoom {_zoom:0.0}×" + (_showPattern&&_patternResult!=null?" · 3D ДН ON":""),new Point(15,ActualHeight-46),11,Brushes.SlateGray);
    }

    private (double X,double Y,double Z) PulseLocation(MaaWire w, char where)
    {
        double t=where switch{'b'=>0.0,'e'=>1.0,_=>0.5};
        return (w.X1+(w.X2-w.X1)*t,w.Y1+(w.Y2-w.Y1)*t,w.Z1+(w.Z2-w.Z1)*t);
    }

    // Unit vector from the scene towards the viewer, consistent with Project():
    // screen-right x screen-up (right-handed). Recomputed from the current camera on every frame.
    private (double X,double Y,double Z) ViewerDirection() => _projection switch
    {
        1 => (0.0,0.0,1.0),
        2 => (0.0,-1.0,0.0),
        3 => (1.0,0.0,0.0),
        _ => (-Math.Sin(_azimuth)*Math.Cos(_elevation), -Math.Cos(_azimuth)*Math.Cos(_elevation), Math.Sin(_elevation))
    };

    // Depth cue for the 3D pattern: the hemisphere facing the viewer is darker, the far one lighter.
    // facing = cos(angle between the pattern direction and the line of sight), -1..+1.
    private const double FrontDarkening=0.30, BackLightening=0.45;
    private static int ShadeHemisphere(int argb,double facing)
    {
        if(!double.IsFinite(facing)) return argb;
        facing=Math.Clamp(facing,-1,1);
        int r=(argb>>16)&255,g=(argb>>8)&255,b=argb&255;
        if(facing>=0)
        {
            double k=1.0-FrontDarkening*facing;
            r=(int)(r*k); g=(int)(g*k); b=(int)(b*k);
        }
        else
        {
            double t=BackLightening*(-facing);
            r=(int)(r+(255-r)*t); g=(int)(g+(255-g)*t); b=(int)(b+(255-b)*t);
        }
        return (argb & unchecked((int)0xFF000000))|(r<<16)|(g<<8)|b;
    }

    private Point Project(double x,double y,double z)
    {
        return _projection switch
        {
            1 => new Point(x,y),
            2 => new Point(x,z),
            3 => new Point(y,z),
            _ => new Point(x*Math.Cos(_azimuth)-y*Math.Sin(_azimuth),
                (x*Math.Sin(_azimuth)+y*Math.Cos(_azimuth))*Math.Sin(_elevation)+z*Math.Cos(_elevation))
        };
    }


    // Software triangle rasterizer with a true per-pixel Z buffer.
    // Unlike painter sorting, crossing triangles are resolved at pixel level.
    private void DrawPattern(DrawingContext dc, Func<double,double,double,Point> screen,
        (double U,double V) projectedCenter, double uvSpan)
    {
        var dirs=_cachedPattern;
        if(dirs==null || _model==null || _cachedMaxAmp<=0)return;
        int width=(int)Math.Ceiling(ActualWidth),height=(int)Math.Ceiling(ActualHeight);
        if(width<2||height<2)return;
        // Avoid disproportionate UI memory usage on 4K displays.
        double pixelScale=Math.Min(1.0,Math.Sqrt(1600000.0/((double)width*height)));
        int rw=Math.Max(2,(int)(width*pixelScale)),rh=Math.Max(2,(int)(height*pixelScale));
        var argb=new int[rw*rh];
        var depth=new float[rw*rh];
        Array.Fill(depth,float.NegativeInfinity);
        // Radiation-pattern camera is normalized to the viewport, NOT to physical wire spans.
        // This prevents kilometre-long antennas from producing tiny, displaced lobes.
        double worldRadius = 1.0;
        double pixelRadius = Math.Max(10,Math.Min(rw*0.39,rh*0.42))*_patternScale*_zoom;
        double centerX = rw * 0.47, centerY = rh * 0.51;
        Point PatternScreen(double x,double y,double z)
        {
            var p=Project(x,y,z);
            return new Point(centerX+p.X*pixelRadius,centerY-p.Y*pixelRadius);
        }
        if (_showSphere) DrawReferenceSphere(dc, (x,y,z)=> {
            var pt=PatternScreen(x,y,z);
            return new Point(pt.X/pixelScale,pt.Y/pixelScale);
        });
        double maxAmp=_cachedMaxAmp;
        int nt=dirs.GetLength(0)-1,np=dirs.GetLength(1)-1;
        int thetaLimit=_model.GroundType!=0?nt/2:nt;
        // Cache projected vertices. Recalculate only when camera or zoom changes.
        var projected=new RasterVertex[(thetaLimit+1)*(np+1)];
        var world=new (double X,double Y,double Z)[(thetaLimit+1)*(np+1)];
        var view=ViewerDirection();
        for(int it=0;it<=thetaLimit;it++)
        for(int ip=0;ip<=np;ip++)
        {
            var q=dirs[it,ip];
            double amplitude=double.IsFinite(q.Amp)?Math.Clamp(q.Amp/maxAmp,0,1):0;
            double radius=worldRadius*(0.045+0.955*amplitude);
            double x=q.X*radius,y=q.Y*radius,z=q.Z*radius;
            var pt=PatternScreen(x,y,z);
            // Larger value = closer to the viewer (the z-buffer keeps the larger one).
            double viewDepth=x*view.X+y*view.Y+z*view.Z;
            double dirNorm=Math.Sqrt(q.X*q.X+q.Y*q.Y+q.Z*q.Z);
            double facing=dirNorm>1e-12 ? (q.X*view.X+q.Y*view.Y+q.Z*view.Z)/dirNorm : 0.0;
            projected[it*(np+1)+ip]=new RasterVertex(pt.X,pt.Y,viewDepth,amplitude,facing);
            world[it*(np+1)+ip]=(x,y,z);
        }
        // Flat-shaded patch mode: one measured-grid cell = one uniform colour.
        // This is a rendering choice only: solver currents and farfield samples are unchanged.
        int patchPitch = _patchMode==0 ? 1 : Math.Max(1,(int)Math.Round(_meshStepDegrees/_cachedStep));
        if(_translucent)
        {
            RenderTranslucent(projected,world,thetaLimit,np,patchPitch,view,rw,rh,argb);
        }
        else
        {
        for(int it=0;it<thetaLimit;it+=patchPitch)
        for(int ip=0;ip<np;ip+=patchPitch)
        {
            int nextT=Math.Min(thetaLimit,it+patchPitch);
            int nextP=Math.Min(np,ip+patchPitch);
            int i=it*(np+1)+ip,j=nextT*(np+1)+ip;
            var a=projected[i];var b=projected[j];
            var c=projected[nextT*(np+1)+nextP];var d=projected[it*(np+1)+nextP];
            int? faceColour = _patchMode==0 ? null : ShadeHemisphere(RainbowArgb(
                (a.Amplitude+b.Amplitude+c.Amplitude+d.Amplitude)*0.25),
                (a.Facing+b.Facing+c.Facing+d.Facing)*0.25);
            RasterTriangle(a,b,c,rw,rh,argb,depth,faceColour,_patternAlpha);
            RasterTriangle(a,c,d,rw,rh,argb,depth,faceColour,_patternAlpha);
        }
        if (_patchMode==2 && _showMesh)
        {
            int meshPitch=patchPitch;
            for(int it=0;it<=thetaLimit;it+=meshPitch)
                for(int ip=0;ip<np;ip++)
                    MeshLine(projected[it*(np+1)+ip],projected[it*(np+1)+ip+1],rw,rh,argb,depth);
            if(thetaLimit%meshPitch!=0)
                for(int ip=0;ip<np;ip++)
                    MeshLine(projected[thetaLimit*(np+1)+ip],projected[thetaLimit*(np+1)+ip+1],rw,rh,argb,depth);
            for(int ip=0;ip<=np;ip+=meshPitch)
                for(int it=0;it<thetaLimit;it++)
                    MeshLine(projected[it*(np+1)+ip],projected[(it+1)*(np+1)+ip],rw,rh,argb,depth);
        }
        }
        var bitmap=new WriteableBitmap(rw,rh,96,96,PixelFormats.Bgra32,null);
        bitmap.WritePixels(new Int32Rect(0,0,rw,rh),argb,rw*4,0);
        bitmap.Freeze();
        dc.DrawImage(bitmap,new Rect(0,0,ActualWidth,ActualHeight));
        if (_showAntennaOnPattern) DrawScaledAntennaOverlay(dc,(x,y,z) => {
            var pt=PatternScreen(x,y,z);
            return new Point(pt.X/pixelScale,pt.Y/pixelScale);
        });
        DrawReferenceAxesAndLegend(dc, (x,y,z)=> {
            var pt=PatternScreen(x,y,z);
            return new Point(pt.X/pixelScale,pt.Y/pixelScale);
        });
    }


    // Rendering-only overlay: no change to the electrical model, current distribution or source coordinates.
    // All scene elements share the same Project() camera and the same normalized pattern viewport.
    private void DrawScaledAntennaOverlay(DrawingContext dc, Func<double,double,double,Point> project)
    {
        if (_model is not { Wires.Count: > 0 } model) return;
        var anchor=PatternAnchor();
        double extent=0;
        foreach (var w in model.Wires)
        {
            extent=Math.Max(extent,Math.Max(Math.Abs(w.X1-anchor.X),Math.Abs(w.X2-anchor.X)));
            extent=Math.Max(extent,Math.Max(Math.Abs(w.Y1-anchor.Y),Math.Abs(w.Y2-anchor.Y)));
            extent=Math.Max(extent,Math.Max(Math.Abs(w.Z1-anchor.Z),Math.Abs(w.Z2-anchor.Z)));
        }
        if (!(extent>1e-12) || !double.IsFinite(extent)) return;
        // Fit the antenna to about 45% of the reference sphere diameter. Visual only.
        double scale=0.42/extent;
        Point Display(double x,double y,double z) => project((x-anchor.X)*scale,(y-anchor.Y)*scale,(z-anchor.Z)*scale);
        var wirePen=new Pen(new SolidColorBrush(Color.FromArgb(205,31,65,111)),1.65);
        wirePen.Freeze();
        int stride=Math.Max(1,(model.Wires.Count+14999)/15000);
        for(int i=0;i<model.Wires.Count;i+=stride)
        {
            var w=model.Wires[i];
            dc.DrawLine(wirePen,Display(w.X1,w.Y1,w.Z1),Display(w.X2,w.Y2,w.Z2));
        }
        foreach(var source in model.Sources)
        {
            var w=model.Wires.ElementAtOrDefault(source.WireNumber-1);
            if(w is null) continue;
            var pos=PulseLocation(w,source.Position);
            dc.DrawEllipse(Brushes.OrangeRed,new Pen(Brushes.White,1.0),Display(pos.X,pos.Y,pos.Z),4.2,4.2);
        }
        foreach(var load in model.Loads)
        {
            var w=model.Wires.ElementAtOrDefault(load.WireNumber-1);
            if(w is null) continue;
            var pos=PulseLocation(w,load.Position);
            dc.DrawEllipse(Brushes.Gold,new Pen(Brushes.DimGray,0.8),Display(pos.X,pos.Y,pos.Z),3.7,3.7);
        }
    }

    private void DrawReferenceSphere(DrawingContext dc,Func<double,double,double,Point> project)
    {
        // Reference sphere is drawn behind the actual radiation surface.
        // Arcs on the hemisphere facing the viewer are darker; the far hemisphere is light and dashed.
        var frontPen=new Pen(new SolidColorBrush(Color.FromArgb(165,84,104,132)),1.0);
        frontPen.Freeze();
        var backPen=new Pen(new SolidColorBrush(Color.FromArgb(80,150,166,186)),0.8){ DashStyle=DashStyles.Dash };
        backPen.Freeze();
        var view=ViewerDirection();
        for(int latitude=-60;latitude<=60;latitude+=30)
        {
            double phi=latitude*Math.PI/180.0;
            DrawSphereCurve(t => (Math.Cos(phi)*Math.Cos(t),Math.Cos(phi)*Math.Sin(t),Math.Sin(phi)));
        }
        for(int azimuth=0;azimuth<180;azimuth+=30)
        {
            double az=azimuth*Math.PI/180.0;
            DrawSphereCurve(t => (Math.Cos(t)*Math.Cos(az),Math.Cos(t)*Math.Sin(az),Math.Sin(t)));
        }
        void DrawSphereCurve(Func<double,(double X,double Y,double Z)> fn)
        {
            var front=new StreamGeometry();
            var back=new StreamGeometry();
            using(var cf=front.Open())
            using(var cb=back.Open())
            {
                Point previous=default;
                int previousSide=0;          // 0 = no segment yet, 1 = front, -1 = back
                for(int j=0;j<=144;j++)
                {
                    var v=fn(j*2*Math.PI/144);
                    var point=project(v.X,v.Y,v.Z);
                    if(j>0)
                    {
                        var m=fn((j-0.5)*2*Math.PI/144);
                        int side=(m.X*view.X+m.Y*view.Y+m.Z*view.Z)>=0 ? 1 : -1;
                        var ctx=side>0 ? cf : cb;
                        if(side!=previousSide) ctx.BeginFigure(previous,false,false);
                        ctx.LineTo(point,true,false);
                        previousSide=side;
                    }
                    previous=point;
                }
            }
            back.Freeze(); front.Freeze();
            dc.DrawGeometry(null,backPen,back);
            dc.DrawGeometry(null,frontPen,front);
        }
    }

    /// <summary>
    /// θ/φ guides drawn just outside the pattern (radius 1.08 of the unit pattern, inside the axis tips):
    /// a dashed φ arc in the horizontal plane from +X towards +Y and a dashed θ arc in the XZ plane from
    /// the zenith downwards, each with an arrow in the direction of increasing angle. They are projected
    /// with the same camera, so they follow every rotation and projection.
    /// </summary>
    private void DrawAngleGuides(DrawingContext dc,Func<double,double,double,Point> project)
    {
        var colour=Color.FromArgb(170,82,100,118);
        var guide=new Pen(new SolidColorBrush(colour),1.1){ DashStyle=DashStyles.Dash };
        guide.Freeze();
        var head=new Pen(new SolidColorBrush(colour),1.3);
        head.Freeze();
        var muted=new SolidColorBrush(colour);
        muted.Freeze();
        const double r=1.08;
        // Arcs stop short of the axis tips so the arrow heads never touch the tip labels.
        DrawArc(t=>(r*Math.Cos(t),r*Math.Sin(t),0.0),0.10,Math.PI/2-0.22);   // φ: X -> Y
        DrawArc(t=>(r*Math.Sin(t),0.0,r*Math.Cos(t)),0.10,Math.PI/2-0.22);   // θ: zenith -> horizon (towards +X)
        // φ letter at 30° and slightly outside the arc: at 45° it would sit on the Z axis in the default view.
        var pPhi=project(r*1.12*Math.Cos(Math.PI/6),r*1.12*Math.Sin(Math.PI/6),0);
        DrawLabel(dc,"φ",new Point(pPhi.X+2,pPhi.Y-9),15,muted);
        var pTheta=project(r*1.07*Math.Sin(Math.PI/4),0,r*1.07*Math.Cos(Math.PI/4));
        DrawLabel(dc,"θ",new Point(pTheta.X+2,pTheta.Y-9),15,muted);
        var mx=project(-1.12,0,0); DrawLabel(dc,"φ = 180°",new Point(mx.X-24,mx.Y-8),10,muted);
        var my=project(0,-1.12,0); DrawLabel(dc,"φ = 270°",new Point(my.X-24,my.Y-8),10,muted);
        if(_model?.GroundType==0)
        {
            var mz=project(0,0,-1.12); DrawLabel(dc,"θ = 180°",new Point(mz.X+6,mz.Y-6),10,muted);
        }
        void DrawArc(Func<double,(double X,double Y,double Z)> f,double t0,double t1)
        {
            const int steps=40;
            var points=new Point[steps+1];
            for(int i=0;i<=steps;i++)
            {
                var q=f(t0+(t1-t0)*i/steps);
                points[i]=project(q.X,q.Y,q.Z);
            }
            var geometry=new StreamGeometry();
            using(var ctx=geometry.Open())
            {
                ctx.BeginFigure(points[0],false,false);
                for(int i=1;i<=steps;i++) ctx.LineTo(points[i],true,false);
            }
            geometry.Freeze();
            dc.DrawGeometry(null,guide,geometry);
            // Arrow head in the direction of increasing angle (skipped if the arc is seen edge-on).
            var end=points[steps]; var prev=points[steps-3];
            double dx=end.X-prev.X, dy=end.Y-prev.Y, len=Math.Sqrt(dx*dx+dy*dy);
            if(len<1.5) return;
            double ux=dx/len, uy=dy/len;
            dc.DrawLine(head,end,new Point(end.X-8*ux-3.5*uy,end.Y-8*uy+3.5*ux));
            dc.DrawLine(head,end,new Point(end.X-8*ux+3.5*uy,end.Y-8*uy-3.5*ux));
        }
    }

    private void DrawReferenceAxesAndLegend(DrawingContext dc,Func<double,double,double,Point> project)
    {
        if(_angleAxes)
        {
            DrawAxis(1.17,0,0,"φ = 0°",Brushes.IndianRed,13);
            DrawAxis(0,1.17,0,"φ = 90°",Brushes.ForestGreen,13);
            DrawAxis(0,0,1.17,"θ = 0°",Brushes.RoyalBlue,13);
            DrawAngleGuides(dc,project);
        }
        else
        {
            DrawAxis(1.17,0,0,"X",Brushes.IndianRed,15);
            DrawAxis(0,1.17,0,"Y",Brushes.ForestGreen,15);
            DrawAxis(0,0,1.17,"Z",Brushes.RoyalBlue,15);
        }
        void DrawAxis(double x,double y,double z,string label,Brush brush,double size)
        {
            var o=project(0,0,0);var p=project(x,y,z);
            var pen=new Pen(brush,1.9);pen.Freeze(); dc.DrawLine(pen,o,p);
            var dx=p.X-o.X;var dy=p.Y-o.Y;var len=Math.Sqrt(dx*dx+dy*dy);
            if(len>1){var ux=dx/len;var uy=dy/len;
                dc.DrawLine(pen,p,new Point(p.X-10*ux-4*uy,p.Y-10*uy+4*ux));
                dc.DrawLine(pen,p,new Point(p.X-10*ux+4*uy,p.Y-10*uy-4*ux));}
            DrawLabel(dc,label,new Point(p.X+4,p.Y-14),size,brush);
        }
        if(!_angleAxes)
        {
            var bounds=project(0,0,1);
            DrawLabel(dc,"0°",new Point(bounds.X+8,bounds.Y),11,Brushes.SlateGray);
            DrawLabel(dc,"180°",new Point(project(0,0,-1).X+8,project(0,0,-1).Y),11,Brushes.SlateGray);
        }
        // Legend samples use the exact same RainbowArgb() as the rasterized surface.
        double left=Math.Max(ActualWidth-62,8), top=48, height=Math.Min(285,ActualHeight*0.45);
        // The top of the colour bar corresponds to the true sampled maximum, not 0 dBi.
        // Integrated directional power gives directivity; without efficiency it must NOT be called gain.
        DrawLabel(dc,double.IsFinite(_cachedDmaxDbi)
            ? $"ДН: Dmax ≈ {_cachedDmaxDbi:0.##} dBi"
            : "ДН: отн. максимум",new Point(left-144,top-29),11,Brushes.SlateGray);
        for(int i=0;i<100;i++)
        {
            double level=Math.Pow(10.0,-30.0*(i/99.0)/20.0);
            int rgb=RainbowArgb(level);
            var brush=new SolidColorBrush(Color.FromRgb((byte)((rgb>>16)&255),(byte)((rgb>>8)&255),(byte)(rgb&255)));
            dc.DrawRectangle(brush,null,new Rect(left,top+i*height/100.0,13,height/100.0+1));
        }
        for(int i=0;i<=5;i++)
        {
            double fraction=i/5.0;
            string tick=double.IsFinite(_cachedDmaxDbi)
                ? $"{_cachedDmaxDbi-30*fraction:0.#} dBi"
                : $"{-30*fraction:0} dB";
            DrawLabel(dc,tick,new Point(left+16,top+fraction*height-7),9,Brushes.SlateGray);
        }
    }

    private readonly record struct RasterVertex(double X,double Y,double Z,double Amplitude,double Facing);

    private void RenderTranslucent(RasterVertex[] projected,(double X,double Y,double Z)[] world,
        int thetaLimit,int np,int patchPitch,(double X,double Y,double Z) view,int width,int height,int[] pixels)
    {
        int stride=np+1;
        // Smooth vertex normals from the measured grid (central differences, wrap in azimuth),
        // oriented outwards; only n·v (cosine to the line of sight) is needed.
        var ndv=new float[world.Length];
        for(int it=0;it<=thetaLimit;it++)
        for(int ip=0;ip<=np;ip++)
        {
            var up=world[Math.Max(0,it-1)*stride+ip]; var down=world[Math.Min(thetaLimit,it+1)*stride+ip];
            int il=ip==0?np-1:ip-1, ir=ip==np?1:ip+1;
            var left=world[it*stride+il]; var right=world[it*stride+ir];
            double tx=down.X-up.X,ty=down.Y-up.Y,tz=down.Z-up.Z;
            double px=right.X-left.X,py=right.Y-left.Y,pz=right.Z-left.Z;
            double nx=ty*pz-tz*py, ny=tz*px-tx*pz, nz=tx*py-ty*px;
            var p=world[it*stride+ip];
            double len=Math.Sqrt(nx*nx+ny*ny+nz*nz);
            if(len<1e-12){ nx=p.X; ny=p.Y; nz=p.Z; len=Math.Sqrt(nx*nx+ny*ny+nz*nz); }
            if(len<1e-12){ ndv[it*stride+ip]=0; continue; }
            if(nx*p.X+ny*p.Y+nz*p.Z<0){ nx=-nx; ny=-ny; nz=-nz; }
            ndv[it*stride+ip]=(float)((nx*view.X+ny*view.Y+nz*view.Z)/len);
        }
        // Triangles sorted far -> near and composited with the "over" operator.
        var triangles=new List<(double Depth,int A,int B,int C,int Colour,bool Flat)>();
        for(int it=0;it<thetaLimit;it+=patchPitch)
        for(int ip=0;ip<np;ip+=patchPitch)
        {
            int nextT=Math.Min(thetaLimit,it+patchPitch), nextP=Math.Min(np,ip+patchPitch);
            int ia=it*stride+ip, ib=nextT*stride+ip, ic=nextT*stride+nextP, id=it*stride+nextP;
            var a=projected[ia]; var b=projected[ib]; var c=projected[ic]; var d=projected[id];
            bool flat=_patchMode!=0;
            int colour=flat ? ShadeHemisphere(RainbowArgb((a.Amplitude+b.Amplitude+c.Amplitude+d.Amplitude)*0.25),
                (a.Facing+b.Facing+c.Facing+d.Facing)*0.25) : 0;
            triangles.Add(((a.Z+b.Z+c.Z)/3,ia,ib,ic,colour,flat));
            triangles.Add(((a.Z+c.Z+d.Z)/3,ia,ic,id,colour,flat));
        }
        triangles.Sort((u,v)=>u.Depth.CompareTo(v.Depth));
        int n=width*height;
        var accR=new float[n]; var accG=new float[n]; var accB=new float[n]; var accA=new float[n];
        double baseAlpha=_patternAlpha/255.0;
        foreach(var t in triangles)
            BlendTriangle(projected[t.A],projected[t.B],projected[t.C],ndv[t.A],ndv[t.B],ndv[t.C],
                width,height,accR,accG,accB,accA,t.Flat?t.Colour:(int?)null,baseAlpha);
        // Grid on every layer: near lines denser than far ones; dense grids are drawn fainter.
        if(_patchMode==2 && _showMesh)
        {
            double meshScale=Math.Clamp(_meshStepDegrees/10.0,0.2,1.0);
            for(int it=0;it<=thetaLimit;it+=patchPitch)
                for(int ip=0;ip<np;ip++)
                    BlendLine(projected[it*stride+ip],projected[it*stride+ip+1],ndv[it*stride+ip]+ndv[it*stride+ip+1],meshScale,width,height,accR,accG,accB,accA);
            for(int ip=0;ip<=np;ip+=patchPitch)
                for(int it=0;it<thetaLimit;it++)
                    BlendLine(projected[it*stride+ip],projected[(it+1)*stride+ip],ndv[it*stride+ip]+ndv[(it+1)*stride+ip],meshScale,width,height,accR,accG,accB,accA);
        }
        for(int i=0;i<n;i++)
        {
            float a=accA[i];
            if(a<=0){ pixels[i]=0; continue; }
            int r=(int)Math.Clamp(accR[i]/a,0,255), g=(int)Math.Clamp(accG[i]/a,0,255), b=(int)Math.Clamp(accB[i]/a,0,255);
            int al=(int)Math.Clamp(a*255,0,255);
            pixels[i]=(al<<24)|(r<<16)|(g<<8)|b;
        }
    }

    private static void BlendTriangle(RasterVertex a,RasterVertex b,RasterVertex c,float na,float nb,float nc,
        int width,int height,float[] accR,float[] accG,float[] accB,float[] accA,int? flatArgb,double baseAlpha)
    {
        double area=(b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X);
        if(Math.Abs(area)<1e-9||!double.IsFinite(area))return;
        int left=Math.Max(0,(int)Math.Floor(Math.Min(a.X,Math.Min(b.X,c.X))));
        int right=Math.Min(width-1,(int)Math.Ceiling(Math.Max(a.X,Math.Max(b.X,c.X))));
        int top=Math.Max(0,(int)Math.Floor(Math.Min(a.Y,Math.Min(b.Y,c.Y))));
        int bottom=Math.Min(height-1,(int)Math.Ceiling(Math.Max(a.Y,Math.Max(b.Y,c.Y))));
        for(int py=top;py<=bottom;py++)
        for(int px=left;px<=right;px++)
        {
            double x=px+0.5,y=py+0.5;
            double wa=((b.X-x)*(c.Y-y)-(b.Y-y)*(c.X-x))/area;
            double wb=((c.X-x)*(a.Y-y)-(c.Y-y)*(a.X-x))/area;
            double wc=1-wa-wb;
            if(wa< -1e-8||wb< -1e-8||wc< -1e-8)continue;
            double nd=wa*na+wb*nb+wc*nc;
            int colour=flatArgb ?? ShadeHemisphere(RainbowArgb(wa*a.Amplitude+wb*b.Amplitude+wc*c.Amplitude),
                wa*a.Facing+wb*b.Facing+wc*c.Facing);
            double r=(colour>>16)&255, g=(colour>>8)&255, bl=colour&255;
            // Fresnel-like opacity: clear when facing the viewer, dense at the silhouette.
            double alpha=baseAlpha*(0.34+0.66*Math.Pow(1-Math.Min(1,Math.Abs(nd)),1.6));
            // Soft headlight highlight on surfaces turned to the viewer.
            double spec=nd>0 ? Math.Pow(nd,36)*0.32 : 0;
            r+=(255-r)*spec; g+=(255-g)*spec; bl+=(255-bl)*spec;
            alpha=Math.Min(1,alpha+0.20*spec);
            int i=py*width+px;
            float k=(float)(1-alpha);
            accR[i]=(float)(r*alpha)+accR[i]*k;
            accG[i]=(float)(g*alpha)+accG[i]*k;
            accB[i]=(float)(bl*alpha)+accB[i]*k;
            accA[i]=(float)alpha+accA[i]*k;
        }
    }

    private static void BlendLine(RasterVertex a,RasterVertex b,double ndvSum,double scale,int width,int height,
        float[] accR,float[] accG,float[] accB,float[] accA)
    {
        double dx=b.X-a.X,dy=b.Y-a.Y;
        int steps=(int)Math.Ceiling(Math.Max(Math.Abs(dx),Math.Abs(dy))*1.2);
        if(steps<1 || steps>100000 || !double.IsFinite(dx) || !double.IsFinite(dy))return;
        double alpha=(ndvSum>0?0.30:0.10)*scale;
        float k=(float)(1-alpha);
        for(int s=0;s<=steps;s++)
        {
            double t=(double)s/steps;
            int x=(int)Math.Round(a.X+dx*t),y=(int)Math.Round(a.Y+dy*t);
            if(x<0 || x>=width || y<0 || y>=height)continue;
            int i=y*width+x;
            accR[i]=(float)(22*alpha)+accR[i]*k;
            accG[i]=(float)(40*alpha)+accG[i]*k;
            accB[i]=(float)(68*alpha)+accB[i]*k;
            accA[i]=(float)alpha+accA[i]*k;
        }
    }

    private static void RasterTriangle(RasterVertex a,RasterVertex b,RasterVertex c,
        int width,int height,int[] pixels,float[] zbuffer,int? flatArgb=null,byte alpha=255)
    {
        double area=(b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X);
        if(Math.Abs(area)<1e-9||!double.IsFinite(area))return;
        int left=Math.Max(0,(int)Math.Floor(Math.Min(a.X,Math.Min(b.X,c.X))));
        int right=Math.Min(width-1,(int)Math.Ceiling(Math.Max(a.X,Math.Max(b.X,c.X))));
        int top=Math.Max(0,(int)Math.Floor(Math.Min(a.Y,Math.Min(b.Y,c.Y))));
        int bottom=Math.Min(height-1,(int)Math.Ceiling(Math.Max(a.Y,Math.Max(b.Y,c.Y))));
        for(int py=top;py<=bottom;py++)
        for(int px=left;px<=right;px++)
        {
            double x=px+0.5,y=py+0.5;
            double wa=((b.X-x)*(c.Y-y)-(b.Y-y)*(c.X-x))/area;
            double wb=((c.X-x)*(a.Y-y)-(c.Y-y)*(a.X-x))/area;
            double wc=1-wa-wb;
            if(wa< -1e-8||wb< -1e-8||wc< -1e-8)continue;
            double z=wa*a.Z+wb*b.Z+wc*c.Z;
            int index=py*width+px;
            if(z<=zbuffer[index])continue;
            zbuffer[index]=(float)z;
            double amplitude=wa*a.Amplitude+wb*b.Amplitude+wc*c.Amplitude;
            int colour=flatArgb ?? ShadeHemisphere(RainbowArgb(amplitude),wa*a.Facing+wb*b.Facing+wc*c.Facing);
            pixels[index]=(colour & 0x00FFFFFF) | (alpha << 24);
        }
    }

    private static void MeshLine(RasterVertex a,RasterVertex b,int width,int height,int[] pixels,float[] zbuffer)
    {
        double dx=b.X-a.X,dy=b.Y-a.Y;
        int steps=(int)Math.Ceiling(Math.Max(Math.Abs(dx),Math.Abs(dy))*1.2);
        if(steps<1 || steps>100000 || !double.IsFinite(dx) || !double.IsFinite(dy))return;
        for(int i=0;i<=steps;i++)
        {
            double t=(double)i/steps;
            int x=(int)Math.Round(a.X+dx*t),y=(int)Math.Round(a.Y+dy*t);
            if(x<0 || x>=width || y<0 || y>=height)continue;
            double z=a.Z+(b.Z-a.Z)*t;
            int idx=y*width+x;
            // A small relative depth tolerance avoids flickering at triangle edges.
            double epsilon=0.002*Math.Max(1,Math.Abs(z));
            if(z+epsilon<zbuffer[idx] || pixels[idx]==0)continue;
            int rgb=pixels[idx];
            int r=(rgb>>16)&255,g=(rgb>>8)&255,bl=rgb&255;
            // Dark blue-gray at 52% opacity, preserving the rainbow gain mapping.
            pixels[idx]=(rgb & unchecked((int)0xFF000000))|(((r*48+22*52)/100)<<16)|(((g*48+40*52)/100)<<8)|((bl*48+68*52)/100);
        }
    }

    private static int RainbowArgb(double power)
    {
        double db=20.0*Math.Log10(Math.Max(1e-12,Math.Clamp(power,0,1)));
        double h=(1-Math.Clamp((db+30.0)/30.0,0,1))*270;
        double c=1,x=c*(1-Math.Abs((h/60)%2-1));
        double r=0,g=0,b=0;
        if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}
        else if(h<180){g=c;b=x;}else if(h<240){g=x;b=c;}
        else if(h<300){r=x;b=c;}else{r=c;b=x;}
        return unchecked((int)0xFF000000)|((int)(255*r)<<16)|((int)(255*g)<<8)|(int)(255*b);
    }

    private void DrawLabel(DrawingContext dc,string label,Point at,double size,Brush brush)
    {
        var ft=new FormattedText(label,CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,
            new Typeface("Segoe UI"),size,brush,VisualTreeHelper.GetDpi(this).PixelsPerDip);
        dc.DrawText(ft,at);
    }

    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        base.OnMouseWheel(e);
        _zoom=Math.Clamp(_zoom*Math.Pow(1.1,e.Delta/120.0),0.02,100);
        InvalidateVisual(); e.Handled=true;
    }
    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonDown(e);
        if(_projection==0) { _drag=e.GetPosition(this); CaptureMouse(); e.Handled=true; }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if(_drag is not Point old || !IsMouseCaptured) return;
        var current=e.GetPosition(this);
        _azimuth += (current.X-old.X)*0.008;
        _elevation=Math.Clamp(_elevation+(current.Y-old.Y)*0.008,-1.55,1.55);
        _drag=current; InvalidateVisual(); e.Handled=true;
    }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonUp(e);
        _drag=null; if(IsMouseCaptured)ReleaseMouseCapture();
    }
}
