using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>
/// LiteVNA64 over its USB virtual COM port (STM32 CDC, usually VID:PID 0483:5740). The command sequence
/// and FIFO handling follow the Android LiteVnaUsb session used with the real instrument.
/// </summary>
internal sealed class LiteVnaSerial : IDisposable
{
    public sealed record PortEntry(string Port,string Description,bool LooksLikeVna)
    {
        public override string ToString()=>LooksLikeVna ? $"{Port} — {Description} (LiteVNA?)" : (Description.Length>0 ? $"{Port} — {Description}" : Port);
    }
    public sealed record DeviceInfo(string Port,int Variant,int Protocol,int Hardware,int FirmwareMajor,int FirmwareMinor)
    {
        public string Text=>$"V2 Binary · {Port} · variant {Variant} · HW {Hardware} · FW {FirmwareMajor}.{FirmwareMinor} · протокол {Protocol}";
    }

    readonly SerialPort _port;
    const int ChunkRecords=64;

    LiteVnaSerial(string portName)
    {
        _port=new SerialPort(portName,115200,Parity.None,8,StopBits.One)
        {
            ReadTimeout=8000, WriteTimeout=3000, DtrEnable=true, RtsEnable=true, ReadBufferSize=1<<20, Handshake=Handshake.None
        };
    }

    /// <summary>Opens the port, resets the protocol parser (8 × NOP), checks INDICATE and the device registers.</summary>
    public static (LiteVnaSerial Session,DeviceInfo Info) Open(string portName,bool liteOnly=true)
    {
        var s=new LiteVnaSerial(portName);
        try
        {
            s._port.Open();
            Thread.Sleep(50);
            s._port.DiscardInBuffer();
            s.Write(LiteVnaProtocol.Nops(8));
            Thread.Sleep(30);
            s._port.DiscardInBuffer();
            if(!s.Indicate()) throw new InvalidOperationException("Устройство не ответило на команду INDICATE (ожидался '2').");
            var info=new DeviceInfo(portName,
                s.ReadRegister(LiteVnaProtocol.RegDeviceVariant),s.ReadRegister(LiteVnaProtocol.RegProtocolVersion),
                s.ReadRegister(LiteVnaProtocol.RegHardwareRevision),s.ReadRegister(LiteVnaProtocol.RegFirmwareMajor),
                s.ReadRegister(LiteVnaProtocol.RegFirmwareMinor));
            if(info.FirmwareMajor==0xff) throw new InvalidOperationException("LiteVNA в режиме DFU/загрузчика — перезапустите прибор в обычном режиме.");
            if(liteOnly && info.Variant!=LiteVnaProtocol.LiteVnaVariant) throw new InvalidOperationException($"Устройство ответило, но deviceVariant = {info.Variant}; для LiteVNA ожидается 2.");
            s._variant=info.Variant;
            return (s,info);
        }
        catch
        {
            s.Dispose();
            throw;
        }
    }

    bool Indicate()
    {
        Write(LiteVnaProtocol.Indicate());
        return ReadExact(1,2500)[0]==LiteVnaProtocol.IndicateReply;
    }
    int ReadRegister(byte address)
    {
        Write(LiteVnaProtocol.ReadByte(address));
        return ReadExact(1,2500)[0];
    }

    int _variant=LiteVnaProtocol.LiteVnaVariant;
    /// <summary>Discards buffered FIFO records; the running sweep continues with unchanged settings.</summary>
    public void ClearFifo()=>Write(LiteVnaProtocol.WriteByte(LiteVnaProtocol.RegValuesFifo,0));
    public void Configure(LiteVnaProtocol.SweepConfig config)
    {
        foreach(var command in LiteVnaProtocol.ConfigureSweep(config,_variant==LiteVnaProtocol.LiteVnaVariant)) Write(command);
    }

    /// <summary>Reads one coherent sweep from the running FIFO (call <see cref="Configure"/> first).</summary>
    public LiteVnaProtocol.RawValue[] ReadNextSweep(LiteVnaProtocol.SweepConfig config,CancellationToken ct,Action<int,int>? progress)
    {
        var assembler=new LiteVnaProtocol.SweepAssembler(config.Points);
        int batches=0, maxBatches=((config.Points+ChunkRecords-1)/ChunkRecords)*12+64;
        while(!assembler.Complete)
        {
            ct.ThrowIfCancellationRequested();
            if(batches++>maxBatches) throw new TimeoutException($"LiteVNA: не удалось собрать полную развёртку ({assembler.Received}/{config.Points}).");
            int count=Math.Min(ChunkRecords,Math.Max(1,config.Points-assembler.Received));
            Write(LiteVnaProtocol.ReadFifo(count));
            var block=ReadExact(count*LiteVnaProtocol.FifoRecordBytes,8000);
            for(int offset=0;offset<block.Length;offset+=LiteVnaProtocol.FifoRecordBytes)
            {
                if(assembler.Feed(LiteVnaProtocol.ParseRawValue(block.AsSpan(offset,LiteVnaProtocol.FifoRecordBytes)))) break;
            }
            progress?.Invoke(assembler.Received,config.Points);
        }
        return assembler.Result();
    }

    void Write(byte[] bytes)=>_port.Write(bytes,0,bytes.Length);

    byte[] ReadExact(int count,int timeoutMs)
    {
        _port.ReadTimeout=timeoutMs;
        var buffer=new byte[count];
        int offset=0;
        while(offset<count)
        {
            int n=_port.Read(buffer,offset,count-offset);   // throws TimeoutException on timeout
            if(n<=0) throw new TimeoutException($"USB: нет данных ({offset}/{count} байт).");
            offset+=n;
        }
        return buffer;
    }

    public void Dispose()
    {
        try { if(_port.IsOpen) Write(LiteVnaProtocol.WriteByte(LiteVnaProtocol.RegRawSamplesMode,2)); } catch { }   // back to normal device mode
        try { _port.Close(); } catch { }
        _port.Dispose();
    }

    /// <summary>COM ports with descriptions; STM32 virtual COM (VID 0483, PID 5740) is marked as a likely LiteVNA.</summary>
    public static List<PortEntry> FindPorts()
    {
        var names=SerialPort.GetPortNames().Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var info=new Dictionary<string,(string Caption,bool Vna)>(StringComparer.OrdinalIgnoreCase);
        try
        {
            using var searcher=new System.Management.ManagementObjectSearcher(
                "SELECT Caption, PNPDeviceID FROM Win32_PnPEntity WHERE Caption LIKE '%(COM%'");
            foreach(System.Management.ManagementObject o in searcher.Get())
            {
                string caption=o["Caption"]?.ToString() ?? "";
                string pnp=o["PNPDeviceID"]?.ToString() ?? "";
                var m=Regex.Match(caption,@"\((COM\d+)\)");
                if(!m.Success) continue;
                bool vna=pnp.Contains("VID_0483&PID_5740",StringComparison.OrdinalIgnoreCase)
                      || caption.Contains("VNA",StringComparison.OrdinalIgnoreCase);
                info[m.Groups[1].Value]=(Regex.Replace(caption,@"\s*\(COM\d+\)",""),vna);
                if(!names.Contains(m.Groups[1].Value,StringComparer.OrdinalIgnoreCase)) names.Add(m.Groups[1].Value);
            }
        }
        catch { }   // WMI unavailable: plain port names
        return names
            .Select(n=>info.TryGetValue(n,out var d) ? new PortEntry(n,d.Caption,d.Vna) : new PortEntry(n,"",false))
            .OrderByDescending(p=>p.LooksLikeVna)
            .ThenBy(p=>p.Port.Length).ThenBy(p=>p.Port,StringComparer.OrdinalIgnoreCase)
            .ToList();
    }
}
