using System;
using System.Collections.Generic;
using System.Numerics;
using System.Runtime.InteropServices;
using AntennaCalculator.Core;
namespace AntennaCalculator.Wpf;
/// <summary>
/// Optional CUDA field grid. Since 0.6.47 the export antenna_field_sample_ex applies the same ground operator as the
/// CPU kernel (NearFieldKernel) and the 3D pattern. With an older DLL the real ground (G=2) is computed on the CPU.
/// </summary>
internal static class CudaFieldSolver
{
  [DllImport("AntennaCudaField64.dll",CallingConvention=CallingConvention.Cdecl,EntryPoint="antenna_field_sample")]
  private static extern int Native([In] double[] segments,int count,double frequency,int n,double cx,double cy,double cz,double span,[Out] double[] output);
  [DllImport("AntennaCudaField64.dll",CallingConvention=CallingConvention.Cdecl,EntryPoint="antenna_field_sample_ex")]
  private static extern int NativeEx([In] double[] segments,int count,double frequency,int n,double cx,double cy,double cz,double span,
      int ground,double epsR,double sigma,[Out] double[] output);
  internal static string LastStatus {get;private set;}="CUDA Field not checked";
  private static bool _noEx;
  internal static bool TrySample(IReadOnlyList<MininecPulseSolver.FieldSample> samples,double freq,int ground,double cx,double cy,double cz,double span,int n,Complex[] ex,Complex[] ey,Complex[] ez,Complex[] hx,Complex[] hy,Complex[] hz,double[] power)
  {
    try{
      int count=samples.Count;
      if(count==0)return false;
      var values=new double[n*n*n*13];
      int error;
      if(!_noEx)
      {
        var data=new double[count*9];int p=0;
        foreach(var a in samples){
          data[p++]=a.X;data[p++]=a.Y;data[p++]=a.Z;data[p++]=a.Dx;data[p++]=a.Dy;data[p++]=a.Dz;data[p++]=a.RealCurrent;data[p++]=a.ImagCurrent;
          data[p++]=a.GroundPulse?2:0;
        }
        try{ error=NativeEx(data,count,freq,n,cx,cy,cz,span,ground,FieldMapView.GroundEpsilonR,FieldMapView.GroundSigma,values); }
        catch(EntryPointNotFoundException){ _noEx=true; error=int.MinValue; }
        if(error==int.MinValue)
        {
          if(ground==2){ LastStatus="CUDA Field DLL старой версии — реальная земля считается на CPU (пересоберите BUILD_CUDA_FIELD_WIN64.bat)"; return false; }
          error=OldPath(samples,freq,n,cx,cy,cz,span,values);
        }
      }
      else
      {
        if(ground==2){ LastStatus="CUDA Field DLL старой версии — реальная земля считается на CPU"; return false; }
        error=OldPath(samples,freq,n,cx,cy,cz,span,values);
      }
      if(error!=0){LastStatus="CUDA Field error "+error;return false;}
      for(int i=0;i<ex.Length;i++){
        int b=i*13;
        ex[i]=new Complex(values[b],values[b+1]);ey[i]=new Complex(values[b+2],values[b+3]);ez[i]=new Complex(values[b+4],values[b+5]);
        hx[i]=new Complex(values[b+6],values[b+7]);hy[i]=new Complex(values[b+8],values[b+9]);hz[i]=new Complex(values[b+10],values[b+11]);power[i]=values[b+12];
      }
      LastStatus="CUDA Field OK";return true;
    }catch(DllNotFoundException){LastStatus="CUDA Field DLL missing";return false;}
    catch(EntryPointNotFoundException){LastStatus="CUDA Field DLL outdated";return false;}
    catch(BadImageFormatException){LastStatus="CUDA Field DLL architecture";return false;}
    catch(Exception e){LastStatus=e.GetType().Name+": "+e.Message;return false;}
  }
  /// <summary>Pre-0.6.47 export (no ground weighting): valid for G = 0 and G = 1 only.</summary>
  private static int OldPath(IReadOnlyList<MininecPulseSolver.FieldSample> samples,double freq,int n,double cx,double cy,double cz,double span,double[] values)
  {
    var data=new double[samples.Count*8];int p=0;
    foreach(var a in samples){data[p++]=a.X;data[p++]=a.Y;data[p++]=a.Z;data[p++]=a.Dx;data[p++]=a.Dy;data[p++]=a.Dz;data[p++]=a.RealCurrent;data[p++]=a.ImagCurrent;}
    return Native(data,samples.Count,freq,n,cx,cy,cz,span,values);
  }
}
