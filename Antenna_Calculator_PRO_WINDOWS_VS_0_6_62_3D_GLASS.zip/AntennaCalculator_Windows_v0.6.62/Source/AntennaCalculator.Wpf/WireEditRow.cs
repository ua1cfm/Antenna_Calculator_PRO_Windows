using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Data;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>Editable row of the wires table: current values, the values of the applied model, change flag.</summary>
public sealed class WireEditRow : INotifyPropertyChanged
{
    private readonly MaaWire _original;
    private double _x1, _y1, _z1, _x2, _y2, _z2, _r;

    public WireEditRow(MaaWire wire, bool editable)
    {
        _original = wire; Editable = editable;
        _x1 = wire.X1; _y1 = wire.Y1; _z1 = wire.Z1; _x2 = wire.X2; _y2 = wire.Y2; _z2 = wire.Z2; _r = wire.RadiusMetres;
    }

    public int Number => _original.Number;
    public int Tag => _original.Tag;
    /// <summary>False for Make Stack copies (not written in the file): only the base antenna can be edited.</summary>
    public bool Editable { get; }
    public double X1 { get => _x1; set => Set(ref _x1, value); }
    public double Y1 { get => _y1; set => Set(ref _y1, value); }
    public double Z1 { get => _z1; set => Set(ref _z1, value); }
    public double X2 { get => _x2; set => Set(ref _x2, value); }
    public double Y2 { get => _y2; set => Set(ref _y2, value); }
    public double Z2 { get => _z2; set => Set(ref _z2, value); }
    public double RadiusMetres { get => _r; set => Set(ref _r, value); }
    /// <summary>Length of the wire with the current (possibly not yet applied) values.</summary>
    public double LengthMetres => Math.Sqrt((_x2 - _x1) * (_x2 - _x1) + (_y2 - _y1) * (_y2 - _y1) + (_z2 - _z1) * (_z2 - _z1));
    public bool Changed =>
        _x1 != _original.X1 || _y1 != _original.Y1 || _z1 != _original.Z1 ||
        _x2 != _original.X2 || _y2 != _original.Y2 || _z2 != _original.Z2 || _r != _original.RadiusMetres;

    public MaaParser.WireGeometry Geometry => new(_x1, _y1, _z1, _x2, _y2, _z2, _r);

    public event PropertyChangedEventHandler? PropertyChanged;
    private void Set(ref double field, double value, [CallerMemberName] string? name = null)
    {
        if (!double.IsFinite(value) || field.Equals(value)) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LengthMetres)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Changed)));
    }
}

/// <summary>Number ⇄ text for editable cells: shows "0.######", accepts both '.' and ',' as the decimal separator.</summary>
public sealed class FlexibleNumberConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is double d ? d.ToString("0.#######", CultureInfo.InvariantCulture) : value?.ToString() ?? "";

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        string s = (value as string ?? "").Trim().Replace(',', '.').Replace(" ", "");
        if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out double d) && double.IsFinite(d)) return d;
        return Binding.DoNothing;          // invalid input: keep the previous value
    }
}
