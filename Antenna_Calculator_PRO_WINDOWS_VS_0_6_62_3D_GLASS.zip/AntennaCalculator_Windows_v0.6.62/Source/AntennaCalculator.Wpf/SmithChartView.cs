﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Globalization;
using System.Windows.Input;
using System.Windows;
using System.Windows.Media;

namespace AntennaCalculator.Wpf;

/// <summary>Smith impedance chart (reflection plane), no data smoothing.</summary>
public sealed class SmithChartView : FrameworkElement
{
    private readonly List<Complex> _gamma=new();
    private readonly List<double> _frequenciesMHz=new();
    private double _referenceOhms=50;
    private int _selected=-1;
    public void SetReferenceOhms(double value)
    {
        _referenceOhms=value>0&&double.IsFinite(value)?value:50;
        InvalidateVisual();
    }
    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonDown(e);
        if(_gamma.Count==0)return;
        double r=Math.Max(10,Math.Min(ActualWidth-30,ActualHeight-15)/2);
        double cx=ActualWidth/2,cy=ActualHeight/2;
        var p=e.GetPosition(this);
        int closest=-1;double best=double.PositiveInfinity;
        for(int i=0;i<_gamma.Count;i++)
        {
            var g=_gamma[i];
            if(!double.IsFinite(g.Real)||!double.IsFinite(g.Imaginary))continue;
            double dx=p.X-(cx+g.Real*r),dy=p.Y-(cy-g.Imaginary*r);
            double d=dx*dx+dy*dy;
            if(d<best){best=d;closest=i;}
        }
        if(closest>=0&&best<=18*18){_selected=closest;InvalidateVisual();e.Handled=true;}
    }
    private void DrawMarkerImpedance(DrawingContext dc)
    {
        if(_gamma.Count==0)return;
        int i=_selected>=0&&_selected<_gamma.Count?_selected:_gamma.Count-1;
        Complex g=_gamma[i];
        Complex denominator=Complex.One-g;
        if(denominator.Magnitude<1e-12)return;
        Complex z=_referenceOhms*(Complex.One+g)/denominator;
        if(!double.IsFinite(z.Real)||!double.IsFinite(z.Imaginary))return;
        string sign=z.Imaginary<0?"−":"+";
        string frequency=_frequenciesMHz.Count==_gamma.Count &&
            double.IsFinite(_frequenciesMHz[i]) && _frequenciesMHz[i]>0
            ? $"f = {_frequenciesMHz[i]:0.######} МГц    "
            : "";
        string label=$"{frequency}Z = {z.Real:0.###} {sign} j{Math.Abs(z.Imaginary):0.###} Ω";
        var text=new FormattedText(label,CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,
            new Typeface("Segoe UI"),13,Brushes.DarkSlateBlue,VisualTreeHelper.GetDpi(this).PixelsPerDip);
        double x=Math.Max(8,ActualWidth-text.Width-14);
        dc.DrawRoundedRectangle(Brushes.WhiteSmoke,new Pen(Brushes.LightGray,0.7),
            new Rect(x-6,7,text.Width+12,text.Height+9),4,4);
        dc.DrawText(text,new Point(x,11));
    }
    public void Clear(){_gamma.Clear();_frequenciesMHz.Clear();_selected=-1;InvalidateVisual();}
    public void SetPoint(Complex gamma, double frequencyMHz)
    {
        _gamma.Clear();_frequenciesMHz.Clear();
        _gamma.Add(gamma);_frequenciesMHz.Add(frequencyMHz);
        _selected=0;InvalidateVisual();
    }
    public void SetTrace(IEnumerable<(double FrequencyMHz, Complex Gamma)> samples)
    {
        _gamma.Clear();_frequenciesMHz.Clear();
        foreach(var sample in samples)
        {
            _frequenciesMHz.Add(sample.FrequencyMHz);
            _gamma.Add(sample.Gamma);
        }
        _selected=_gamma.Count-1;InvalidateVisual();
    }
    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        if(ActualWidth<=0||ActualHeight<=0)return;
        double cy=ActualHeight/2,cx=ActualWidth/2,r=Math.Max(10,Math.Min(ActualWidth-30,ActualHeight-15)/2);
        var grid=new Pen(new SolidColorBrush(Color.FromRgb(207,219,231)),0.9);
        var major=new Pen(new SolidColorBrush(Color.FromRgb(100,126,150)),1.4);
        var ink=new Pen(new SolidColorBrush(Color.FromRgb(21,114,168)),2.5);
        var fill=Brushes.White;
        dc.DrawRectangle(fill,null,new Rect(0,0,ActualWidth,ActualHeight));
        dc.DrawEllipse(null,major,new Point(cx,cy),r,r);
        dc.DrawLine(grid,new Point(cx-r,cy),new Point(cx+r,cy));
        // Constant resistance circles z = R + jX under gamma = (z - 1)/(z + 1)
        foreach(double rho in new[]{0.2,0.5,1.0,2.0,5.0})
        {
            double cc=rho/(rho+1),rad=1/(rho+1);
            dc.DrawEllipse(null,grid,new Point(cx+r*cc,cy),r*rad,r*rad);
        }
        // Constant reactance arcs. Clip to the physical unit reflection circle.
        dc.PushClip(new EllipseGeometry(new Point(cx,cy),r,r));
        foreach(double x in new[]{0.2,0.5,1,2,5})
        {
            double rr=1/x;
            dc.DrawEllipse(null,grid,new Point(cx+r,cy-r*rr),r*rr,r*rr);
            dc.DrawEllipse(null,grid,new Point(cx+r,cy+r*rr),r*rr,r*rr);
        }
        if(_gamma.Count>0)
        {
            Point Project(Complex g)=>new(cx+g.Real*r,cy-g.Imaginary*r);
            var geometry=new StreamGeometry();
            using(var ctx=geometry.Open())
            {
                bool first=true;
                foreach(var g in _gamma)
                {
                    if(!double.IsFinite(g.Real)||!double.IsFinite(g.Imaginary))continue;
                    if(first){ctx.BeginFigure(Project(g),false,false);first=false;}
                    else ctx.LineTo(Project(g),true,false);
                }
            }
            geometry.Freeze();dc.DrawGeometry(null,ink,geometry);
            foreach(var g in _gamma)
            {
                if(!double.IsFinite(g.Real)||!double.IsFinite(g.Imaginary))continue;
                dc.DrawEllipse(new SolidColorBrush(Color.FromRgb(221,85,50)),null,Project(g),_gamma.Count==1?4:2.1,_gamma.Count==1?4:2.1);
            }
        }
        dc.Pop();
        dc.DrawEllipse(new SolidColorBrush(Color.FromRgb(87,102,119)),null,new Point(cx+r,cy),2,2);
        DrawMarkerImpedance(dc);
    }
}
