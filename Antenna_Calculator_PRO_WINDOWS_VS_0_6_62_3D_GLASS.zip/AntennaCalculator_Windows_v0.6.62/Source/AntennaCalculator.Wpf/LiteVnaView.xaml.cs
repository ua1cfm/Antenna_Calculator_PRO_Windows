using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using AntennaCalculator.Core;
using Microsoft.Win32;

namespace AntennaCalculator.Wpf;

/// <summary>
/// VNA workspace (LiteVNA64, NanoVNA V2, NanoVNA H/H4 shell): instrument over USB (virtual COM), single / continuous sweep, in-app OSL + THRU
/// calibration, Touchstone .s1p/.s2p and CSV export, Touchstone import, Smith chart and rectangular
/// charts with four markers, overlay of the model's Smith Sweep for comparison.
/// </summary>
public partial class LiteVnaView : UserControl
{
    static readonly CultureInfo Inv=CultureInfo.InvariantCulture;
    readonly VnaMarkers _markers=new();
    VnaCalibration _cal=new();
    string? _calPath;                   // library file of the current calibration, null if not saved
    bool _calDirty;                     // changed since it was loaded/saved
    bool _profileLoading;
    VnaCalibration.ApplyMode _calMode;
    bool _calDeviceMismatch;            // calibration of another instrument family: not applied
    IVnaConnection? _session;
    string? _info;
    CancellationTokenSource? _cts;
    Task? _running;
    VnaSweep? _raw;                     // last instrument sweep (RAW), null for an imported file
    VnaSweep? _shown;                   // what is displayed: calibrated, RAW or imported
    LiteVnaProtocol.SweepConfig? _rawConfig;
    IReadOnlyList<(double Hz,Complex Gamma)>? _model;
    int _uiPending;

    public sealed record MarkerRow(string Name,string Frequency,string R,string X,string AbsZ,string Swr,string ReturnLoss,
        string Gamma,string LC,string Q,string S21Db,string S21Phase,string GroupDelay);

    // ---- calibration popup and full-window mode
    DateTime _calPopupClosedAt;
    void CalButton_Click(object sender,RoutedEventArgs e)
    {
        // A click on the button while the popup is open first closes it (StaysOpen = False); do not reopen at once.
        if((DateTime.Now-_calPopupClosedAt).TotalMilliseconds<300) return;
        CalPopup.IsOpen=!CalPopup.IsOpen;
    }
    void CalPopup_Closed(object? sender,EventArgs e)=>_calPopupClosedAt=DateTime.Now;

    /// <summary>Text for the main window status bar.</summary>
    public event Action? BackRequested;
    private void BackToAntenna_Click(object sender,RoutedEventArgs e)=>BackRequested?.Invoke();
    public event Action<string>? StatusChanged;
    /// <summary>Frequency of the open MMANA model (for «Диапазон модели»).</summary>
    public double ModelFrequencyMHz { get; set; }

    public LiteVnaView()
    {
        InitializeComponent();
        Smith.Markers=_markers;
        Chart.Markers=_markers;
        _markers.Changed+=UpdateMarkerInfo;
        Loaded+=(_,_)=>
        {
            if(PortBox.Items.Count==0) RefreshPorts();
            if(ProfileBox.ItemsSource==null)
            {
                var last=VnaCalibrationLibrary.LastUsed();
                RefreshProfiles(last);
                if(last!=null) LoadProfile(last,setGrid:true,quiet:true);
                else UpdateCalText();
            }
        };
    }

    void Status(string text)=>StatusChanged?.Invoke(text);
    Window? Owner=>Window.GetWindow(this);

    // ------------------------------------------------------------ model overlay
    /// <summary>Model reflection coefficient versus frequency (from the main window's Smith Sweep), or null.</summary>
    public void SetModelTrace(IReadOnlyList<(double Hz,Complex Gamma)>? trace){ _model=trace; UpdateOverlay(); }
    void UpdateOverlay()
    {
        if(Smith==null || Chart==null || OverlayCheck==null) return;
        var ov=OverlayCheck.IsChecked==true ? _model : null;
        Smith.Overlay=ov; Chart.Overlay=ov;
        UpdateMarkerInfo();
    }
    void Overlay_Changed(object sender,RoutedEventArgs e){ if(IsLoaded) UpdateOverlay(); }
    void Quantity_Changed(object sender,SelectionChangedEventArgs e){ if(Chart!=null && QuantityBox!=null) Chart.Quantity=(VnaQuantity)Math.Max(0,QuantityBox.SelectedIndex); }
    void ModelRange_Click(object sender,RoutedEventArgs e)
    {
        if(!(ModelFrequencyMHz>0)){ MessageBox.Show(Owner!,"Сначала откройте модель MAA."); return; }
        StartBox.Text=Math.Max(0.05,ModelFrequencyMHz*0.9).ToString("0.######",Inv);
        StopBox.Text=Math.Min(6300,ModelFrequencyMHz*1.1).ToString("0.######",Inv);
    }

    // ------------------------------------------------------------ instrument
    async void RefreshPorts()
    {
        RefreshButton.IsEnabled=false;
        try
        {
            var previous=(PortBox.SelectedItem as LiteVnaSerial.PortEntry)?.Port;
            var ports=await Task.Run(()=>LiteVnaSerial.FindPorts());
            PortBox.ItemsSource=ports;
            PortBox.SelectedItem=ports.FirstOrDefault(p=>p.Port==previous) ?? ports.FirstOrDefault();
            if(_session==null)
                DeviceText.Text=ports.Count==0 ? "COM-порты не найдены: подключите VNA кабелем с данными"
                              : ports[0].LooksLikeVna ? "Найден вероятный VNA — нажмите «Подключить»" : "Выберите порт VNA";
        }
        catch(Exception ex){ DeviceText.Text="Список портов: "+ex.Message; }
        finally{ RefreshButton.IsEnabled=true; }
    }
    void Refresh_Click(object sender,RoutedEventArgs e)=>RefreshPorts();

    async void Connect_Click(object sender,RoutedEventArgs e)
    {
        if(_session!=null){ await DisconnectAsync(); return; }
        if(PortBox.SelectedItem is not LiteVnaSerial.PortEntry entry){ MessageBox.Show(Owner!,"Выберите COM-порт VNA."); return; }
        // WPF controls may only be accessed on their owning UI Dispatcher thread.
        // Snapshot every UI-dependent value BEFORE entering Task.Run.
        string portName=entry.Port;
        int protocolMode=ProtocolBox.SelectedIndex;
        ConnectButton.IsEnabled=false; DeviceText.Text="Подключение…";
        try
        {
            var session=await Task.Run(()=>VnaConnectionFactory.Open(portName,protocolMode));
            _session=session; _info=session.Description;
            DeviceText.Text=session.Description;
            ConnectButton.Content="Отключить";
            Status("VNA подключён: "+session.Description);
        }
        catch(Exception ex)
        {
            DeviceText.Text="Нет связи: "+ex.Message;
            Status("VNA: "+ex.Message);
        }
        finally{ ConnectButton.IsEnabled=true; }
    }

    async Task DisconnectAsync()
    {
        _cts?.Cancel();
        if(_running!=null){ try{ await _running; } catch{ } }
        var s=_session; _session=null; _info=null;
        ConnectButton.Content="Подключить";
        DeviceText.Text="Прибор не подключён";
        if(s!=null) await Task.Run(()=>s.Dispose());
        Status("VNA отключён");
    }

    /// <summary>Called when the main window closes.</summary>
    public void Shutdown()
    {
        try{ _cts?.Cancel(); } catch{ }
        try{ _running?.Wait(1500); } catch{ }
        try{ _session?.Dispose(); } catch{ }
        _session=null;
    }

    LiteVnaProtocol.SweepConfig ReadConfig()
    {
        double Mhz(TextBox box,string name)
        {
            if(!double.TryParse(box.Text.Trim().Replace(',','.'),NumberStyles.Float,Inv,out double v) || !double.IsFinite(v))
                throw new ArgumentException($"{name}: введите частоту в МГц.");
            return v;
        }
        int Item(ComboBox box)=>int.Parse(((ComboBoxItem)box.SelectedItem).Content.ToString()!,Inv);
        double f1=Mhz(StartBox,"Начало"), f2=Mhz(StopBox,"Конец");
        return new LiteVnaProtocol.SweepConfig((long)Math.Round(f1*1e6),(long)Math.Round(f2*1e6),Item(PointsBox),Item(AverageBox));
    }

    /// <summary>Busy state: the button that started the work stays enabled and becomes "■ Стоп".</summary>
    void SetBusy(bool busy,Button? active=null)
    {
        SweepButton.IsEnabled=!busy || active==SweepButton;
        LiveButton.IsEnabled=!busy || active==LiveButton;
        SweepButton.Content=busy && active==SweepButton ? "■  Стоп" : "Sweep";
        LiveButton.Content=busy && active==LiveButton ? "■  Стоп" : "▶  Непрерывно";
        CalOpenButton.IsEnabled=!busy; CalShortButton.IsEnabled=!busy; CalLoadButton.IsEnabled=!busy; CalThruButton.IsEnabled=!busy;
        ConnectButton.IsEnabled=!busy; PortBox.IsEnabled=!busy; RefreshButton.IsEnabled=!busy; ProtocolBox.IsEnabled=!busy;
    }

    bool Ready(out LiteVnaProtocol.SweepConfig config,bool autoMatch=true)
    {
        config=null!;
        if(_running!=null) return false;
        if(_session==null){ MessageBox.Show(Owner!,"Подключите VNA (порт → «Подключить»)."); return false; }
        try{ config=ReadConfig(); }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Параметры развёртки"); return false; }
        // A saved calibration on exactly this grid is picked automatically.
        if(autoMatch && ApplyCalCheck.IsChecked==true && !(_cal.IsComplete && GridEquals(_cal,config)) && !_calDirty)
        {
            var match=VnaCalibrationLibrary.FindExact(config.StartHz,config.ActualStopHz,config.Points,_info);
            if(match!=null && !string.Equals(match.Path,_calPath,StringComparison.OrdinalIgnoreCase))
            {
                RefreshProfiles(match.Path);
                LoadProfile(match.Path,setGrid:false,quiet:true);
                Status($"Подобрана калибровка «{match.Name}» для этой сетки частот");
            }
        }
        return true;
    }
    static bool GridEquals(VnaCalibration c,LiteVnaProtocol.SweepConfig g)=>c.Points==g.Points && c.StartHz==g.StartHz && c.StopHz==g.ActualStopHz;

    Task<VnaSweep> MeasureAsync(LiteVnaProtocol.SweepConfig c,CancellationToken ct)
    {
        var s=_session ?? throw new InvalidOperationException("VNA не подключён.");
        IProgress<(int Done,int Total)> progress=new Progress<(int Done,int Total)>(p=>SweepText.Text=$"развёртка {p.Done}/{p.Total}");
        string source=_info ?? "VNA";
        return Task.Run(()=>
        {
            return s.Measure(c,ct,(d,t)=>progress.Report((d,t)));
        },ct);
    }

    async Task RunSingle(LiteVnaProtocol.SweepConfig c,string what,Action<VnaSweep>? store)
    {
        _cts=new CancellationTokenSource();
        SetBusy(true,SweepButton);
        try
        {
            var task=MeasureAsync(c,_cts.Token);
            _running=task;
            var sweep=await task;
            store?.Invoke(sweep);
            _rawConfig=c;
            ShowSweep(sweep,fromInstrument:true);
            SweepText.Text=$"{what}: {c.Points} точек";
            Status($"VNA · {what}: {c.StartHz/1e6:0.######}–{c.ActualStopHz/1e6:0.######} МГц, {c.Points} точек, усреднение {c.Average}");
        }
        catch(OperationCanceledException){ SweepText.Text="остановлено"; }
        catch(Exception ex)
        {
            SweepText.Text="ошибка";
            Status("VNA: "+ex.Message);
            MessageBox.Show(Owner!,ex.Message,"VNA");
        }
        finally
        {
            _running=null; _cts.Dispose(); _cts=null;
            SetBusy(false);
        }
    }

    async void Sweep_Click(object sender,RoutedEventArgs e)
    {
        if(_running!=null){ _cts?.Cancel(); return; }      // the button is "■ Стоп" while sweeping
        if(Ready(out var c)) await RunSingle(c,"развёртка",null);
    }

    async void Live_Click(object sender,RoutedEventArgs e)
    {
        if(_running!=null){ _cts?.Cancel(); return; }      // the button is "■ Стоп" in continuous mode
        if(!Ready(out var c)) return;
        var s=_session!;
        _cts=new CancellationTokenSource();
        var ct=_cts.Token;
        string source=_info ?? "VNA";
        long count=0;
        SetBusy(true,LiveButton);
        IProgress<VnaSweep> show=new Progress<VnaSweep>(sweep=>
        {
            count++;
            _rawConfig=c;
            ShowSweep(sweep,fromInstrument:true);
            SweepText.Text=$"непрерывно · развёртка {count}";
            Interlocked.Exchange(ref _uiPending,0);
        });
        IProgress<string> note=new Progress<string>(m=>SweepText.Text=m);
        var task=Task.Run(()=>
        {
            int failures=0;
            bool fresh=true;            // the first sweep of the series starts after the click
            while(!ct.IsCancellationRequested)
            {
                try
                {
                    var sweep=s.Measure(c,ct,null,fresh);
                    fresh=false;
                    failures=0;
                    // Skip a sweep if the previous one is still being drawn: no growing UI queue.
                    if(Interlocked.Exchange(ref _uiPending,1)==0) show.Report(sweep);
                }
                catch(OperationCanceledException){ break; }
                catch(Exception ex)
                {
                    failures++;
                    note.Report($"повтор {failures}: {ex.Message}");
                    if(failures>=12) throw;
                    Thread.Sleep(Math.Min(400,80*failures));
                    // Next sweep configures the active protocol as required.
                }
            }
        },ct);
        _running=task;
        try{ await task; }
        catch(OperationCanceledException){ }
        catch(Exception ex){ Status("VNA: "+ex.Message); MessageBox.Show(Owner!,ex.Message,"VNA — непрерывный режим"); }
        finally
        {
            _running=null; _cts.Dispose(); _cts=null;
            Interlocked.Exchange(ref _uiPending,0);
            SetBusy(false);
            SweepText.Text=$"остановлено · {count} развёрток";
        }
    }


    // ------------------------------------------------------------ display
    void ShowSweep(VnaSweep sweep,bool fromInstrument)
    {
        _raw=fromInstrument ? sweep : null;
        _calMode=VnaCalibration.ApplyMode.None;
        // A calibration taken with another instrument family (LiteVNA / NanoVNA V2 / NanoVNA shell) is not applied.
        _calDeviceMismatch=fromInstrument && _cal.IsComplete && !VnaCalibrationLibrary.DevicesCompatible(_cal.Device,_info);
        _shown=fromInstrument && ApplyCalCheck.IsChecked==true && !_calDeviceMismatch
            ? _cal.Apply(sweep,InterpolateCheck.IsChecked==true,out _calMode) : sweep;
        Smith.Sweep=_shown; Chart.Sweep=_shown;
        for(int m=0;m<VnaMarkers.Count;m++) if(_markers.Index[m]>=_shown.Points.Count) _markers.Index[m]=-1;
        if(_markers.Index.All(i=>i<0) && _shown.Points.Count>0) _markers.Index[0]=VnaMath.IndexOfMinSwr(_shown.Points);
        UpdateCalText();
        _markers.Notify();
    }

    // ------------------------------------------------------------ calibration (one full mode)
    void UpdateCalText()
    {
        UpdateCalTextCore();
        CalDetailText.Text=CalText.Text;
        CalDetailText.Foreground=CalText.Foreground;
    }
    void UpdateCalTextCore()
    {
        CalOpenButton.Content=_cal.Open!=null?"OPEN ✓":"OPEN";
        CalShortButton.Content=_cal.Short!=null?"SHORT ✓":"SHORT";
        CalLoadButton.Content=_cal.Load!=null?"LOAD ✓":"LOAD";
        CalThruButton.Content=_cal.Thru!=null?"THRU ✓":"THRU";
        var warn=new SolidColorBrush(Color.FromRgb(163,90,18));
        var ok=new SolidColorBrush(Color.FromRgb(30,120,60));
        CalText.Foreground=warn;
        int n=_cal.StandardsTaken;
        if(n==0){ CalText.Text="Нет калибровки — показываются RAW-данные. Снимите OPEN, SHORT, LOAD (нагрузки на оба порта) и THRU или выберите профиль."; return; }
        if(_cal.StandardsOnDifferentGrids){ CalText.Text="Эталоны сняты на разных сетках частот — нажмите «Сброс» и повторите калибровку."; return; }
        if(!_cal.IsComplete){ CalText.Text=$"Калибровка: снято {n} из 4 эталонов (OPEN, SHORT, LOAD на обоих портах, THRU) — до полной калибровки показываются RAW-данные."; return; }
        string name=_cal.Name.Length>0 ? $"«{_cal.Name}»" : "новая";
        string grid=$"{_cal.StartHz/1e6:0.######}–{_cal.StopHz/1e6:0.######} МГц, {_cal.Points} т.";
        double age=_cal.AgeDays;
        string ageText=age<1 ? "снята сегодня" : $"снята {Math.Floor(age):0} дн. назад";
        string ext=_cal.PortExtensionPs!=0 ? $" · удлинение порта {_cal.PortExtensionPs.ToString("0.###",Inv)} пс" : "";
        string unsaved=_calPath==null ? " · не сохранена — «Сохранить как…»" : _calDirty ? " · изменена, не сохранена" : "";
        if(ApplyCalCheck.IsChecked!=true){ CalText.Text=$"Калибровка {name} ({grid}) выключена — RAW-данные{unsaved}"; return; }
        if(_calDeviceMismatch)
        {
            CalText.Text=$"Калибровка {name} снята другим прибором ({VnaCalibrationLibrary.DeviceKind(_cal.Device)}) — не применяется, RAW-данные. Снимите калибровку этим прибором или выберите его профиль.";
            return;
        }
        if(_raw!=null && _calMode==VnaCalibration.ApplyMode.None)
        {
            CalText.Text=$"Калибровка {name} ({grid}) не подходит к текущей сетке — RAW-данные. Выберите профиль для этой сетки"+
                         (_cal.Covers(_raw) ? " или включите «Интерполировать»." : " (диапазон развёртки выходит за калиброванный).");
            return;
        }
        string interp=_calMode==VnaCalibration.ApplyMode.Interpolated ? " · интерполированная" : "";
        CalText.Text=$"Полная калибровка {name} · {grid}{interp}{ext} · {ageText}{(age>7?" — рекомендуется переснять":"")}{unsaved}";
        CalText.Foreground=age>7 ? warn : ok;
    }

    async void MeasureStandard(string name,Action<VnaSweep> store)
    {
        if(!Ready(out var c,autoMatch:false)) return;
        // Standards must share one grid: a changed grid starts a new calibration.
        var r=_cal.Reference;
        if(r!=null && !(r.Points.Count==c.Points && Math.Abs(r.Points[0].FrequencyHz-c.StartHz)<0.5 && Math.Abs(r.Points[^1].FrequencyHz-c.ActualStopHz)<0.5))
        {
            _cal=new VnaCalibration();
            Status("Сетка частот изменена — снятые ранее эталоны сброшены, начата новая калибровка");
        }
        if(_cal.StandardsTaken==0 || _calPath!=null)
        {
            if(_calPath!=null) _cal=new VnaCalibration{ PortExtensionPs=_cal.PortExtensionPs };
            _calPath=null;
            SelectProfileQuietly(null);
        }
        await RunSingle(c,"эталон "+name,s=>
        {
            store(s);
            _cal.StartHz=c.StartHz; _cal.StopHz=c.ActualStopHz; _cal.Points=c.Points; _cal.Average=c.Average;
            _cal.Device=_info ?? ""; _cal.Created=DateTime.Now;
            _calDirty=true;
        });
        if(_cal.IsComplete) Status("Полная калибровка снята — сохраните её в библиотеку: «Сохранить как…»");
    }
    void CalOpen_Click(object sender,RoutedEventArgs e)=>MeasureStandard("OPEN",s=>_cal.Open=s);
    void CalShort_Click(object sender,RoutedEventArgs e)=>MeasureStandard("SHORT",s=>_cal.Short=s);
    void CalLoad_Click(object sender,RoutedEventArgs e)=>MeasureStandard("LOAD (оба порта)",s=>_cal.Load=s);
    void CalThru_Click(object sender,RoutedEventArgs e)=>MeasureStandard("THRU",s=>_cal.Thru=s);

    void Reshow(){ if(_raw!=null) ShowSweep(_raw,fromInstrument:true); else UpdateCalText(); }
    void ApplyCal_Changed(object sender,RoutedEventArgs e){ if(IsLoaded) Reshow(); }
    void CalReset_Click(object sender,RoutedEventArgs e)
    {
        _cal=new VnaCalibration(); _calPath=null; _calDirty=false;
        SelectProfileQuietly(null);
        PortExtBox.Text="0";
        Reshow();
        Status("Калибровка сброшена");
    }

    void PortExt_KeyDown(object sender,System.Windows.Input.KeyEventArgs e){ if(e.Key==System.Windows.Input.Key.Enter) PortExt_Changed(sender,e); }
    void PortExt_Changed(object sender,RoutedEventArgs e)
    {
        if(!double.TryParse(PortExtBox.Text.Trim().Replace(',','.'),NumberStyles.Float,Inv,out double ps) || !double.IsFinite(ps) || Math.Abs(ps)>1e7)
        {
            PortExtBox.Text=_cal.PortExtensionPs.ToString("0.###",Inv);
            return;
        }
        if(Math.Abs(ps-_cal.PortExtensionPs)<1e-9) return;
        _cal.PortExtensionPs=ps;
        if(_cal.IsComplete) _calDirty=true;
        Reshow();
    }

    // ---- profiles (library)
    void RefreshProfiles(string? select)
    {
        _profileLoading=true;
        try
        {
            var list=VnaCalibrationLibrary.List();
            ProfileBox.ItemsSource=list;
            ProfileBox.SelectedItem=select==null ? null : list.FirstOrDefault(x=>string.Equals(x.Path,select,StringComparison.OrdinalIgnoreCase));
        }
        catch(Exception ex){ Status("Библиотека калибровок: "+ex.Message); }
        finally{ _profileLoading=false; }
    }
    void SelectProfileQuietly(string? path)
    {
        _profileLoading=true;
        try
        {
            ProfileBox.SelectedItem=path==null ? null :
                (ProfileBox.ItemsSource as IEnumerable<VnaCalibrationLibrary.Entry>)?.FirstOrDefault(x=>string.Equals(x.Path,path,StringComparison.OrdinalIgnoreCase));
        }
        finally{ _profileLoading=false; }
    }
    void Profile_Changed(object sender,SelectionChangedEventArgs e)
    {
        if(_profileLoading || !IsLoaded) return;
        if(ProfileBox.SelectedItem is not VnaCalibrationLibrary.Entry entry) return;
        if(_calDirty && _calPath==null && _cal.IsComplete &&
           MessageBox.Show(Owner!,"Текущая калибровка не сохранена. Загрузить выбранную вместо неё?","Калибровка",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)
        { SelectProfileQuietly(null); return; }
        LoadProfile(entry.Path,setGrid:true,quiet:false);
    }
    void LoadProfile(string path,bool setGrid,bool quiet)
    {
        try
        {
            var c=VnaCalibration.LoadFile(path);
            _cal=c; _calPath=path; _calDirty=false;
            VnaCalibrationLibrary.RememberLast(path);
            if(setGrid) SetGrid(c);
            PortExtBox.Text=c.PortExtensionPs.ToString("0.###",Inv);
            Reshow();
            if(!quiet) Status($"Калибровка «{c.Name}» загружена{(setGrid?" — диапазон и число точек выставлены по ней":"")}");
        }
        catch(Exception ex){ if(!quiet) MessageBox.Show(Owner!,ex.Message,"Загрузка калибровки"); else Status("Калибровка: "+ex.Message); }
    }
    void SetGrid(VnaCalibration c)
    {
        if(c.Points<2) return;
        StartBox.Text=(c.StartHz/1e6).ToString("0.######",Inv);
        StopBox.Text=(c.StopHz/1e6).ToString("0.######",Inv);
        foreach(ComboBoxItem item in PointsBox.Items)
            if(item.Content?.ToString()==c.Points.ToString(Inv)){ PointsBox.SelectedItem=item; break; }
        foreach(ComboBoxItem item in AverageBox.Items)
            if(item.Content?.ToString()==c.Average.ToString(Inv)){ AverageBox.SelectedItem=item; break; }
    }
    string DefaultName()=>$"{_cal.StartHz/1e6:0.###}–{_cal.StopHz/1e6:0.###} МГц, {_cal.Points} т.";
    bool ConfirmOverwrite(string target)=>!File.Exists(target) || string.Equals(target,_calPath,StringComparison.OrdinalIgnoreCase) ||
        MessageBox.Show(Owner!,$"Калибровка с именем «{Path.GetFileNameWithoutExtension(target)}» уже есть. Заменить?","Калибровка",MessageBoxButton.YesNo,MessageBoxImage.Question)==MessageBoxResult.Yes;

    void ProfileSave_Click(object sender,RoutedEventArgs e)
    {
        if(!_cal.IsComplete){ MessageBox.Show(Owner!,"Калибровка неполная: снимите OPEN, SHORT, LOAD (нагрузки на оба порта) и THRU."); return; }
        var dlg=new CalibrationNameDialog("Сохранить калибровку",_cal.Name.Length>0?_cal.Name:DefaultName(),_cal.Comment){ Owner=Owner };
        if(dlg.ShowDialog()!=true) return;
        string target=VnaCalibrationLibrary.PathFor(dlg.ProfileName);
        if(!ConfirmOverwrite(target)) return;
        try
        {
            _cal.Name=dlg.ProfileName; _cal.Comment=dlg.Comment;
            _calPath=VnaCalibrationLibrary.Save(_cal); _calDirty=false;
            RefreshProfiles(_calPath); UpdateCalText();
            Status($"Калибровка «{_cal.Name}» сохранена в библиотеку");
        }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Сохранение калибровки"); }
    }
    void ProfileRename_Click(object sender,RoutedEventArgs e)
    {
        if(_calPath==null){ MessageBox.Show(Owner!,"Выберите сохранённую калибровку в списке «Профиль»."); return; }
        var dlg=new CalibrationNameDialog("Переименовать калибровку",_cal.Name,_cal.Comment){ Owner=Owner };
        if(dlg.ShowDialog()!=true) return;
        string target=VnaCalibrationLibrary.PathFor(dlg.ProfileName);
        if(!ConfirmOverwrite(target)) return;
        try
        {
            string old=_calPath;
            _cal.Name=dlg.ProfileName; _cal.Comment=dlg.Comment;
            _calPath=VnaCalibrationLibrary.Save(_cal); _calDirty=false;
            if(!string.Equals(old,_calPath,StringComparison.OrdinalIgnoreCase) && File.Exists(old)) File.Delete(old);
            RefreshProfiles(_calPath); UpdateCalText();
            Status($"Калибровка переименована: «{_cal.Name}»");
        }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Переименование калибровки"); }
    }
    void ProfileDelete_Click(object sender,RoutedEventArgs e)
    {
        if(ProfileBox.SelectedItem is not VnaCalibrationLibrary.Entry entry){ MessageBox.Show(Owner!,"Выберите калибровку в списке «Профиль»."); return; }
        if(MessageBox.Show(Owner!,$"Удалить калибровку «{entry.Name}» из библиотеки?","Калибровка",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes) return;
        try
        {
            File.Delete(entry.Path);
            if(string.Equals(entry.Path,_calPath,StringComparison.OrdinalIgnoreCase)){ _calPath=null; _calDirty=_cal.IsComplete; VnaCalibrationLibrary.RememberLast(null); }
            RefreshProfiles(null); UpdateCalText();
            Status($"Калибровка «{entry.Name}» удалена (текущие поправки остаются до сброса)");
        }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Удаление калибровки"); }
    }
    void ProfileImport_Click(object sender,RoutedEventArgs e)
    {
        var d=new OpenFileDialog{ Filter="Калибровка VNA (*.vnacal)|*.vnacal" };
        if(d.ShowDialog(Owner)!=true) return;
        try
        {
            var c=VnaCalibration.LoadFile(d.FileName);
            if(!c.IsComplete && MessageBox.Show(Owner!,"В файле неполная калибровка. Всё равно добавить?","Импорт калибровки",MessageBoxButton.YesNo)!=MessageBoxResult.Yes) return;
            string target=VnaCalibrationLibrary.PathFor(c.Name);
            if(!ConfirmOverwrite(target)) return;
            string path=VnaCalibrationLibrary.Save(c);
            RefreshProfiles(path);
            LoadProfile(path,setGrid:true,quiet:false);
        }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Импорт калибровки"); }
    }
    void ProfileExport_Click(object sender,RoutedEventArgs e)
    {
        if(!_cal.IsComplete){ MessageBox.Show(Owner!,"Нет полной калибровки для экспорта."); return; }
        var d=new SaveFileDialog{ Filter="Калибровка VNA (*.vnacal)|*.vnacal", FileName=(_cal.Name.Length>0?_cal.Name:DefaultName()).Replace('/','_')+".vnacal" };
        if(d.ShowDialog(Owner)!=true) return;
        try{ _cal.Save(d.FileName); Status("Калибровка экспортирована: "+d.FileName); }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Экспорт калибровки"); }
    }

    // ------------------------------------------------------------ files
    void Menu_Click(object sender,RoutedEventArgs e)
    {
        if(sender is Button b && b.ContextMenu!=null)
        {
            b.ContextMenu.PlacementTarget=b;
            b.ContextMenu.Placement=System.Windows.Controls.Primitives.PlacementMode.Bottom;
            b.ContextMenu.IsOpen=true;
        }
    }
    IEnumerable<string> Header()
    {
        yield return "Antenna Calculator PRO - VNA";
        yield return "Source: "+(_shown?.Source ?? "");
        yield return "Saved: "+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss",Inv);
        if(_raw!=null && _rawConfig!=null)
            yield return $"Sweep: {_rawConfig.StartHz} Hz .. {_rawConfig.ActualStopHz} Hz, {_rawConfig.Points} points, average {_rawConfig.Average}";
    }
    string? AskSave(string filter,string extension)
    {
        if(_shown==null){ MessageBox.Show(Owner!,"Нет данных: выполните Sweep или откройте файл."); return null; }
        var d=new SaveFileDialog{ Filter=filter, FileName="litevna_"+DateTime.Now.ToString("yyyyMMdd_HHmmss",Inv)+extension };
        return d.ShowDialog(Owner)==true ? d.FileName : null;
    }
    void ExportS1p_Click(object sender,RoutedEventArgs e)
    {
        var path=AskSave("Touchstone 1-port (*.s1p)|*.s1p",".s1p"); if(path==null) return;
        try{ File.WriteAllText(path,TouchstoneFile.WriteS1p(_shown!,Header()),Encoding.ASCII); Status($"Сохранено .s1p: {_shown!.Points.Count} точек · {path}"); }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Экспорт .s1p"); }
    }
    void ExportS2p_Click(object sender,RoutedEventArgs e)
    {
        var path=AskSave("Touchstone 2-port (*.s2p)|*.s2p",".s2p"); if(path==null) return;
        try{ File.WriteAllText(path,TouchstoneFile.WriteS2p(_shown!,Header()),Encoding.ASCII); Status($"Сохранено .s2p: {_shown!.Points.Count} точек (S12, S22 = 0) · {path}"); }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Экспорт .s2p"); }
    }
    void ExportCsv_Click(object sender,RoutedEventArgs e)
    {
        var path=AskSave("CSV (*.csv)|*.csv",".csv"); if(path==null) return;
        var s=_shown!; double z0=s.ReferenceOhms;
        string F(double v)=>double.IsFinite(v)?v.ToString("G10",Inv):"";
        var sb=new StringBuilder("freq_hz,s11_re,s11_im,r_ohm,x_ohm,abs_z_ohm,swr,return_loss_db,s21_re,s21_im,s21_db,s21_phase_deg,group_delay_ns\r\n");
        for(int i=0;i<s.Points.Count;i++)
        {
            var p=s.Points[i]; var z=VnaMath.Impedance(p.S11,z0);
            sb.Append(F(p.FrequencyHz)).Append(',').Append(F(p.S11.Real)).Append(',').Append(F(p.S11.Imaginary)).Append(',')
              .Append(F(z.Real)).Append(',').Append(F(z.Imaginary)).Append(',').Append(F(z.Magnitude)).Append(',')
              .Append(F(VnaMath.Swr(p.S11))).Append(',').Append(F(VnaMath.ReturnLossDb(p.S11))).Append(',')
              .Append(p.HasS21?F(p.S21.Real):"").Append(',').Append(p.HasS21?F(p.S21.Imaginary):"").Append(',')
              .Append(p.HasS21?F(VnaMath.Db(p.S21)):"").Append(',').Append(p.HasS21?F(VnaMath.PhaseDeg(p.S21)):"").Append(',')
              .Append(F(VnaMath.GroupDelay(s.Points,i)*1e9)).Append("\r\n");
        }
        try{ File.WriteAllText(path,sb.ToString(),new UTF8Encoding(true)); Status($"Сохранено CSV: {s.Points.Count} точек · {path}"); }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Экспорт CSV"); }
    }
    void Import_Click(object sender,RoutedEventArgs e)
    {
        var d=new OpenFileDialog{ Filter="Touchstone (*.s1p;*.s2p)|*.s1p;*.s2p|Все файлы (*.*)|*.*" };
        if(d.ShowDialog(Owner)!=true) return;
        try
        {
            var s=TouchstoneFile.Read(d.FileName);
            ShowSweep(s,fromInstrument:false);
            Status($"Открыт {Path.GetFileName(d.FileName)}: {s.Points.Count} точек, Z0 = {s.ReferenceOhms:0.##} Ω{(s.HasS21?", S11 + S21":", S11")}");
        }
        catch(Exception ex){ MessageBox.Show(Owner!,ex.Message,"Открытие Touchstone"); }
    }

    // ------------------------------------------------------------ markers
    void MarkerRadio_Checked(object sender,RoutedEventArgs e)
    {
        _markers.Active=sender==M2Radio?1:sender==M3Radio?2:sender==M4Radio?3:0;
        _markers.Notify();
    }
    bool HaveData(){ if(_shown is {Points.Count: >0}) return true; MessageBox.Show(Owner!,"Нет данных."); return false; }
    void MarkMinSwr_Click(object sender,RoutedEventArgs e){ if(HaveData()) _markers.SetActive(VnaMath.IndexOfMinSwr(_shown!.Points)); }
    void MarkResonance_Click(object sender,RoutedEventArgs e)
    {
        if(!HaveData()) return;
        var list=VnaMath.Resonances(_shown!.Points,_shown.ReferenceOhms);
        if(list.Count==0){ Status("Резонансов (X = 0) в диапазоне нет"); return; }
        int current=_markers.Index[_markers.Active];
        int next=list.FirstOrDefault(i=>i>current,-1);
        _markers.SetActive(next>=0?next:list[0]);
    }
    void MarkMaxS21_Click(object sender,RoutedEventArgs e)
    {
        if(!HaveData()) return;
        if(!_shown!.HasS21){ Status("В данных нет S21"); return; }
        _markers.SetActive(VnaMath.IndexOfMaxS21(_shown.Points));
    }
    void MarkMinS21_Click(object sender,RoutedEventArgs e)
    {
        if(!HaveData()) return;
        if(!_shown!.HasS21){ Status("В данных нет S21"); return; }
        _markers.SetActive(VnaMath.IndexOfMinS21(_shown.Points));
    }
    void MarkClear_Click(object sender,RoutedEventArgs e)=>_markers.SetActive(-1);

    static string F(double v,string format)=>double.IsFinite(v)?v.ToString(format,Inv):"—";
    static string Lc(double henry,double farad)
    {
        if(double.IsFinite(henry)) return henry>=1e-6 ? F(henry*1e6,"0.###")+" мкГн" : F(henry*1e9,"0.##")+" нГн";
        if(double.IsFinite(farad)) return farad>=1e-9 ? F(farad*1e9,"0.###")+" нФ" : F(farad*1e12,"0.##")+" пФ";
        return "—";
    }

    void UpdateMarkerInfo()
    {
        if(MarkerGrid==null) return;
        var rows=new List<MarkerRow>();
        var s=_shown;
        if(s!=null)
        {
            double z0=s.ReferenceOhms;
            for(int m=0;m<VnaMarkers.Count;m++)
            {
                int i=_markers.Index[m];
                if(i<0 || i>=s.Points.Count) continue;
                var p=s.Points[i]; var z=VnaMath.Impedance(p.S11,z0); var lc=VnaMath.SeriesLC(z,p.FrequencyHz);
                rows.Add(new MarkerRow((m==_markers.Active?"▸":"")+"M"+(m+1),F(p.FrequencyHz/1e6,"0.000000"),F(z.Real,"0.00"),F(z.Imaginary,"0.00"),
                    F(z.Magnitude,"0.00"),F(VnaMath.Swr(p.S11),"0.000"),F(VnaMath.ReturnLossDb(p.S11),"0.00"),
                    F(p.S11.Magnitude,"0.0000")+" ∠"+F(VnaMath.PhaseDeg(p.S11),"0.0"),Lc(lc.Henry,lc.Farad),F(VnaMath.Q(z),"0.0"),
                    p.HasS21?F(VnaMath.Db(p.S21),"0.00"):"—",p.HasS21?F(VnaMath.PhaseDeg(p.S21),"0.0"):"—",
                    p.HasS21?F(VnaMath.GroupDelay(s.Points,i)*1e9,"0.00"):"—"));
            }
        }
        MarkerGrid.ItemsSource=rows;
        BandText.Text=BandSummary();
    }

    string BandSummary()
    {
        var s=_shown;
        if(s is not {Points.Count: >1}) return "";
        int iMin=VnaMath.IndexOfMinSwr(s.Points);
        if(iMin<0) return "";
        var text=new StringBuilder();
        text.Append($"мин. КСВ {F(VnaMath.Swr(s.Points[iMin].S11),"0.00")} на {F(s.Points[iMin].FrequencyHz/1e6,"0.000")} МГц");
        var band=VnaMath.SwrBand(s.Points,iMin,2.0);
        if(band is { } b) text.Append($" · КСВ ≤ 2: {F(b.LowHz/1e6,"0.000")}–{F(b.HighHz/1e6,"0.000")} МГц ({F((b.HighHz-b.LowHz)/1e3,"0")} кГц)");
        if(OverlayCheck.IsChecked==true && _model is {Count: >1} model)
        {
            int jm=0; double best=double.PositiveInfinity;
            for(int j=0;j<model.Count;j++){ double g=model[j].Gamma.Magnitude; if(g<best){ best=g; jm=j; } }
            double df=s.Points[iMin].FrequencyHz-model[jm].Hz;
            text.Append($" · модель: мин. КСВ на {F(model[jm].Hz/1e6,"0.000")} МГц, Δ = {F(df/1e3,"+0;-0;0")} кГц ({F(df/model[jm].Hz*100,"+0.00;-0.00;0")} %)");
        }
        return text.ToString();
    }
}
