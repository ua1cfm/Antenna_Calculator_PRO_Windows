﻿using AntennaCalculator.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace AntennaCalculator.Wpf;

/// <summary>
/// 3D view of the E/H/S field: volume ray casting over the sampled n³ grid (CUDA, CPU fallback).
/// Rays are marched FRONT TO BACK starting at the viewer side; opacity is defined per unit path length,
/// so the preview and the final image look the same. Styles: glass iso-shells (faces towards the viewer
/// clear, silhouettes dense), emission–absorption volume, maximum intensity projection. Colour scale:
/// dB (30 dB range) or linear, normalised by a stable P96 of the amplitude (phase independent).
/// Depth cue: far samples are darker. Headlight shading from the field gradient.
/// </summary>
public sealed class FieldVolumeView : FrameworkElement
{
    private int GridN = 128;
    private int _quality = 1;
    private bool _gridGpu;
    private const int PreviewImageSize = 256;
    private const int FinalImageSize = 1024;
    private const int CpuFinalImageSize = 768;
    private const int PreviewSteps = 80;
    private const int FinalSteps = 512;
    private const int CpuFinalSteps = 320;
    private double _dbRange = 30.0;
    internal const double DbRange = 30.0; // Native CUDA reference window (scaled through DbFactor).

    private MaaModel? _model;
    private MininecPulseSolver.Result? _result;
    private ScalarGrid? _grid;
    private float[]? _normalized;          // field / P96, the array that is rendered
    private int _volumeRevision;           // changes whenever _normalized changes (GPU upload cache)
    private double _gradRef = 1;           // P90 of the gradient magnitude of the normalised amplitude
    private WriteableBitmap? _bitmap;
    private int _revision;
    private int _renderRevision;
    private int _fieldRevision;
    private bool _showAntenna = true;
    private bool _showVolumeBounds = true;
    private bool _lastPreview;
    private bool _lastGpu;
    private int _component, _displayMode;
    private int _style;                    // 0 glass shells, 1 volume, 2 MIP
    private bool _db = true;
    private double _density = 1;
    private double _phase, _extentFactor = 1, _azimuth = Math.PI / 4, _elevation = .58, _zoom = 1;
    private Point? _drag;
    private double _zOffset;               // MAA Z → solver z (H above ground)

    // Stable normalisation: computed once per grid / component / mode, not per animation frame.
    private readonly object _refSync = new();
    private (ScalarGrid Grid, int Component, int Mode)? _refKey;
    private double _refValue = 1, _refGrad = 1;

    private readonly record struct P(double X, double Y, double Z);
    private sealed record ScalarGrid(P Centre, double Span,
        Complex[] Ex, Complex[] Ey, Complex[] Ez,
        Complex[] Hx, Complex[] Hy, Complex[] Hz,
        double[] Power,
        // 0.6.52: same far-field calibration as the 2D map (3D-pattern operator, ground included)
        double Wavelength = 0, double FarGMax = 0, double DmaxDbi = double.NaN, P AntennaCentre = default,
        int GroundType = 0, double FarZone = 0, P CompCentre = default, bool Radiated = false);

    // 1/r compensation (shared switch with the 2D map): field·r, S·r²; with it the scale is dBi from Dmax.
    private bool _compensate = true;
    private bool _absolute;            // current scale is dBi from Dmax
    private double _topDbi;
    // Field vectors (arrows) on a coarse 3D lattice, shared switch with the 2D map.
    private bool _showVectors;
    private double _vectorSize = 1;
    public void SetVectors(bool on, double size) { _showVectors = on; _vectorSize = Math.Clamp(size, 0.4, 3); InvalidateVisual(); }
    public void SetDistanceCompensation(bool on) { _compensate = on; lock (_refSync) _refKey = null; RefreshField(); }
    // Field model shared with the 2D map: radiated field from the 3D pattern (default) or full near field.
    private bool _radiated = true;
    public void SetFieldModel(bool radiated) { if (_radiated == radiated) return; _radiated = radiated; Rebuild(); }

    /// <summary>Rendering style, shared by the CPU and CUDA renderers.</summary>
    internal readonly record struct VolumeStyle(int Mode, bool Db, double DbFactor, double Density, double GradRef);

    public void SetVolumeStyle(int style) { _style = Math.Clamp(style, 0, 3); QueueRender(false); }
    public void SetLogScale(bool db) { _db = db; QueueRender(false); }
    public void SetDbRange(double range) { _dbRange = Math.Clamp(range, 10, 80); QueueRender(false); }
    public void SetDensity(double density) { _density = Math.Clamp(density, .2, 4); QueueRender(false); }
    public void SetModel(MaaModel? model) { _model = model; Rebuild(); }
    public void SetResult(MininecPulseSolver.Result? result) { _result = result; Rebuild(); }
    public void SetExtentFactor(double factor) { _extentFactor = Math.Clamp(factor, .25, 10); Rebuild(); }
    public void SetComponent(int component) { _component = Math.Clamp(component, 0, 1); RefreshField(); }
    public void SetDisplayMode(int mode) { _displayMode = Math.Clamp(mode, 0, 2); RefreshField(); }
    public void SetPhase(double degrees) { _phase = degrees; if (_displayMode == 0) RefreshField(previewOnly: true); }
    public void SetQuality(int quality) {
        quality = Math.Clamp(quality, 0, 2);
        if (_quality == quality) return;
        _quality = quality;
        GridN = quality == 0 ? 64 : quality == 1 ? 128 : 192;
        Rebuild();
    }
    public void SetVolumeBounds(bool shown) { _showVolumeBounds = shown; InvalidateVisual(); }
    public void SetAntennaOverlay(bool shown) { _showAntenna = shown; InvalidateVisual(); }
    public void Fit() { _zoom = 1; QueueRender(false); }
    public void ResetViewAndFit() { _azimuth = Math.PI / 4; _elevation = .58; _drag = null; Fit(); }

    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        base.OnMouseWheel(e);
        _zoom = Math.Clamp(_zoom * (e.Delta > 0 ? 1.12 : 1 / 1.12), .3, 7);
        QueueRender(false);
    }
    protected override void OnMouseDown(MouseButtonEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.LeftButton == MouseButtonState.Pressed)
        {
            _drag = e.GetPosition(this);
            CaptureMouse();
        }
    }
    protected override void OnMouseUp(MouseButtonEventArgs e)
    {
        base.OnMouseUp(e);
        if (_drag != null)
        {
            _drag = null;
            ReleaseMouseCapture();
            QueueRender(false);
        }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_drag is not Point p || e.LeftButton != MouseButtonState.Pressed) return;
        Point q = e.GetPosition(this);
        System.Windows.Vector d = q - p;
        _drag = q;
        _azimuth += d.X * .012;
        _elevation = Math.Clamp(_elevation + d.Y * .01, -1.35, 1.35);
        QueueRender(true);
    }

    private async void Rebuild()
    {
        int revision = ++_revision;
        ++_renderRevision;
        _grid = null; _normalized = null; _bitmap = null;
        lock (_refSync) _refKey = null;
        InvalidateVisual();
        var result = _result; var model = _model;
        if (result?.FieldSamples is not { Count: > 0 } samples || model == null || result.FrequencyMHz <= 0) return;
        double f = result.FrequencyMHz, extent = _extentFactor; int ground = model.GroundType;
        // Solver coordinates: z = Z + H above ground (also used by the antenna overlay).
        double zOffset = FieldGeometry.ZOffset(model, samples).Offset;
        _zOffset = zOffset;
        var ends = model.Wires.SelectMany(w => new[] { new P(w.X1, w.Y1, w.Z1 + zOffset), new P(w.X2, w.Y2, w.Z2 + zOffset) }).ToArray();
        if (ends.Length == 0) return;
        ScalarGrid grid;
        bool radiated = _radiated;
        try { grid = await Task.Run(() => SampleGrid(samples, f, ground, ends, extent, GridN, radiated)); }
        catch { return; }
        if (revision != _revision || !ReferenceEquals(result, _result)) return;
        _grid = grid;
        RefreshField();
    }

    private void RefreshField(bool previewOnly = false)
    {
        var grid = _grid;
        if (grid == null) return;
        int component = _component, mode = _displayMode, revision = ++_fieldRevision;
        double phase = _phase;
        Task.Run(() => ComputeNormalized(grid, component, mode, phase))
            .ContinueWith(t => Dispatcher.BeginInvoke(new Action(() =>
            {
                if (t.IsFaulted || t.IsCanceled || revision != _fieldRevision || !ReferenceEquals(grid, _grid)) return;
                (_normalized, _gradRef) = t.Result;
                _volumeRevision++;
                QueueRender(previewOnly);
            })), TaskScheduler.Default);
    }

    /// <summary>Field values divided by the P96 of the phase-independent amplitude (instantaneous frames never exceed it much).</summary>
    private (float[] Values, double GradRef) ComputeNormalized(ScalarGrid grid, int component, int mode, double phaseDeg)
    {
        double reference, gradRef;
        bool compensate = _compensate;
        int n = (int)Math.Round(Math.Cbrt(grid.Ex.Length));
        // r (field) or r² (power density) from the antenna centre, limited at 0.05 λ.
        double[]? comp = null;
        if (compensate && grid.Wavelength > 0)
        {
            var c = new double[grid.Ex.Length];
            Parallel.For(0, n, iz =>
            {
                double z = grid.Centre.Z + ((double)iz / (n - 1) - .5) * grid.Span - grid.CompCentre.Z;
                for (int iy = 0; iy < n; iy++)
                {
                    double y = grid.Centre.Y + ((double)iy / (n - 1) - .5) * grid.Span - grid.CompCentre.Y;
                    for (int ix = 0; ix < n; ix++)
                    {
                        double x = grid.Centre.X + ((double)ix / (n - 1) - .5) * grid.Span - grid.CompCentre.X;
                        double r = Math.Max(Math.Sqrt(x * x + y * y + z * z), 0.05 * grid.Wavelength);
                        c[iz * n * n + iy * n + ix] = mode == 2 ? r * r : r;
                    }
                }
            });
            comp = c;
        }
        // dBi scale: the top is the far field·r in the direction of maximum radiation (Dmax of the 3D pattern).
        double absolute = 0;
        if (comp != null && grid.FarGMax > 0 && double.IsFinite(grid.DmaxDbi))
        {
            double k = 2 * Math.PI / grid.Wavelength, eFar = NearFieldKernel.Eta0 * k / (4 * Math.PI) * grid.FarGMax;
            absolute = mode == 2 ? eFar * eFar / (2 * NearFieldKernel.Eta0) : component == 1 ? eFar / NearFieldKernel.Eta0 : eFar;
        }
        _absolute = absolute > 0; _topDbi = _absolute ? grid.DmaxDbi : 0;
        lock (_refSync)
        {
            if (_refKey is not { } key || !ReferenceEquals(key.Grid, grid) || key.Component != component || key.Mode != mode)
            {
                var amplitude = new double[grid.Ex.Length];
                Parallel.For(0, amplitude.Length, i => amplitude[i] = (mode == 2 ? Math.Max(0, grid.Power[i]) : Amplitude(grid, component, i)) * (comp?[i] ?? 1));
                _refValue = absolute > 0 ? absolute : Math.Max(Percentile(amplitude, .96), 1e-30);
                _refGrad = GradientPercentile(amplitude, (int)Math.Round(Math.Cbrt(amplitude.Length)), _refValue, .90);
                _refKey = (grid, component, mode);
            }
            reference = _refValue; gradRef = _refGrad;
        }
        double co = Math.Cos(phaseDeg * Math.PI / 180), si = Math.Sin(phaseDeg * Math.PI / 180);
        var values = new float[grid.Ex.Length];
        float inv = (float)(1.0 / reference);
        Parallel.For(0, values.Length, i =>
        {
            double v;
            if (mode == 2) v = Math.Max(0, grid.Power[i]);
            else if (mode == 1) v = Amplitude(grid, component, i);
            else
            {
                Complex x = component == 1 ? grid.Hx[i] : grid.Ex[i];
                Complex y = component == 1 ? grid.Hy[i] : grid.Ey[i];
                Complex z = component == 1 ? grid.Hz[i] : grid.Ez[i];
                double a = x.Real * co - x.Imaginary * si, b = y.Real * co - y.Imaginary * si, c = z.Real * co - z.Imaginary * si;
                v = Math.Sqrt(a * a + b * b + c * c);
            }
            values[i] = (float)(v * (comp?[i] ?? 1)) * inv;
        });
        return (values, Math.Max(gradRef, 1e-9));
    }

    private static double Amplitude(ScalarGrid g, int component, int i)
    {
        Complex x = component == 1 ? g.Hx[i] : g.Ex[i], y = component == 1 ? g.Hy[i] : g.Ey[i], z = component == 1 ? g.Hz[i] : g.Ez[i];
        return Math.Sqrt(x.Magnitude * x.Magnitude + y.Magnitude * y.Magnitude + z.Magnitude * z.Magnitude);
    }

    /// <summary>Percentile from an even subsample (at most 262144 values): no full sort of millions of voxels.</summary>
    private static double Percentile(double[] values, double q)
    {
        int stride = Math.Max(1, values.Length / 262144);
        var s = new double[(values.Length + stride - 1) / stride];
        for (int i = 0, j = 0; i < values.Length && j < s.Length; i += stride, j++) s[j] = values[i];
        Array.Sort(s);
        return s[(int)Math.Round((s.Length - 1) * q)];
    }

    /// <summary>P90 of the central-difference gradient magnitude (same stencil as the renderers), normalised field.</summary>
    private static double GradientPercentile(double[] v, int n, double reference, double q)
    {
        if (n < 3 || n * n * n != v.Length) return 1;
        var list = new List<double>(200000);
        int step = Math.Max(1, (int)Math.Ceiling(Math.Cbrt((double)(n - 2) * (n - 2) * (n - 2) / 150000.0)));
        for (int z = 1; z < n - 1; z += step)
            for (int y = 1; y < n - 1; y += step)
                for (int x = 1; x < n - 1; x += step)
                {
                    int o = z * n * n + y * n + x;
                    double gx = v[o + 1] - v[o - 1], gy = v[o + n] - v[o - n], gz = v[o + n * n] - v[o - n * n];
                    list.Add(Math.Sqrt(gx * gx + gy * gy + gz * gz) / reference);
                }
        if (list.Count == 0) return 1;
        list.Sort();
        return list[(int)Math.Round((list.Count - 1) * q)];
    }

    private ScalarGrid SampleGrid(IReadOnlyList<MininecPulseSolver.FieldSample> samples, double frequency, int groundType, P[] ends, double extent, int n, bool radiated = false)
    {
        double lambda = 299.792458 / frequency, k = 2 * Math.PI / lambda;
        double minx = ends.Min(p => p.X), maxx = ends.Max(p => p.X), miny = ends.Min(p => p.Y), maxy = ends.Max(p => p.Y), minz = ends.Min(p => p.Z), maxz = ends.Max(p => p.Z);
        P center = new((minx + maxx) * .5, (miny + maxy) * .5, (minz + maxz) * .5);
        P antennaCentre = center;
        double span = Math.Max(1.55 * Math.Max(maxx - minx, Math.Max(maxy - miny, maxz - minz)), 0.95 * lambda) * extent;
        // Over ground the cube reaches down to the ground (antenna raised by H): the ground plane lies 4 % above the
        // bottom face; below it nothing is shown. The cube grows if needed; without ground it is unchanged.
        if (groundType != 0)
        {
            if (center.Z > 0 && center.Z - 0.5 * span > -0.04 * span) span = Math.Max(span, center.Z / 0.46);
            center = center with { Z = Math.Max(center.Z, 0.46 * span) };
        }
        var (farGMax, dmaxDbi, _) = FieldMapView.FarFieldCalibration(samples, frequency, groundType);
        double lmax = Math.Max(maxx - minx, Math.Max(maxy - miny, maxz - minz));
        double farZone = Math.Max(Math.Max(2 * lmax * lmax / lambda, 3 * lambda), groundType != 0 ? 6 * Math.Max(0, antennaCentre.Z) : 0);
        int total = n * n * n;
        var exv = new Complex[total]; var eyv = new Complex[total]; var ezv = new Complex[total];
        var hxv = new Complex[total]; var hyv = new Complex[total]; var hzv = new Complex[total]; var pw = new double[total];
        Complex er = NearFieldKernel.GroundPermittivity(frequency, FieldMapView.GroundEpsilonR, FieldMapView.GroundSigma);
        if (radiated)
        {
            // The 3D pattern propagated from O (ground point below the antenna / antenna centre): no field below the
            // horizon, lobes exactly as the pattern. Tabulated pattern, CPU (no per-voxel sum over the currents).
            P origin = groundType != 0 ? antennaCentre with { Z = 0 } : antennaCentre;
            var table = new RadiatedFieldTable(samples, frequency, groundType, origin.X, origin.Y, origin.Z);
            Parallel.For(0, n, iz =>
            {
                for (int iy = 0; iy < n; iy++) for (int ix = 0; ix < n; ix++)
                {
                    double x = center.X + ((double)ix / (n - 1) - .5) * span;
                    double y = center.Y + ((double)iy / (n - 1) - .5) * span;
                    double z = center.Z + ((double)iz / (n - 1) - .5) * span;
                    table.Field(x, y, z, out var ex, out var ey, out var ez, out var hx, out var hy, out var hz);
                    int i = iz * n * n + iy * n + ix;
                    exv[i] = ex; eyv[i] = ey; ezv[i] = ez; hxv[i] = hx; hyv[i] = hy; hzv[i] = hz;
                    double sx = .5 * (ey * Complex.Conjugate(hz) - ez * Complex.Conjugate(hy)).Real;
                    double sy = .5 * (ez * Complex.Conjugate(hx) - ex * Complex.Conjugate(hz)).Real;
                    double sz = .5 * (ex * Complex.Conjugate(hy) - ey * Complex.Conjugate(hx)).Real;
                    double dx = x - origin.X, dy = y - origin.Y, dz = z - origin.Z, norm = Math.Sqrt(dx * dx + dy * dy + dz * dz);
                    pw[i] = norm > 1e-12 ? Math.Max(0, (sx * dx + sy * dy + sz * dz) / norm) : 0;
                }
            });
            _gridGpu = false;
            MaskBelowGround(groundType, center, span, n, exv, eyv, ezv, hxv, hyv, hzv, pw);
            return new ScalarGrid(center, span, exv, eyv, ezv, hxv, hyv, hzv, pw, lambda, farGMax, dmaxDbi, antennaCentre, groundType, farZone, origin, true);
        }
        if (CudaFieldSolver.TrySample(samples, frequency, groundType, center.X, center.Y, center.Z, span, n, exv, eyv, ezv, hxv, hyv, hzv, pw))
        {
            _gridGpu = true;
            MaskBelowGround(groundType, center, span, n, exv, eyv, ezv, hxv, hyv, hzv, pw);
            return new ScalarGrid(center, span, exv, eyv, ezv, hxv, hyv, hzv, pw, lambda, farGMax, dmaxDbi, antennaCentre, groundType, farZone, antennaCentre, false);
        }
        _gridGpu = false;
        Parallel.For(0, n, iz =>
        {
            for (int iy = 0; iy < n; iy++) for (int ix = 0; ix < n; ix++)
            {
                double x = center.X + ((double)ix / (n - 1) - .5) * span;
                double y = center.Y + ((double)iy / (n - 1) - .5) * span;
                double z = center.Z + ((double)iz / (n - 1) - .5) * span;
                Complex ex = Complex.Zero, ey = Complex.Zero, ez = Complex.Zero;
                Complex hx = Complex.Zero, hy = Complex.Zero, hz = Complex.Zero;
                // Same kernel as the 2D map and the CUDA field (G=2 images: 3D-pattern ground operator).
                foreach (var a in samples)
                    NearFieldKernel.Add(a, x, y, z, k, lambda, groundType, er, ref ex, ref ey, ref ez, ref hx, ref hy, ref hz);

                int i = iz * n * n + iy * n + ix;
                exv[i] = ex; eyv[i] = ey; ezv[i] = ez; hxv[i] = hx; hyv[i] = hy; hzv[i] = hz;
                double sx = .5 * (ey * Complex.Conjugate(hz) - ez * Complex.Conjugate(hy)).Real;
                double sy = .5 * (ez * Complex.Conjugate(hx) - ex * Complex.Conjugate(hz)).Real;
                double sz = .5 * (ex * Complex.Conjugate(hy) - ey * Complex.Conjugate(hx)).Real;
                double dx = x - center.X, dy = y - center.Y, dz = z - center.Z;
                double norm = Math.Sqrt(dx * dx + dy * dy + dz * dz);
                pw[i] = norm > 1e-12 ? Math.Max(0, (sx * dx + sy * dy + sz * dz) / norm) : 0;
            }
        });
        MaskBelowGround(groundType, center, span, n, exv, eyv, ezv, hxv, hyv, hzv, pw);
        return new ScalarGrid(center, span, exv, eyv, ezv, hxv, hyv, hzv, pw, lambda, farGMax, dmaxDbi, antennaCentre, groundType, farZone, antennaCentre, false);
    }

    /// <summary>
    /// Below ground (z &lt; 0) the image construction is not the physical field (PEC: zero; real ground: transmitted
    /// field, not modelled). Those voxels are cleared, so the volume shows only the half-space above ground.
    /// </summary>
    private static void MaskBelowGround(int groundType, P center, double span, int n,
        Complex[] ex, Complex[] ey, Complex[] ez, Complex[] hx, Complex[] hy, Complex[] hz, double[] pw)
    {
        if (groundType == 0) return;
        for (int iz = 0; iz < n; iz++)
        {
            double z = center.Z + ((double)iz / (n - 1) - .5) * span;
            if (z >= 0) continue;
            int start = iz * n * n, end = start + n * n;
            for (int i = start; i < end; i++)
            {
                ex[i] = ey[i] = ez[i] = hx[i] = hy[i] = hz[i] = Complex.Zero;
                pw[i] = 0;
            }
        }
    }

    private void QueueRender(bool preview)
    {
        int revision = ++_renderRevision;
        var values = _normalized;
        if (values == null) return;
        double az = _azimuth, el = _elevation, zoom = _zoom;
        int gridN = GridN, volumeRevision = _volumeRevision;
        var style = new VolumeStyle(_style, _db, (_displayMode == 2 ? 10.0 : 20.0) * DbRange / _dbRange, _density, _gradRef);
        _ = Task.Run(() =>
        {
            if (revision != _renderRevision) return (Pixels: Array.Empty<byte>(), Gpu: false, Size: 0);
            int gpuSize = preview ? PreviewImageSize : FinalImageSize, gpuSteps = preview ? PreviewSteps : FinalSteps;
            // Optional CUDA fast path, never affecting the EM solver.
            byte[]? gpu = CudaVolumeRenderer.TryRender(values, gridN, volumeRevision, style, az, el, zoom, gpuSize, gpuSteps);
            if (gpu != null) return (Pixels: gpu, Gpu: true, Size: gpuSize);
            int size = preview ? PreviewImageSize : CpuFinalImageSize, steps = preview ? PreviewSteps : CpuFinalSteps;
            return (Pixels: RenderVolume(values, gridN, style, az, el, zoom, size, steps), Gpu: false, Size: size);
        })
            .ContinueWith(t => Dispatcher.BeginInvoke(new Action(() =>
            {
                if (revision != _renderRevision || t.IsFaulted || t.IsCanceled || t.Result.Size == 0) return;
                int size = t.Result.Size;
                _lastGpu = t.Result.Gpu;
                _lastPreview = preview;
                var bitmap = new WriteableBitmap(size, size, 96, 96, PixelFormats.Bgra32, null);
                bitmap.WritePixels(new Int32Rect(0, 0, size, size), t.Result.Pixels, size * 4, 0);
                _bitmap = bitmap;
                RenderOptions.SetBitmapScalingMode(this, preview ? BitmapScalingMode.LowQuality : BitmapScalingMode.HighQuality);
                InvalidateVisual();
            })), TaskScheduler.Default);
    }

    // Opacity is specified for this path length (box side = 2): the image does not depend on the step count.
    private const double ReferenceStep = 2.0 / 128;
    internal static readonly double[] ShellLevelsDb = { 1.0 / 3, 2.0 / 3, 0.9 };       // −20, −10, −3 dB of a 30 dB scale
    internal static readonly double[] ShellLevelsLinear = { 0.20, 0.45, 0.80 };
    private static readonly double[] ShellStrength = { 0.16, 0.34, 0.70 };            // outer shells more transparent

    /// <summary>Colour coordinate 0..1: dB over DbRange, or linear (both relative to P96).</summary>
    internal static double ToScale(double rel, in VolumeStyle st)
    {
        if (!st.Db) return Math.Clamp(rel, 0, 1);
        double db = st.DbFactor * Math.Log10(Math.Max(rel, 1e-12));
        return Math.Clamp((db + DbRange) / DbRange, 0, 1);
    }

    private static byte[] RenderVolume(float[] v, int n, VolumeStyle st, double az, double el, double zoom, int size, int steps)
    {
        var pixels = new byte[size * size * 4];
        double ca = Math.Cos(az), sa = Math.Sin(az), ce = Math.Cos(el), se = Math.Sin(el);
        double rx = ca, ry = -sa, rz = 0;
        double ux = sa * se, uy = ca * se, uz = ce;
        // Unit vector from the scene TOWARDS THE VIEWER (same as WirePreview.ViewerDirection).
        double fx = -sa * ce, fy = -ca * ce, fz = se;
        double scale = 2.45 / zoom;
        double[] levels = st.Db ? ShellLevelsDb : ShellLevelsLinear;

        Parallel.For(0, size, iy =>
        {
            for (int ix = 0; ix < size; ix++)
            {
                int k = (iy * size + ix) * 4;
                pixels[k + 3] = 255;
                double a = ((ix + .5) / size - .5) * scale;
                double b = (.5 - (iy + .5) / size) * scale;
                double ox = a * rx + b * ux, oy = a * ry + b * uy, oz = a * rz + b * uz;
                if (!IntersectBox(ox, oy, oz, fx, fy, fz, out double t0, out double t1) || t1 <= t0) continue;
                double dt = (t1 - t0) / steps;
                double stepFactor = dt / ReferenceStep;
                double red = 0, green = 0, blue = 0, alpha = 0, best = 0, bestDepth = 0, lum = 0;
                for (int s = 0; s < steps; s++)
                {
                    // FRONT TO BACK: t1 is the entry point on the viewer's side.
                    double t = t1 - (s + .5) * dt;
                    double x = ox + t * fx, y = oy + t * fy, z = oz + t * fz;
                    double rel = Trilinear(v, n, x, y, z);
                    if (rel <= 0) continue;
                    double c = ToScale(rel, st);
                    double depth = (s + .5) / steps;            // 0 near, 1 far
                    if (st.Mode == 2) { if (c > best) { best = c; bestDepth = depth; } continue; }
                    if (st.Mode == 1 && c > best) best = c;                 // volume: colour of the ray maximum (as MIP)
                    double aRef = OpacityAt(c, st, levels);
                    if (aRef < 1e-5) continue;
                    double opacity = 1 - Math.Pow(1 - Math.Min(aRef, .999), stepFactor);
                    Gradient(v, n, x, y, z, out double gx, out double gy, out double gz);
                    double gl = Math.Sqrt(gx * gx + gy * gy + gz * gz);
                    double facing = gl > 1e-12 ? Math.Abs((gx * fx + gy * fy + gz * fz) / gl) : 1;
                    if (st.Mode == 0) opacity *= 0.10 + 0.90 * (1 - facing) * (1 - facing);          // glass shells
                    else if (st.Mode == 3)
                    {
                        // Glass: opaque where the field changes (layer boundaries), faces turned to the viewer clear,
                        // silhouettes dense — inner structures are seen through outer ones.
                        double edge = 1 - facing;
                        opacity *= Math.Min(1, gl / st.GradRef) * (0.03 + 0.97 * edge * edge * edge);
                    }
                    else if (st.Db) opacity *= 0.35 + 0.65 * Math.Min(1, gl / st.GradRef);         // boundary enhancement
                    double w = (1 - alpha) * opacity;
                    if (w <= 0) continue;
                    if (st.Mode == 1)
                    {
                        // Volume: brightness from the accumulated opacity; the colour is set after the ray (maximum).
                        lum += w * (1 - 0.25 * depth);
                        alpha += w;
                        continue;                                           // no early exit: the maximum may lie further
                    }
                    // Glass shells: palette and lighting as in 0.6.53; glass: rainbow of the local value, soft light.
                    var col = st.Mode == 3 ? Rainbow(c) : Vivid(c);
                    double light = st.Mode == 3 ? (0.75 + 0.25 * facing) * (1 - 0.25 * depth)
                                                : (0.45 + 0.55 * facing) * (1 - 0.55 * depth);   // headlight + depth cue
                    red += w * col.R * light; green += w * col.G * light; blue += w * col.B * light;
                    alpha += w;
                    if (alpha > .995) break;
                }
                if (st.Mode == 1)
                {
                    // Colour of the strongest field on the ray (rainbow, as MIP); volumetric brightness with a floor,
                    // so weak field shows blue/violet and no field stays black.
                    if (best <= 0.02) continue;
                    double bright = (0.40 + 0.60 * Math.Pow(Math.Min(1, lum), 0.6)) * SmoothStep(0.02, 0.15, best);
                    var col = Rainbow(best);
                    red = col.R * bright; green = col.G * bright; blue = col.B * bright;
                }
                if (st.Mode == 2)
                {
                    if (best <= 0.02) continue;
                    var col = Rainbow(best); double light = 1 - 0.35 * bestDepth;
                    red = col.R * light; green = col.G * light; blue = col.B * light;
                }
                pixels[k] = (byte)Math.Clamp(Math.Round(blue), 0, 255);
                pixels[k + 1] = (byte)Math.Clamp(Math.Round(green), 0, 255);
                pixels[k + 2] = (byte)Math.Clamp(Math.Round(red), 0, 255);
            }
        });
        return pixels;
    }

    private static double OpacityAt(double c, in VolumeStyle st, double[] levels)
    {
        if (st.Mode == 1)
            return (st.Db ? 0.16 : 0.10) * st.Density * Math.Pow(SmoothStep(st.Db ? 0.40 : 0.12, 1.0, c), st.Db ? 2.2 : 1.6);
        if (st.Mode == 3)   // glass (as the translucent 3D pattern): base opacity, strong field denser
            return 0.30 * st.Density * SmoothStep(0.05, 0.25, c) * (0.3 + 0.7 * c);
        double a = 0;
        for (int i = 0; i < levels.Length; i++)
        {
            double d = (c - levels[i]) / 0.03;
            a = Math.Max(a, ShellStrength[i] * st.Density * Math.Exp(-d * d));
        }
        return a;
    }

    private static bool IntersectBox(double ox, double oy, double oz, double dx, double dy, double dz, out double t0, out double t1)
    {
        t0 = double.NegativeInfinity;
        t1 = double.PositiveInfinity;
        if (!IntersectAxis(ox, dx, ref t0, ref t1)) return false;
        if (!IntersectAxis(oy, dy, ref t0, ref t1)) return false;
        if (!IntersectAxis(oz, dz, ref t0, ref t1)) return false;
        return t1 > t0;
    }
    private static bool IntersectAxis(double o, double d, ref double t0, ref double t1)
    {
        if (Math.Abs(d) < 1e-12) return Math.Abs(o) < 1.0;
        double a = (-1 - o) / d, b = (1 - o) / d;
        if (a > b) (a, b) = (b, a);
        t0 = Math.Max(t0, a);
        t1 = Math.Min(t1, b);
        return t1 >= t0;
    }

    private static double SmoothStep(double a, double b, double x)
    {
        if (x <= a) return 0;
        if (x >= b) return 1;
        x = (x - a) / (b - a);
        return x * x * (3 - 2 * x);
    }

    private static void Gradient(float[] values, int n, double x, double y, double z, out double gx, out double gy, out double gz)
    {
        double h = 2.0 / (n - 1);
        gx = Trilinear(values, n, Math.Clamp(x + h, -1, 1), y, z) - Trilinear(values, n, Math.Clamp(x - h, -1, 1), y, z);
        gy = Trilinear(values, n, x, Math.Clamp(y + h, -1, 1), z) - Trilinear(values, n, x, Math.Clamp(y - h, -1, 1), z);
        gz = Trilinear(values, n, x, y, Math.Clamp(z + h, -1, 1)) - Trilinear(values, n, x, y, Math.Clamp(z - h, -1, 1));
    }

    private static double Trilinear(float[] a, int n, double x, double y, double z)
    {
        double xx = (x + 1) * .5 * (n - 1), yy = (y + 1) * .5 * (n - 1), zz = (z + 1) * .5 * (n - 1);
        int i = Math.Clamp((int)xx, 0, n - 2), j = Math.Clamp((int)yy, 0, n - 2), k = Math.Clamp((int)zz, 0, n - 2);
        double u = xx - i, v = yy - j, w = zz - k;
        int o = k * n * n + j * n + i;
        double c00 = a[o] * (1 - u) + a[o + 1] * u;
        double c10 = a[o + n] * (1 - u) + a[o + n + 1] * u;
        double c01 = a[o + n * n] * (1 - u) + a[o + n * n + 1] * u;
        double c11 = a[o + n * n + n] * (1 - u) + a[o + n * n + n + 1] * u;
        return (c00 * (1 - v) + c10 * v) * (1 - w) + (c01 * (1 - v) + c11 * v) * w;
    }

    // Palette of the glass shells (as in 0.6.53): nine vivid stops, identical to palette_vivid in CUDA.
    private static Color Vivid(double t)
    {
        t = Math.Clamp(t, 0, 1);
        (byte R, byte G, byte B)[] stops =
        {
            (8,10,85), (16,55,230), (5,130,255),
            (0,220,255), (0,235,80), (30,255,0),
            (255,238,0), (255,135,0), (220,24,30)
        };
        double q = t * (stops.Length - 1);
        int i = Math.Min(stops.Length - 2, (int)q);
        double a = q - i;
        return Color.FromRgb((byte)(stops[i].R + (stops[i + 1].R - stops[i].R) * a),
                             (byte)(stops[i].G + (stops[i + 1].G - stops[i].G) * a),
                             (byte)(stops[i].B + (stops[i + 1].B - stops[i].B) * a));
    }
    /// <summary>Palette of the current style: shells — vivid stops (0.6.53); volume and MIP — rainbow of the 3D pattern.</summary>
    private Color StylePalette(double t) => _style == 0 ? Vivid(t) : Rainbow(t);

    // Rainbow palette of the 3D radiation pattern (WirePreview.RainbowArgb): hue = (1 − t)·270°, full saturation
    // and brightness — violet (weak) → blue → cyan → green → yellow → orange → red (strong). Same in CUDA.
    // Colour coordinate 0..1 from ToScale (dB or linear); the legend uses the same mapping.
    private static Color Rainbow(double t)
    {
        double h = (1 - Math.Clamp(t, 0, 1)) * 270;
        double x = 1 - Math.Abs((h / 60) % 2 - 1);
        double r = 0, g = 0, b = 0;
        if (h < 60) { r = 1; g = x; } else if (h < 120) { r = x; g = 1; }
        else if (h < 180) { g = 1; b = x; } else if (h < 240) { g = x; b = 1; }
        else { r = x; b = 1; }
        return Color.FromRgb((byte)Math.Round(255 * r), (byte)Math.Round(255 * g), (byte)Math.Round(255 * b));
    }
    /// <summary>
    /// Arrows of the field on an m×m×m lattice inside the cube: direction = instantaneous E or H at the current phase
    /// (S mode: mean Poynting vector), length = the colour coordinate of that voxel (same scale as the volume), far
    /// arrows fainter. Nothing below ground or where the field is below the scale.
    /// </summary>
    private void DrawVectors3D(DrawingContext dc, Rect view, double side)
    {
        var grid = _grid; var values = _normalized;
        if (!_showVectors || grid == null || values == null) return;
        int n = (int)Math.Round(Math.Cbrt(values.Length));
        if (n < 2 || n * n * n != values.Length || grid.Ex.Length != values.Length) return;
        int m = Math.Clamp((int)Math.Round(9 / _vectorSize), 5, 16);
        var style = new VolumeStyle(_style, _db, (_displayMode == 2 ? 10.0 : 20.0) * DbRange / _dbRange, _density, _gradRef);   // same scale as the image
        double ca = Math.Cos(_azimuth), sa = Math.Sin(_azimuth), ce = Math.Cos(_elevation), se = Math.Sin(_elevation);
        double fx = -sa * ce, fy = -ca * ce, fz = se;                       // towards the viewer
        double factor = side * _zoom / 2.45;
        Point P(double x, double y, double z)
            => new(view.Left + side * .5 + (x * ca - y * sa) * factor, view.Top + side * .5 - ((x * sa + y * ca) * se + z * ce) * factor);
        double ph = _phase * Math.PI / 180, co = Math.Cos(ph), si = Math.Sin(ph);
        bool magnetic = _component == 1;
        const int Buckets = 4;
        var geos = new StreamGeometry[Buckets]; var ctxs = new StreamGeometryContext[Buckets];
        for (int b = 0; b < Buckets; b++) { geos[b] = new StreamGeometry(); ctxs[b] = geos[b].Open(); }
        for (int k = 0; k < m; k++)
            for (int j = 0; j < m; j++)
                for (int i = 0; i < m; i++)
                {
                    double qx = -1 + (i + .5) * 2 / m, qy = -1 + (j + .5) * 2 / m, qz = -1 + (k + .5) * 2 / m;
                    int ix = (int)Math.Round((qx + 1) * .5 * (n - 1)), iy = (int)Math.Round((qy + 1) * .5 * (n - 1)), iz = (int)Math.Round((qz + 1) * .5 * (n - 1));
                    int p = iz * n * n + iy * n + ix;
                    double t = ToScale(values[p], style);
                    if (!(t >= 0.06)) continue;
                    double ax, ay, az;
                    if (_displayMode == 2)
                    {
                        Complex ex = grid.Ex[p], ey = grid.Ey[p], ez = grid.Ez[p], hx = grid.Hx[p], hy = grid.Hy[p], hz = grid.Hz[p];
                        ax = .5 * (ey * Complex.Conjugate(hz) - ez * Complex.Conjugate(hy)).Real;
                        ay = .5 * (ez * Complex.Conjugate(hx) - ex * Complex.Conjugate(hz)).Real;
                        az = .5 * (ex * Complex.Conjugate(hy) - ey * Complex.Conjugate(hx)).Real;
                    }
                    else
                    {
                        Complex fxv = magnetic ? grid.Hx[p] : grid.Ex[p], fyv = magnetic ? grid.Hy[p] : grid.Ey[p], fzv = magnetic ? grid.Hz[p] : grid.Ez[p];
                        ax = fxv.Real * co - fxv.Imaginary * si; ay = fyv.Real * co - fyv.Imaginary * si; az = fzv.Real * co - fzv.Imaginary * si;
                    }
                    double mag = Math.Sqrt(ax * ax + ay * ay + az * az);
                    if (!(mag > 0)) continue;
                    double dx = ax / mag, dy = ay / mag, dz = az / mag;
                    double half = (2.0 / m) * 0.21 * Math.Max(0.2, t);                  // half the 0.6.61 size
                    var a = P(qx - dx * half, qy - dy * half, qz - dz * half);
                    var b2 = P(qx + dx * half, qy + dy * half, qz + dz * half);
                    double sx = b2.X - a.X, sy = b2.Y - a.Y, sl = Math.Sqrt(sx * sx + sy * sy);
                    double depth = (qx * fx + qy * fy + qz * fz + 1.733) / 3.466;     // 0 far … 1 near
                    var ctx = ctxs[Math.Clamp((int)(depth * Buckets), 0, Buckets - 1)];
                    ctx.BeginFigure(a, false, false); ctx.LineTo(b2, true, true);
                    if (sl > 3)
                    {
                        double ux = sx / sl, uy = sy / sl, head = Math.Max(2.0, 0.3 * sl), hc = Math.Cos(0.45), hs = Math.Sin(0.45);
                        ctx.BeginFigure(new Point(b2.X - head * (ux * hc - uy * hs), b2.Y - head * (uy * hc + ux * hs)), false, false);
                        ctx.LineTo(b2, true, true);
                        ctx.LineTo(new Point(b2.X - head * (ux * hc + uy * hs), b2.Y - head * (uy * hc - ux * hs)), true, true);
                    }
                }
        for (int b = 0; b < Buckets; b++)
        {
            ctxs[b].Close(); geos[b].Freeze();
            byte alpha = (byte)(90 + 165 * (b + .5) / Buckets);                 // far arrows fainter
            var under = new Pen(new SolidColorBrush(Color.FromArgb((byte)(alpha * .6), 0, 0, 0)), 2.6) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
            var pen = new Pen(new SolidColorBrush(Color.FromArgb(alpha, 255, 255, 255)), 1.15) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
            under.Freeze(); pen.Freeze();
            dc.DrawGeometry(null, under, geos[b]); dc.DrawGeometry(null, pen, geos[b]);
        }
    }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        dc.DrawRectangle(Brushes.Black, null, new Rect(0, 0, ActualWidth, ActualHeight));
        double side = Math.Max(1, Math.Min(ActualWidth, ActualHeight));
        var view = new Rect((ActualWidth - side) * .5, (ActualHeight - side) * .5, side, side);
        if (_bitmap != null) dc.DrawImage(_bitmap, view);
        // A subtle frame is a visual guide to the sampled volume, NOT a physical EM boundary.
        // Draw directly over the CUDA/CPU image so the native render ABI stays unchanged.
        if (_showVolumeBounds && _grid != null)
        {
            double ca = Math.Cos(_azimuth), sa = Math.Sin(_azimuth);
            double ce = Math.Cos(_elevation), se = Math.Sin(_elevation);
            Point ProjectBox(double x, double y, double z)
            {
                double right = x * ca - y * sa;
                double up = (x * sa + y * ca) * se + z * ce;
                double factor = side * _zoom / 2.45;
                return new Point(view.Left + side * .5 + right * factor,
                                 view.Top + side * .5 - up * factor);
            }
            // The back edges are subdued, while edges nearest the viewer are more visible.
            var rear = new Pen(new SolidColorBrush(Color.FromArgb(35, 140, 191, 223)), .75);
            var front = new Pen(new SolidColorBrush(Color.FromArgb(104, 173, 210, 233)), 1.05);
            rear.Freeze(); front.Freeze();
            for (int axis = 0; axis < 3; axis++)
                for (int u = -1; u <= 1; u += 2)
                    for (int v = -1; v <= 1; v += 2)
                    {
                        double x0 = axis == 0 ? -1 : u, y0 = axis == 1 ? -1 : (axis == 0 ? u : v);
                        double z0 = axis == 2 ? -1 : v;
                        double x1 = axis == 0 ? 1 : x0, y1 = axis == 1 ? 1 : y0;
                        double z1 = axis == 2 ? 1 : z0;
                        // Camera ray orientation is (-sin(az)*cos(el), -cos(az)*cos(el), sin(el)).
                        double depth = (x0+x1)*-.5*sa*ce + (y0+y1)*-.5*ca*ce + (z0+z1)*.5*se;
                        dc.DrawLine(depth < 0 ? rear : front,
                                    ProjectBox(x0,y0,z0),ProjectBox(x1,y1,z1));
                    }
        }
        // Ground plane z = 0 (below it the volume is empty).
        if (_grid is { GroundType: not 0 } gg)
        {
            double z0 = (0 - gg.Centre.Z) * 2 / gg.Span;
            if (z0 > -1 && z0 < 1)
            {
                double ca = Math.Cos(_azimuth), sa = Math.Sin(_azimuth), ce = Math.Cos(_elevation), se = Math.Sin(_elevation);
                Point PB(double x, double y, double z)
                {
                    double right = x * ca - y * sa, up = (x * sa + y * ca) * se + z * ce, factor = side * _zoom / 2.45;
                    return new Point(view.Left + side * .5 + right * factor, view.Top + side * .5 - up * factor);
                }
                var geo = new StreamGeometry();
                using (var ctx = geo.Open())
                {
                    ctx.BeginFigure(PB(-1, -1, z0), true, true);
                    ctx.LineTo(PB(1, -1, z0), true, false); ctx.LineTo(PB(1, 1, z0), true, false); ctx.LineTo(PB(-1, 1, z0), true, false);
                }
                geo.Freeze();
                var fill = new SolidColorBrush(Color.FromArgb(38, 196, 150, 92)); fill.Freeze();
                var pen = new Pen(new SolidColorBrush(Color.FromArgb(170, 196, 150, 92)), 1.3); pen.Freeze();
                dc.DrawGeometry(fill, pen, geo);
            }
        }
        if (_showAntenna && _model is { Wires.Count: > 0 } model && _grid is { } grid)
        {
            double ca = Math.Cos(_azimuth), sa = Math.Sin(_azimuth), ce = Math.Cos(_elevation), se = Math.Sin(_elevation);
            Point Project(double x, double y, double z)
            {
                x = (x - grid.Centre.X) * 2 / grid.Span;
                y = (y - grid.Centre.Y) * 2 / grid.Span;
                z = (z - grid.Centre.Z) * 2 / grid.Span;
                double right = x * ca - y * sa, up = (x * sa + y * ca) * se + z * ce;
                double factor = side * _zoom / 2.45;
                return new Point(view.Left + side * .5 + right * factor, view.Top + side * .5 - up * factor);
            }
            var edge = new Pen(Brushes.Black, 4.2); edge.Freeze();
            var wire = new Pen(Brushes.WhiteSmoke, 2.25); wire.Freeze();
            foreach (var w in model.Wires)
            {
                var a = Project(w.X1, w.Y1, w.Z1 + _zOffset); var b = Project(w.X2, w.Y2, w.Z2 + _zOffset);
                dc.DrawLine(edge, a, b); dc.DrawLine(wire, a, b);
            }
        }
        DrawVectors3D(dc, view, side);
        string label = _displayMode == 2 ? "S" : _component == 1 ? "H" : "E";
        string styleName = _style == 0 ? "оболочки (стекло)" : _style == 1 ? "объём" : _style == 3 ? "стекло (как 3D ДН)" : "MIP — максимум вдоль луча";
        string scaleName = _absolute
            ? (_db ? $"{(_displayMode == 2 ? "S·r²" : "·r")} · dBi от Dmax {_topDbi:0.#} (диапазон {_dbRange:0} дБ)" : $"·r · линейно (100% = Dmax {_topDbi:0.#} dBi)")
            : (_db ? $"дБ относительно P96 (диапазон {_dbRange:0} дБ)" : "линейно относительно P96");
        var culture = System.Globalization.CultureInfo.InvariantCulture;
        FormattedText Text(string s, int font, Brush brush) => new(s, culture, FlowDirection.LeftToRight, new Typeface("Segoe UI"), font, brush, 1);
        dc.DrawText(Text($"3D · поле {label} · {styleName} · {scaleName}", 14, Brushes.WhiteSmoke), new Point(20, 18));
        string quality = _lastPreview ? "черновик при вращении — отпустите мышь для финального кадра"
                                      : (_lastGpu ? "1024 px / 512 шагов" : "768 px / 320 шагов");
        dc.DrawText(Text($"Сетка: {GridN}³ ({(_grid?.Radiated == true ? "излучаемое поле по ДН" : _gridGpu ? "CUDA Field" : "CPU Field")}) · Рендер: {(_lastGpu ? "CUDA GPU" : "CPU / " + CudaVolumeRenderer.LastStatus)} · {quality} · дальние слои темнее · ЛКМ — вращение · колесо — масштаб", 11, Brushes.Gainsboro), new Point(20, Math.Max(42, ActualHeight - 30)));
        double left = Math.Max(12, ActualWidth - 63), top = 54, height = Math.Min(230, ActualHeight * .35);
        for (int i = 0; i < 96; i++)
        {
            double t = 1.0 - i / 95.0;
            dc.DrawRectangle(new SolidColorBrush(StylePalette(t)), null, new Rect(left, top + i * height / 96, 14, height / 96 + 1));
        }
        if (_style == 0)
        {
            var tick = new Pen(Brushes.WhiteSmoke, 1.2); tick.Freeze();
            foreach (double lv in _db ? ShellLevelsDb : ShellLevelsLinear)
            {
                double y = top + (1 - lv) * height;
                dc.DrawLine(tick, new Point(left - 5, y), new Point(left + 19, y));
                string txt = _db ? (_absolute ? $"{_topDbi + (lv - 1) * _dbRange:0.#}" : $"{(lv - 1) * _dbRange:0}") : $"{lv * 100:0}%";
                dc.DrawText(Text(txt, 9, Brushes.WhiteSmoke), new Point(left - 30, y - 6));
            }
        }
        dc.DrawText(Text(_db ? (_absolute ? $"{_topDbi:0.#} dBi" : "0 дБ") : "100%", 10, Brushes.WhiteSmoke), new Point(left - 8, top - 17));
        dc.DrawText(Text(_db ? (_absolute ? $"{_topDbi - _dbRange:0.#} dBi" : $"−{_dbRange:0} дБ") : "0%", 10, Brushes.WhiteSmoke), new Point(left - 12, top + height + 5));
        // Ground / far zone: the 3D-pattern lobes form only from the far-zone distance on.
        if (_grid is { } info)
        {
            string groundText = info.GroundType == 0 ? "свободное пространство"
                : $"земля z = 0 (коричневая плоскость), антенна на {info.AntennaCentre.Z:0.##} м";
            string zone = info.Radiated
                ? (info.GroundType != 0 ? "поле излучения по 3D ДН от точки на земле под антенной — ниже горизонта поля нет" : "поле излучения по 3D ДН")
                : info.FarZone > 0
                ? (0.5 * info.Span >= info.FarZone ? $"куб ±{0.5 * info.Span:0.#} м ≥ дальней зоны ≈ {info.FarZone:0.#} м — лепестки как в 3D ДН"
                                                   : $"куб ±{0.5 * info.Span:0.#} м — ближняя зона; лепестки 3D ДН складываются от ≈ {info.FarZone:0.#} м (увеличьте «Обзор ЭМ поля»)")
                : "";
            dc.DrawText(Text($"{groundText} · {zone}" + (_compensate ? "" : " · без компенсации 1/r шкала относительная"), 11,
                0.5 * info.Span >= info.FarZone ? Brushes.Gainsboro : Brushes.Khaki), new Point(20, 44));
        }
    }
}
