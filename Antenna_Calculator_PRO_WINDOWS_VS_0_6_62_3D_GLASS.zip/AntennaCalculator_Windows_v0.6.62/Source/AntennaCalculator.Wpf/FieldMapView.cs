﻿using System;
using System.Numerics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>
/// Phase animation of thin-wire dipole near-fields on a sampled plane.
/// Phasors are computed once on a background thread. Each frame only evaluates
/// Re(E * exp(j phase)) and writes one BGRA bitmap, avoiding repeated O(Ncells*Npulses) work.
/// Thin-wire point-segment approximation; dielectric-ground near fields are not solved.
/// </summary>
public sealed class FieldMapView : FrameworkElement
{
    // Grid: at least 12 cells per wavelength (wavefronts of the instantaneous field are λ/2 apart), 176…384.
    private const int MinGrid = 176, MaxGrid = 384;
    private static int GridFor(double span,double wavelength)=>Math.Clamp((int)Math.Ceiling(12.0*span/wavelength),MinGrid,MaxGrid);
    // Ground used for the reflected field of G = 2: the same values as the 3D / 2D radiation patterns.
    internal const double GroundEpsilonR = 13.0, GroundSigma = 0.005;
    // Precomputed palette avoids per-pixel HSV conversions during playback.
    private const int PaletteSize = 2048;
    private static readonly uint[] Palette = BuildPalette();
    private static uint[] BuildPalette()
    {
        var table = new uint[PaletteSize];
        for (int i = 0; i < table.Length; i++)
        {
            var col = Vivid((double)i / (table.Length - 1));
            table[i] = (uint)(col.B | (col.G << 8) | (col.R << 16)) | 0xff000000u;
        }
        return table;
    }
    private MininecPulseSolver.Result? _result;
    private FieldGrid? _grid;
    private MaaModel? _model;
    private int _plane; // 0 XY, 1 XZ, 2 YZ
    private int _component; // 0 near E, 1 near H
    private int _displayMode; // 0 instantaneous E/H; 1 |E| phasor norm; 2 time-average outward Poynting flux
    // Colour scale (0.6.46). The reference is a robust P99.5 OUTSIDE the zone next to the conductors (where the
    // thin-wire field grows like 1/r³ and is only limited by the segment cutoff), so the field spreading away
    // from the antenna uses the whole palette; values at the wires saturate.
    private int _scale;               // 0 dB, 1 linear, 2 histogram equalisation
    private double _dbRange;          // 0 = automatic from the map (P99.5 / P2, 20…60 dB)
    private bool _compensate = true;  // show |E|·r, |H|·r, S·r²: the radiated wave does not fade with distance
    private ScaleStats? _stats;
    private double _zOffset;          // MAA Z → solver z (H above ground), applied to the overlay as well
    private bool _zFromCurrents;      // offset taken from the solver's pulse positions (rule disagreed)
    // Absolute = true: the 1/r-compensated field is expressed in dBi; the top of the scale (Reference) is the far
    // field in the direction of maximum radiation, i.e. TopDb = Dmax of the 3D pattern.
    private sealed record ScaleStats(double Reference, double AutoRange, double[] Sorted, double DbFactor, bool Absolute = false, double TopDb = 0);
    public void SetScale(int scale) { _scale = Math.Clamp(scale, 0, 2); Restyle(); }
    public void SetDbRange(double range) { _dbRange = range <= 0 ? 0 : Math.Clamp(range, 5, 120); Restyle(); }
    public void SetDistanceCompensation(bool on) { _compensate = on; _stats = null; Restyle(); }
    private bool _showPattern = true;
    /// <summary>Contour of the 3D-pattern cut in the current plane, in the same dB scale as the map.</summary>
    public void SetPatternContour(bool on) { _showPattern = on; InvalidateVisual(); }
    // Field vectors (arrows): instantaneous E/H at the current phase (S: mean Poynting vector), projected on the plane.
    private bool _showVectors;
    private double _vectorSize = 1;
    public void SetVectors(bool on, double size) { _showVectors = on; _vectorSize = Math.Clamp(size, 0.4, 3); InvalidateVisual(); }
    // Field model: true = radiated field built from the 3D pattern (no field below the horizon, lobes exactly as the
    // pattern); false = full physical near field of the currents (direct + ground-reflected, near-zone terms).
    private bool _radiated = true;
    public void SetFieldModel(bool radiated) { if(_radiated==radiated) return; _radiated = radiated; SetResult(_result); }
    private void Restyle() { UpdateFrame(); InvalidateVisual(); }
    public void SetDisplayMode(int mode)
    {
        _displayMode=Math.Clamp(mode,0,2);
        _stats=null;
        UpdateFrame();InvalidateVisual();
    }
    private double _extentFactor=1.0;
    public void SetExtentFactor(double factor)
    {
        factor=Math.Clamp(factor,0.25,40.0); // Physical window scale, smaller = zoom in (large: far zone over ground)
        if(Math.Abs(_extentFactor-factor)<1e-9)return;
        _extentFactor=factor;
        SetResult(_result); // physical EM grid must be sampled again, not bitmap-stretched
    }
    // Wheel zoom works in all XY/XZ/YZ planes, and resamples the physical field.
    protected override void OnMouseWheel(System.Windows.Input.MouseWheelEventArgs e)
    {
        double next = _extentFactor * Math.Pow(1.15, -e.Delta / 120.0);
        SetExtentFactor(next);
        e.Handled = true;
        base.OnMouseWheel(e);
    }

    public void SetComponent(int component)
    {
        _component=Math.Clamp(component,0,1);
        _stats=null;
        UpdateFrame();InvalidateVisual();
    }
    public void SetPlane(int plane)
    {
        plane=Math.Clamp(plane,0,2);
        if(_plane==plane)return;
        _plane=plane;
        SetResult(_result);
    }
    public void SetModel(MaaModel? model) { _model=model; InvalidateVisual(); }
    private WriteableBitmap? _bitmap;
    private double _phase;
    private int _revision;
    private bool _showAntennaOverlay = true;
    public void SetAntennaOverlay(bool value) { _showAntennaOverlay = value; InvalidateVisual(); }
    private byte[] _pixels = Array.Empty<byte>();
    private Int32Rect _rect;
    private sealed record FieldGrid(double[] ExR, double[] ExI, double[] EyR, double[] EyI,
        double[] EzR, double[] EzI, double[] HxR, double[] HxI, double[] HyR, double[] HyI,
        double[] HzR, double[] HzI, double[] Power, double MaxEnvelope,double MaxHEnvelope,double MaxPower,
        double[] Distance, bool[] Near, double Wavelength, int N, bool[] Below, int Images, int GroundType,
        double Span, double Cu, double Cv, double Perp, int Plane,
        double FarGMax, double DmaxDbi,
        double[] PatternCut, double PatternElevationDeg, double OriginU, double OriginV, double FarZoneMetres, bool Radiated=false);

    public void SetResult(MininecPulseSolver.Result? result)
    {
        _result = result;
        _grid = null;
        _bitmap = null;
        int revision = Interlocked.Increment(ref _revision);
        InvalidateVisual();
        var samples = result?.FieldSamples;
        if (samples == null || samples.Count == 0) return;
        double freq = result.FrequencyMHz;
        int plane = _plane;
        double extentFactor=_extentFactor;
        // Do not access UI objects from a worker thread.
        int groundType=_model?.GroundType??0;
        // Snapshot the physical wire endpoints on the UI thread: sampled pulse centres
        // are not the full antenna extent, especially near endpoints.
        // Solver coordinates: z = Z + H above ground (the same offset is used for the antenna overlay).
        var (zOffset,zFromCurrents)=_model!=null ? FieldGeometry.ZOffset(_model,samples) : (0.0,false);
        _zOffset=zOffset; _zFromCurrents=zFromCurrents;
        var endpoints=_model?.Wires.SelectMany(w=>new[] {
            (w.X1,w.Y1,w.Z1+zOffset),(w.X2,w.Y2,w.Z2+zOffset)
        }).ToArray() ?? Array.Empty<(double,double,double)>();
        bool radiated=_radiated;
        _ = Task.Run(() => BuildGrid(samples, freq, plane, groundType, endpoints, extentFactor, radiated))
            .ContinueWith(t => Dispatcher.BeginInvoke(new Action(() =>
            {
                if (revision != _revision) return;
                if (t.IsFaulted || t.IsCanceled || t.Result == null) return;
                _grid = t.Result;
                _stats = null;
                int n=_grid.N;
                _pixels = new byte[n * n * 4];
                _rect = new Int32Rect(0, 0, n, n);
                _bitmap = new WriteableBitmap(n, n, 96, 96, PixelFormats.Bgra32, null);
                UpdateFrame();
                InvalidateVisual();
            })), TaskScheduler.Default);
    }

    public void SetPhase(double degrees)
    {
        if (Math.Abs(_phase - degrees) < 1e-9) return;
        _phase = degrees;
        // Envelope and average Poynting modes are phase independent.
        if (_displayMode != 0) return;
        UpdateFrame();
        InvalidateVisual();
    }

    // 1.5 antenna dimensions beyond EACH projected extreme: the full window is
    // 4 times the larger projected antenna dimension. A wavelength-based floor
    // handles zero-span projections (e.g. a vertical monopole in XY).
    private static double ViewSpan(double extentU,double extentV,double wavelength) =>
        Math.Max(4.0*Math.Max(extentU,extentV),0.6*wavelength);

    private static FieldGrid? BuildGrid(System.Collections.Generic.IReadOnlyList<MininecPulseSolver.FieldSample> samples, double frequency, int plane, int groundType,
        (double X,double Y,double Z)[] endpoints, double extentFactor, bool radiated=false)
    {
        if (frequency <= 0 || !double.IsFinite(frequency)) return null;
        double wavelength = 299.792458 / frequency;
        double k = 2 * Math.PI / wavelength;
        double xmin = double.PositiveInfinity, xmax = double.NegativeInfinity;
        double ymin = double.PositiveInfinity, ymax = double.NegativeInfinity;
        double zmin = double.PositiveInfinity, zmax = double.NegativeInfinity;
        foreach (var a in samples)
        {
            xmin = Math.Min(xmin, a.X); xmax = Math.Max(xmax, a.X);
            ymin = Math.Min(ymin, a.Y); ymax = Math.Max(ymax, a.Y);
            zmin = Math.Min(zmin, a.Z); zmax = Math.Max(zmax, a.Z);
        }
        // Use physical wire endpoints rather than pulse centres for viewport bounds.
        double bxmin=xmin,bxmax=xmax,bymin=ymin,bymax=ymax,bzmin=zmin,bzmax=zmax;
        if(endpoints.Length>0)
        {
            bxmin=endpoints.Min(p=>p.X); bxmax=endpoints.Max(p=>p.X);
            bymin=endpoints.Min(p=>p.Y); bymax=endpoints.Max(p=>p.Y);
            bzmin=endpoints.Min(p=>p.Z); bzmax=endpoints.Max(p=>p.Z);
        }
        double umin=plane==2?bymin:bxmin, umax=plane==2?bymax:bxmax;
        double vmin=plane==0?bymin:bzmin, vmax=plane==0?bymax:bzmax;
        double cu=(umin+umax)*.5, cv=(vmin+vmax)*.5;
        double span=ViewSpan(umax-umin,vmax-vmin,wavelength)*extentFactor;
        // Vertical planes over ground: if the ground line z = 0 would be outside the window (antenna raised by H),
        // keep the antenna in the centre and enlarge the window until the ground is 8 % above the bottom edge.
        // Windows that already show the ground (e.g. H = 0) are left exactly as before.
        if(groundType!=0 && plane!=0 && cv>0 && cv-0.5*span>-0.04*span)
            span=Math.Max(span,cv/(0.5-0.08));
        // Below ground nothing is shown: put the ground line 8 % above the bottom edge instead of the middle,
        // so a large view shows the space above ground (where the 3D-pattern lobes form).
        if(groundType!=0 && plane!=0) cv=Math.Max(cv,(0.5-0.08)*span);
        // The displayed conductors and the sampled field MUST refer to the SAME section.
        // Previous versions displaced XZ/YZ sections by >= 0.6 wavelength, but still
        // drew the antenna at its undisplaced coordinates; that misleading offset
        // looked like a mirrored/incorrect interference field.
        double perp=plane==0?(bzmin+bzmax)*.5:plane==1?(bymin+bymax)*.5:(bxmin+bxmax)*.5;
        int GridSize = GridFor(span, wavelength);
        int count = GridSize * GridSize;
        var below = new bool[count];
        Complex er = NearFieldKernel.GroundPermittivity(frequency, GroundEpsilonR, GroundSigma);
        int images = 0;
        foreach (var a in samples) if (groundType != 0 && a.Z < -1e-9) images++;
        var exr = new double[count]; var exi = new double[count];
        var eyr = new double[count]; var eyi = new double[count];
        var ezr = new double[count]; var ezi = new double[count];
        var hxr=new double[count];var hxi=new double[count];var hyr=new double[count];var hyi=new double[count];var hzr=new double[count];var hzi=new double[count];
        double max = 1e-30,maxH=1e-30,maxPower=1e-30;
        var rowMaxE=new double[GridSize];
        var rowMaxH=new double[GridSize];
        var rowMaxP=new double[GridSize];
        var power=new double[count];
        var distance=new double[count];   // from the antenna centre (for the 1/r compensation)
        var near=new bool[count];         // zone next to the conductors, excluded from the scale statistics
        double maxSegment=0;
        foreach(var a in samples) maxSegment=Math.Max(maxSegment,Math.Sqrt(a.Dx*a.Dx+a.Dy*a.Dy+a.Dz*a.Dz));
        double nearRadius=Math.Max(Math.Max(2.0*maxSegment,0.012*wavelength),1.5*span/GridSize);
        double acx=(bxmin+bxmax)*.5, acy=(bymin+bymax)*.5, acz=(bzmin+bzmax)*.5;
        // Radiated model: the pattern propagated from the origin O (ground point below the antenna over ground,
        // antenna centre in free space); the 1/r compensation is referred to O as well, so dBi = pattern exactly.
        RadiatedFieldTable? table=null;
        if(radiated)
        {
            double oz=groundType!=0 ? 0.0 : acz;
            table=new RadiatedFieldTable(samples,frequency,groundType,acx,acy,oz);
            acz=oz;
        }
        const double eta0=376.730313668;
        // Rows are independent: evaluate on multiple cores without accessing WPF objects.
        Parallel.For(0, GridSize, iy =>
        {
            double localE=1e-30, localH=1e-30, localP=1e-30;
            double v = cv + (.5 - (iy + .5) / GridSize) * span;
            for (int ix = 0; ix < GridSize; ix++)
            {
                double u = cu + ((ix + .5) / GridSize - .5) * span;
                double x = plane==2?perp:u;
                double y = plane==0?v:plane==1?perp:u;
                double z = plane==0?perp:v;
                // e^(+j omega t) convention, free-space short-current-element fields.
                // The dynamic wire current is supplied by the electromagnetic solver.
                // Distances close to the conductor are regularized by the segment length.
                Complex ex=Complex.Zero, ey=Complex.Zero, ez=Complex.Zero;
                Complex hx=Complex.Zero, hy=Complex.Zero, hz=Complex.Zero;
                double nearest=double.PositiveInfinity;
                foreach (var a in samples)
                {
                    double rx=x-a.X, ry=y-a.Y, rz=z-a.Z;
                    if(a.Z>=-1e-9 || groundType==0) nearest=Math.Min(nearest,rx*rx+ry*ry+rz*rz);   // real conductors, not ground images
                    // Same kernel as the 3D volume and the CUDA field; G=2 images use the 3D-pattern ground operator.
                    if(table==null) NearFieldKernel.Add(a,x,y,z,k,wavelength,groundType,er,ref ex,ref ey,ref ez,ref hx,ref hy,ref hz);
                }
                if(table!=null) table.Field(x,y,z,out ex,out ey,out ez,out hx,out hy,out hz);
                int p=iy*GridSize+ix;
                near[p]=Math.Sqrt(nearest)<nearRadius;
                // Below ground the image construction is not the physical field (PEC: zero; real ground:
                // transmitted field, not modelled): masked, excluded from the scale, drawn as ground.
                below[p]=groundType!=0 && z<0;
                distance[p]=Math.Sqrt((x-acx)*(x-acx)+(y-acy)*(y-acy)+(z-acz)*(z-acz));
                exr[p]=ex.Real;exi[p]=ex.Imaginary;
                eyr[p]=ey.Real;eyi[p]=ey.Imaginary;
                ezr[p]=ez.Real;ezi[p]=ez.Imaginary;
                hxr[p]=hx.Real;hxi[p]=hx.Imaginary;
                hyr[p]=hy.Real;hyi[p]=hy.Imaginary;
                hzr[p]=hz.Real;hzi[p]=hz.Imaginary;
                localE=Math.Max(localE,Math.Sqrt(ex.Magnitude*ex.Magnitude+ey.Magnitude*ey.Magnitude+ez.Magnitude*ez.Magnitude));
                localH=Math.Max(localH,Math.Sqrt(hx.Magnitude*hx.Magnitude+hy.Magnitude*hy.Magnitude+hz.Magnitude*hz.Magnitude));
                // Real time-average Poynting vector. Negative radial flow is valid
                // in the reactive field; display signed outward power clipped at zero.
                double sx=0.5*(ey*Complex.Conjugate(hz)-ez*Complex.Conjugate(hy)).Real;
                double sy=0.5*(ez*Complex.Conjugate(hx)-ex*Complex.Conjugate(hz)).Real;
                double sz=0.5*(ex*Complex.Conjugate(hy)-ey*Complex.Conjugate(hx)).Real;
                double nrx=x-(xmin+xmax)*0.5,nry=y-(ymin+ymax)*0.5,nrz=z-(zmin+zmax)*0.5;
                double nr=Math.Sqrt(nrx*nrx+nry*nry+nrz*nrz);
                double outward=nr>1e-12?Math.Max(0,(sx*nrx+sy*nry+sz*nrz)/nr):0;
                power[p]=outward;
                localP=Math.Max(localP,outward);
            }
            rowMaxE[iy]=localE;rowMaxH[iy]=localH;rowMaxP[iy]=localP;
        });
        for(int iy=0;iy<GridSize;iy++)
        {
            max=Math.Max(max,rowMaxE[iy]);
            maxH=Math.Max(maxH,rowMaxH[iy]);
            maxPower=Math.Max(maxPower,rowMaxP[iy]);
        }
        var (farGMax,dmaxDbi,maxElevationDeg)=FarFieldCalibration(samples,frequency,groundType);
        // Cut of the 3D pattern in this plane (1° steps, dBi), for the contour drawn over the map.
        // XZ: directions (cos a, 0, sin a); YZ: (0, cos a, sin a); XY: azimuth cut at the elevation of maximum
        // radiation (over ground the horizon itself is a null).
        double cutElevation=plane==0 ? (groundType!=0 ? maxElevationDeg : 0) : 0;
        var cut=new double[360];
        Parallel.For(0,360,ia=>
        {
            double a=ia*Math.PI/180, ce=Math.Cos(cutElevation*Math.PI/180), se=Math.Sin(cutElevation*Math.PI/180);
            (double nx,double ny,double nz)=plane switch
            {
                1=>(Math.Cos(a),0.0,Math.Sin(a)),
                2=>(0.0,Math.Cos(a),Math.Sin(a)),
                _=>(ce*Math.Cos(a),ce*Math.Sin(a),se)
            };
            double pw=farGMax>0 ? RadiationField.Direction(samples,frequency,groundType,nx,ny,nz).Power : 0;
            cut[ia]=pw>0 && farGMax>0 ? dmaxDbi+10*Math.Log10(pw/(farGMax*farGMax)) : double.NegativeInfinity;
        });
        // Contour origin: the antenna centre; over ground in XZ/YZ the ground point below it (far-field
        // directions over ground start from the ground plane: antenna + image).
        double originU=(umin+umax)*.5, originV=plane==0 ? (vmin+vmax)*.5 : (groundType!=0 ? 0.0 : (vmin+vmax)*.5);
        // Distance from which the map agrees with the 3D pattern within ≈1 dB (far zone): 2·L²/λ, 3 λ and, over
        // ground, ~6 antenna heights (direct and reflected rays must become nearly parallel).
        double lmax=Math.Max(bxmax-bxmin,Math.Max(bymax-bymin,bzmax-bzmin));
        double hCentre=groundType!=0 ? Math.Max(0,(bzmin+bzmax)*.5) : 0;
        double farZone=Math.Max(Math.Max(2*lmax*lmax/wavelength,3*wavelength),6*hCentre);
        return new FieldGrid(exr,exi,eyr,eyi,ezr,ezi,hxr,hxi,hyr,hyi,hzr,hzi,power,max,maxH,maxPower,distance,near,wavelength,
            GridSize,below,images,groundType,span,cu,cv,perp,plane,farGMax,dmaxDbi,cut,cutElevation,originU,originV,farZone,radiated);
    }

    /// <summary>
    /// Radiation pattern over the sphere with the SAME operator as the 3D pattern (RadiationField.Direction, ground
    /// included): maximum |g| of the transverse current moment and Dmax = 4π·|g|²max / ∮|g|² dΩ (dBi). Far from the
    /// antenna r·|E| = η·k/(4π)·|g|, so a 1/r-compensated map can be labelled in dBi with its top at Dmax.
    /// </summary>
    internal static (double GMax,double DmaxDbi,double MaxElevationDeg) FarFieldCalibration(System.Collections.Generic.IReadOnlyList<MininecPulseSolver.FieldSample> samples,
        double frequency,int groundType)
    {
        const int nTheta=91, nPhi=90;                       // 2° in θ, 4° in φ
        double dTheta=Math.PI/(nTheta-1), dPhi=2*Math.PI/nPhi;
        var rowSum=new double[nTheta]; var rowMax=new double[nTheta];
        Parallel.For(0,nTheta,it=>
        {
            double theta=it*dTheta, st=Math.Sin(theta), ct=Math.Cos(theta);
            if(groundType!=0 && ct<-1e-12) return;          // no radiation into the ground
            double weight=(it==0||it==nTheta-1?0.5:1.0)*st*dTheta*dPhi, sum=0, mx=0;
            for(int ip=0;ip<nPhi;ip++)
            {
                double phi=ip*dPhi;
                double power=RadiationField.Direction(samples,frequency,groundType,st*Math.Cos(phi),st*Math.Sin(phi),ct).Power;
                if(!double.IsFinite(power)) continue;
                sum+=power*weight; mx=Math.Max(mx,power);
            }
            rowSum[it]=sum; rowMax[it]=mx;
        });
        double total=0,max2=0; int maxRow=0;
        for(int i=0;i<nTheta;i++){ total+=rowSum[i]; if(rowMax[i]>max2){ max2=rowMax[i]; maxRow=i; } }
        if(!(total>0) || !(max2>0)) return (0,double.NaN,0);
        return (Math.Sqrt(max2),10*Math.Log10(4*Math.PI*max2/total),90.0-maxRow*dTheta*180/Math.PI);
    }

    /// <summary>Phase-independent value of a cell: amplitude |E|/|H| or mean outward flux S, with the 1/r compensation.</summary>
    private double ReferenceValue(int p)
    {
        var g=_grid!;
        double v;
        if(_displayMode==2) v=Math.Max(0,g.Power[p]);
        else
        {
            bool m=_component==1;
            double a=m?g.HxR[p]:g.ExR[p], b=m?g.HxI[p]:g.ExI[p], c=m?g.HyR[p]:g.EyR[p];
            double d=m?g.HyI[p]:g.EyI[p], e=m?g.HzR[p]:g.EzR[p], f=m?g.HzI[p]:g.EzI[p];
            v=Math.Sqrt(a*a+b*b+c*c+d*d+e*e+f*f);
        }
        return v*Compensation(p);
    }
    /// <summary>r in metres (field) or r² (power density); 1 without compensation. Limited at 0.05 λ near the centre.</summary>
    private double Compensation(int p)
    {
        if(!_compensate) return 1;
        double r=Math.Max(_grid!.Distance[p],0.05*_grid.Wavelength);
        return _displayMode==2 ? r*r : r;
    }
    /// <summary>Far field·r in the direction of maximum radiation for the shown quantity (top of the dBi scale).</summary>
    private double AbsoluteReference()
    {
        var g=_grid!;
        if(!_compensate || !(g.FarGMax>0) || !double.IsFinite(g.DmaxDbi)) return 0;
        double k=2*Math.PI/g.Wavelength, eFar=NearFieldKernel.Eta0*k/(4*Math.PI)*g.FarGMax;   // r·|E| at Dmax
        return _displayMode==2 ? eFar*eFar/(2*NearFieldKernel.Eta0) : _component==1 ? eFar/NearFieldKernel.Eta0 : eFar;
    }
    /// <summary>Scale statistics from the phase-independent values outside the near-wire zone (stable during animation).</summary>
    private ScaleStats Stats()
    {
        if(_stats!=null) return _stats;
        var g=_grid!;
        int cells=g.N*g.N;
        var list=new System.Collections.Generic.List<double>(cells);
        for(int p=0;p<cells;p++) if(!g.Near[p] && !g.Below[p]) { double v=ReferenceValue(p); if(v>0 && double.IsFinite(v)) list.Add(v); }
        if(list.Count<16) for(int p=0;p<cells;p++) if(!g.Below[p]){ double v=ReferenceValue(p); if(v>0 && double.IsFinite(v)) list.Add(v); }
        list.Sort();
        double factor=_displayMode==2?10.0:20.0;
        if(list.Count==0) return _stats=new ScaleStats(1,30,new[]{1.0},factor);
        double absolute=AbsoluteReference();
        bool isAbsolute=absolute>0;
        double reference=isAbsolute ? absolute : Math.Max(list[(int)Math.Round((list.Count-1)*.995)],1e-30);
        double floor=Math.Max(list[(int)Math.Round((list.Count-1)*.02)],reference*1e-6);
        double auto=Math.Clamp(factor*Math.Log10(reference/floor),20,60);
        // 2048 quantiles are enough for the equalisation lookup.
        int nq=Math.Min(2048,list.Count); var q=new double[nq];
        for(int i=0;i<nq;i++) q[i]=list[(int)Math.Round((list.Count-1)*(double)i/(nq-1))];
        return _stats=new ScaleStats(reference,auto,q,factor,isAbsolute,isAbsolute?g.DmaxDbi:0);
    }
    private double EffectiveRange(ScaleStats st)=>_dbRange>0?_dbRange:st.AutoRange;
    /// <summary>Colour coordinate 0..1 of a value (already compensated) for the current scale.</summary>
    private double ToScale(double v,ScaleStats st)
    {
        if(!(v>0)) return 0;
        switch(_scale)
        {
            case 1: return Math.Clamp(v/st.Reference,0,1);
            case 2:
            {
                int i=Array.BinarySearch(st.Sorted,v); if(i<0) i=~i;
                return Math.Clamp((double)i/Math.Max(1,st.Sorted.Length-1),0,1);
            }
            default:
            {
                double range=EffectiveRange(st);
                return Math.Clamp((st.DbFactor*Math.Log10(v/st.Reference)+range)/range,0,1);
            }
        }
    }

    private void UpdateFrame()
    {
        if (_grid == null || _bitmap == null) return;
        var st=Stats();
        double angle=_phase*Math.PI/180.0;
        double c=Math.Cos(angle), s=Math.Sin(angle);
        bool magnetic=_component==1;
        var g=_grid;
        int cellCount=g.N*g.N;
        for (int p=0; p<cellCount; p++)
        {
            if(g.Below[p])
            {
                // Ground (below z = 0): no field is shown there.
                int qb=p*4; _pixels[qb]=34; _pixels[qb+1]=40; _pixels[qb+2]=48; _pixels[qb+3]=255;
                continue;
            }
            double v;
            if(_displayMode==0)
            {
                // Instantaneous |Re(F·e^{jφ})|; scaled with the amplitude statistics, so colours do not pulsate.
                double x=(magnetic?g.HxR[p]:g.ExR[p])*c-(magnetic?g.HxI[p]:g.ExI[p])*s;
                double y=(magnetic?g.HyR[p]:g.EyR[p])*c-(magnetic?g.HyI[p]:g.EyI[p])*s;
                double z=(magnetic?g.HzR[p]:g.EzR[p])*c-(magnetic?g.HzI[p]:g.EzI[p])*s;
                v=Math.Sqrt(x*x+y*y+z*z)*Compensation(p);
            }
            else v=ReferenceValue(p);
            double t=ToScale(v,st);
            uint bgra = Palette[Math.Clamp((int)(t * (PaletteSize - 1) + .5), 0, PaletteSize - 1)];
            int q=p*4;
            _pixels[q]=(byte)bgra;
            _pixels[q+1]=(byte)(bgra>>8);
            _pixels[q+2]=(byte)(bgra>>16);
            _pixels[q+3]=255;
        }
        _bitmap.WritePixels(_rect,_pixels,g.N*4,0);
    }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        var bounds=new Rect(0,0,ActualWidth,ActualHeight);
        dc.DrawRectangle(Brushes.Black,null,bounds);
        // Square world-to-screen mapping: never stretch XY geometry with the window aspect ratio.
        double side=Math.Max(1,Math.Min(ActualWidth,ActualHeight)-24);
        var view=new Rect((ActualWidth-side)*.5,(ActualHeight-side)*.5,side,side);
        if (_bitmap != null)
        {
            // Bilinear scaling avoids the expensive high-quality resampling on every frame.
            RenderOptions.SetBitmapScalingMode(this,BitmapScalingMode.Linear);
            dc.DrawImage(_bitmap,view);
        }
        var model=_model;
        if(_showAntennaOverlay && model!=null && model.Wires.Count>0)
        {
            double minU=double.PositiveInfinity,maxU=double.NegativeInfinity;
            double minV=double.PositiveInfinity,maxV=double.NegativeInfinity;
            (double U,double V) UV(double x,double y,double z)=>_plane switch
            {
                1=>(x,z), 2=>(y,z), _=>(x,y)
            };
            foreach(var a in model.Wires)
            {
                var q=UV(a.X1,a.Y1,a.Z1+_zOffset);var r=UV(a.X2,a.Y2,a.Z2+_zOffset);
                minU=Math.Min(minU,Math.Min(q.U,r.U));maxU=Math.Max(maxU,Math.Max(q.U,r.U));
                minV=Math.Min(minV,Math.Min(q.V,r.V));maxV=Math.Max(maxV,Math.Max(q.V,r.V));
            }
            double cu=(minU+maxU)*.5,cv=(minV+maxV)*.5;
            double wavelength=_result!=null&&_result.FrequencyMHz>0?299.792458/_result.FrequencyMHz:1;
            double span=ViewSpan(maxU-minU,maxV-minV,wavelength)*_extentFactor;
            // The overlay uses exactly the window of the computed grid (same centre, span and plane).
            if(_grid is { } fg && fg.Plane==_plane){ cu=fg.Cu; cv=fg.Cv; span=fg.Span; }
            Point Map(double u,double v)=>new(view.Left+(.5+(u-cu)/span)*side,
                view.Top+(.5-(v-cv)/span)*side);
            var under=new Pen(new SolidColorBrush(Color.FromArgb(170,0,0,0)),3);under.Freeze();
            var wirePen=new Pen(Brushes.White,1.4);wirePen.Freeze();
            foreach(var a in model.Wires)
            {
                var a1=UV(a.X1,a.Y1,a.Z1+_zOffset);var a2=UV(a.X2,a.Y2,a.Z2+_zOffset);
                Point u=Map(a1.U,a1.V),v=Map(a2.U,a2.V);
                dc.DrawLine(under,u,v);dc.DrawLine(wirePen,u,v);
            }
        }
        DrawGround(dc,view,side);
        DrawPatternContour(dc,view,side);
        DrawVectors(dc,view,side);
        DrawLegend(dc,view);
    }

    /// <summary>
    /// The 3D-pattern cut of this plane as a polar contour around the origin (antenna centre; over ground the ground
    /// point below it). Radius: the same dB scale as the map (top = Dmax, range = map range); the far part of the map
    /// should lie along this contour.
    /// </summary>
    private void DrawPatternContour(DrawingContext dc,Rect view,double side)
    {
        var g=_grid;
        if(!_showPattern || g==null || !(g.FarGMax>0) || !double.IsFinite(g.DmaxDbi)) return;
        var st=Stats();
        double range=st.Absolute ? EffectiveRange(st) : 30;
        double top=g.DmaxDbi, radiusMax=0.42*g.Span;
        Point Map(double u,double v)=>new(view.Left+(.5+(u-g.Cu)/g.Span)*side,view.Top+(.5-(v-g.Cv)/g.Span)*side);
        var geometry=new StreamGeometry();
        using(var ctx=geometry.Open())
        {
            for(int i=0;i<=360;i++)
            {
                double gain=g.PatternCut[i%360];
                double rr=double.IsFinite(gain) ? Math.Clamp((gain-(top-range))/range,0,1)*radiusMax : 0;
                double a=(i%360)*Math.PI/180;
                var p=Map(g.OriginU+rr*Math.Cos(a),g.OriginV+rr*Math.Sin(a));
                if(i==0) ctx.BeginFigure(p,false,true); else ctx.LineTo(p,true,true);
            }
        }
        geometry.Freeze();
        var under=new Pen(new SolidColorBrush(Color.FromArgb(150,0,0,0)),3.2); under.Freeze();
        var pen=new Pen(Brushes.White,1.5); pen.Freeze();
        dc.DrawGeometry(null,under,geometry); dc.DrawGeometry(null,pen,geometry);
    }

    /// <summary>
    /// Arrows of the field on a coarse lattice: direction = projection of the instantaneous E or H (current phase) or
    /// of the mean Poynting vector (S mode) on the plane; length = the colour coordinate of that cell (same dB/dBi
    /// scale as the map), so arrows are visible over the whole dynamic range. A field mostly perpendicular to the
    /// plane is drawn as ⊙. Size slider: arrow size and lattice pitch together.
    /// </summary>
    private void DrawVectors(DrawingContext dc,Rect view,double side)
    {
        var g=_grid;
        if(!_showVectors || g==null) return;
        var st=Stats();
        double pitch=Math.Max(10,26*_vectorSize);
        int count=(int)Math.Floor(side/pitch);
        if(count<2) return;
        double step=side/count;
        double ph=_phase*Math.PI/180, co=Math.Cos(ph), si=Math.Sin(ph);
        bool magnetic=_component==1;
        var arrows=new StreamGeometry(); var dots=new StreamGeometry();
        using(var ca=arrows.Open())
        using(var cd=dots.Open())
        {
            for(int iy=0;iy<count;iy++)
                for(int ix=0;ix<count;ix++)
                {
                    int gx=Math.Clamp((int)((ix+.5)*step/side*g.N),0,g.N-1), gy=Math.Clamp((int)((iy+.5)*step/side*g.N),0,g.N-1);
                    int p=gy*g.N+gx;
                    if(g.Below[p]) continue;
                    double ax,ay,az;
                    if(_displayMode==2)
                    {
                        var ex=new Complex(g.ExR[p],g.ExI[p]); var ey=new Complex(g.EyR[p],g.EyI[p]); var ez=new Complex(g.EzR[p],g.EzI[p]);
                        var hx=new Complex(g.HxR[p],g.HxI[p]); var hy=new Complex(g.HyR[p],g.HyI[p]); var hz=new Complex(g.HzR[p],g.HzI[p]);
                        ax=.5*(ey*Complex.Conjugate(hz)-ez*Complex.Conjugate(hy)).Real;
                        ay=.5*(ez*Complex.Conjugate(hx)-ex*Complex.Conjugate(hz)).Real;
                        az=.5*(ex*Complex.Conjugate(hy)-ey*Complex.Conjugate(hx)).Real;
                    }
                    else
                    {
                        ax=(magnetic?g.HxR[p]:g.ExR[p])*co-(magnetic?g.HxI[p]:g.ExI[p])*si;
                        ay=(magnetic?g.HyR[p]:g.EyR[p])*co-(magnetic?g.HyI[p]:g.EyI[p])*si;
                        az=(magnetic?g.HzR[p]:g.EzR[p])*co-(magnetic?g.HzI[p]:g.EzI[p])*si;
                    }
                    double mag=Math.Sqrt(ax*ax+ay*ay+az*az);
                    if(!(mag>0)) continue;
                    // Length: the cell's colour coordinate (instantaneous value in the instantaneous mode).
                    double v=_displayMode==0 ? mag*Compensation(p) : ReferenceValue(p);
                    double t=ToScale(v,st);
                    if(t<0.04) continue;
                    (double pu,double pv)=g.Plane switch { 1=>(ax,az), 2=>(ay,az), _=>(ax,ay) };
                    double inPlane=Math.Sqrt(pu*pu+pv*pv);
                    var c=new Point(view.Left+(ix+.5)*step,view.Top+(iy+.5)*step);
                    if(inPlane<0.25*mag)
                    {
                        double rr=1.2+2.3*t*_vectorSize;           // field perpendicular to the plane: ⊙
                        cd.BeginFigure(new Point(c.X+rr,c.Y),false,true);
                        cd.ArcTo(new Point(c.X-rr,c.Y),new Size(rr,rr),0,false,SweepDirection.Clockwise,true,false);
                        cd.ArcTo(new Point(c.X+rr,c.Y),new Size(rr,rr),0,false,SweepDirection.Clockwise,true,false);
                        continue;
                    }
                    double dx=pu/inPlane, dy=-pv/inPlane;                   // screen: v points up
                    double len=step*0.88*Math.Max(0.18,t);
                    var a=new Point(c.X-dx*len*.5,c.Y-dy*len*.5); var b=new Point(c.X+dx*len*.5,c.Y+dy*len*.5);
                    double head=Math.Max(2.5,0.32*len), hc=Math.Cos(0.45), hs=Math.Sin(0.45);
                    var h1=new Point(b.X-head*(dx*hc-dy*hs),b.Y-head*(dy*hc+dx*hs));
                    var h2=new Point(b.X-head*(dx*hc+dy*hs),b.Y-head*(dy*hc-dx*hs));
                    ca.BeginFigure(a,false,false); ca.LineTo(b,true,true);
                    ca.BeginFigure(h1,false,false); ca.LineTo(b,true,true); ca.LineTo(h2,true,true);
                }
        }
        arrows.Freeze(); dots.Freeze();
        var under=new Pen(new SolidColorBrush(Color.FromArgb(170,0,0,0)),2.8){StartLineCap=PenLineCap.Round,EndLineCap=PenLineCap.Round,LineJoin=PenLineJoin.Round};
        var pen=new Pen(Brushes.White,1.2){StartLineCap=PenLineCap.Round,EndLineCap=PenLineCap.Round,LineJoin=PenLineJoin.Round};
        under.Freeze(); pen.Freeze();
        dc.DrawGeometry(null,under,arrows); dc.DrawGeometry(null,pen,arrows);
        dc.DrawGeometry(null,under,dots); dc.DrawGeometry(Brushes.White,null,dots);
    }

    /// <summary>Ground line z = 0 in the vertical planes (the area below it is masked).</summary>
    private void DrawGround(DrawingContext dc,Rect view,double side)
    {
        var g=_grid;
        if(g==null || g.GroundType==0 || g.Plane==0) return;
        double y=view.Top+(.5-(0-g.Cv)/g.Span)*side;
        if(y<view.Top || y>view.Bottom) return;
        var pen=new Pen(new SolidColorBrush(Color.FromRgb(196,150,92)),1.6); pen.Freeze();
        dc.DrawLine(pen,new Point(view.Left,y),new Point(view.Right,y));
        var culture=System.Globalization.CultureInfo.InvariantCulture;
        var t=new FormattedText("земля, z = 0",culture,FlowDirection.LeftToRight,new Typeface("Segoe UI"),10,
            new SolidColorBrush(Color.FromRgb(214,176,120)),1);
        dc.DrawText(t,new Point(view.Left+6,y+3));
    }

    /// <summary>Colour bar with the quantity, the scale and its values.</summary>
    private void DrawLegend(DrawingContext dc,Rect view)
    {
        if(_grid==null) return;
        var st=Stats();
        var g=_grid!;
        // In the free (black) area to the right of the square map when there is room; otherwise over the map.
        double room=ActualWidth-view.Right;
        bool outside=room>=160;
        double w=outside?16:13;
        double left=outside?view.Right+22:Math.Max(4,view.Right-w-56);
        double top=outside?view.Top+40:view.Top+28;
        double h=outside?Math.Min(360,view.Height*.55):Math.Min(220,view.Height*.45);
        double textWidth=outside?Math.Max(80,room-34):Math.Max(80,view.Width*.5);
        for(int i=0;i<96;i++)
        {
            double t=1-i/95.0;
            dc.DrawRectangle(new SolidColorBrush(Vivid(t)),null,new Rect(left,top+i*h/96,w,h/96+1));
        }
        var culture=System.Globalization.CultureInfo.InvariantCulture;
        FormattedText T(string text,double size,Brush? brush=null)
        {
            var ft=new FormattedText(text,culture,FlowDirection.LeftToRight,new Typeface("Segoe UI"),size,brush??Brushes.WhiteSmoke,1);
            ft.MaxTextWidth=textWidth;
            return ft;
        }
        string unit=st.Absolute?"dBi":"дБ";
        string q=_displayMode==2?"S":_component==1?"|H|":"|E|";
        if(_displayMode==0) q=_component==1?"H(t)":"E(t)";
        if(_compensate) q+=_displayMode==2?"·r²":"·r";
        string scale=_scale==1?"линейно":_scale==2?"выравнивание":$"{unit}, {EffectiveRange(st):0} дБ{(_dbRange>0?"":" авто")}";
        var title=T($"{q} · {scale}",outside?12:11);
        dc.DrawText(title,outside?new Point(left,view.Top+6):new Point(Math.Max(4,view.Right-title.Width-6),view.Top+6));
        // Ticks: dBi (relative to Dmax) or dB (relative to P99.5); percent on the linear scale.
        int ticks=outside?7:5;
        for(int i=0;i<ticks;i++)
        {
            double t=1-(double)i/(ticks-1);
            string label;
            if(_scale==1) label=st.Absolute?$"{t*100:0}% Emax":$"{t*100:0}%";
            else if(_scale==2)
            {
                double v=st.Sorted[(int)Math.Round(t*(st.Sorted.Length-1))];
                label=$"{st.TopDb+st.DbFactor*Math.Log10(Math.Max(v,1e-300)/st.Reference):0.#} {unit}";
            }
            else label=$"{st.TopDb+(t-1)*EffectiveRange(st):0.#} {unit}";
            double y=top+(1-t)*h;
            dc.DrawLine(new Pen(Brushes.WhiteSmoke,1),new Point(left+w,y),new Point(left+w+4,y));
            dc.DrawText(T(label,outside?11:10),new Point(left+w+7,y-7));
        }
        // Notes under the bar: scale reference, ground model, grid.
        double y0=top+h+12;
        void Note(string text,Brush? brush=null)
        {
            var ft=T(text,outside?10:9,brush??Brushes.Gainsboro);
            dc.DrawText(ft,outside?new Point(left,y0):new Point(Math.Max(4,view.Right-ft.Width-6),y0));
            y0+=ft.Height+3;
        }
        if(st.Absolute)
            Note($"верх шкалы = Dmax {st.TopDb:0.0} dBi (как 3D ДН); вдали от антенны цвет = ДН в этой плоскости, у проводников — насыщение");
        else if(_compensate)
            Note("0 дБ = P99.5 вне зоны у проводников (Dmax не определён)");
        else
            Note("0 дБ = P99.5 вне зоны у проводников · шкала в dBi — с «Компенсацией 1/r»");
        string ground=g.GroundType switch
        {
            0=>"земля: свободное пространство",
            1=>$"земля: идеальная · изображений {g.Images}",
            _=>$"земля: реальная, Френель ε={GroundEpsilonR:0.#}, σ={GroundSigma.ToString("0.###",culture)} (как 3D ДН) · изображений {g.Images}"
        };
        bool missing=g.GroundType!=0 && g.Images==0;
        if(missing) ground="⚠ земля задана, но изображений нет — поле посчитано БЕЗ земли";
        Note(ground,missing?Brushes.OrangeRed:Brushes.Gainsboro);
        Note($"сетка {g.N}² · {g.Span/g.Wavelength:0.#} λ · {g.N*g.Wavelength/g.Span:0} клеток на λ");
        if(g.Radiated)
            Note(g.GroundType!=0 ? "поле излучения (как ДН): ДН·e^−jkr/r от точки на земле под антенной — ниже горизонта поля нет; ближнее поле — режим «Полное ближнее»"
                                 : "поле излучения (как ДН): ДН·e^−jkr/r от центра антенны; ближнее поле — режим «Полное ближнее»");
        if(g.FarZoneMetres>0 && !g.Radiated)
        {
            bool enough=0.5*g.Span>=g.FarZoneMetres;
            Note(enough ? $"дальняя зона (как 3D ДН, ±1 дБ) — от ≈ {g.FarZoneMetres:0.#} м; край карты {0.5*g.Span:0.#} м"
                        : $"на карте в основном ближняя зона: 3D ДН складывается от ≈ {g.FarZoneMetres:0.#} м, край карты {0.5*g.Span:0.#} м — увеличьте «Обзор ЭМ поля»",
                 enough?Brushes.Gainsboro:Brushes.Khaki);
        }
        if(_showPattern && g.FarGMax>0)
            Note(g.Plane==0 && g.GroundType!=0 ? $"белый контур — срез 3D ДН при угле места {g.PatternElevationDeg:0}°" : "белый контур — срез 3D ДН в этой плоскости");
        if(_zOffset!=0 || _zFromCurrents)
            Note(_zFromCurrents ? $"⚠ высота антенны взята по токам решателя: +{_zOffset:0.###} м (не совпала с H модели)"
                                : $"антенна поднята на H = {_zOffset:0.###} м над землёй (как в расчёте)",
                 _zFromCurrents?Brushes.OrangeRed:Brushes.Gainsboro);
    }

    // Nine-stop vivid palette, identical to the 3D field view.
    private static Color Vivid(double t)
    {
        t=Math.Clamp(t,0,1);
        (byte R,byte G,byte B)[] stops={(8,10,85),(16,55,230),(5,130,255),(0,220,255),(0,235,80),(30,255,0),(255,238,0),(255,135,0),(220,24,30)};
        double q=t*(stops.Length-1); int i=Math.Min(stops.Length-2,(int)q); double a=q-i;
        return Color.FromRgb((byte)(stops[i].R+(stops[i+1].R-stops[i].R)*a),(byte)(stops[i].G+(stops[i+1].G-stops[i].G)*a),(byte)(stops[i].B+(stops[i+1].B-stops[i].B)*a));
    }

}
