﻿using AntennaCalculator.Core;
using Microsoft.Win32;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Controls;

namespace AntennaCalculator.Wpf;

public partial class MainWindow : Window
{
    private MaaModel? _model;
    // Original MAA text of the loaded model: input of the MMANA impedance core.
    private string? _maaText;
    // Pulses used by the MMANA core for the last shown result (0 = core not used).
    private int _mmanaPulses;
    private CancellationTokenSource? _calculationCts;
    private IReadOnlyList<MininecPulseSolver.Result> _lastSweep = Array.Empty<MininecPulseSolver.Result>();
    // Last single-frequency result (for a one-point Touchstone file when no sweep exists).
    private MininecPulseSolver.Result? _lastResult;
    private readonly DispatcherTimer _fieldPlayTimer = new() { Interval = TimeSpan.FromMilliseconds(80) };
    public MainWindow()
    {
        InitializeComponent();
        Title=$"Antenna Calculator PRO · Windows v{AppInfo.Version} · UA1CFM";
        _fieldPlayTimer.Tick += (_,__) => AdvanceFieldPhase();
        VnaView.StatusChanged += text => StatusText.Text = text;
        VnaView.BackRequested += () => SetInstrumentMode(false);
        // F1 = help for the current view tab.
        PreviewKeyDown += (_,e) =>
        {
            if(e.Key==System.Windows.Input.Key.F1){ OpenHelp(ContextHelpSection()); e.Handled=true; }
            else if(e.Key==System.Windows.Input.Key.Escape && _instrumentMode){ SetInstrumentMode(false); e.Handled=true; }
            // F11: full screen for the EM field view (only while it is shown).
            else if(e.Key==System.Windows.Input.Key.F11 && (FieldMap.IsVisible || FieldVolume.IsVisible || _fieldFullscreen!=null)){ ToggleFieldFullscreen(); e.Handled=true; }
        };
        Loaded += (_,__) => RestoreUiSettings();
    }

    private static string LayoutPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"UA1CFM","AntennaCalculator_Windows_layout.txt");
    private void RestoreUiSettings()
    {
        try
        {
            if(!File.Exists(LayoutPath))return;
            var parts=File.ReadAllText(LayoutPath).Split(';');
            if(parts.Length>=1 && double.TryParse(parts[0],NumberStyles.Float,CultureInfo.InvariantCulture,out double width))
                LeftColumn.Width=new GridLength(Math.Clamp(width,235,Math.Max(235,ActualWidth-390)));
            if(parts.Length>=2 && double.TryParse(parts[1],NumberStyles.Float,CultureInfo.InvariantCulture,out double zoom))PatternZoomSlider.Value=Math.Clamp(zoom,.6,3);
            if(parts.Length>=4 && double.TryParse(parts[3],NumberStyles.Float,CultureInfo.InvariantCulture,out double speed))FieldSpeedSlider.Value=Math.Clamp(speed,.25,4);
            if(parts.Length>=5)FieldComponentBox.SelectedIndex=parts[4]=="1"?1:0;
            if(parts.Length>=6)PatternCenterCheck.IsChecked=parts[5]!="0";
            if(parts.Length>=7 && double.TryParse(parts[6],NumberStyles.Float,CultureInfo.InvariantCulture,out double infoHeight))
                LeftInfoRow.Height=new GridLength(Math.Clamp(infoHeight,125,Math.Max(125,ActualHeight-370)));
        }
        catch(Exception){/* malformed settings should never block startup */}
    }
    private void Window_Closing(object? sender,System.ComponentModel.CancelEventArgs e)
    {
        // Normal layout before the window layout is saved (the left panel width must not be stored as 0).
        SetInstrumentMode(false);
        // LiteVNA: stop sweeping, return the instrument to normal mode and close the COM port.
        try { VnaView.Shutdown(); } catch { }
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LayoutPath)!);
            File.WriteAllText(LayoutPath,string.Join(";",LeftColumn.ActualWidth.ToString("R",CultureInfo.InvariantCulture),
                PatternZoomSlider.Value.ToString("R",CultureInfo.InvariantCulture),"0",
                FieldSpeedSlider.Value.ToString("R",CultureInfo.InvariantCulture),FieldComponentBox.SelectedIndex.ToString(CultureInfo.InvariantCulture),PatternCenterCheck.IsChecked==true?"1":"0",LeftInfoRow.ActualHeight.ToString("R",CultureInfo.InvariantCulture)));
        }
        catch(Exception){/* settings are optional */}
    }
    private void PatternZoom_Changed(object sender,RoutedPropertyChangedEventArgs<double> e)
    {
        if(PatternZoomText!=null)PatternZoomText.Text=$"{e.NewValue:0.00}×";
        GeometryPreview?.SetPatternScale(e.NewValue);
    }

    private void MeshOptions_Changed(object sender,RoutedEventArgs e)
    {
        if(GeometryPreview==null)return;
        GeometryPreview.SetPatchMode(PatchModeBox?.SelectedIndex ?? 2);
        GeometryPreview.SetAntennaOverlay(AntennaOverlayCheck?.IsChecked==true);
        GeometryPreview.SetSphereVisible(SphereCheck?.IsChecked==true);
        GeometryPreview.SetMeshStep(MeshStepBox?.SelectedIndex switch { 0=>1, 1=>2, 2=>5, 3=>10, 4=>15, _=>2 });
        GeometryPreview.SetTranslucent(GlassCheck?.IsChecked==true);
        GeometryPreview.SetAngleAxes(AngleAxesCheck?.IsChecked==true);
        FieldMap?.SetAntennaOverlay(AntennaOverlayCheck?.IsChecked==true);
        FieldVolume?.SetAntennaOverlay(AntennaOverlayCheck?.IsChecked==true);
    }

    private void PatternOpacity_Changed(object sender,RoutedPropertyChangedEventArgs<double> e)
    {
        if(PatternOpacityText!=null) PatternOpacityText.Text=$"{e.NewValue:0}%";
        GeometryPreview?.SetPatternOpacity(e.NewValue/100.0);
    }

    private void FieldExtent_Changed(object sender,SelectionChangedEventArgs e)
    {
        if(FieldMap==null || FieldExtentBox==null)return;
        // 0% = existing viewport, +100% doubles, +500% = ×6 of the covered region.
        // Negative values progressively zoom in, −100% = half the current span.
        int percent=(FieldExtentBox.SelectedIndex-4)*25;
        double factor=percent>=0?1.0+percent/100.0:1.0/(1.0-percent/100.0);
        FieldMap.SetExtentFactor(factor);
        FieldVolume?.SetExtentFactor(factor);
    }

    private void FieldMode_Changed(object sender,SelectionChangedEventArgs e)
    {
        if(FieldMap!=null && FieldModeBox!=null)
            FieldMap.SetDisplayMode(FieldModeBox.SelectedIndex);
        if(FieldVolume!=null && FieldModeBox!=null)
            FieldVolume.SetDisplayMode(FieldModeBox.SelectedIndex);
    }

    private void FieldComponent_Changed(object sender,SelectionChangedEventArgs e)
    {
        if(FieldMap!=null && FieldComponentBox!=null)FieldMap.SetComponent(FieldComponentBox.SelectedIndex);
        if(FieldVolume!=null && FieldComponentBox!=null)FieldVolume.SetComponent(FieldComponentBox.SelectedIndex);
    }
    private void FieldSpeed_Changed(object sender,RoutedPropertyChangedEventArgs<double> e)
    {
        if(FieldSpeedText!=null)FieldSpeedText.Text=$"{e.NewValue:0.0}×";
        _fieldPlayTimer.Interval=TimeSpan.FromMilliseconds(Math.Clamp(80/e.NewValue,16,320));
    }

    private void FieldPlane_Changed(object sender, SelectionChangedEventArgs e)
    {
        if(FieldMap!=null && FieldPlaneBox!=null)
            FieldMap.SetPlane(FieldPlaneBox.SelectedIndex);
    }

    private void FieldQuality_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (FieldVolume != null && FieldQualityBox != null)
            FieldVolume.SetQuality(FieldQualityBox.SelectedIndex);
    }

    private void FieldBounds_Changed(object sender, RoutedEventArgs e)
    {
        if (FieldVolume != null && FieldBoundsCheck != null)
            FieldVolume.SetVolumeBounds(FieldBoundsCheck.IsChecked == true);
    }

    private void FieldStyle_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (FieldVolume == null || FieldStyleBox == null) return;
        FieldVolume.SetVolumeStyle(FieldStyleBox.SelectedIndex);
        bool mip = FieldStyleBox.SelectedIndex == 2;              // MIP has no opacity
        if (FieldDensitySlider != null) FieldDensitySlider.IsEnabled = !mip && FieldViewBox?.SelectedIndex == 1;
    }

    private void FieldScale_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (FieldScaleBox == null) return;
        FieldMap?.SetScale(FieldScaleBox.SelectedIndex);
        FieldVolume?.SetLogScale(FieldScaleBox.SelectedIndex != 1);      // equalisation is shown as dB in 3D
    }

    private void FieldDbRange_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (FieldDbRangeBox == null) return;
        double range = FieldDbRangeBox.SelectedIndex switch { 0 => 10.0, 1 => 20.0, 3 => 40.0, 4 => 60.0, _ => 30.0 };
        FieldVolume?.SetDbRange(range);
        FieldMap?.SetDbRange(FieldDbRangeBox.SelectedIndex == 2 ? 0 : range);   // 2D «Авто»: from the map itself
    }

    private void FieldModel_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (FieldModelBox == null) return;
        bool radiated = FieldModelBox.SelectedIndex != 1;
        FieldMap?.SetFieldModel(radiated);
        FieldVolume?.SetFieldModel(radiated);
    }

    private void FieldVectors_Changed(object sender, RoutedEventArgs e) => ApplyFieldVectors();
    private void FieldVectorSize_Changed(object sender, RoutedPropertyChangedEventArgs<double> e) => ApplyFieldVectors();
    /// <summary>Arrows of the field vectors: one switch and size for the 2D map and the 3D volume.</summary>
    private void ApplyFieldVectors()
    {
        if (FieldVectorsCheck == null || FieldVectorSizeSlider == null) return;
        bool on = FieldVectorsCheck.IsChecked == true;
        FieldVectorSizeSlider.IsEnabled = on;
        FieldMap?.SetVectors(on, FieldVectorSizeSlider.Value);
        FieldVolume?.SetVectors(on, FieldVectorSizeSlider.Value);
    }

    private void FieldPattern_Changed(object sender, RoutedEventArgs e)
    {
        if (FieldMap != null && FieldPatternCheck != null) FieldMap.SetPatternContour(FieldPatternCheck.IsChecked == true);
    }

    private void FieldDistance_Changed(object sender, RoutedEventArgs e)
    {
        if (FieldDistanceCheck == null) return;
        FieldMap?.SetDistanceCompensation(FieldDistanceCheck.IsChecked == true);
        FieldVolume?.SetDistanceCompensation(FieldDistanceCheck.IsChecked == true);
    }

    private void FieldDensity_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        FieldVolume?.SetDensity(e.NewValue);
    }

    private void FieldView_Changed(object sender, SelectionChangedEventArgs e)
    {
        bool is3D = FieldViewBox?.SelectedIndex == 1;
        // 3D-only controls.
        foreach (var element in new FrameworkElement?[] { FieldStyleBox, FieldStyleLabel, FieldDensityLabel })
            if (element != null) element.IsEnabled = is3D;
        if (FieldDistanceCheck != null) FieldDistanceCheck.IsEnabled = true;           // 2D and 3D
        if (FieldPatternCheck != null) FieldPatternCheck.IsEnabled = !is3D;
        if (FieldQualityBox != null) FieldQualityBox.IsEnabled = is3D;                // 3D only
        if (FieldBoundsCheck != null) FieldBoundsCheck.IsEnabled = is3D;
        if (FieldDensitySlider != null) FieldDensitySlider.IsEnabled = is3D && FieldStyleBox?.SelectedIndex != 2;
        if(FieldMap!=null) FieldMap.Visibility = is3D ? Visibility.Collapsed : Visibility.Visible;
        if(FieldVolume!=null) FieldVolume.Visibility = is3D ? Visibility.Visible : Visibility.Collapsed;
        // Synchronize the newly visible view after skipping its hidden frames.
        if(FieldPhaseSlider!=null)
        {
            if(is3D) FieldVolume?.SetPhase(FieldPhaseSlider.Value);
            else FieldMap?.SetPhase(FieldPhaseSlider.Value);
        }
        if(FieldPlaneBox!=null) FieldPlaneBox.IsEnabled = !is3D;
        if(FieldPlaneLabel!=null) FieldPlaneLabel.Opacity = is3D ? 0.55 : 1.0;
    }

    private void FieldPhaseSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if(FieldPhaseText!=null)FieldPhaseText.Text=$"{e.NewValue:0}°";
        // Do not redraw the hidden visualization on every animation tick.
        if(FieldViewBox?.SelectedIndex == 1)
        {
            if(FieldVolume!=null)FieldVolume.SetPhase(e.NewValue);
        }
        else
        {
            if(FieldMap!=null)FieldMap.SetPhase(e.NewValue);
        }
    }

    private double SelectedFieldStep()
    {
        if(FieldStepBox?.SelectedItem is ComboBoxItem item &&
           double.TryParse(item.Content?.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out double step) &&
           step > 0) return step;
        return 5;
    }
    private void AdvanceFieldPhase()
    {
        if(FieldPhaseSlider==null)return;
        double next=FieldPhaseSlider.Value+SelectedFieldStep();
        while(next>360)next-=360;
        FieldPhaseSlider.Value=next;
    }
    private void FieldPlayButton_Click(object sender, RoutedEventArgs e)
    {
        if(_fieldPlayTimer.IsEnabled)
        {
            _fieldPlayTimer.Stop();
            if(FieldPlayButton!=null)FieldPlayButton.Content="▶  Пуск";
        }
        else
        {
            _fieldPlayTimer.Start();
            if(FieldPlayButton!=null)FieldPlayButton.Content="⏸  Пауза";
        }
    }
    // Stop = stop and return to the start frame (phase 0°); pause keeps the current phase.
    private void FieldStopButton_Click(object sender, RoutedEventArgs e)
    {
        _fieldPlayTimer.Stop();
        if(FieldPlayButton!=null)FieldPlayButton.Content="▶  Пуск";
        if(FieldPhaseSlider!=null)FieldPhaseSlider.Value=0;
    }

    private void OpenButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog {
            Title = "Открыть проект MMANA", Filter = "MMANA antennas (*.maa)|*.maa|Все файлы (*.*)|*.*",
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) == true) LoadModel(dialog.FileName);
    }

    private void SampleButton_Click(object sender, RoutedEventArgs e)
    {
        string path = Path.Combine(AppContext.BaseDirectory, "Samples", "TWIND.MAA");
        if (!File.Exists(path)) { MessageBox.Show(this, "Файл примера не найден: " + path); return; }
        LoadModel(path);
    }

    private void StackSampleButton_Click(object sender, RoutedEventArgs e)
    {
        string path = Path.Combine(AppContext.BaseDirectory, "Samples", "fixture_stack_2x.maa");
        if (!File.Exists(path)) { MessageBox.Show(this, "Файл примера не найден: " + path); return; }
        LoadModel(path);
    }

    private void LoadModel(string path)
    {
        try
        {
            MaaModel m = MaaParser.ParseFile(path);
            string? text;
            try { text = MmanaReferenceEngine.Decode(File.ReadAllBytes(path)); } catch { text = null; }
            ShowModel(m, text, path, edited: false);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка чтения MAA", MessageBoxButton.OK, MessageBoxImage.Error);
            StatusText.Text = "Не удалось открыть файл: " + Path.GetFileName(path);
        }
    }


    /// <summary>Shows a model read from a file or produced by editing the wire geometry (text = its MAA text).</summary>
    private void ShowModel(MaaModel m, string? text, string path, bool edited)
    {
        _maaText = text;
        _modelEdited = edited;
        _calculationCts?.Cancel();
        _fieldPlayTimer.Stop();
        if(FieldPlayButton!=null)FieldPlayButton.Content="▶  Пуск";
        _model = m;
        // Начальный диапазон sweep: +/- 2% вокруг частоты модели; поля можно изменять вручную.
        if(m.FrequencyMHz>0 && SweepStartMHzBox!=null && SweepStopMHzBox!=null)
        {
            SweepStartMHzBox.Text=(m.FrequencyMHz*0.98).ToString("0.######",CultureInfo.CurrentCulture);
            SweepStopMHzBox.Text=(m.FrequencyMHz*1.02).ToString("0.######",CultureInfo.CurrentCulture);
        }
        _lastSweep=Array.Empty<MininecPulseSolver.Result>();
        VnaView.ModelFrequencyMHz=m.FrequencyMHz;
        VnaView.SetModelTrace(null);
        SmithView.Clear();CartesianView.Clear();
        FieldMap.SetResult(null);
        FieldVolume.SetResult(null);
        GeometryPreview.PatternResult=null;
        Pattern2D.SetResult(null,0);
        PortsGrid.ItemsSource=null;
        PortPowerText.Text="Расчёт портов ещё не выполнялся.";
        DiagnosticText.Text="";
        MethodText.Text="";
        UpdateGroundDiagnostic();
        ImpedanceText.Text="R + jX: —";
        SwrText.Text="КСВ: —";
        ResidualText.Text="Невязка: —";
        TitleText.Text = m.Title;
        FileText.Text = Path.GetFileName(path) + (edited ? " · изменено" : "");
        FrequencyText.Text = m.FrequencyMHz > 0 ? m.FrequencyMHz.ToString("0.######", CultureInfo.InvariantCulture) + " MHz" : "не задана";
        WiresText.Text = m.Wires.Count.ToString("N0");
        SourcesText.Text = m.Sources.Count.ToString("N0");
        LoadsText.Text = m.Loads.Count.ToString("N0");
        DetailsText.Text = $"λ = {(m.FrequencyMHz > 0 ? m.WavelengthMetres.ToString("0.###") + " м" : "—")}   ·   ΣL = {m.TotalWireLengthMetres:0.###} м   ·   Z₀ = {m.ReferenceOhms:0.##} Ω\n" +
            GroundSummary(m) +
            (m.HasCompactStack ? $"\nStack {m.StackHorizontal}×{m.StackVertical}" + (m.StackExpanded ? "" : " · геометрия НЕ развёрнута") : "");
        BindWireEditor(m);
        SourcesGrid.ItemsSource = m.Sources;
        LoadsGrid.ItemsSource = m.Loads;
        WarningsText.Text = m.Warnings.Count == 0 ? "Замечаний к прочитанным строкам нет. Это НЕ подтверждение физической корректности модели." : string.Join("\n\n", m.Warnings.Select((s,i)=>$"{i+1}. {s}"));
        GeometryPreview.Model = m;
        FieldMap.SetModel(m);
        FieldVolume.SetModel(m);
        GeometryPreview.Fit();
        StatusText.Text = $"Загружено {m.Wires.Count} проводников · {m.Sources.Count} источников · {m.Loads.Count} нагрузок · предупреждений: {m.Warnings.Count}" +
            (m.GroundType is 2 or -1 ? " · G=2: для пробного R+jX нужна отметка PEC-приближения" : "") +
            (m.Wires.Any(w=>w.RadiusMetres==0) ? $" · изоляторов R=0: {m.Wires.Count(w=>w.RadiusMetres==0)}" : "");
    }

    private MininecPulseSolver.RealEarthMode SelectedGroundMode() =>
        _model?.GroundType is 2 or -1
            ? MininecPulseSolver.RealEarthMode.MmanaPecCurrentApproximation
            : MininecPulseSolver.RealEarthMode.Strict;

    // G and H come from the imported MAA. The finite-earth impedance model is not implemented.
    // Fresnel visualization uses explicit fixed defaults, not imaginary MAA parameters.
    private const double DisplayGroundEpsilonR=13.0;
    private const double DisplayGroundSigma=0.005;
    private static string GroundSummary(MaaModel m) => m.GroundType switch
    {
        1 => $"Земля: PEC · H = {m.AddHeightMetres:0.###} м",
        2 or -1 => $"Земля: реальная (PEC-приближение) · H = {m.AddHeightMetres:0.###} м",
        _ => "Свободное пространство"
    };

    // One short caveat for G=2: the finite-earth losses are not part of the matrix.
    private string GroundCaveat() =>
        _model?.GroundType is 2 or -1 ? "G=2: PEC-приближение, потери реальной земли не учтены." : "";

    private void UpdateGroundDiagnostic()
    {
        if(_model==null || GroundInfoText==null)return;
        // Normalize tabs / repeated spaces of the MAA record: "800,\t80,\t2.0,\t4" -> "800, 80, 2.0, 4".
        string record=System.Text.RegularExpressions.Regex.Replace(_model.SegmentationRecord ?? "", @"\s+", " ").Trim();
        GroundInfoText.Text=record.Length>0 ? $"Сегментация: {record}" : "";
        // The ground approximation is already stated in the model summary; no extra warning line.
        if(DiagnosticText==null)return;
        DiagnosticText.Text="";
    }

    // Linear progress reflects iterations consumed, NOT convergence achieved.
    // Convergence is indicated exclusively by the verified true residual.
    private static readonly Regex SolverIterationPattern = new(@"(?:FGMRES(?: CHECKPOINT| АВТОПРОДЛЕНИЕ)?\s*:?\s*|итерации=)(?<step>\d+)\s*/\s*(?<limit>\d+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex SolverStepPattern = new(@"итерации=(?<step>\d+)", RegexOptions.Compiled);
    private static readonly Regex SolverResidualPattern = new(@"(?:истинная невязка|true=)(?:\s*)(?<res>[0-9.,]+E[+-]\d+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    // Compact stage telemetry reuses the existing progress bar and its single detail line.
    private readonly System.Diagnostics.Stopwatch _stageClock = new();
    private readonly DispatcherTimer _stageTicker = new() { Interval = TimeSpan.FromSeconds(1) };
    private string _stageName = "";
    private string _stageDetail = "";
    private void StartStage(string name,string detail="")
    {
        _stageName=name;_stageDetail=detail;_stageClock.Restart();
        SolverProgressTitle.Text=name;
        SolverProgressPercent.Text="…";
        SolverProgressBar.IsIndeterminate=false;
        SolverProgressBar.Value=0;
        SolverResidualLabel.Text=detail;
        StatusText.Text=name + (detail.Length>0 ? " · "+detail : "");
        UpdateStageClock();
    }
    private void UpdateStageClock()
    {
        if(!_stageClock.IsRunning)return;
        string elapsed=FormatDuration(_stageClock.Elapsed);
        SolverResidualLabel.Text=$"{_stageDetail}{(_stageDetail.Length>0 ? " · " : "")}время {elapsed}";
    }
    private void StopStageClock(){_stageTicker.Stop();_stageClock.Stop();SolverProgressBar.IsIndeterminate=false;}
    private void ResetSolverProgress()
    {
        SolverProgressPanel.Visibility=Visibility.Visible;
        SolverProgressBar.IsIndeterminate=false;
        SolverProgressTitle.Text="MININEC · итерации";
        SolverProgressBar.Value=0;
        SolverProgressPercent.Text="0%";
        SolverResidualLabel.Text="Ожидание первой проверки невязки. Цель ≤ 2×10⁻⁷";
    }
    // Batch progress in the existing progress panel: bar, "37.5% (913/2435)" and a status line
    // with the current file, OK/error counts, elapsed time and an estimate of the remaining time.
    private void SetBatchProgress(int done,int total,string current,int ok,int failed,TimeSpan elapsed)
    {
        double fraction=total>0?Math.Clamp(100.0*done/total,0,100):0;
        SolverProgressBar.Value=fraction;
        SolverProgressPercent.Text=$"{fraction:0.0}% ({done}/{total})";
        string remaining=done>0 && done<total
            ? $" · осталось ≈ {FormatDuration(TimeSpan.FromSeconds(elapsed.TotalSeconds/done*(total-done)))}" : "";
        SolverResidualLabel.Text=$"{current} · OK {ok}, ошибок {failed} · прошло {FormatDuration(elapsed)}{remaining}";
    }

    private static string FormatDuration(TimeSpan t) =>
        t.TotalHours>=1 ? $"{(int)t.TotalHours}:{t.Minutes:00}:{t.Seconds:00}" : $"{t.Minutes}:{t.Seconds:00}";

    private void UpdateSolverProgress(string message)
    {
        var m=SolverIterationPattern.Match(message);
        if(m.Success && int.TryParse(m.Groups["step"].Value,out int step) &&
           int.TryParse(m.Groups["limit"].Value,out int limit) && limit>0)
        {
            double fraction=Math.Clamp(100.0*step/limit,0,100);
            SolverProgressBar.IsIndeterminate=false;
            SolverProgressTitle.Text="MININEC · итерации";
            SolverProgressBar.Value=fraction;
            SolverProgressPercent.Text=$"{fraction:0.0}% ({step}/{limit})";
        }
        var residualMatch=SolverResidualPattern.Match(message);
        if(residualMatch.Success && double.TryParse(residualMatch.Groups["res"].Value.Replace(',','.'),NumberStyles.Float,CultureInfo.InvariantCulture,out var residual))
        {
            SolverResidualLabel.Text=$"Истинная невязка: {residual:E3} · цель ≤ 2,000E-007";
        }
    }

    /// <summary>Stage progress of the MMANA core (matrix fill, LU, GPU LU, back substitution).</summary>
    private void UpdateMmanaProgress(MmanaReferenceEngine.MmanaProgress p)
    {
        if(p.Total<=0) return;
        double percent=Math.Clamp(100.0*p.Done/p.Total,0,100);
        _stageDetail=$"{p.Stage}: {p.Done}/{p.Total}";
        SolverProgressBar.IsIndeterminate=false;
        SolverProgressBar.Value=percent;
        SolverProgressTitle.Text=$"MMANA · {p.Stage}";
        SolverProgressPercent.Text=$"{percent:0.0}%";
        UpdateStageClock();
    }

    private void StageTick(object? sender,EventArgs e)
    {
        if(_stageClock.IsRunning && _stageName.StartsWith("MMANA",StringComparison.Ordinal)) UpdateStageClock();
        else if(_stageClock.IsRunning && _stageDetail.Length>0 && !SolverResidualLabel.Text.Contains("время"))
            SolverResidualLabel.Text+=$" · время {FormatDuration(_stageClock.Elapsed)}";
    }

    private async void Calculate_Click(object sender, RoutedEventArgs e)
    {
        if(_model==null){MessageBox.Show(this,"Сначала откройте MAA.");return;}
        MaaModel model=_model;
        if(_calculationCts!=null)return;
        using var cts=new CancellationTokenSource();_calculationCts=cts;
        CalculateButton.IsEnabled=false;SweepButton.IsEnabled=false;CancelButton.IsEnabled=true;
        ResetSolverProgress();
        var watch=System.Diagnostics.Stopwatch.StartNew();
        _stageTicker.Tick+=StageTick;
        _stageTicker.Start();
        var progress=new Progress<string>(message=>
        {
            if(_calculationCts!=cts)return;
            _stageDetail=message;
            StatusText.Text=message;
            UpdateSolverProgress(message);
            // Keep the exact solver-reported residual; append elapsed time only on the periodic tick.
        });
        try
        {
            var mode=SelectedGroundMode();
            string? maaText=_maaText;double fCalc=model.FrequencyMHz;
            StartStage("MMANA · токи", "решение матрицы, затем ДН");
            // The MMANA core is authoritative for R+jX, complex currents and patterns.
            // Do not solve the same large antenna twice when this core already supports it.
            var coreProgress=new Progress<MmanaReferenceEngine.MmanaProgress>(p=>{ if(_calculationCts==cts) UpdateMmanaProgress(p); });
            var applied=await Task.Run(()=>ApplyMmanaCore(model,null,fCalc,maaText,cts.Token,coreProgress),cts.Token);
            cts.Token.ThrowIfCancellationRequested();
            string? coreError=null;
            if(applied.Result==null)
            {
                coreError=applied.CoreError;
                StartStage("MININEC · резерв", "ядро MMANA: "+(coreError ?? "не поддержало модель"));
                MininecPulseSolver.Result baseResult;
                baseResult=await Task.Run(()=>MininecPulseSolver.Solve(model,cts.Token,realEarthMode:mode,progress:progress),cts.Token);
                applied=(baseResult,0,"MININEC · резерв",coreError);
            }
            cts.Token.ThrowIfCancellationRequested();
            var result=applied.Result ?? throw new InvalidOperationException("Модель не удалось рассчитать.");
            _mmanaPulses=applied.Pulses;
            StartStage("ДН · подготовка", "построение полевых данных и графиков");
            ShowResult(result,model.ReferenceOhms);
            _lastResult=result;
            FieldMap.SetResult(result);
            FieldVolume.SetResult(result);
            GeometryPreview.PatternResult=result;
            UpdatePattern2D(result,model);
            DiagnosticText.Text="";
            if(result.ROhm>0)
            {
                SmithView.SetReferenceOhms(model.ReferenceOhms);
                SmithView.SetPoint(result.Reflection(model.ReferenceOhms),model.FrequencyMHz);
            }
            else SmithView.Clear();
            StopStageClock();
            SolverProgressBar.Value=100;SolverProgressPercent.Text="100%";
            SolverProgressTitle.Text="Расчёт завершён";
            SolverResidualLabel.Text=$"Готово · {applied.Backend} · {FormatDuration(watch.Elapsed)} · {(_mmanaPulses>0 ? $"{_mmanaPulses} имп. MMANA" : $"{result.PulseCount} имп. MININEC")}";
            if(coreError!=null) DiagnosticText.Text=$"Ядро MMANA не посчитало модель ({coreError}) — показан результат резервного MININEC.";
            StatusText.Text=_mmanaPulses>0
                ? $"Ядро MMANA: R+jX, токи и ДН · {_mmanaPulses} импульсов · {watch.Elapsed.TotalSeconds:0} с"
                : $"MININEC: {result.PulseCount} импульсов; {result.JunctionCount} узлов; {result.LinearSolver}; {watch.Elapsed.TotalSeconds:0} с";
        }
        catch(OperationCanceledException){StatusText.Text="Расчёт остановлен пользователем.";SolverResidualLabel.Text="Остановлено пользователем · сходимость не подтверждена";}
        catch(Exception ex){StatusText.Text="MININEC: " + ex.Message;DiagnosticText.Text=ex.Message;SolverResidualLabel.Text="Расчёт не завершён · достоверная сходимость не подтверждена";}
        finally{StopStageClock();_stageTicker.Tick-=StageTick;_calculationCts=null;CalculateButton.IsEnabled=true;SweepButton.IsEnabled=true;CancelButton.IsEnabled=false;}
    }
    private async void Sweep_Click(object sender, RoutedEventArgs e)
    {
        if(_model==null){MessageBox.Show(this,"Сначала откройте MAA.");return;}
        if(_calculationCts!=null)return;
        MaaModel model=_model;double f0=model.FrequencyMHz;
        if(f0<=0){MessageBox.Show(this,"Частота должна быть больше нуля.");return;}
        static bool ReadMHz(string? input,out double mhz)
        {
            string value=(input??"").Trim().Replace(',', '.');
            return double.TryParse(value,NumberStyles.Float,CultureInfo.InvariantCulture,out mhz)
                && double.IsFinite(mhz) && mhz>0;
        }
        if(!ReadMHz(SweepStartMHzBox.Text,out double frequencyStart) ||
           !ReadMHz(SweepStopMHzBox.Text,out double frequencyStop) || frequencyStop<=frequencyStart)
        {
            MessageBox.Show(this,"Укажите корректный диапазон в МГц: начало > 0, конец > начала.",
                "Частотное моделирование",MessageBoxButton.OK,MessageBoxImage.Warning);
            return;
        }
        if(frequencyStop/frequencyStart>10.0)
        {
            if(MessageBox.Show(this,"Диапазон превышает 10:1. Расчёт может занять очень много времени, а точность сегментации необходимо проверить. Продолжить?",
                "Широкий диапазон",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        }
        using var cts=new CancellationTokenSource();_calculationCts=cts;
        CalculateButton.IsEnabled=false;SweepButton.IsEnabled=false;CancelButton.IsEnabled=true;
        _lastSweep=Array.Empty<MininecPulseSolver.Result>();SmithView.Clear();CartesianView.Clear();
        var output=new List<MininecPulseSolver.Result>();
        var mode=SelectedGroundMode();
        if(model.Wires.Count>=2 && MininecSegmentation.Parse(model.SegmentationRecord).Dm1>=3000)
        {
            var response=MessageBox.Show(this,
                "Модель имеет очень мелкую сегментацию. до 1001 полного матричного расчёта могут занять много времени и памяти. Продолжить?",
                "Большой Smith Sweep",MessageBoxButton.YesNo,MessageBoxImage.Warning);
            if(response!=MessageBoxResult.Yes)
            {
                _calculationCts=null;CalculateButton.IsEnabled=true;SweepButton.IsEnabled=true;CancelButton.IsEnabled=false;
                StatusText.Text="Smith sweep отменён до начала вычислений.";
                return;
            }
        }
        const int maximumSamples=1001;
        const int maximumDepth=9;
        // Chord size and true midpoint deviation are measured in the complex reflection plane.
        const double maxGammaChord=0.075;
        const double maxMidpointDeviation=0.008;
        var progress=new Progress<string>(message=>{if(_calculationCts==cts)DiagnosticText.Text=message;});
        var samples=new SortedDictionary<double,MininecPulseSolver.Result>();
        var pending=new Queue<(double Left,double Right,int Depth)>();
        string? coreError=null; int fallbackPoints=0;
        async Task<MininecPulseSolver.Result> Evaluate(double freq)
        {
            cts.Token.ThrowIfCancellationRequested();
            if(samples.TryGetValue(freq,out var cached))return cached;
            if(samples.Count>=maximumSamples)throw new InvalidOperationException("Достигнут лимит точек Smith Sweep.");
            StatusText.Text=$"Smith sweep: расчёт {samples.Count+1}/{maximumSamples} · {freq:0.######} MHz";
            // MMANA core first (as in «Рассчитать R+jX»): one matrix solution per frequency.
            string? sweepText=_maaText;
            var core=await Task.Run(()=>ApplyMmanaCore(model,null,freq,sweepText,cts.Token),cts.Token);
            cts.Token.ThrowIfCancellationRequested();
            MininecPulseSolver.Result result;
            if(core.Result!=null){ result=core.Result; _mmanaPulses=core.Pulses; }
            else
            {
                // Fallback: the application solver, with its convergence check.
                coreError??=core.CoreError;
                var baseResult=await Task.Run(()=>MininecPulseSolver.Solve(model,cts.Token,f0,freq,mode,progress),cts.Token);
                if(!double.IsFinite(baseResult.RelativeResidual)||baseResult.RelativeResidual>2e-7 ||
                   !double.IsFinite(baseResult.ROhm)||!double.IsFinite(baseResult.XOhm))
                    throw new InvalidOperationException($"Не подтверждена сходимость для {freq:G10} MHz: невязка {baseResult.RelativeResidual:E3}."+
                        (core.CoreError!=null?$" Ядро MMANA: {core.CoreError}":""));
                result=baseResult; _mmanaPulses=0; fallbackPoints++;
            }
            samples.Add(freq,result);
            // Draw only actual solver samples sorted by ascending frequency.
            if(samples.Values.All(x=>x.ROhm>0))
            {
                SmithView.SetReferenceOhms(model.ReferenceOhms);
                SmithView.SetTrace(samples.Select(point=>(point.Key,point.Value.Reflection(model.ReferenceOhms))));
                CartesianView.SetTrace(samples.Values,model.ReferenceOhms);
            }
            else {SmithView.Clear();CartesianView.SetTrace(samples.Values,model.ReferenceOhms);}
            return result;
        }
        try
        {
            double[] baseFrequencies=Enumerable.Range(0,21)
                .Select(k=>frequencyStart+(frequencyStop-frequencyStart)*k/20.0).ToArray();
            for(int k=0;k<baseFrequencies.Length;k++)await Evaluate(baseFrequencies[k]);
            for(int k=0;k<baseFrequencies.Length-1;k++)pending.Enqueue((baseFrequencies[k],baseFrequencies[k+1],0));
            while(pending.Count>0 && samples.Count<maximumSamples)
            {
                cts.Token.ThrowIfCancellationRequested();
                var interval=pending.Dequeue();
                if(interval.Depth>=maximumDepth)continue;
                double mid=interval.Left+(interval.Right-interval.Left)*0.5;
                if(mid<=interval.Left||mid>=interval.Right)continue;
                var left=samples[interval.Left];var right=samples[interval.Right];
                var center=await Evaluate(mid);
                Complex gLeft=left.Reflection(model.ReferenceOhms);
                Complex gRight=right.Reflection(model.ReferenceOhms);
                Complex gMid=center.Reflection(model.ReferenceOhms);
                double chord=(gRight-gLeft).Magnitude;
                double deviation=(gMid-(gLeft+gRight)*0.5).Magnitude;
                // Subdivide only when genuine evaluated curvature or steepness requires it.
                if(chord>maxGammaChord || deviation>maxMidpointDeviation)
                {
                    pending.Enqueue((interval.Left,mid,interval.Depth+1));
                    pending.Enqueue((mid,interval.Right,interval.Depth+1));
                }
                if(samples.Count%20==0)StatusText.Text=$"Smith sweep: {samples.Count}/{maximumSamples}, осталось интервалов {pending.Count}; без сглаживания";
            }
            output.AddRange(samples.Values);
            _lastSweep=output;
            // Model reflection coefficient for comparison with LiteVNA measurements (dashed overlay).
            VnaView.SetModelTrace(output.Where(r=>double.IsFinite(r.ROhm)&&double.IsFinite(r.XOhm))
                .Select(r=>(r.FrequencyMHz*1e6,r.Reflection(model.ReferenceOhms))).ToList());
            // Отображать результат на исходной частоте MAA, если она внутри диапазона.
            // В противном случае — середину выбранного диапазона.
            double displayFrequency=(f0>=frequencyStart && f0<=frequencyStop)
                ? f0 : (frequencyStart+(frequencyStop-frequencyStart)*0.5);
            var reference=samples.TryGetValue(displayFrequency,out var exactReference)
                ? exactReference
                : (samples.Count<maximumSamples
                    ? await Evaluate(displayFrequency)
                    : samples.OrderBy(kv=>Math.Abs(kv.Key-displayFrequency)).First().Value);
            output=samples.Values.ToList();
            _lastSweep=output;
            VnaView.SetModelTrace(output.Where(r=>double.IsFinite(r.ROhm)&&double.IsFinite(r.XOhm))
                .Select(r=>(r.FrequencyMHz*1e6,r.Reflection(model.ReferenceOhms))).ToList());
            ShowResult(reference,model.ReferenceOhms);
            FieldMap.SetResult(reference);
            FieldVolume.SetResult(reference);
            GeometryPreview.PatternResult=reference;
            UpdatePattern2D(reference,model);
            DiagnosticText.Text=fallbackPoints>0 ? $"Резервный MININEC в {fallbackPoints} точках: ядро MMANA — {coreError}" : "";
            string finish=pending.Count>0?"достигнут лимит 1001 точек": "адаптивное уточнение завершено";
            StatusText.Text=$"Smith sweep: {output.Count} точек, {finish}" +
                (fallbackPoints==0 ? " · R+jX: ядро MMANA" : $" · резервный MININEC: {fallbackPoints} точек");
        }
        catch(OperationCanceledException){StatusText.Text="Smith sweep остановлен пользователем.";}
        catch(Exception ex)
        {
            StatusText.Text="Smith sweep: часть точек не вычислена.";
            DiagnosticText.Text=ex.Message;
        }
        finally{_calculationCts=null;CalculateButton.IsEnabled=true;SweepButton.IsEnabled=true;CancelButton.IsEnabled=false;}
    }
    private void Cancel_Click(object sender,RoutedEventArgs e)
    {
        if(_calculationCts==null)return;
        _calculationCts.Cancel();
        CancelButton.IsEnabled=false;
        StatusText.Text="Запрошена остановка расчёта…";
        SolverResidualLabel.Text="Отмена: завершение текущей операции…";
    }

    // Batch: every MAA file in a folder and its subfolders, one CSV row per file, flushed after each file.
    private async void BatchFolder_Click(object sender,RoutedEventArgs e)
    {
        if(_calculationCts!=null) return;
        var folder=new OpenFolderDialog{ Title="Папка с MAA-файлами (вместе с подпапками)" };
        if(folder.ShowDialog(this)!=true) return;
        string root=folder.FolderName;
        var save=new SaveFileDialog{ Title="Файл результатов", Filter="CSV (*.csv)|*.csv",
            FileName=$"antcalc_batch_{DateTime.Now:yyyyMMdd_HHmmss}.csv", InitialDirectory=root };
        if(save.ShowDialog(this)!=true) return;
        List<string> files;
        try { files=BatchCalculator.FindMaaFiles(root); }
        catch(Exception ex) { MessageBox.Show(this,ex.Message); return; }
        if(files.Count==0){ MessageBox.Show(this,"В папке и подпапках нет файлов .maa."); return; }
        using var cts=new CancellationTokenSource(); _calculationCts=cts;
        CalculateButton.IsEnabled=false; SweepButton.IsEnabled=false; BatchButton.IsEnabled=false; CancelButton.IsEnabled=true;
        SolverProgressPanel.Visibility=Visibility.Visible;
        SolverProgressTitle.Text="Пакетный расчёт";
        var mode=SelectedGroundMode();
        int ok=0, failed=0;
        var watch=System.Diagnostics.Stopwatch.StartNew();
        string target=save.FileName;
        try
        {
            using var writer=new StreamWriter(target,false,new UTF8Encoding(true)){ AutoFlush=true };
            writer.WriteLine(BatchCalculator.Header);
            for(int i=0;i<files.Count;i++)
            {
                cts.Token.ThrowIfCancellationRequested();
                string path=files[i];
                StatusText.Text=$"Пакетный расчёт: {Path.GetRelativePath(root,path)}";
                SetBatchProgress(i,files.Count,Path.GetFileName(path),ok,failed,watch.Elapsed);
                var row=await Task.Run(()=>BatchCalculator.CalculateFile(path,root,mode,DisplayGroundEpsilonR,DisplayGroundSigma,cts.Token));
                writer.WriteLine(row.ToCsv());
                if(row.Status=="OK") ok++; else failed++;
                SetBatchProgress(i+1,files.Count,Path.GetFileName(path),ok,failed,watch.Elapsed);
            }
            SolverResidualLabel.Text=$"Готово: OK {ok}, ошибок {failed} · {FormatDuration(watch.Elapsed)}";
            StatusText.Text=$"Пакетный расчёт завершён: {files.Count} файлов, OK {ok}, ошибок {failed} · {watch.Elapsed:hh\\:mm\\:ss} · {target}";
        }
        catch(OperationCanceledException)
        {
            StatusText.Text=$"Пакетный расчёт остановлен: OK {ok}, ошибок {failed} · записано в {target}";
            SolverResidualLabel.Text=$"Остановлено: OK {ok}, ошибок {failed} · {FormatDuration(watch.Elapsed)}";
        }
        catch(Exception ex)
        {
            StatusText.Text="Пакетный расчёт: "+ex.Message;
        }
        finally
        {
            _calculationCts=null; CalculateButton.IsEnabled=true; SweepButton.IsEnabled=true; BatchButton.IsEnabled=true; CancelButton.IsEnabled=false;
        }
    }
    private static string FormatOhms(double r,double x) =>
        $"{r:0.###} {(x<0?"−":"+")} j{Math.Abs(x):0.###} Ω";

    private static string FormatPortSwr(double r,double x,double reference)
    {
        if(!double.IsFinite(r)||!double.IsFinite(x)||r<=0||reference<=0)return "не определён";
        var v=new System.Numerics.Complex(r,x);
        double gamma=System.Numerics.Complex.Abs((v-reference)/(v+reference));
        return gamma<1.0?$"{(1+gamma)/(1-gamma):0.###}":"не определён";
    }

    // Width of the widest port number, so that the Σ row lines up under "Порт N".
    private static int p0Width(IEnumerable<MininecPulseSolver.PortResult> ports) =>
        ports.Select(p=>p.PortNumber.ToString(CultureInfo.InvariantCulture).Length).DefaultIfEmpty(1).Max();

    // "FGMRES(96) right preconditioned + parallel MatVec + overlapping LU" -> "FGMRES(96)".
    private static string ShortSolver(string? s)
    {
        if(string.IsNullOrWhiteSpace(s)) return "";
        var m=System.Text.RegularExpressions.Regex.Match(s,@"FGMRES\(\d+\)");
        if(m.Success) return m.Value;
        if(s.Contains("FGMRES")) return "FGMRES";
        if(s.Contains("Gauss",StringComparison.OrdinalIgnoreCase)) return "LU (Гаусс)";
        int cut=s.IndexOfAny(new[]{'+','|','·'});
        return (cut>0?s[..cut]:s).Trim();
    }

    private string GroundShort() => _model?.GroundType switch
    {
        1 => "PEC-земля",
        2 or -1 => "PEC-приближение, σ не учтена",
        _ => "свободное пространство"
    };

    /// <summary>
    /// R+jX from the MMANA core (port of mininec3.cpp/ComLib.cpp, MMANA-GAL rule EC ≥ 2).
    /// Currents, field and pattern stay with the application solver; multi-source models keep
    /// the per-port values of the application solver (the core reports the first source only).
    /// </summary>
    /// <summary>
    /// Impedance, ports, currents and pattern from the MMANA core (MMANA-GAL rules), for any number of
    /// sources. <paramref name="r"/> is the application solver result or null when it could not solve
    /// the model; then the whole result comes from the core. Returns (null,0) only if both failed.
    /// </summary>
    private static (MininecPulseSolver.Result? Result,int Pulses,string Backend,string? CoreError) ApplyMmanaCore(
        MaaModel model,MininecPulseSolver.Result? r,double freqMHz,string? maaText,CancellationToken ct=default,
        IProgress<MmanaReferenceEngine.MmanaProgress>? progress=null)
    {
        ct.ThrowIfCancellationRequested();
        if(maaText==null) return (r,0,"MININEC","нет текста MAA");
        try
        {
            var (z,error)=MmanaReferenceEngine.SolveText(maaText,freqMHz,galCompat:true,ct:ct,progress:progress);
            ct.ThrowIfCancellationRequested();
            if(z==null) return (r,0,"MININEC",error ?? "нет результата");
            var built=BatchCalculator.FromCore(model,z,freqMHz,r);
            // The native backend reports success only after its original-matrix residual check.
            // A present DLL is NOT proof of GPU use: a rejected GPU result uses CPU LU.
            bool gpuAccepted=z.Warnings.Any(w=>w.StartsWith("GPU cuSOLVER FP32 + refinement:",StringComparison.Ordinal));
            string backend=gpuAccepted ? "GPU LU · cuSOLVER" : "CPU Parallel LU";
            return built==null ? (r,0,"MININEC","нет конечного импеданса") : (built,z.Pulses,backend,null);
        }
        catch(OperationCanceledException) { throw; }
        catch(AggregateException ae) when(ae.InnerExceptions.All(x=>x is OperationCanceledException)) { throw new OperationCanceledException(ct); }
        catch(Exception ex) { return (r,0,"MININEC",ex.GetType().Name+": "+ex.Message); }
    }

    private void ShowResult(MininecPulseSolver.Result z,double reference)
    {
        bool multi=z.SourceCount>1;
        PortsGrid.ItemsSource=z.Ports;
        if(multi && z.Ports is {Count: >0} ports)
        {
            // Результат отдельного источника: U_k / I_k с ориентацией тока к зажиму.
            // Запрещено делить общий ток на общее напряжение при фазированном возбуждении.
            // One aligned row per port; the last row is the equivalent impedance of the whole system.
            ImpedanceText.FontSize=14;
            ImpedanceText.Text=string.Join("\n",ports.Select(p=>
                $"Порт {p.PortNumber}  {FormatOhms(p.ROhm,p.XOhm),-20}  КСВ {FormatPortSwr(p.ROhm,p.XOhm,reference)}"));
            SwrText.Text="";
            EquivalentText.Text=$"Σ{new string(' ',4+p0Width(ports))}  {FormatOhms(z.ROhm,z.XOhm),-20}  КСВ {FormatPortSwr(z.ROhm,z.XOhm,reference)}";
            PortPowerText.Text=$"Фазированная система: {z.SourceCount} источника. Импеданс каждого порта вычислен как Zk=Uk/Ik при одновременном возбуждении. Положительные направления Ik соответствуют зажимам портов. " +
                $"ΣP = {z.TotalActivePower:G9}; ΣQ = {z.TotalReactivePower:G9} (относительные единицы). " +
                "MMANA-GAL следует сравнивать по портам при одинаковых фазах U и режиме земли, а не с Zэкв системы." +
                (ports.Any(p=>p.ROhm<0)?" Отрицательная активная часть отдельного активного порта допускается при передаче мощности между источниками.":"");
        }
        else
        {
            ImpedanceText.FontSize=20;
            ImpedanceText.Text=$"R+jX = {FormatOhms(z.ROhm,z.XOhm)}";
            EquivalentText.Text="";
            SwrText.Text=$"КСВ ({reference:0.#} Ω) = {FormatPortSwr(z.ROhm,z.XOhm,reference)}";
            PortPowerText.Text=$"Один источник. ΣP = {z.TotalActivePower:G9}; ΣQ = {z.TotalReactivePower:G9}.";
        }
        ResidualText.Text=_mmanaPulses>0
            ? $"Ядро MMANA · {_mmanaPulses} импульсов"
            : $"Невязка {z.RelativeResidual:0.0E+0} · {z.PulseCount} импульсов";
        string method=ShortSolver(z.LinearSolver);
        if(z.Iterations>0) method+=(method.Length>0?" · ":"")+$"{z.Iterations} итераций";
        string ground=GroundShort();
        if(_mmanaPulses>0) method="R+jX, токи и ДН";
        MethodText.Text=method.Length>0 && ground.Length>0 ? $"{method} · {ground}" : method+ground;
    }

    private void UpdatePattern2D(MininecPulseSolver.Result result,MaaModel model)
    {
        Pattern2D.SetResult(result,model.GroundType,DisplayGroundEpsilonR,DisplayGroundSigma);
    }

    private void Projection_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (GeometryPreview != null && ProjectionBox != null)
            GeometryPreview.Projection = ProjectionBox.SelectedIndex;
    }
    private void FitButton_Click(object sender, RoutedEventArgs e)
    {
        // Return the antenna, 3D radiation pattern and reference sphere to the default isometric view.
        ProjectionBox.SelectedIndex = 0;
        GeometryPreview.ResetViewAndFit();
        FieldVolume?.ResetViewAndFit();
    }

    private void PatternCenter_Changed(object sender, RoutedEventArgs e)
    {
        if(GeometryPreview!=null && PatternCenterCheck!=null)
            GeometryPreview.PlacePatternAtFeed = PatternCenterCheck.IsChecked==true;
    }

    private void PatternOverlay_Changed(object sender, RoutedEventArgs e)
    {
        if(GeometryPreview!=null && PatternOverlayCheck!=null)
            GeometryPreview.ShowPattern = PatternOverlayCheck.IsChecked == true;
    }
    private void Window_DragOver(object sender, DragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }
    private void Window_Drop(object sender, DragEventArgs e)
    {
        if (e.Data.GetData(DataFormats.FileDrop) is string[] files && files.Length > 0)
        {
            string path = files.FirstOrDefault(x => Path.GetExtension(x).Equals(".maa", StringComparison.OrdinalIgnoreCase)) ?? "";
            if (path.Length > 0) LoadModel(path);
        }
    }
}
