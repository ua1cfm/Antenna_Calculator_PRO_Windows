﻿using System.Windows;
namespace AntennaCalculator.Wpf;
public partial class App : Application { }
