using System;
using System.Threading;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

internal interface IVnaConnection : IDisposable
{
    string Description { get; }
    bool IsShell { get; }
    /// <summary>
    /// One sweep. fresh = true (single sweep, calibration standards): only data measured after the call are used.
    /// fresh = false (continuous mode after the first sweep): the running stream is read on.
    /// </summary>
    VnaSweep Measure(LiteVnaProtocol.SweepConfig config, CancellationToken ct, Action<int,int>? progress, bool fresh=true);
}

internal sealed class V2Connection : IVnaConnection
{
    readonly LiteVnaSerial _session;
    public string Description { get; }
    public bool IsShell => false;
    V2Connection(LiteVnaSerial session, string description) { _session=session; Description=description; }
    public static V2Connection Open(string port, bool liteOnly)
    {
        var (s, info)=LiteVnaSerial.Open(port,liteOnly);
        return new V2Connection(s,info.Text);
    }
    // The FIFO keeps sweeping with the last settings: configure only when they change or after a failure
    // (re-configuring every sweep restarts the sweep and puts the first points on synthesizer settling).
    LiteVnaProtocol.SweepConfig? _configured;
    public VnaSweep Measure(LiteVnaProtocol.SweepConfig c,CancellationToken ct,Action<int,int>? progress,bool fresh=true)
    {
        if(!c.SameSettings(_configured))
        {
            _session.Configure(c);          // also clears the FIFO
            _configured=c;
        }
        else if(fresh)
            _session.ClearFifo();           // discard sweeps buffered before this request (e.g. a previous standard)
        try
        {
            return VnaSweep.FromRaw(c,_session.ReadNextSweep(c,ct,progress),Description);
        }
        catch(OperationCanceledException){ throw; }
        catch
        {
            _configured=null;      // the next sweep re-configures the instrument
            throw;
        }
    }
    public void Dispose()=>_session.Dispose();
}

internal static class VnaConnectionFactory
{
    public static IVnaConnection Open(string port,int mode)
    {
        // Auto: try harmless V2 identity registers first; if no V2, reopen as shell.
        if(mode==1) return V2Connection.Open(port,true);
        if(mode==2) return V2Connection.Open(port,false);
        if(mode==3) return NanoVnaShellConnection.Open(port);
        try { return V2Connection.Open(port,false); }
        catch { return NanoVnaShellConnection.Open(port); }
    }
}
