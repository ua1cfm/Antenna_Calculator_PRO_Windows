﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>Frequency-domain MININEC results. All vertices are solved samples, never smoothed.</summary>
public sealed class ImpedanceCartesianView : FrameworkElement
{
    private readonly List<MininecPulseSolver.Result> _points = new();
    private double _referenceOhms = 50;
    private int _selected = -1;
    private readonly Typeface _typeface = new("Segoe UI");
    public void Clear() { _points.Clear(); _selected=-1; InvalidateVisual(); }
    public void SetTrace(IEnumerable<MininecPulseSolver.Result> results,double referenceOhms)
    {
        double prior = _selected>=0 && _selected<_points.Count ? _points[_selected].FrequencyMHz:double.NaN;
        _points.Clear();
        _points.AddRange(results.Where(x=>double.IsFinite(x.FrequencyMHz)&&double.IsFinite(x.ROhm)&&double.IsFinite(x.XOhm)).OrderBy(x=>x.FrequencyMHz));
        _referenceOhms=referenceOhms>0&&double.IsFinite(referenceOhms)?referenceOhms:50;
        _selected=_points.Count==0?-1:double.IsFinite(prior)?ClosestFrequency(prior):_points.Count/2;
        InvalidateVisual();
    }
    private int ClosestFrequency(double f)
    {
        int nearest=0; double best=double.MaxValue;
        for(int i=0;i<_points.Count;i++){double delta=Math.Abs(_points[i].FrequencyMHz-f);if(delta<best){best=delta;nearest=i;}}
        return nearest;
    }
    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonDown(e);
        if(_points.Count==0)return;
        double left=86,right=28;
        double t=Math.Clamp((e.GetPosition(this).X-left)/Math.Max(1,ActualWidth-left-right),0,1);
        double f=_points[0].FrequencyMHz+t*(_points[^1].FrequencyMHz-_points[0].FrequencyMHz);
        _selected=ClosestFrequency(f);InvalidateVisual(); e.Handled=true;
    }
    private void Write(DrawingContext dc,string value,double x,double y,Brush color,double size=12)
    {
        var text=new FormattedText(value,CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,_typeface,size,color,VisualTreeHelper.GetDpi(this).PixelsPerDip);
        dc.DrawText(text,new Point(x,y));
    }
    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        double width=ActualWidth,height=ActualHeight;
        dc.DrawRectangle(Brushes.White,null,new Rect(0,0,Math.Max(0,width),Math.Max(0,height)));
        if(width<160||height<220)return;
        const double left=86,right=28,header=57,bottom=42,gap=15;
        double graphWidth=Math.Max(1,width-left-right);
        double panelHeight=(height-header-bottom-2*gap)/3;
        if(panelHeight<35)return;
        if(_points.Count==0)
        {
            Write(dc,"Запустите Smith Sweep, чтобы построить R(f), X(f) и КСВ(f).",left,30,Brushes.SlateGray,14);
            return;
        }
        int sel=Math.Clamp(_selected,0,_points.Count-1);
        var item=_points[sel];
        string sign=item.XOhm<0?"−":"+";
        double swr=item.Swr(_referenceOhms);
        Write(dc,$"Маркер  f = {item.FrequencyMHz:0.######} МГц    Z = {item.ROhm:0.###} {sign} j{Math.Abs(item.XOhm):0.###} Ω    КСВ = {(double.IsFinite(swr)?swr.ToString("0.###",CultureInfo.CurrentCulture):"∞")}",left,13,Brushes.DarkSlateBlue,14);
        Write(dc,"Щёлкните по графику для перемещения маркера",left,36,Brushes.SlateGray,11);
        double minF=_points[0].FrequencyMHz,maxF=_points[^1].FrequencyMHz;
        if(maxF<=minF)maxF=minF+0.001;
        double X(double f)=>left+graphWidth*(f-minF)/(maxF-minF);
        var gridPen=new Pen(new SolidColorBrush(Color.FromRgb(217,225,233)),0.8);
        var axisPen=new Pen(new SolidColorBrush(Color.FromRgb(112,133,152)),1);
        var markerPen=new Pen(new SolidColorBrush(Color.FromRgb(217,83,37)),1.15){DashStyle=DashStyles.Dash};
        var lineColors=new[]{Color.FromRgb(20,116,169),Color.FromRgb(191,66,85),Color.FromRgb(32,143,101)};
        for(int k=0;k<3;k++)
        {
            double top=header+k*(panelHeight+gap), h=panelHeight;
            double[] values=_points.Select(p=>k==0?p.ROhm:k==1?p.XOhm:p.Swr(_referenceOhms)).ToArray();
            var finite=values.Where(double.IsFinite).ToArray();
            if(finite.Length==0)continue;
            double ymin=finite.Min(),ymax=finite.Max();
            if(k==2){ymin=1.0;if(ymax>1000)ymax=1000;}
            double pad=Math.Max((ymax-ymin)*0.075,Math.Max(Math.Abs(ymax),1)*0.015);
            if(k!=2)ymin-=pad;
            ymax+=pad;
            if(ymax<=ymin)ymax=ymin+1;
            double Y(double y)=>top+h-(Math.Clamp(y,ymin,ymax)-ymin)/(ymax-ymin)*h;
            dc.DrawRectangle(null,axisPen,new Rect(left,top,graphWidth,h));
            for(int j=1;j<5;j++)
            {
                double gy=top+j*h/5;
                dc.DrawLine(gridPen,new Point(left,gy),new Point(left+graphWidth,gy));
            }
            for(int j=1;j<5;j++)
            {
                double gx=left+j*graphWidth/5;
                dc.DrawLine(gridPen,new Point(gx,top),new Point(gx,top+h));
            }
            string name=k==0?"R, Ом":k==1?"X, Ом":"КСВ";
            Write(dc,name,7,top+1,new SolidColorBrush(lineColors[k]),12);
            Write(dc,ymax.ToString("0.###",CultureInfo.CurrentCulture),7,top+18,Brushes.Gray,10);
            Write(dc,ymin.ToString("0.###",CultureInfo.CurrentCulture),7,top+h-13,Brushes.Gray,10);
            var geometry=new StreamGeometry();
            using(var context=geometry.Open())
            {
                bool started=false;
                for(int i=0;i<_points.Count;i++)
                {
                    if(!double.IsFinite(values[i])){started=false;continue;}
                    var pt=new Point(X(_points[i].FrequencyMHz),Y(values[i]));
                    if(!started){context.BeginFigure(pt,false,false);started=true;}
                    else context.LineTo(pt,true,false);
                }
            }
            geometry.Freeze();
            dc.DrawGeometry(null,new Pen(new SolidColorBrush(lineColors[k]),1.8),geometry);
            double mx=X(item.FrequencyMHz);
            dc.DrawLine(markerPen,new Point(mx,top),new Point(mx,top+h));
            if(double.IsFinite(values[sel]))
                dc.DrawEllipse(Brushes.OrangeRed,new Pen(Brushes.White,1),new Point(mx,Y(values[sel])),4,4);
        }
        Write(dc,$"{minF:0.######} МГц",left,height-bottom+12,Brushes.SlateGray,11);
        Write(dc,$"{maxF:0.######} МГц",Math.Max(left,width-135),height-bottom+12,Brushes.SlateGray,11);
        Write(dc,"Частота (МГц)",Math.Max(left,width/2-52),height-19,Brushes.SlateGray,11);
    }
}
