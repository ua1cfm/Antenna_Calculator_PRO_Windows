﻿using AntennaCalculator.Core;
using Microsoft.Win32;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Controls;

namespace AntennaCalculator.Wpf;

/// <summary>Main window: geometry export (CSV, CST .bas, Fairbeam) and R+jX export (CSV, Touchstone .s1p).</summary>
public partial class MainWindow
{
    private void ExportGeometryMenu_Click(object sender,RoutedEventArgs e)
    {
        if(sender is Button b && b.ContextMenu!=null)
        {
            b.ContextMenu.PlacementTarget=b;
            b.ContextMenu.Placement=System.Windows.Controls.Primitives.PlacementMode.Bottom;
            b.ContextMenu.IsOpen=true;
        }
    }

    private void ExportCst_Click(object sender,RoutedEventArgs e)=>ExportConverterFile(cst:true);
    private void ExportFairbeam_Click(object sender,RoutedEventArgs e)=>ExportConverterFile(cst:false);

    // Same output as UA1CFM's maa_to_cst2026.py v0.3.1 (MaaToCstFairbeam); geometry only.
    private void ExportConverterFile(bool cst)
    {
        if(_model==null){ MessageBox.Show(this,"Сначала откройте модель MAA."); return; }
        string label=cst?"CST Studio Suite 2026 .bas":"Fairbeam .design.json";
        var dialog=new SaveFileDialog
        {
            Title="Экспорт геометрии: "+label,
            Filter=cst?"CST Studio Suite 2026 macro (*.bas)|*.bas":"Fairbeam design (*.design.json)|*.design.json",
            FileName=Path.GetFileNameWithoutExtension(_model.FilePath)+(cst?".bas":".design.json")
        };
        if(dialog.ShowDialog(this)!=true) return;
        try
        {
            var (m,_)=MaaToCstFairbeam.Load(_model.FilePath,expandCombined:true);
            string text=cst ? MaaToCstFairbeam.EmitBas(m)
                            : MaaToCstFairbeam.FairbeamJson(m,Path.GetFileName(_model.FilePath));
            File.WriteAllText(dialog.FileName,text,new UTF8Encoding(cst));
            int exported=m.Wires.Count(w=>w!=null);
            string extra=m.CombinedExpanded>0 ? $" · ступенчатых проводов разбито по CombWire: {m.CombinedExpanded}" : "";
            string warn=m.Warnings.Count>0 ? $" · предупреждений: {m.Warnings.Count} ({m.Warnings[0]})" : "";
            StatusText.Text=$"{label}: {exported} проводников · только геометрия{extra}{warn} · {dialog.FileName}";
        }
        catch(Exception ex)
        {
            MessageBox.Show(this,ex.Message,"Экспорт геометрии: "+label);
        }
    }

    private void ExportButton_Click(object sender, RoutedEventArgs e)
    {
        if (_model == null) { MessageBox.Show(this,"Сначала откройте модель MAA."); return; }
        var dialog = new SaveFileDialog { Filter="CSV (*.csv)|*.csv", FileName=Path.GetFileNameWithoutExtension(_model.FilePath)+"_wires.csv", Title="Сохранить геометрию" };
        if (dialog.ShowDialog(this) != true) return;
        var sb = new StringBuilder("wire,x1_m,y1_m,z1_m,x2_m,y2_m,z2_m,radius_m,tag\r\n");
        foreach (var w in _model.Wires)
            sb.AppendJoin(",", new[] { w.Number.ToString(), w.X1.ToString("G17",CultureInfo.InvariantCulture), w.Y1.ToString("G17",CultureInfo.InvariantCulture), w.Z1.ToString("G17",CultureInfo.InvariantCulture), w.X2.ToString("G17",CultureInfo.InvariantCulture), w.Y2.ToString("G17",CultureInfo.InvariantCulture), w.Z2.ToString("G17",CultureInfo.InvariantCulture), w.RadiusMetres.ToString("G17",CultureInfo.InvariantCulture), w.Tag.ToString() }).Append("\r\n");
        try { File.WriteAllText(dialog.FileName, sb.ToString(), new UTF8Encoding(true)); StatusText.Text="CSV сохранён: " + dialog.FileName; }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Ошибка сохранения CSV"); }
    }

    // Ground type is selected solely from the imported MMANA model.
    // G=2 (or -1) uses the EXISTING PEC-current approximation: not a full lossy-ground solver.
    /// <summary>
    /// Touchstone 1.x one-port file: "# MHZ S RI R z0", S11 = (Z − Z0)/(Z + Z0) with Z = R + jX of the
    /// result (for several sources: the system equivalent Zeq) and Z0 = reference impedance of the model.
    /// Data: the last Smith Sweep (ascending frequencies) or, without a sweep, the last single calculation.
    /// </summary>
    private void ExportS1p_Click(object sender,RoutedEventArgs e)
    {
        var points=_lastSweep.Count>0 ? _lastSweep : (_lastResult!=null ? new[]{ _lastResult } : Array.Empty<MininecPulseSolver.Result>());
        if(points.Count==0){ MessageBox.Show(this,"Сначала выполните расчёт R+jX или Smith Sweep."); return; }
        double z0=_model?.ReferenceOhms ?? 50;
        if(!(z0>0)) z0=50;
        var dialog=new SaveFileDialog{ Filter="Touchstone 1-port (*.s1p)|*.s1p", Title="Сохранить Touchstone .s1p",
            FileName=Path.GetFileNameWithoutExtension(_model?.FilePath ?? "antenna")+".s1p" };
        if(dialog.ShowDialog(this)!=true) return;
        var inv=CultureInfo.InvariantCulture;
        string Ascii(string text)=>new string(text.Select(ch=>ch>=32 && ch<127 ? ch : '?').ToArray());
        var sb=new StringBuilder();
        sb.Append("! ").Append(Ascii(Title)).Append("\r\n");
        if(_model!=null)
        {
            sb.Append("! Source MAA: ").Append(Ascii(Path.GetFileName(_model.FilePath))).Append("\r\n");
            sb.Append("! Title: ").Append(Ascii(_model.Title)).Append("\r\n");
        }
        sb.Append("! S11 = (Z - Z0)/(Z + Z0), Z = R + jX").Append(_mmanaPulses>0?" from the MMANA core":"")
          .Append(points.Any(p=>p.SourceCount>1)?" (several sources: system equivalent Zeq)":"").Append("\r\n");
        sb.Append("! Points: ").Append(points.Count).Append(_lastSweep.Count>0?" (Smith Sweep)":" (single calculation)").Append("\r\n");
        sb.Append("! freq_MHz  Re(S11)  Im(S11)\r\n");
        sb.Append("# MHZ S RI R ").Append(z0.ToString("0.######",inv)).Append("\r\n");
        int written=0; double lastF=double.NegativeInfinity;
        foreach(var p in points.OrderBy(p=>p.FrequencyMHz))
        {
            if(!double.IsFinite(p.ROhm)||!double.IsFinite(p.XOhm)||!(p.FrequencyMHz>lastF)) continue;
            var gamma=p.Reflection(z0);
            sb.Append(p.FrequencyMHz.ToString("0.#########",inv)).Append(' ')
              .Append(gamma.Real.ToString("G12",inv)).Append(' ')
              .Append(gamma.Imaginary.ToString("G12",inv)).Append("\r\n");
            lastF=p.FrequencyMHz; written++;
        }
        try
        {
            File.WriteAllText(dialog.FileName,sb.ToString(),Encoding.ASCII);
            StatusText.Text=$"Touchstone .s1p: {written} точек, Z0 = {z0:0.##} Ω · {dialog.FileName}";
        }
        catch(Exception ex){ MessageBox.Show(this,ex.Message,"Ошибка сохранения .s1p"); }
    }

    private void ExportSweep_Click(object sender,RoutedEventArgs e)
    {
        if(_lastSweep.Count==0){MessageBox.Show(this,"Сначала запусти Smith Sweep и дождись окончания расчёта.");return;}
        var dialog=new SaveFileDialog {Filter="CSV (*.csv)|*.csv",Title="Сохранить R+jX",
            FileName=Path.GetFileNameWithoutExtension(_model?.FilePath??"sweep")+"_mininec_sweep.csv"};
        if(dialog.ShowDialog(this)!=true)return;
        var sb=new StringBuilder("freq_mhz,r_ohm,x_ohm,swr,pulses,matrix_relative_residual,ground_method,linear_solver,iterations\r\n");
        foreach(var z in _lastSweep)
        {
            double z0=_model?.ReferenceOhms??50;
            sb.Append(z.FrequencyMHz.ToString("G17",CultureInfo.InvariantCulture)).Append(',')
              .Append(z.ROhm.ToString("G17",CultureInfo.InvariantCulture)).Append(',')
              .Append(z.XOhm.ToString("G17",CultureInfo.InvariantCulture)).Append(',')
              .Append(z.Swr(z0).ToString("G17",CultureInfo.InvariantCulture)).Append(',')
              .Append(z.PulseCount).Append(',')
              .Append(z.RelativeResidual.ToString("G17",CultureInfo.InvariantCulture)).Append(',')
              .Append('"').Append(z.GroundMethod.Replace("\"","\"\"")).Append('"').Append(',')
              .Append('"').Append(z.LinearSolver.Replace("\"","\"\"")).Append('"').Append(',')
              .Append(z.Iterations).Append("\r\n");
        }
        try
        {
            File.WriteAllText(dialog.FileName,sb.ToString(),new UTF8Encoding(true));
            var perPort=new StringBuilder("freq_mhz,port,wire,phase_u_deg,voltage_mag,current_mag,phase_i_deg,r_ohm,x_ohm,active_power,reactive_power,total_active_power,total_reactive_power\r\n");
            foreach(var z in _lastSweep)foreach(var p in z.Ports??Array.Empty<MininecPulseSolver.PortResult>())
            {
                string F(double v)=>v.ToString("G17",CultureInfo.InvariantCulture);
                perPort.Append(F(z.FrequencyMHz)).Append(',').Append(p.PortNumber).Append(',').Append(p.WireNumber).Append(',')
                    .Append(F(p.PhaseDegrees)).Append(',').Append(F(p.VoltageMagnitude)).Append(',')
                    .Append(F(p.CurrentMagnitude)).Append(',').Append(F(p.CurrentPhaseDegrees)).Append(',')
                    .Append(F(p.ROhm)).Append(',').Append(F(p.XOhm)).Append(',')
                    .Append(F(p.ActivePower)).Append(',').Append(F(p.ReactivePower)).Append(',')
                    .Append(F(z.TotalActivePower)).Append(',').Append(F(z.TotalReactivePower)).Append("\r\n");
            }
            var portPath=Path.Combine(Path.GetDirectoryName(dialog.FileName)!,Path.GetFileNameWithoutExtension(dialog.FileName)+"_ports.csv");
            File.WriteAllText(portPath,perPort.ToString(),new UTF8Encoding(true));
            StatusText.Text="CSV сохранены: "+dialog.FileName+" и "+portPath;
        }
        catch(Exception ex){MessageBox.Show(this,ex.Message,"Ошибка записи CSV",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
}
