using System;
using System.Collections.Generic;
using System.Linq;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>
/// Shared coordinate rule of the field views (2D map, 3D volume). Field samples are in solver coordinates
/// (z = Z + H above ground); MAA wires are in file coordinates (Z). Without this offset models with G ≠ 0 and H ≠ 0
/// were drawn with the antenna on the ground line and the map centred on the ground instead of the antenna.
/// </summary>
internal static class FieldGeometry
{
    /// <summary>
    /// Offset to add to MAA wire Z. Normally <see cref="MaaModel.PhysicalZOffset"/>; it is checked against the solver's
    /// pulse positions and, if they disagree by more than two segments / 0.02 λ, the offset seen in the currents is
    /// used (FromCurrents = true) so the overlay still matches the field. Stacked models use the rule only.
    /// </summary>
    internal static (double Offset, bool FromCurrents) ZOffset(MaaModel model, IReadOnlyList<MininecPulseSolver.FieldSample>? samples)
    {
        double rule = model.PhysicalZOffset;
        if (samples == null || samples.Count == 0 || model.Wires.Count == 0) return (rule, false);
        if (model.HasCompactStack || model.StackExpanded || model.StackHorizontal * model.StackVertical > 1) return (rule, false);
        var real = samples.Where(s => model.GroundType == 0 || s.Z >= -1e-9).ToList();
        if (real.Count == 0) return (rule, false);
        double zSamples = (real.Min(s => s.Z) + real.Max(s => s.Z)) * .5;
        double zWires = (model.Wires.Min(w => Math.Min(w.Z1, w.Z2)) + model.Wires.Max(w => Math.Max(w.Z1, w.Z2))) * .5;
        double observed = zSamples - zWires;
        double segment = real.Max(s => Math.Sqrt(s.Dx * s.Dx + s.Dy * s.Dy + s.Dz * s.Dz));
        double lambda = model.WavelengthMetres;
        double tolerance = Math.Max(4 * segment, double.IsFinite(lambda) ? 0.02 * lambda : 0);
        return Math.Abs(observed - rule) <= tolerance ? (rule, false) : (observed, true);
    }
}
