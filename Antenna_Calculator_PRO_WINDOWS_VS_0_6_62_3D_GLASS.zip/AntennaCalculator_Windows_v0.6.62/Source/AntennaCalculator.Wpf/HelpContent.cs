﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Linq;

namespace AntennaCalculator.Wpf;

/// <summary>Version and authorship shown in the help and About windows.</summary>
internal static class AppInfo
{
    /// <summary>Program version from Source\Directory.Build.props (assembly informational version).</summary>
    public static readonly string Version=
        (System.Reflection.Assembly.GetEntryAssembly() ?? typeof(AppInfo).Assembly)
            .GetCustomAttributes(typeof(System.Reflection.AssemblyInformationalVersionAttribute),false)
            .OfType<System.Reflection.AssemblyInformationalVersionAttribute>().FirstOrDefault()?.InformationalVersion?.Split('+')[0]
        ?? typeof(AppInfo).Assembly.GetName().Version?.ToString(3) ?? "?";
    public const string Product="Antenna Calculator PRO для Windows";
    public const string Author="UA1CFM";
}

/// <summary>One help chapter (level 0) or subsection (level 1) of help_ru.xml / help_en.xml.</summary>
internal sealed class HelpSection
{
    public string Id="";
    public string Title="";
    public int Level;
    public HelpSection? Parent;
    public readonly List<XElement> Blocks=new();
    public readonly List<HelpSection> Children=new();
    public string PlainText="";
    public HelpSection Top=>Parent ?? this;
}

/// <summary>Help text embedded as WPF resources (Help/help_ru.xml, Help/help_en.xml, Help/fig/*.png).</summary>
internal sealed class HelpDocument
{
    public string Language { get; private init; }="ru";
    public string Title { get; private init; }="";
    public List<HelpSection> Chapters { get; }=new();
    public IEnumerable<HelpSection> All=>Chapters.SelectMany(c=>new[]{ c }.Concat(c.Children));

    public static HelpDocument Load(string language)
    {
        var uri=new Uri($"pack://application:,,,/Help/help_{language}.xml",UriKind.Absolute);
        var info=Application.GetResourceStream(uri) ?? throw new InvalidOperationException("Файл справки не найден: "+uri);
        XDocument xml;
        using(var stream=info.Stream) xml=XDocument.Load(stream);
        var root=xml.Root ?? throw new InvalidOperationException("Пустой файл справки.");
        var doc=new HelpDocument{ Language=language, Title=(string?)root.Attribute("title") ?? "" };
        foreach(var chapter in root.Elements("section"))
        {
            var top=Read(chapter,0,null);
            doc.Chapters.Add(top);
            foreach(var sub in chapter.Elements("section")) top.Children.Add(Read(sub,1,top));
            top.PlainText=top.Title+" "+string.Join(" ",top.Blocks.Select(b=>b.Value))+" "+string.Join(" ",top.Children.Select(c=>c.PlainText));
        }
        return doc;
    }
    static HelpSection Read(XElement e,int level,HelpSection? parent)
    {
        var s=new HelpSection{ Id=(string?)e.Attribute("id") ?? "", Title=(string?)e.Attribute("title") ?? "", Level=level, Parent=parent };
        foreach(var b in e.Elements()) if(b.Name.LocalName!="section") s.Blocks.Add(b);
        s.PlainText=s.Title+" "+string.Join(" ",s.Blocks.Select(b=>b.Value))+" "+string.Join(" ",s.Blocks.Select(b=>(string?)b.Attribute("caption") ?? ""));
        return s;
    }
}

/// <summary>Renders a help chapter into a FlowDocument in the program's visual style.</summary>
internal static class HelpRenderer
{
    static readonly Brush Ink=Freeze(new SolidColorBrush(Color.FromRgb(30,42,54)));
    static readonly Brush Muted=Freeze(new SolidColorBrush(Color.FromRgb(91,107,124)));
    static readonly Brush Accent=Freeze(new SolidColorBrush(Color.FromRgb(31,95,139)));
    static readonly Brush Line=Freeze(new SolidColorBrush(Color.FromRgb(201,212,221)));
    static readonly Brush HeaderBack=Freeze(new SolidColorBrush(Color.FromRgb(237,244,249)));
    static readonly Brush NoteBack=Freeze(new SolidColorBrush(Color.FromRgb(237,244,249)));
    static readonly Brush WarnBack=Freeze(new SolidColorBrush(Color.FromRgb(251,241,230)));
    static readonly Brush WarnLine=Freeze(new SolidColorBrush(Color.FromRgb(194,124,44)));
    static Brush Freeze(SolidColorBrush b){ b.Freeze(); return b; }

    public static FlowDocument Render(HelpSection chapter,Dictionary<string,Block> anchors)
    {
        var doc=new FlowDocument
        {
            FontFamily=new FontFamily("Segoe UI"), FontSize=14, Foreground=Ink, PagePadding=new Thickness(30,22,30,30),
            ColumnWidth=100000, TextAlignment=TextAlignment.Left
        };
        var h1=new Paragraph(new Run(chapter.Title)){ FontSize=24, FontWeight=FontWeights.SemiBold, Foreground=Accent, Margin=new Thickness(0,0,0,12) };
        doc.Blocks.Add(h1); anchors[chapter.Id]=h1;
        foreach(var b in chapter.Blocks) Add(doc.Blocks,b);
        foreach(var sub in chapter.Children)
        {
            var h2=new Paragraph(new Run(sub.Title)){ FontSize=18, FontWeight=FontWeights.SemiBold, Margin=new Thickness(0,16,0,8) };
            doc.Blocks.Add(h2); anchors[sub.Id]=h2;
            foreach(var b in sub.Blocks) Add(doc.Blocks,b);
        }
        return doc;
    }

    static void Add(BlockCollection blocks,XElement e)
    {
        switch(e.Name.LocalName)
        {
            case "p":
                blocks.Add(Para(e,new Thickness(0,0,0,8)));
                break;
            case "ul":
            case "ol":
            {
                var list=new List{ MarkerStyle=e.Name.LocalName=="ol"?TextMarkerStyle.Decimal:TextMarkerStyle.Disc, Margin=new Thickness(0,0,0,10), Padding=new Thickness(22,0,0,0) };
                foreach(var li in e.Elements("li")) list.ListItems.Add(new ListItem(Para(li,new Thickness(0,0,0,4))));
                blocks.Add(list);
                break;
            }
            case "table":
            {
                var widths=((string?)e.Attribute("cols") ?? "").Split(',',StringSplitOptions.RemoveEmptyEntries)
                    .Select(w=>double.TryParse(w,NumberStyles.Float,CultureInfo.InvariantCulture,out var v)?v:1).ToList();
                var table=new Table{ CellSpacing=0, Margin=new Thickness(0,4,0,14), BorderBrush=Line, BorderThickness=new Thickness(0.5) };
                int ncol=e.Elements("tr").Select(r=>r.Elements("td").Count()).DefaultIfEmpty(1).Max();
                for(int i=0;i<ncol;i++) table.Columns.Add(new TableColumn{ Width=new GridLength(i<widths.Count?widths[i]:1,GridUnitType.Star) });
                var group=new TableRowGroup(); table.RowGroups.Add(group);
                bool first=true;
                foreach(var tr in e.Elements("tr"))
                {
                    var row=new TableRow();
                    if(first) row.Background=HeaderBack;
                    foreach(var td in tr.Elements("td"))
                    {
                        var p=Para(td,new Thickness(0)); p.FontSize=13;
                        if(first) p.FontWeight=FontWeights.SemiBold;
                        row.Cells.Add(new TableCell(p){ BorderBrush=Line, BorderThickness=new Thickness(0.5), Padding=new Thickness(6,4,6,4) });
                    }
                    group.Rows.Add(row); first=false;
                }
                blocks.Add(table);
                break;
            }
            case "img":
            {
                string src=(string?)e.Attribute("src") ?? "";
                double frac=double.TryParse((string?)e.Attribute("width"),NumberStyles.Float,CultureInfo.InvariantCulture,out var f)?f:1;
                try
                {
                    var bmp=new BitmapImage(new Uri("pack://application:,,,/Help/"+src,UriKind.Absolute));
                    var image=new Image{ Source=bmp, Stretch=Stretch.Uniform, MaxWidth=980*frac, HorizontalAlignment=HorizontalAlignment.Center };
                    RenderOptions.SetBitmapScalingMode(image,BitmapScalingMode.HighQuality);
                    blocks.Add(new BlockUIContainer(image){ Margin=new Thickness(0,6,0,2) });
                }
                catch(Exception ex){ blocks.Add(new Paragraph(new Run("[рисунок не найден: "+src+" — "+ex.Message+"]")){ Foreground=Muted }); }
                var caption=(string?)e.Attribute("caption");
                if(!string.IsNullOrEmpty(caption))
                    blocks.Add(new Paragraph(new Run(caption)){ FontStyle=FontStyles.Italic, FontSize=12, Foreground=Muted, TextAlignment=TextAlignment.Center, Margin=new Thickness(0,0,0,14) });
                break;
            }
            case "note":
            case "warn":
            {
                bool warn=e.Name.LocalName=="warn";
                var section=new Section(Para(e,new Thickness(0)))
                {
                    Background=warn?WarnBack:NoteBack, BorderBrush=warn?WarnLine:Accent, BorderThickness=new Thickness(3,0,0,0),
                    Padding=new Thickness(10,7,10,7), Margin=new Thickness(0,2,0,12)
                };
                blocks.Add(section);
                break;
            }
            case "mono":
            {
                var p=new Paragraph{ FontFamily=new FontFamily("Consolas"), FontSize=12.5, Margin=new Thickness(0,0,0,10) };
                var lines=e.Value.Split('\n');
                for(int i=0;i<lines.Length;i++){ if(i>0) p.Inlines.Add(new LineBreak()); p.Inlines.Add(new Run(lines[i])); }
                blocks.Add(p);
                break;
            }
        }
    }

    static Paragraph Para(XElement e,Thickness margin)
    {
        var p=new Paragraph{ Margin=margin, LineHeight=21 };
        AddInlines(p.Inlines,e);
        return p;
    }
    static void AddInlines(InlineCollection target,XElement e)
    {
        foreach(var node in e.Nodes())
        {
            if(node is XText text){ target.Add(new Run(text.Value)); continue; }
            if(node is not XElement child) continue;
            switch(child.Name.LocalName)
            {
                case "b": { var span=new Bold(); AddInlines(span.Inlines,child); target.Add(span); break; }
                case "i": { var span=new Italic(); AddInlines(span.Inlines,child); target.Add(span); break; }
                case "sub": target.Add(new Run(child.Value){ BaselineAlignment=BaselineAlignment.Subscript, FontSize=10.5 }); break;
                case "super": target.Add(new Run(child.Value){ BaselineAlignment=BaselineAlignment.Superscript, FontSize=10.5 }); break;
                default: target.Add(new Run(child.Value)); break;
            }
        }
    }
}
