using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Threading;

namespace AntennaCalculator.Wpf;

/// <summary>Help window: section tree with search, chapter view (FlowDocumentReader: Ctrl+F, zoom), RU / EN.</summary>
public partial class HelpWindow : Window
{
    HelpDocument? _doc;
    HelpSection? _shownChapter;
    readonly Dictionary<string,Block> _anchors=new();
    bool _ready;

    public HelpWindow()
    {
        InitializeComponent();
        LoadLanguage("ru");
        _ready=true;
    }

    void LoadLanguage(string language)
    {
        try { _doc=HelpDocument.Load(language); }
        catch(Exception ex)
        {
            MessageBox.Show(this,ex.Message,"Справка");
            return;
        }
        bool en=language=="en";
        Title=en?"Help — Antenna Calculator PRO":"Справка — Antenna Calculator PRO";
        SearchLabel.Text=en?"Search the help":"Поиск по справке";
        Tree.Items.Clear();
        foreach(var chapter in _doc.Chapters)
        {
            var item=new TreeViewItem{ Header=chapter.Title, Tag=chapter, FontWeight=FontWeights.SemiBold, Padding=new Thickness(2,3,2,3) };
            foreach(var sub in chapter.Children)
                item.Items.Add(new TreeViewItem{ Header=sub.Title, Tag=sub, FontWeight=FontWeights.Normal, Padding=new Thickness(2,2,2,2) });
            Tree.Items.Add(item);
        }
        _shownChapter=null;
        ApplyFilter(SearchBox.Text);
    }

    /// <summary>Opens a chapter or subsection by id (s1…s15, s12.3, appA, appB).</summary>
    public void ShowSection(string id)
    {
        foreach(TreeViewItem top in Tree.Items)
        {
            if(top.Tag is HelpSection s && s.Id==id){ Select(top); return; }
            foreach(TreeViewItem sub in top.Items)
                if(sub.Tag is HelpSection c && c.Id==id){ top.IsExpanded=true; Select(sub); return; }
        }
        if(Tree.Items.Count>0) Select((TreeViewItem)Tree.Items[0]);
    }
    static void Select(TreeViewItem item){ item.IsSelected=true; item.BringIntoView(); }

    void Tree_SelectedItemChanged(object sender,RoutedPropertyChangedEventArgs<object> e)
    {
        if(e.NewValue is not TreeViewItem { Tag: HelpSection section }) return;
        var chapter=section.Top;
        if(_shownChapter!=chapter)
        {
            _anchors.Clear();
            Reader.Document=HelpRenderer.Render(chapter,_anchors);
            _shownChapter=chapter;
        }
        // Scroll to the subsection once the document is laid out.
        Dispatcher.BeginInvoke(DispatcherPriority.Loaded,new Action(()=>
        {
            if(_anchors.TryGetValue(section.Id,out var block)) block.BringIntoView();
        }));
    }

    void Search_Changed(object sender,TextChangedEventArgs e){ if(_ready) ApplyFilter(SearchBox.Text); }

    /// <summary>Shows only sections containing the text (case-insensitive); opens the first match.</summary>
    void ApplyFilter(string query)
    {
        query=query.Trim();
        TreeViewItem? first=null;
        foreach(TreeViewItem top in Tree.Items)
        {
            var chapter=(HelpSection)top.Tag;
            bool any=false;
            foreach(TreeViewItem sub in top.Items)
            {
                bool match=query.Length==0 || ((HelpSection)sub.Tag).PlainText.Contains(query,StringComparison.CurrentCultureIgnoreCase);
                sub.Visibility=match?Visibility.Visible:Visibility.Collapsed;
                if(match && query.Length>0){ any=true; first??=sub; }
            }
            bool own=query.Length==0 || chapter.PlainText.Contains(query,StringComparison.CurrentCultureIgnoreCase);
            top.Visibility=own||any?Visibility.Visible:Visibility.Collapsed;
            top.IsExpanded=query.Length>0 && any;
            if(own && first==null) first=top;
        }
        if(query.Length>0 && first!=null) Select(first);
        else if(query.Length==0 && Tree.SelectedItem==null && Tree.Items.Count>0) Select((TreeViewItem)Tree.Items[0]);
    }

    void Language_Changed(object sender,RoutedEventArgs e)
    {
        if(!_ready) return;
        string? current=(Tree.SelectedItem as TreeViewItem)?.Tag is HelpSection s ? s.Id : null;
        LoadLanguage(EnRadio.IsChecked==true?"en":"ru");
        if(current!=null) ShowSection(current);
    }

    public string HelpLanguage=>EnRadio.IsChecked==true?"en":"ru";
}
