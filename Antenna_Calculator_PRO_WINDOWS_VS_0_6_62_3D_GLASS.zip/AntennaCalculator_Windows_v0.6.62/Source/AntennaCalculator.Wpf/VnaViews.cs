﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>Four markers shared by the VNA Smith chart, the rectangular chart and the marker table.</summary>
internal sealed class VnaMarkers
{
    public const int Count=4;
    public readonly int[] Index={ -1,-1,-1,-1 };
    public int Active { get; set; }
    public event Action? Changed;
    public void Set(int marker,int index){ if(marker<0||marker>=Count) return; Index[marker]=index; Changed?.Invoke(); }
    public void SetActive(int index)=>Set(Active,index);
    public void Notify()=>Changed?.Invoke();
    public static readonly Color[] Colors=
    {
        Color.FromRgb(214,48,49), Color.FromRgb(39,174,96), Color.FromRgb(41,128,185), Color.FromRgb(142,68,173)
    };
}

internal static class VnaDraw
{
    public static readonly CultureInfo Inv=CultureInfo.InvariantCulture;
    public static FormattedText Text(string s,double size,Brush brush,Visual v,bool bold=false)=>
        new(s,CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,
            new Typeface(new FontFamily("Segoe UI"),FontStyles.Normal,bold?FontWeights.SemiBold:FontWeights.Normal,FontStretches.Normal),
            size,brush,VisualTreeHelper.GetDpi(v).PixelsPerDip);
    public static Pen Pen(Color c,double w,bool dash=false)
    {
        var p=new Pen(new SolidColorBrush(c),w);
        if(dash) p.DashStyle=DashStyles.Dash;
        p.Freeze();
        return p;
    }
    public static double NiceStep(double span,int targetTicks)
    {
        if(!(span>0) || !double.IsFinite(span)) return 1;
        double raw=span/Math.Max(1,targetTicks), mag=Math.Pow(10,Math.Floor(Math.Log10(raw))), f=raw/mag;
        return (f<=1?1:f<=2?2:f<=5?5:10)*mag;
    }
}

/// <summary>Smith chart for measured S11 with an optional model overlay and four markers.</summary>
internal sealed class VnaSmithView : FrameworkElement
{
    VnaSweep? _sweep;
    IReadOnlyList<(double Hz,Complex Gamma)>? _overlay;
    VnaMarkers? _markers;
    public VnaSweep? Sweep { get=>_sweep; set{ _sweep=value; InvalidateVisual(); } }
    public IReadOnlyList<(double Hz,Complex Gamma)>? Overlay { get=>_overlay; set{ _overlay=value; InvalidateVisual(); } }
    public VnaMarkers? Markers
    {
        get=>_markers;
        set{ if(_markers!=null) _markers.Changed-=InvalidateVisual; _markers=value; if(_markers!=null) _markers.Changed+=InvalidateVisual; InvalidateVisual(); }
    }

    (Point C,double R) Frame()
    {
        double r=Math.Max(10,Math.Min(ActualWidth,ActualHeight)/2-26);
        return (new Point(ActualWidth/2,ActualHeight/2),r);
    }
    Point ToScreen(Complex g,(Point C,double R) f)=>new(f.C.X+g.Real*f.R,f.C.Y-g.Imaginary*f.R);

    protected override void OnRender(DrawingContext dc)
    {
        dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(252,253,254)),null,new Rect(0,0,ActualWidth,ActualHeight));
        if(ActualWidth<40 || ActualHeight<40) return;
        var f=Frame();
        var grid=VnaDraw.Pen(Color.FromRgb(205,214,222),0.8);
        var axis=VnaDraw.Pen(Color.FromRgb(150,162,174),1.0);
        var muted=new SolidColorBrush(Color.FromRgb(112,128,144)); muted.Freeze();
        dc.PushClip(new EllipseGeometry(f.C,f.R,f.R));
        foreach(double r in new[]{ 0.2,0.5,1,2,5 })
            dc.DrawEllipse(null,grid,new Point(f.C.X+f.R*r/(1+r),f.C.Y),f.R/(1+r),f.R/(1+r));
        foreach(double x in new[]{ 0.2,0.5,1,2,5 })
            foreach(int sgn in new[]{ 1,-1 })
                dc.DrawEllipse(null,grid,new Point(f.C.X+f.R,f.C.Y-sgn*f.R/x),f.R/x,f.R/x);
        dc.Pop();
        dc.DrawEllipse(null,axis,f.C,f.R,f.R);
        dc.DrawLine(axis,new Point(f.C.X-f.R,f.C.Y),new Point(f.C.X+f.R,f.C.Y));
        foreach(double r in new[]{ 0.2,0.5,1,2,5 })
        {
            double gx=(r-1)/(r+1);
            dc.DrawText(VnaDraw.Text(r.ToString("0.#",VnaDraw.Inv),9,muted,this),new Point(f.C.X+gx*f.R+2,f.C.Y+1));
        }
        if(_overlay is {Count: >1} ov)
        {
            var g=new StreamGeometry();
            using(var ctx=g.Open()){ ctx.BeginFigure(ToScreen(ov[0].Gamma,f),false,false); for(int i=1;i<ov.Count;i++) ctx.LineTo(ToScreen(ov[i].Gamma,f),true,false); }
            g.Freeze(); dc.DrawGeometry(null,VnaDraw.Pen(Color.FromRgb(230,126,34),1.4,true),g);
        }
        if(_sweep is {Points.Count: >0} s)
        {
            var g=new StreamGeometry();
            using(var ctx=g.Open()){ ctx.BeginFigure(ToScreen(s.Points[0].S11,f),false,false); for(int i=1;i<s.Points.Count;i++) ctx.LineTo(ToScreen(s.Points[i].S11,f),true,false); }
            g.Freeze(); dc.DrawGeometry(null,VnaDraw.Pen(Color.FromRgb(31,97,141),1.7),g);
            if(_markers!=null)
                for(int m=0;m<VnaMarkers.Count;m++)
                {
                    int i=_markers.Index[m];
                    if(i<0 || i>=s.Points.Count) continue;
                    var p=ToScreen(s.Points[i].S11,f);
                    var brush=new SolidColorBrush(VnaMarkers.Colors[m]); brush.Freeze();
                    dc.DrawEllipse(brush,VnaDraw.Pen(Colors.White,1.2),p,m==_markers.Active?5.5:4.2,m==_markers.Active?5.5:4.2);
                    dc.DrawText(VnaDraw.Text("M"+(m+1),11,brush,this,true),new Point(p.X+6,p.Y-16));
                }
        }
        else dc.DrawText(VnaDraw.Text("Нет измерения: подключите LiteVNA и нажмите Sweep, или откройте .s1p/.s2p",12,muted,this),new Point(12,10));
        dc.DrawText(VnaDraw.Text($"Z₀ = {(_sweep?.ReferenceOhms ?? 50):0.##} Ω",10,muted,this),new Point(10,ActualHeight-18));
    }

    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e){ CaptureMouse(); Pick(e.GetPosition(this)); e.Handled=true; }
    protected override void OnMouseMove(MouseEventArgs e){ if(e.LeftButton==MouseButtonState.Pressed && IsMouseCaptured) Pick(e.GetPosition(this)); }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e){ ReleaseMouseCapture(); }
    void Pick(Point pos)
    {
        if(_sweep is not {Points.Count: >0} s || _markers==null) return;
        var f=Frame(); int best=-1; double d=double.PositiveInfinity;
        for(int i=0;i<s.Points.Count;i++)
        {
            var p=ToScreen(s.Points[i].S11,f); double e=(p.X-pos.X)*(p.X-pos.X)+(p.Y-pos.Y)*(p.Y-pos.Y);
            if(e<d){ d=e; best=i; }
        }
        if(best>=0) _markers.SetActive(best);
    }
}

internal enum VnaQuantity { Swr, ReturnLoss, RX, AbsZ, PhaseS11, S21Db, S21Phase, GroupDelay }

/// <summary>Rectangular chart of one selectable quantity versus frequency, with markers.</summary>
internal sealed class VnaChartView : FrameworkElement
{
    VnaSweep? _sweep;
    IReadOnlyList<(double Hz,Complex Gamma)>? _overlay;
    VnaMarkers? _markers;
    VnaQuantity _quantity=VnaQuantity.Swr;
    public VnaChartView(){ Focusable=true; }
    public VnaSweep? Sweep { get=>_sweep; set{ _sweep=value; InvalidateVisual(); } }
    public IReadOnlyList<(double Hz,Complex Gamma)>? Overlay { get=>_overlay; set{ _overlay=value; InvalidateVisual(); } }
    public VnaQuantity Quantity { get=>_quantity; set{ _quantity=value; InvalidateVisual(); } }
    public VnaMarkers? Markers
    {
        get=>_markers;
        set{ if(_markers!=null) _markers.Changed-=InvalidateVisual; _markers=value; if(_markers!=null) _markers.Changed+=InvalidateVisual; InvalidateVisual(); }
    }

    const double Left=58, Right=16, Top=24, Bottom=34;
    double Z0=>_sweep?.ReferenceOhms ?? 50;

    static string Title(VnaQuantity q)=>q switch
    {
        VnaQuantity.Swr=>"КСВ",
        VnaQuantity.ReturnLoss=>"Обратные потери S11, дБ",
        VnaQuantity.RX=>"R (синий) и X (зелёный), Ом",
        VnaQuantity.AbsZ=>"|Z|, Ом",
        VnaQuantity.PhaseS11=>"Фаза S11, °",
        VnaQuantity.S21Db=>"|S21|, дБ",
        VnaQuantity.S21Phase=>"Фаза S21, °",
        _=>"ГВЗ S21, нс"
    };

    /// <summary>Series of the selected quantity: (frequency MHz, value) lists; RX gives two series.</summary>
    List<List<(double X,double Y)>> Series(IReadOnlyList<VnaPoint> p)
    {
        var a=new List<(double,double)>(); var b=new List<(double,double)>();
        for(int i=0;i<p.Count;i++)
        {
            double fx=p[i].FrequencyHz/1e6;
            var z=VnaMath.Impedance(p[i].S11,Z0);
            switch(_quantity)
            {
                case VnaQuantity.Swr: a.Add((fx,Math.Min(VnaMath.Swr(p[i].S11),50))); break;
                case VnaQuantity.ReturnLoss: a.Add((fx,VnaMath.ReturnLossDb(p[i].S11))); break;
                case VnaQuantity.RX: a.Add((fx,z.Real)); b.Add((fx,z.Imaginary)); break;
                case VnaQuantity.AbsZ: a.Add((fx,z.Magnitude)); break;
                case VnaQuantity.PhaseS11: a.Add((fx,VnaMath.PhaseDeg(p[i].S11))); break;
                case VnaQuantity.S21Db: if(p[i].HasS21) a.Add((fx,VnaMath.Db(p[i].S21))); break;
                case VnaQuantity.S21Phase: if(p[i].HasS21) a.Add((fx,VnaMath.PhaseDeg(p[i].S21))); break;
                case VnaQuantity.GroupDelay: a.Add((fx,VnaMath.GroupDelay(p,i)*1e9)); break;
            }
        }
        var r=new List<List<(double,double)>>{ a.Where(t=>double.IsFinite(t.Item2)).ToList() };
        if(b.Count>0) r.Add(b.Where(t=>double.IsFinite(t.Item2)).ToList());
        return r;
    }
    List<List<(double X,double Y)>> OverlaySeries()
    {
        if(_overlay is not {Count: >1} ov) return new();
        if(_quantity is VnaQuantity.S21Db or VnaQuantity.S21Phase or VnaQuantity.GroupDelay) return new();
        var pts=ov.Select(o=>new VnaPoint(o.Hz,o.Gamma,Complex.Zero,false)).ToList();
        return Series(pts);
    }

    protected override void OnRender(DrawingContext dc)
    {
        dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(252,253,254)),null,new Rect(0,0,ActualWidth,ActualHeight));
        var muted=new SolidColorBrush(Color.FromRgb(112,128,144)); muted.Freeze();
        var ink=new SolidColorBrush(Color.FromRgb(30,42,54)); ink.Freeze();
        double w=ActualWidth-Left-Right, h=ActualHeight-Top-Bottom;
        if(w<40 || h<40) return;
        dc.DrawText(VnaDraw.Text(Title(_quantity),11,ink,this,true),new Point(Left,4));
        if(_sweep is not {Points.Count: >1} s){ dc.DrawText(VnaDraw.Text("Нет данных",12,muted,this),new Point(Left+8,Top+8)); return; }
        var series=Series(s.Points); var overlay=OverlaySeries();
        var all=series.Concat(overlay).SelectMany(x=>x).ToList();
        if(all.Count==0){ dc.DrawText(VnaDraw.Text(_quantity is VnaQuantity.S21Db or VnaQuantity.S21Phase or VnaQuantity.GroupDelay ? "В данных нет S21" : "Нет данных",12,muted,this),new Point(Left+8,Top+8)); return; }
        double x0=s.Points[0].FrequencyHz/1e6, x1=s.Points[^1].FrequencyHz/1e6;
        if(!(x1>x0)) x1=x0+1;
        double y0=all.Min(t=>t.Y), y1=all.Max(t=>t.Y);
        if(_quantity==VnaQuantity.Swr){ y0=1; y1=Math.Max(2,Math.Min(10,y1)); }
        if(!(y1>y0)){ y0-=1; y1+=1; }
        double pad=(y1-y0)*0.06; if(_quantity!=VnaQuantity.Swr){ y0-=pad; y1+=pad; }
        double X(double v)=>Left+(v-x0)/(x1-x0)*w;
        double Y(double v)=>_quantity==VnaQuantity.ReturnLoss
            ? Top+(Math.Clamp(v,y0,y1)-y0)/(y1-y0)*h
            : Top+h-(Math.Clamp(v,y0,y1)-y0)/(y1-y0)*h;
        var grid=VnaDraw.Pen(Color.FromRgb(222,229,234),0.8);
        double ys=VnaDraw.NiceStep(y1-y0,6);
        for(double v=Math.Ceiling(y0/ys)*ys;v<=y1+1e-9;v+=ys)
        {
            dc.DrawLine(grid,new Point(Left,Y(v)),new Point(Left+w,Y(v)));
            dc.DrawText(VnaDraw.Text(v.ToString("G4",VnaDraw.Inv),9,muted,this),new Point(4,Y(v)-7));
        }
        double xs=VnaDraw.NiceStep(x1-x0,7);
        for(double v=Math.Ceiling(x0/xs)*xs;v<=x1+1e-9;v+=xs)
        {
            dc.DrawLine(grid,new Point(X(v),Top),new Point(X(v),Top+h));
            dc.DrawText(VnaDraw.Text(v.ToString("G6",VnaDraw.Inv),9,muted,this),new Point(X(v)-14,Top+h+4));
        }
        dc.DrawText(VnaDraw.Text("МГц",9,muted,this),new Point(Left+w-22,Top+h+18));
        dc.DrawRectangle(null,VnaDraw.Pen(Color.FromRgb(190,200,210),1),new Rect(Left,Top,w,h));
        void Line(List<(double X,double Y)> pts,Pen pen)
        {
            if(pts.Count<2) return;
            var g=new StreamGeometry();
            using(var ctx=g.Open()){ ctx.BeginFigure(new Point(X(pts[0].X),Y(pts[0].Y)),false,false); for(int i=1;i<pts.Count;i++) ctx.LineTo(new Point(X(pts[i].X),Y(pts[i].Y)),true,false); }
            g.Freeze(); dc.DrawGeometry(null,pen,g);
        }
        for(int k=0;k<overlay.Count;k++) Line(overlay[k],VnaDraw.Pen(k==0?Color.FromRgb(230,126,34):Color.FromRgb(243,156,18),1.3,true));
        Line(series[0],VnaDraw.Pen(Color.FromRgb(31,97,141),1.7));
        if(series.Count>1) Line(series[1],VnaDraw.Pen(Color.FromRgb(39,174,96),1.7));
        if(_markers!=null)
            for(int m=0;m<VnaMarkers.Count;m++)
            {
                int i=_markers.Index[m];
                if(i<0 || i>=s.Points.Count) continue;
                double fx=X(s.Points[i].FrequencyHz/1e6);
                var col=VnaMarkers.Colors[m];
                dc.DrawLine(VnaDraw.Pen(col,m==_markers.Active?1.6:1.0,true),new Point(fx,Top),new Point(fx,Top+h));
                var b=new SolidColorBrush(col); b.Freeze();
                dc.DrawText(VnaDraw.Text("M"+(m+1),10,b,this,true),new Point(fx+3,Top+2+m*12));
            }
    }

    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e){ Focus(); CaptureMouse(); Pick(e.GetPosition(this).X); e.Handled=true; }
    protected override void OnMouseMove(MouseEventArgs e){ if(e.LeftButton==MouseButtonState.Pressed && IsMouseCaptured) Pick(e.GetPosition(this).X); }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e){ ReleaseMouseCapture(); }
    void Pick(double px)
    {
        if(_sweep is not {Points.Count: >1} s || _markers==null) return;
        double w=ActualWidth-Left-Right;
        double x0=s.Points[0].FrequencyHz, x1=s.Points[^1].FrequencyHz;
        double f=x0+Math.Clamp((px-Left)/w,0,1)*(x1-x0);
        _markers.SetActive(VnaMath.NearestIndex(s.Points,f));
    }
    protected override void OnKeyDown(KeyEventArgs e)
    {
        if(_sweep is not {Points.Count: >0} s || _markers==null) return;
        int step=Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)?10:1;
        int i=_markers.Index[_markers.Active];
        if(e.Key==Key.Left){ _markers.SetActive(Math.Max(0,(i<0?0:i)-step)); e.Handled=true; }
        else if(e.Key==Key.Right){ _markers.SetActive(Math.Min(s.Points.Count-1,(i<0?0:i)+step)); e.Handled=true; }
    }
}
