using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using AntennaCalculator.Core;

namespace AntennaCalculator.Wpf;

/// <summary>
/// NanoVNA H/H4 text shell (<c>version</c>, <c>cal off/on</c>, <c>scan start stop points 7</c>).
/// The instrument's own calibration is switched off for the session (the program calibrates RAW data itself)
/// and switched on again on disconnect. Answers end with the prompt "ch&gt;".
/// </summary>
internal sealed class NanoVnaShellConnection : IVnaConnection
{
    readonly SerialPort _port;
    readonly object _sync=new();
    readonly bool _restoreCalibration;
    int _blockPoints=401;                 // reduced to 101 automatically if the firmware returns fewer rows
    const int SafeBlockPoints=101;
    public string Description { get; }
    public bool IsShell=>true;

    NanoVnaShellConnection(SerialPort port,string description,bool restoreCalibration)
    { _port=port; Description=description; _restoreCalibration=restoreCalibration; }

    public static NanoVnaShellConnection Open(string portName)
    {
        var p=new SerialPort(portName,115200,Parity.None,8,StopBits.One)
        { ReadTimeout=250, WriteTimeout=2000, NewLine="\r", DtrEnable=true, RtsEnable=false, Handshake=Handshake.None, ReadBufferSize=1<<18 };
        try
        {
            p.Open(); Thread.Sleep(200); p.DiscardInBuffer();
            string response=Command(p,"version",1800,CancellationToken.None);
            if(string.IsNullOrWhiteSpace(response) || response.IndexOf("version",StringComparison.OrdinalIgnoreCase)<0 &&
               !response.Contains(NanoVnaShellParser.Prompt) && !response.Contains("NanoVNA",StringComparison.OrdinalIgnoreCase) &&
               !Regex.IsMatch(response,@"\b\d+\.\d+"))
                throw new InvalidOperationException("NanoVNA Shell не распознан: нет ответа на version.");
            // RAW data for the in-app calibration: switch the instrument's correction off for this session.
            string cal=Command(p,"cal off",1500,CancellationToken.None);
            bool calOff=cal.Contains(NanoVnaShellParser.Prompt) && cal.IndexOf("usage",StringComparison.OrdinalIgnoreCase)<0;
            string note=calOff ? "калибровка прибора выключена (RAW)" : "калибровку прибора выключить не удалось — данные могут быть уже исправлены прибором";
            return new NanoVnaShellConnection(p,$"NanoVNA Shell · {portName} · {FirstVersion(response)} · {note}",calOff);
        }
        catch { p.Dispose(); throw; }
    }

    static string FirstVersion(string response)
    {
        var m=Regex.Match(response,@"\b\d+\.\d+(?:\.\d+)?\b");
        return m.Success ? "FW "+m.Value : "version OK";
    }

    /// <summary>Sends a command and reads until the prompt (or, for firmwares without it, until the line is quiet).</summary>
    static string Command(SerialPort p,string command,int timeoutMs,CancellationToken ct)
    {
        p.DiscardInBuffer();
        p.Write(command+"\r");
        var result=new StringBuilder(); var watch=System.Diagnostics.Stopwatch.StartNew(); long last=-1;
        while(watch.ElapsedMilliseconds<timeoutMs)
        {
            ct.ThrowIfCancellationRequested();
            int n=0;
            try{ n=p.BytesToRead; } catch(InvalidOperationException){ break; }
            if(n>0)
            {
                var buf=new byte[Math.Min(n,1<<16)]; int cnt=p.Read(buf,0,buf.Length);
                result.Append(Encoding.ASCII.GetString(buf,0,cnt)); last=watch.ElapsedMilliseconds;
                // The echo of the command is followed by the answer and the prompt.
                string text=result.ToString();
                int echo=text.IndexOf(command,StringComparison.Ordinal);
                if(NanoVnaShellParser.EndsWithPrompt(text) && (echo<0 || text.LastIndexOf(NanoVnaShellParser.Prompt,StringComparison.Ordinal)>echo)) break;
            }
            else
            {
                if(last>=0 && watch.ElapsedMilliseconds-last>1500) break;     // no prompt on this firmware
                Thread.Sleep(5);
            }
        }
        return result.ToString();
    }

    public VnaSweep Measure(LiteVnaProtocol.SweepConfig config,CancellationToken ct,Action<int,int>? progress,bool fresh=true)
    {
        lock(_sync)
        {
            var points=new List<VnaPoint>(config.Points);
            int first=0;
            while(first<config.Points)
            {
                ct.ThrowIfCancellationRequested();
                // Adjacent blocks overlap one sample; this keeps the exact requested frequency grid.
                int count=Math.Min(_blockPoints,config.Points-first);
                long start=(long)Math.Round(config.FrequencyHz(first));
                long stop=(long)Math.Round(config.FrequencyHz(first+count-1));
                string answer=Command(_port,$"scan {start} {stop} {count} 7",Math.Max(5000,4000+count*200),ct);
                double[][] data;
                try { data=NanoVnaShellParser.ParseScan(answer,start,stop,count); }
                catch(FormatException) when(count>SafeBlockPoints)
                {
                    _blockPoints=SafeBlockPoints;       // firmware limit: retry this block in smaller pieces
                    continue;
                }
                catch(FormatException ex)
                {
                    throw new InvalidOperationException($"NanoVNA: {ex.Message}. Ответ: {answer[..Math.Min(160,answer.Length)]}");
                }
                for(int j=0;j<count;j++)
                {
                    if(first>0 && j==0) continue;
                    var a=data[j];
                    points.Add(new VnaPoint(config.FrequencyHz(first+j),new Complex(a[1],a[2]),new Complex(a[3],a[4]),true));
                }
                progress?.Invoke(points.Count,config.Points);
                if(first+count>=config.Points) break;
                first+=count-1;
            }
            if(points.Count!=config.Points) throw new InvalidOperationException($"NanoVNA: собрано {points.Count} из {config.Points} точек.");
            return new VnaSweep{ Points=points, Source=Description, Comments={ "NanoVNA Shell scan outmask=7"+(_restoreCalibration?", instrument calibration off (RAW)":"") } };
        }
    }

    public void Dispose()
    {
        lock(_sync)
        {
            try{ if(_restoreCalibration && _port.IsOpen) Command(_port,"cal on",1000,CancellationToken.None); } catch{ }
            try{ _port.Close(); } catch{ }
            _port.Dispose();
        }
    }
}
