using System;
using System.Diagnostics;
using System.IO;
using System.Windows;

namespace AntennaCalculator.Wpf;

public partial class AboutWindow : Window
{
    public AboutWindow()
    {
        InitializeComponent();
        ProductText.Text=AppInfo.Product;
        VersionText.Text=$"Версия {AppInfo.Version} · {AppInfo.Author} · 2026";
        BuildText.Text="Сборка: "+BuildDate();
    }

    static string BuildDate()
    {
        try
        {
            var path=Environment.ProcessPath;
            return path!=null && File.Exists(path) ? File.GetLastWriteTime(path).ToString("dd.MM.yyyy HH:mm") : "—";
        }
        catch { return "—"; }
    }

    public static string SystemInfo()
    {
        string dir=AppContext.BaseDirectory;
        return $"{AppInfo.Product} {AppInfo.Version}\r\n"+
               $"Сборка: {BuildDate()}\r\n"+
               $"Windows: {Environment.OSVersion} · 64-bit: {Environment.Is64BitOperatingSystem}\r\n"+
               $".NET: {Environment.Version}\r\n"+
               $"Папка: {dir}\r\n"+
               $"AntennaCuda64.dll: {(File.Exists(Path.Combine(dir,"AntennaCuda64.dll"))?"есть":"нет")}\r\n"+
               $"Docs: {(Directory.Exists(Path.Combine(dir,"Docs"))?"есть":"нет")}";
    }

    void OpenFolder_Click(object sender,RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo("explorer.exe","\""+AppContext.BaseDirectory+"\""){ UseShellExecute=true }); }
        catch(Exception ex){ MessageBox.Show(this,ex.Message,"О программе"); }
    }
    void CopyInfo_Click(object sender,RoutedEventArgs e)
    {
        try { Clipboard.SetText(SystemInfo()); MessageBox.Show(this,"Сведения о системе скопированы в буфер обмена.","О программе"); }
        catch(Exception ex){ MessageBox.Show(this,ex.Message,"О программе"); }
    }
    void Close_Click(object sender,RoutedEventArgs e)=>Close();
}
