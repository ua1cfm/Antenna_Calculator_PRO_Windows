using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using AntennaCalculator.Core;
using Microsoft.Win32;

namespace AntennaCalculator.Wpf;

/// <summary>
/// Editing of wire geometry in the «Проводники» table: X1…Z2 and R are edited in the cells, changed rows are
/// highlighted; «Применить и пересчитать» rewrites the Wires section of the MAA text (MaaParser.ReplaceWireGeometry),
/// re-reads the model from that text and recalculates (the MMANA core, MININEC, pattern and field use the same text);
/// «Отменить правки» restores the last applied geometry; «Сохранить MAA…» writes the current (applied) text.
/// The number of wires does not change (sources and loads refer to wires by number). For Make Stack models only the
/// base antenna written in the file is editable.
/// </summary>
public partial class MainWindow
{
    private readonly ObservableCollection<WireEditRow> _wireRows = new();
    private bool _modelEdited;

    private void BindWireEditor(MaaModel m)
    {
        foreach (var r in _wireRows) r.PropertyChanged -= WireRow_PropertyChanged;
        _wireRows.Clear();
        int editable = m.HasCompactStack && m.BaseWireCount > 0 ? Math.Min(m.BaseWireCount, m.Wires.Count) : m.Wires.Count;
        foreach (var w in m.Wires)
        {
            var row = new WireEditRow(w, w.Number <= editable);
            row.PropertyChanged += WireRow_PropertyChanged;
            _wireRows.Add(row);
        }
        WiresGrid.ItemsSource = _wireRows;
        UpdateWireEditState();
    }

    /// <summary>
    /// The grid takes only the height of its rows (the bar sits right under the last wire); with many wires its
    /// height is limited to the panel minus the bar, so the grid scrolls and the bar stays visible.
    /// </summary>
    private void WiresPanel_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        double bar = WireEditBar.ActualHeight > 0 ? WireEditBar.ActualHeight + WireEditBar.Margin.Top + WireEditBar.Margin.Bottom : 32;
        WiresGrid.MaxHeight = Math.Max(60, WiresPanel.ActualHeight - bar - 2);
    }

    private void WireRow_PropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(WireEditRow.Changed)) UpdateWireEditState();
    }

    private void UpdateWireEditState()
    {
        int changed = _wireRows.Count(r => r.Changed);
        if (ApplyWiresButton != null) ApplyWiresButton.IsEnabled = changed > 0 && _maaText != null;
        if (RevertWiresButton != null) RevertWiresButton.IsEnabled = changed > 0;
        if (SaveMaaButton != null) SaveMaaButton.IsEnabled = _maaText != null;
        if (WireEditStatus != null)
            WireEditStatus.Text = changed > 0
                ? $"Изменено: {changed} — «Применить» пересчитает модель"
                : _modelEdited ? "Применено (файл не изменён — «Сохранить MAA…»)"
                               : "Двойной щелчок по ячейке — изменить значение";
    }

    /// <summary>Make Stack copies are not written in the file: they cannot be edited.</summary>
    private void WiresGrid_BeginningEdit(object? sender, DataGridBeginningEditEventArgs e)
    {
        if (e.Row.Item is WireEditRow { Editable: false })
        {
            e.Cancel = true;
            StatusText.Text = "Копии Make Stack не редактируются: измените базовую антенну (первые проводники).";
        }
    }

    private void ApplyWires_Click(object sender, RoutedEventArgs e)
    {
        if (_model == null || _maaText == null) return;
        WiresGrid.CommitEdit(DataGridEditingUnit.Row, true);
        var changes = _wireRows.Where(r => r.Changed && r.Editable).ToDictionary(r => r.Number, r => r.Geometry);
        if (changes.Count == 0) { UpdateWireEditState(); return; }
        try
        {
            string text = MaaParser.ReplaceWireGeometry(_maaText, changes);
            MaaModel edited = MaaParser.Parse(text, _model.FilePath);
            ShowModel(edited, text, _model.FilePath, edited: true);
            StatusText.Text = $"Применено: изменено проводников {changes.Count}. Пересчёт…";
            Calculate_Click(this, new RoutedEventArgs());
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Изменение геометрии не применено", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void RevertWires_Click(object sender, RoutedEventArgs e)
    {
        WiresGrid.CancelEdit(DataGridEditingUnit.Row);
        if (_model != null) BindWireEditor(_model);
    }

    private void SaveMaa_Click(object sender, RoutedEventArgs e)
    {
        if (_model == null || _maaText == null) return;
        if (_wireRows.Any(r => r.Changed) &&
            MessageBox.Show(this, "Есть неприменённые правки. Сохраняется последняя применённая геометрия.\nПродолжить?",
                "Сохранить MAA", MessageBoxButton.OKCancel, MessageBoxImage.Question) != MessageBoxResult.OK) return;
        string dir = Path.GetDirectoryName(_model.FilePath) ?? "";
        string name = Path.GetFileNameWithoutExtension(_model.FilePath);
        var dialog = new SaveFileDialog
        {
            Filter = "MMANA (*.maa)|*.maa",
            InitialDirectory = Directory.Exists(dir) ? dir : "",
            FileName = _modelEdited && !name.EndsWith("_edit", StringComparison.OrdinalIgnoreCase) ? name + "_edit.maa" : name + ".maa"
        };
        if (dialog.ShowDialog(this) != true) return;
        try
        {
            File.WriteAllBytes(dialog.FileName, MaaParser.EncodeForSave(_maaText));
            StatusText.Text = "Сохранено: " + Path.GetFileName(dialog.FileName);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Ошибка записи MAA", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
