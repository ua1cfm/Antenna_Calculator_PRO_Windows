﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using AntennaCalculator.Core;

// A physics-facing regression test of the *actual* UI far-field moment s.D,
// versus the historic diagnostic moment 2*s.D. No arbitrary power correction.
internal static class UiFieldParityAudit
{
    const double Eta = 376.730313668, Speed = 299792458.0;
    static MaaModel Dipole(int n) => new MaaModel {
        Title="FREE_DIPOLE", FilePath="fixture", FrequencyMHz=28.5,
        Wires=new[]{new MaaWire(1,0,0,-2.5,0,0,2.5,.002,n)},
        Sources=new[]{new MaaSource(1,'c',0,0,1,"fixture")},
        Loads=Array.Empty<MaaLoad>(), Warnings=Array.Empty<string>(),GroundType=0,
        SegmentationRecord="800,80,1.1,16",ReferenceOhms=50
    };
    static MaaModel Mono(int n) => new MaaModel {
        Title="PEC_MONO", FilePath="fixture",FrequencyMHz=28.5,
        Wires=new[]{new MaaWire(1,0,0,0,0,0,2.5,.002,n)},
        Sources=new[]{new MaaSource(1,'b',0,0,1,"fixture")},
        Loads=Array.Empty<MaaLoad>(),Warnings=Array.Empty<string>(),GroundType=1,
        SegmentationRecord="800,80,1.1,16",ReferenceOhms=50
    };
    static double Radiation(MininecPulseSolver.Result r,double f,bool upper,int nt=30,int np=60)
    {
        double k=2*Math.PI*f*1e6/Speed,dt=(upper?Math.PI/2:Math.PI)/nt,dp=2*Math.PI/np,sum=0;
        var samples=r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>();
        for(int i=0;i<nt;i++)
        {
            double th=(i+.5)*dt,st=Math.Sin(th),ct=Math.Cos(th);
            for(int j=0;j<np;j++)
            {
                double phi=(j+.5)*dp,nx=st*Math.Cos(phi),ny=st*Math.Sin(phi),nz=ct;
                Complex gx=0,gy=0,gz=0;
                foreach(var s in samples)
                {
                    Complex amp=new Complex(s.RealCurrent,s.ImagCurrent)*Complex.FromPolarCoordinates(1,k*(nx*s.X+ny*s.Y+nz*s.Z));
                    // Exactly the G=0 and G=1 operator in Wpf/RadiationField.Direction.
                    gx+=amp*s.Dx;gy+=amp*s.Dy;gz+=amp*s.Dz;
                }
                Complex d=nx*gx+ny*gy+nz*gz;
                gx-=nx*d;gy-=ny*d;gz-=nz*d;
                sum+=(gx.Magnitude*gx.Magnitude+gy.Magnitude*gy.Magnitude+gz.Magnitude*gz.Magnitude)*st*dt*dp;
            }
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*sum;
    }
    static bool Check(string name,MaaModel model,double f,bool upper,MininecPulseSolver.ConductorMaterial material=MininecPulseSolver.ConductorMaterial.Pec)
    {
        var r=MininecPulseSolver.Solve(model,frequencyMHzOverride:f,segmentationReferenceMHz:28.5,conductor:material);
        double p=r.TotalActivePower-r.PhysicalConductorLossPower;
        double prad=Radiation(r,f,upper),ratio=prad/p;
        // For the simple PEC fixtures, energy conservation should be within 2%; for
        // complex loaded Hairpin, report actual discrepancy; do not treat as proof of normalization.
        bool fixture=name.StartsWith("DIPOLE",StringComparison.Ordinal)||name.StartsWith("MONO",StringComparison.Ordinal);
        bool pass=double.IsFinite(ratio)&&ratio>0&&(fixture?Math.Abs(ratio-1)<0.02:true);
        Console.WriteLine($"{(pass?"PASS":"FAIL")} {name} f={f:G9} pulses={r.PulseCount} Zin=({r.ROhm:G12},{r.XOhm:G12}) Psrc={r.TotalActivePower:G12} Ploss={r.PhysicalConductorLossPower:G12} Prad_UI={prad:G12} ratio={ratio:G12} residual={r.RelativeResidual:E5}");
        if(!fixture && Math.Abs(ratio-1)>.02) Console.WriteLine("  WARNING HAIRPIN_BUDGET_GT_2_PERCENT: investigate pulse basis/junctions; no fitting");
        return pass;
    }
    internal static int Run()
    {
        Console.WriteLine("v0.3.42 UI FIELD PARITY + FIXED SEGMENTATION AUDIT");
        Console.WriteLine("UI field uses s.D = 0.5*(EndPos-EndNeg); old diagnostics used 2*s.D. Hence their radiated powers are 4x UI convention by construction.");
        Console.WriteLine("Old raw power numbers are not evidence of a fourfold error in the WPF field viewer.");
        int failures=0;
        foreach(int n in new[]{30,62}) if(!Check("DIPOLE_N"+n,Dipole(n),28.5,false))failures++;
        foreach(int n in new[]{15,31}) if(!Check("MONO_N"+n,Mono(n),28.5,true))failures++;
        var hair=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        int expected=-1;
        foreach(double f in new[]{28.5,28.7,28.752875,28.8})
        {
            var r=MininecPulseSolver.Solve(hair,frequencyMHzOverride:f,segmentationReferenceMHz:28.5);
            if(expected<0) expected=r.PulseCount;
            bool same=r.PulseCount==expected;
            Console.WriteLine($"{(same?"PASS":"FAIL")} FROZEN_SEGMENTATION f={f:G9} pulses={r.PulseCount} expected={expected}");
            if(!same)failures++;
            if(!Check("HAIRPIN_PEC",hair,f,true))failures++;
        }
        if(!Check("HAIRPIN_COPPER",hair,28.5,true,MininecPulseSolver.ConductorMaterial.Copper))failures++;
        Console.WriteLine($"FINAL {(failures==0?"PASS":"FAIL")} failures={failures} (Hairpin energy deviations remain warnings unless invalid)");
        return failures==0?0:1;
    }
}
