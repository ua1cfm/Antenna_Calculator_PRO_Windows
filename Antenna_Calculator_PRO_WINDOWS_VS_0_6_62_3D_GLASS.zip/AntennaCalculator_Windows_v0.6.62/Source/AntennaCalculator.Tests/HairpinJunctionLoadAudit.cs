﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

// Observational diagnostics only. Do not confuse pulse-basis samples with a strict Kirchhoff proof.
internal static class HairpinJunctionLoadAudit
{
    static MaaModel Clone(MaaModel m,MaaWire[]? wires=null,MaaLoad[]? loads=null) => new() {
      Title=m.Title,FilePath=m.FilePath,FrequencyMHz=m.FrequencyMHz,Wires=wires??m.Wires.ToArray(),
      Sources=m.Sources.ToArray(),Loads=loads??m.Loads.ToArray(),Warnings=m.Warnings,
      GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
      ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,WireHeaderRecord=m.WireHeaderRecord,
      HasCompactStack=m.HasCompactStack,StackExpanded=m.StackExpanded,BaseWireCount=m.BaseWireCount,
      StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
      StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,
      StackPlacementMode=m.StackPlacementMode
    };
    static Complex Z(MininecPulseSolver.Result r)=>new(r.ROhm,r.XOhm);
    static MininecPulseSolver.Result Solve(MaaModel m,MininecPulseSolver.PecJunctionMode mode=MininecPulseSolver.PecJunctionMode.MirroredBalancedTree)
      => MininecPulseSolver.Solve(m,frequencyMHzOverride:28.5,segmentationReferenceMHz:28.5,pecJunctionMode:mode);
    static void Print(string tag,MininecPulseSolver.Result r)
    {
      Console.WriteLine($"CASE {tag} pulses={r.PulseCount} junctions={r.JunctionCount} Zin={Z(r)} residual={r.RelativeResidual:E6} loads={r.LoadStamps?.Count??0} Psrc={r.TotalActivePower:E7}");
      if(!double.IsFinite(r.ROhm)||!double.IsFinite(r.XOhm)||r.RelativeResidual>1e-7) throw new Exception("Invalid impedance or residual");
    }
    static bool Near(double x,double y,double z,double a,double b,double c,double tol=0.023)
      => Math.Sqrt((x-a)*(x-a)+(y-b)*(y-b)+(z-c)*(z-c))<=tol;
    static void JunctionSamples(MininecPulseSolver.Result r)
    {
      var all=r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>();
      int shown=0;
      foreach(var s in all.Where(s=>s.Z>=-1e-8 && Near(s.X,s.Y,s.Z,0.03,0,0.03)).OrderBy(s=>Math.Pow(s.X-.03,2)+s.Y*s.Y+Math.Pow(s.Z-.03,2)).Take(24))
      {
        Console.WriteLine($" NODE_PULSE wires={s.WireNeg}/{s.WirePos} junction={(s.WireNeg!=s.WirePos)} centerMm=({1000*s.X:F4},{1000*s.Y:F4},{1000*s.Z:F4}) I=({s.RealCurrent:G11},{s.ImagCurrent:G11}) halvesNegMm=({1000*s.NegX:F3},{1000*s.NegY:F3},{1000*s.NegZ:F3}) halvesPosMm=({1000*s.PosX:F3},{1000*s.PosY:F3},{1000*s.PosZ:F3})");
        shown++;
      }
      Console.WriteLine($" NODE_SAMPLES={shown}; pulses may share endpoint and are not individually oriented terminal currents; NO KCL PASS asserted");
    }
    static void Stamps(MininecPulseSolver.Result r)
    {
      foreach(var s in r.LoadStamps??Array.Empty<MininecPulseSolver.LoadStampAudit>())
        Console.WriteLine($" STAMP W{s.WireNumber}{s.Position}{s.Offset} pulse={s.PulseIndex} sign={s.PulseSign} sourceCoincident={s.CoincidesWithSource} X={s.XOhm:G12} I=({s.CurrentReal:G12},{s.CurrentImag:G12}) Qload={s.LoadPowerReactive:G12}");
    }
    public static int Run()
    {
      var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
      Console.WriteLine("v0.3.53 JUNCTION / LOAD PLACEMENT / THICK SHORT WIRES; ORIGINAL SOLVER UNCHANGED");
      Console.WriteLine("REFERENCE MMANA 28.5MHz Z=(39.284,-231.814); conductor M=4 not independently mapped");
      int bad=0,count=0; MininecPulseSolver.Result? baseline=null;
      void Check(string tag,Func<MininecPulseSolver.Result> action,bool detailed=false)
      {
        try {var r=action();Print(tag,r);count++;if(detailed){JunctionSamples(r);Stamps(r);}if(tag=="BASE")baseline=r;
          if(baseline!=null && tag!="BASE") Console.WriteLine($" DELTA_Z_FROM_BASE={Z(r)-Z(baseline)}");
          Console.WriteLine($"PASS {tag}");
        } catch(Exception ex){bad++;Console.WriteLine($"FAIL {tag}: {ex}");}
      }
      Console.WriteLine("STEP1 BASE AND OBSERVED NODE PULSE CURRENTS (NOT KCL)");
      Check("BASE",()=>Solve(m),true);
      Console.WriteLine("STEP2 PEC JUNCTION CONSTRUCTION");
      Check("PEC_LEGACY",()=>Solve(m,MininecPulseSolver.PecJunctionMode.LegacyStar),true);
      Console.WriteLine("STEP3 SEPARATE W4/W5 CAPACITORS AND REACTIVE POWER");
      foreach(int w in new[]{4,5})
      {
        var ll=m.Loads.Where(l=>l.WireNumber!=w).ToArray();
        Check($"NO_C_W{w}",()=>Solve(Clone(m,loads:ll)),true);
      }
      Console.WriteLine("STEP4 THIN-WIRE SENSITIVITY W4, W5, BOTH; not physically equivalent antennas");
      foreach(int w in new[]{4,5,45})foreach(double factor in new[]{0.5,0.75,1.25,1.5})
      {
        var ww=m.Wires.Select(x=>(w==45?(x.Number==4||x.Number==5):x.Number==w)?x with{RadiusMetres=x.RadiusMetres*factor}:x).ToArray();
        Check($"RADIUS_W{w}_X{factor:G3}",()=>Solve(Clone(m,wires:ww)));
      }
      Console.WriteLine("STEP5 C_W4 CONTROLLED SWEEP around original, no fitting to MMANA");
      foreach(double factor in new[]{0.90,0.95,0.98,1.02,1.05,1.10})
      {
        var ll=m.Loads.Select(x=>x.WireNumber==4&&x.Kind==0?x with{V2=x.V2*factor}:x).ToArray();
        Check($"CAP_W4_X{factor:G3}",()=>Solve(Clone(m,loads:ll)));
      }
      Console.WriteLine($"FINAL {(bad==0?"PASS":"FAIL")} cases={count} failures={bad}");
      Console.WriteLine("CAUTION: approximate field-sample proximity is not Kirchhoff node balance; source/load stamps are authoritative for pulse indices only.");
      return bad==0?0:1;
    }
}
