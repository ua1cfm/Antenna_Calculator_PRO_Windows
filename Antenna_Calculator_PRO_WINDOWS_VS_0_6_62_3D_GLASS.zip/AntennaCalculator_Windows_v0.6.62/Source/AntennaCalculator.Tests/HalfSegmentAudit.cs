﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

// True geometric half-pulse evaluation: same current as parent pulse, each half
// placed at its own midpoint. Pure diagnostic; solver/matrix unchanged.
internal static class HalfSegmentAudit
{
    const double C=299792458.0, Eta=376.730313668;
    readonly record struct Element(double X,double Y,double Z,Complex Mx,Complex My,Complex Mz);
    readonly record struct Field(Complex X,Complex Y,Complex Z)
    {
        public double Power=>X.Magnitude*X.Magnitude+Y.Magnitude*Y.Magnitude+Z.Magnitude*Z.Magnitude;
    }
    static Element Whole(MininecPulseSolver.FieldSample s)
    {
        Complex i=new(s.RealCurrent,s.ImagCurrent);
        return new(s.X,s.Y,s.Z,2*s.Dx*i,2*s.Dy*i,2*s.Dz*i);
    }
    static Element Half(MininecPulseSolver.FieldSample s,bool positive)
    {
        Complex i=new(s.RealCurrent,s.ImagCurrent);
        double x=positive?s.PosX:s.NegX,y=positive?s.PosY:s.NegY,z=positive?s.PosZ:s.NegZ;
        // Neg half runs EndNeg -> Point, pos half runs Point -> EndPos.
        double dx=positive?x-s.X:s.X-x,dy=positive?y-s.Y:s.Y-y,dz=positive?z-s.Z:s.Z-z;
        return new((x+s.X)/2,(y+s.Y)/2,(z+s.Z)/2,i*dx,i*dy,i*dz);
    }
    static Field Direction(IEnumerable<Element> a,double k,double theta,double phi)
    {
        double nx=Math.Sin(theta)*Math.Cos(phi),ny=Math.Sin(theta)*Math.Sin(phi),nz=Math.Cos(theta);
        Complex x=0,y=0,z=0;
        foreach(var e in a)
        {
            var phase=Complex.FromPolarCoordinates(1,k*(nx*e.X+ny*e.Y+nz*e.Z));
            x+=e.Mx*phase;y+=e.My*phase;z+=e.Mz*phase;
        }
        Complex dot=nx*x+ny*y+nz*z;
        return new(x-nx*dot,y-ny*dot,z-nz*dot);
    }
    static double Power(IReadOnlyList<Element> a,double k,int nt=36,int np=72)
    {
        double dt=Math.PI/(2*nt),dp=2*Math.PI/np,sum=0;
        for(int it=0;it<nt;it++)for(int ip=0;ip<np;ip++)
        {
            double theta=(it+.5)*dt,phi=(ip+.5)*dp;
            sum+=Direction(a,k,theta,phi).Power*Math.Sin(theta)*dt*dp;
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*sum;
    }
    static double Relative(Field a,Field b)
    {
        double diff=(a.X-b.X).Magnitude*(a.X-b.X).Magnitude+(a.Y-b.Y).Magnitude*(a.Y-b.Y).Magnitude+(a.Z-b.Z).Magnitude*(a.Z-b.Z).Magnitude;
        return Math.Sqrt(diff/Math.Max(1e-30,b.Power));
    }
    internal static void Run()
    {
        Console.WriteLine("HALF-SEGMENT CURRENT MOMENT AUDIT v0.3.32 (kernel unchanged)");
        var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        var r=MininecPulseSolver.Solve(model);
        double k=2*Math.PI*model.FrequencyMHz*1e6/C;
        var s=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).ToArray();
        if(s.Any(x=>!double.IsFinite(x.NegX)||!double.IsFinite(x.PosX)))
            throw new InvalidOperationException("Missing exact half-pulse endpoints: rebuild Core and Tests from this archive.");
        var whole=s.Select(Whole).ToArray();
        var halves=s.SelectMany(x=>new[]{Half(x,false),Half(x,true)}).ToArray();
        var regular=s.Where(x=>x.WireNeg==x.WirePos).ToArray();
        var junction=s.Where(x=>x.WireNeg!=x.WirePos).ToArray();
        Console.WriteLine($"f={model.FrequencyMHz:G9} MHz; Z={r.ROhm:G12}+j({r.XOhm:G12}) ohm; Psource={r.TotalActivePower:G12} W; residual={r.RelativeResidual:E7}");
        Console.WriteLine($"pulses={s.Length}; half-elements={halves.Length}; regular={regular.Length}; junction={junction.Length}");
        double maxMoment=0,maxGeo=0,sumDelta=0;
        foreach(var v in s)
        {
            var w=Whole(v);var n=Half(v,false);var p=Half(v,true);
            double e=Complex.Abs(w.Mx-n.Mx-p.Mx)+Complex.Abs(w.My-n.My-p.My)+Complex.Abs(w.Mz-n.Mz-p.Mz);
            maxMoment=Math.Max(maxMoment,e);sumDelta+=e;
            // Endpoint midpoint should be the pulse center, but a cross-wire pulse can have unequal half lengths.
            maxGeo=Math.Max(maxGeo,Math.Sqrt(Math.Pow((v.NegX+v.PosX)/2-v.X,2)+Math.Pow((v.NegY+v.PosY)/2-v.Y,2)+Math.Pow((v.NegZ+v.PosZ)/2-v.Z,2)));
        }
        Console.WriteLine($"MOMENT conservation: sumAbsDelta={sumDelta:E8} A*m; maxDelta={maxMoment:E8} A*m; max midpoint asymmetry={maxGeo:G9} m");
        double pw=Power(whole,k),ph=Power(halves,k),prw=Power(regular.Select(Whole).ToArray(),k),prh=Power(regular.SelectMany(x=>new[]{Half(x,false),Half(x,true)}).ToArray(),k),pjw=Power(junction.Select(Whole).ToArray(),k),pjh=Power(junction.SelectMany(x=>new[]{Half(x,false),Half(x,true)}).ToArray(),k);
        Console.WriteLine($"POWER ALL whole={pw:G12} W, halves={ph:G12} W, half/whole={ph/Math.Max(pw,1e-30):G10}");
        Console.WriteLine($"POWER REGULAR whole={prw:G12} W, halves={prh:G12} W");
        Console.WriteLine($"POWER JUNCTION whole={pjw:G12} W, halves={pjh:G12} W");
        Console.WriteLine($"INTERFERENCE whole={pw-prw-pjw:G12} W, halves={ph-prh-pjh:G12} W");
        Console.WriteLine($"POWER BALANCE half/Psource={ph/Math.Max(r.TotalActivePower,1e-30):G10}; half-Psource={ph-r.TotalActivePower:G12} W (NOT an automatic correction)");
        foreach(var angles in new[]{(20.0,0.0),(45.0,0.0),(70.0,90.0),(88.0,180.0)})
        {
            double t=angles.Item1*Math.PI/180,p=angles.Item2*Math.PI/180;
            var a=Direction(whole,k,t,p);var b=Direction(halves,k,t,p);
            Console.WriteLine($"DIRECTION theta={angles.Item1} phi={angles.Item2}: relative field difference={Relative(a,b):G9}; wholePower={a.Power:G12}, halvesPower={b.Power:G12}");
        }
        foreach(var x in junction)
        {
            var n=Half(x,false);var p=Half(x,true);
            Console.WriteLine($"JUNCTION wires={x.WireNeg},{x.WirePos}; P=({x.X:G7},{x.Y:G7},{x.Z:G7}); EndNeg=({x.NegX:G7},{x.NegY:G7},{x.NegZ:G7}); EndPos=({x.PosX:G7},{x.PosY:G7},{x.PosZ:G7}); I=({x.RealCurrent:G8},{x.ImagCurrent:G8}); halfLengths={Math.Sqrt(Math.Pow(x.X-x.NegX,2)+Math.Pow(x.Y-x.NegY,2)+Math.Pow(x.Z-x.NegZ,2)):G8},{Math.Sqrt(Math.Pow(x.PosX-x.X,2)+Math.Pow(x.PosY-x.Y,2)+Math.Pow(x.PosZ-x.Z,2)):G8}");
        }
        Console.WriteLine("LIMITATION: constant-current half-element approximation uses parent-pulse current. It tests geometry/phase centering only, not a piecewise-linear basis function or MININEC kernel correctness.");
    }
}
