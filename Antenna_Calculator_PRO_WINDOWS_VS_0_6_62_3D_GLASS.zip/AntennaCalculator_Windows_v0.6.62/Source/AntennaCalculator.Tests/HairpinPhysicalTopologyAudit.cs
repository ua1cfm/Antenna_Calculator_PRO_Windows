﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Numerics;
using AntennaCalculator.Core;

internal static class HairpinPhysicalTopologyAudit
{
 static MaaModel Clone(MaaModel m, MaaWire[]? wires=null,MaaSource[]? sources=null,MaaLoad[]? loads=null) => new() {
  Title=m.Title, FilePath=m.FilePath, FrequencyMHz=m.FrequencyMHz, Wires=wires??m.Wires.ToArray(),
  Sources=sources??m.Sources.ToArray(),Loads=loads??m.Loads.ToArray(),Warnings=m.Warnings,
  GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
  ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,WireHeaderRecord=m.WireHeaderRecord,
  HasCompactStack=m.HasCompactStack,StackExpanded=m.StackExpanded,BaseWireCount=m.BaseWireCount,
  StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
  StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,
  StackPlacementMode=m.StackPlacementMode
 };
 static double Dist((double x,double y,double z) a,(double x,double y,double z)b) =>
   Math.Sqrt(Math.Pow(a.x-b.x,2)+Math.Pow(a.y-b.y,2)+Math.Pow(a.z-b.z,2));
 static void Graph(MaaModel m) {
  var ep=m.Wires.SelectMany(w=>new[]{(w:w.Number,e:'B',p:(w.X1,w.Y1,w.Z1)),(w:w.Number,e:'E',p:(w.X2,w.Y2,w.Z2))}).ToArray();
  var seen=new bool[ep.Length];int count=0;
  for(int i=0;i<ep.Length;i++){if(seen[i])continue;var group=Enumerable.Range(0,ep.Length).Where(j=>Dist(ep[i].p,ep[j].p)<1e-7).ToArray();
   foreach(int j in group)seen[j]=true;var p=ep[i].p;
   Console.WriteLine($"NODE {++count} mm=({p.Item1*1000:G7},{p.Item2*1000:G7},{p.Item3*1000:G7}) terminals={string.Join(",",group.Select(j=>$"W{ep[j].w}{ep[j].e}"))} PEC={Math.Abs(p.Item3)<1e-9}");
  }
  Console.WriteLine($"GRAPH nodes={count} wires={m.Wires.Count}");
  foreach(var s in m.Sources)Console.WriteLine($"MAA_SOURCE W{s.WireNumber}{s.Position}{s.Offset} V={s.RelativeVoltage:G8} phase={s.PhaseDegrees:G8}");
  foreach(var l in m.Loads)Console.WriteLine($"MAA_LOAD W{l.WireNumber}{l.Position}{l.Offset} kind={l.Kind} L_uH={l.V1:G8} C_pF={l.V2:G8} Q={l.V3:G8}");
 }
 static MininecPulseSolver.Result Solve(string id,MaaModel m,MininecPulseSolver.PecJunctionMode mode=MininecPulseSolver.PecJunctionMode.MirroredBalancedTree){
  var r=MininecPulseSolver.Solve(m,frequencyMHzOverride:28.5,segmentationReferenceMHz:28.5,pecJunctionMode:mode);
  Console.WriteLine($"CASE {id} pulses={r.PulseCount} junctions={r.JunctionCount} Z=({r.ROhm:G12},{r.XOhm:G12}) P={r.TotalActivePower:E8} residual={r.RelativeResidual:E8} stampedLoads={r.LoadStamps?.Count??0}");
  foreach(var a in r.LoadStamps??Array.Empty<MininecPulseSolver.LoadStampAudit>())
   Console.WriteLine($" STAMP W{a.WireNumber}{a.Position}{a.Offset} idx={a.PulseIndex} sign={a.PulseSign} ground={a.AtGround} sourceCoincident={a.CoincidesWithSource} Z=({a.ROhm:G9},{a.XOhm:G9}) I=({a.CurrentReal:G9},{a.CurrentImag:G9})");
  if(!double.IsFinite(r.ROhm)||!double.IsFinite(r.XOhm)||!double.IsFinite(r.RelativeResidual))throw new Exception("NONFINITE");
  return r;
 }
 public static int Run(){
  var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
  Console.WriteLine("v0.3.52 MULTI-STEP PHYSICAL TOPOLOGY TEST; original solver unchanged; no MMANA fitting");
  Console.WriteLine("MMANA reference at 28.5 MHz: 39.284-j231.814 Ohm");
  int bad=0,pass=0;Graph(m);
  MininecPulseSolver.Result? reference=null;
  void Check(string name,Func<MininecPulseSolver.Result> task,bool invariance=false){
   try {var r=task();if(invariance&&reference!=null){double dz=Complex.Abs(new Complex(r.ROhm-reference.ROhm,r.XOhm-reference.XOhm));Console.WriteLine($"  INVARIANCE_DZ_OHM={dz:E8}");
    if(dz>1e-6*Math.Max(1,Complex.Abs(new Complex(reference.ROhm,reference.XOhm))))throw new Exception("SOURCE_SCALING_INVARIANCE_FAIL");}
    pass++;Console.WriteLine($"PASS {name}");}catch(Exception ex){bad++;Console.WriteLine($"FAIL {name}: {ex}");}
  }
  Console.WriteLine("STEP1 PEC topology comparison");
  Check("PEC_BALANCED",()=>Solve("PEC_BALANCED",m));
  Check("PEC_LEGACY",()=>Solve("PEC_LEGACY",m,MininecPulseSolver.PecJunctionMode.LegacyStar));
  Console.WriteLine("STEP2 source orientation / linearity");
  Check("REFERENCE",()=>reference=Solve("REFERENCE",m));
  Check("PHASE_180",()=>Solve("PHASE_180",Clone(m,sources:m.Sources.Select(s=>s with {PhaseDegrees=s.PhaseDegrees+180}).ToArray())),true);
  Check("VOLTAGE_X2",()=>Solve("VOLTAGE_X2",Clone(m,sources:m.Sources.Select(s=>s with {RelativeVoltage=s.RelativeVoltage*2}).ToArray())),true);
  Console.WriteLine("STEP3 load stamps, remove independently, +/-1% capacitances");
  Check("REMOVE_BOTH_LOADS",()=>Solve("REMOVE_BOTH_LOADS",Clone(m,loads:Array.Empty<MaaLoad>())));
  foreach(int wire in new[]{4,5}){
   int w=wire;Check($"REMOVE_C_W{w}",()=>Solve($"REMOVE_C_W{w}",Clone(m,loads:m.Loads.Where(l=>l.WireNumber!=w).ToArray())));
   foreach(double shift in new[]{-0.01,0.01}){double d=shift;
    var changed=m.Loads.Select(l=>l.WireNumber==w&&l.Kind==0?l with{V2=l.V2*(1+d)}:l).ToArray();
    Check($"W{w}_C_{d:+0%;-0%}",()=>Solve($"W{w}_C_{d:+0%;-0%}",Clone(m,loads:changed)));
   }
  }
  Console.WriteLine("STEP4 geometry variations (not equivalent antennas)");
  Check("W5_RADIUS_90PCT",()=>Solve("W5_RADIUS_90PCT",Clone(m,wires:m.Wires.Select(w=>w.Number==5?w with{RadiusMetres=w.RadiusMetres*0.9}:w).ToArray())));
  var trimmed=m.Wires.Where(w=>w.Number!=4).Select((w,i)=>w with{Number=i+1}).ToArray();
  var srcs=m.Sources.Select(s=>s with {WireNumber=s.WireNumber==5?4:s.WireNumber}).ToArray();
  var loads=m.Loads.Where(l=>l.WireNumber!=4).Select(l=>l with{WireNumber=l.WireNumber==5?4:l.WireNumber}).ToArray();
  Check("REMOVE_W4_WIRE",()=>Solve("REMOVE_W4_WIRE",Clone(m,wires:trimmed,sources:srcs,loads:loads)));
  Console.WriteLine($"FINAL {(bad==0?"PASS":"FAIL")} failures={bad} completed={pass}");
  Console.WriteLine("LIMIT: PASS does not prove physical agreement with MMANA, only diagnostic invariances and finite solutions.");
  return bad==0?0:1;
 }
}
