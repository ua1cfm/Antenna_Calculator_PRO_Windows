using AntennaCalculator.Core;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Threading;

// Matrix/RHS verification harness. The MMANA reference columns are intentionally absent:
// they must be supplied by an independently executed MMANA build, never synthesized.
internal static class MmanaMatrixParity
{
    private static double Norm(Complex[] x) => Math.Sqrt(x.Sum(z => z.Magnitude*z.Magnitude));
    private static double Residual(MininecPulseSolver.MatrixSnapshot a, double[] xr,double[] xi)
    {
        int n=a.Size; double sum=0,bsum=0;
        for(int i=0;i<n;i++)
        {
            double rr=-a.RhsReal[i],ri=-a.RhsImag[i];
            for(int j=0;j<n;j++)
            {
                int k=i*n+j;rr+=a.Real[k]*xr[j]-a.Imag[k]*xi[j];
                ri+=a.Real[k]*xi[j]+a.Imag[k]*xr[j];
            }
            sum+=rr*rr+ri*ri; bsum+=a.RhsReal[i]*a.RhsReal[i]+a.RhsImag[i]*a.RhsImag[i];
        }
        return Math.Sqrt(sum/Math.Max(1e-300,bsum));
    }
    private static void WriteCsv(string path, MininecPulseSolver.MatrixSnapshot a)
    {
        // Full matrix CSV is deliberately limited to small/medium benchmarks.
        using var sw=new StreamWriter(path,false,new System.Text.UTF8Encoding(false));
        sw.WriteLine("row,column,A_real,A_imag,rhs_real,rhs_imag");
        int n=a.Size;
        for(int i=0;i<n;i++)for(int j=0;j<n;j++)
        {
            int k=i*n+j;
            sw.WriteLine(string.Join(",",i,j,a.Real[k].ToString("R",CultureInfo.InvariantCulture),
                a.Imag[k].ToString("R",CultureInfo.InvariantCulture),
                (j==0?a.RhsReal[i]:0).ToString("R",CultureInfo.InvariantCulture),
                (j==0?a.RhsImag[i]:0).ToString("R",CultureInfo.InvariantCulture)));
        }
    }
    public static int Run(string[] args)
    {
        // Examples: --mmana-matrix-parity --model "Samples/fixture_PEC_monopole.maa" --export-dir parity_out
        string Read(string flag,string fallback) { int k=Array.IndexOf(args,flag);return k>=0&&k+1<args.Length?args[k+1]:fallback; }
        string file=Read("--model",Path.Combine(AppContext.BaseDirectory,"Samples","fixture_PEC_monopole.maa"));
        string dest=Path.GetFullPath(Read("--export-dir","matrix_parity_output"));
        Directory.CreateDirectory(dest);
        try
        {
            var model=MaaParser.ParseFile(Path.GetFullPath(file));
            MininecPulseSolver.MatrixSnapshot? snap=null;
            string status="";
            try
            {
                var r=MininecPulseSolver.Solve(model,
                    realEarthMode:MininecPulseSolver.RealEarthMode.MmanaPecCurrentApproximation,
                    matrixSnapshotObserver:m=>snap=m);
                status=$"production Zin={r.ROhm:R}+j{r.XOhm:R}";
            }
            catch(Exception e) when(snap!=null) {status="production solve: "+e.Message;}
            if(snap==null)throw new InvalidOperationException("Matrix snapshot unavailable; production setup failed: "+status);
            var a=snap;int n=a.Size;
            if(n>900)throw new InvalidOperationException($"Matrix size {n} > 900. Use a smaller reference geometry to export full coefficients; no automatic resegmentation is performed.");
            string name=Path.GetFileNameWithoutExtension(file);
            string csv=Path.Combine(dest,"matrix_rhs.csv");
            WriteCsv(csv,a);
            var gauss=MininecPulseSolver.GaussianSolve(a.Real,a.Imag,a.RhsReal,a.RhsImag,n,CancellationToken.None);
            double luResidual=Residual(a,gauss.Real,gauss.Imag);
            string output=$"model={name}; n={n}; G={model.GroundType}; LU residual={luResidual:E8}; {status}";
            bool passed=double.IsFinite(luResidual)&&luResidual<1e-7;
            if(n>360)
            {
                try
                {
                    var iterative=MininecPulseSolver.GmresSolve(a.Real,a.Imag,a.RhsReal,a.RhsImag,n,CancellationToken.None);
                    double iterRes=Residual(a,iterative.Real,iterative.Imag);
                    double diff=0,baseNorm=0;
                    for(int i=0;i<n;i++)
                    {
                        diff+=Math.Pow(iterative.Real[i]-gauss.Real[i],2)+Math.Pow(iterative.Imag[i]-gauss.Imag[i],2);
                        baseNorm+=gauss.Real[i]*gauss.Real[i]+gauss.Imag[i]*gauss.Imag[i];
                    }
                    double relativeDiff=Math.Sqrt(diff/Math.Max(1e-300,baseNorm));
                    output+=$"; FGMRES residual={iterRes:E8}; current delta={relativeDiff:E8}; iterations={iterative.Iterations}";
                    passed&=double.IsFinite(iterRes)&&iterRes<2e-7&&relativeDiff<2e-4;
                }
                catch(Exception e) {output+="; FGMRES failed: "+e.Message;passed=false;}
            }
            else output+="; FGMRES not compared (production uses direct solve <=360)";
            File.WriteAllText(Path.Combine(dest,"results.txt"),output+Environment.NewLine+
                "MMANA numerical reference: NOT PROVIDED. Do not report MMANA parity from this test alone."+Environment.NewLine);
            Console.WriteLine(output);
            Console.WriteLine("Matrix/RHS export: "+csv);
            Console.WriteLine("Internal consistency "+(passed?"PASS":"FAIL")+"; MMANA parity NOT VERIFIED");
            return passed?0:1;
        }
        catch(Exception e){Console.Error.WriteLine("FAIL "+e);return 1;}
    }
}
