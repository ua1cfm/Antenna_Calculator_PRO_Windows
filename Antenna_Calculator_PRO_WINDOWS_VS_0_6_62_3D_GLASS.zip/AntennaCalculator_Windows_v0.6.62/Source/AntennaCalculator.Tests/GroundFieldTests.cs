using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using AntennaCalculator.Core;

/// <summary>
/// dotnet run -- --ground-field : the near-field kernel (2D map / 3D volume / CUDA) with ground images must reproduce,
/// far from the antenna, the ground-reflection operator of the 3D radiation pattern (MININEC v89/h89, εr=13, σ=0.005).
/// </summary>
internal static class GroundFieldTests
{
    public static int Run()
    {
        int failed = 0;
        double f = 7.05, lambda = 299.792458 / f, k = 2 * Math.PI / lambda, h = 7.0;
        // Horizontal half-wave dipole along Y at 7 m (0.16 λ), plus a sloping element (vertical components).
        var real = new List<MininecPulseSolver.FieldSample>();
        int n = 40; double half = 0.25 * lambda;
        for (int i = 0; i < n; i++)
        {
            double y = -half + (i + .5) * 2 * half / n, s = Math.Abs(y) / half;
            real.Add(new MininecPulseSolver.FieldSample(0, y, h, 0, 2 * half / n, 0, Math.Cos(Math.PI / 2 * s), 0));
        }
        for (int i = 0; i < 20; i++)
        {
            double t = (i + .5) / 20;
            real.Add(new MininecPulseSolver.FieldSample(5, -10 * t, h - 4 * t, 0, -10.0 / 20, -4.0 / 20, 0.6 * (1 - t), 0.3 * (1 - t)));
        }
        var samples = new List<MininecPulseSolver.FieldSample>(real);
        foreach (var a in real)   // PEC images, as BatchCalculator.BuildMmanaSamples builds them
            samples.Add(a with { Z = -a.Z, Dx = -a.Dx, Dy = -a.Dy });
        Complex er = NearFieldKernel.GroundPermittivity(f, 13.0, 0.005);
        double R = 300 * lambda;
        foreach (int ground in new[] { 1, 2 })
        {
            var near = new List<double>(); var far = new List<double>();
            foreach (double elDeg in new[] { 3.0, 10, 20, 35, 50, 70, 85 })
                foreach (double azDeg in new[] { 0.0, 45, 90 })
                {
                    double el = elDeg * Math.PI / 180, az = azDeg * Math.PI / 180;
                    double nx = Math.Cos(el) * Math.Cos(az), ny = Math.Cos(el) * Math.Sin(az), nz = Math.Sin(el);
                    Complex ex = 0, ey = 0, ez = 0, hx = 0, hy = 0, hz = 0;
                    foreach (var a in samples)
                        NearFieldKernel.Add(a, R * nx, R * ny, R * nz, k, lambda, ground, er, ref ex, ref ey, ref ez, ref hx, ref hy, ref hz);
                    near.Add(Math.Sqrt(ex.Magnitude * ex.Magnitude + ey.Magnitude * ey.Magnitude + ez.Magnitude * ez.Magnitude));
                    far.Add(Reference(real, k, ground == 2 ? er : new Complex(1e12, 0), nx, ny, nz));
                }
            double nMax = near.Max(), fMax = far.Max(), worst = 0;
            for (int i = 0; i < near.Count; i++)
            {
                double a = 20 * Math.Log10(near[i] / nMax), b = 20 * Math.Log10(far[i] / fMax);
                if (b > -40) worst = Math.Max(worst, Math.Abs(a - b));
            }
            bool ok = worst < 0.1;
            Console.WriteLine($"{(ok ? "OK  " : "FAIL")}  G={ground}: near-field kernel at 300 λ vs 3D-pattern ground operator: max {worst:0.000} dB");
            if (!ok) failed++;
        }
        // Antenna height H: with ground the solvers place the wires at z = Z + H; the field views use
        // MaaModel.PhysicalZOffset for the same rule (0.6.50: maps were centred on Z, not on Z + H).
        foreach (var (g, hgt) in new[] { (2, 5.0), (1, 3.0), (0, 5.0) })
        {
            string text = string.Join("\r\n", new[]
            {
                "height test", "*", "50.3", "*** Wires ***", "1",
                "0.0, -1.449, 0.0, 0.0, 1.449, 0.0, 0.003, -1",
                "*** Source ***", "1, 1", "w1c, 0.0, 1.0",
                "*** Load ***", "0, 1", "*** Segmentation ***", "400, 80, 2.0, 2",
                "*** G/H/M/R/AzEl/X ***", $"{g}, {hgt.ToString(System.Globalization.CultureInfo.InvariantCulture)}, 0, 50.0, 120, 60, 0.0", ""
            });
            var model = MaaParser.Parse(text);
            var (res, err) = MmanaReferenceEngine.SolveText(text);
            if (res?.Currents is not { Count: > 0 } cur) { Console.WriteLine($"FAIL  G={g}, H={hgt}: no currents ({err})"); failed++; continue; }
            double zCurrents = cur.Average(c => c.Z);
            bool ok = Math.Abs(zCurrents - model.PhysicalZOffset) < 1e-6;
            Console.WriteLine($"{(ok ? "OK  " : "FAIL")}  G={g}, H={hgt}: currents at z = {zCurrents:0.###} m, PhysicalZOffset = {model.PhysicalZOffset:0.###} m");
            if (!ok) failed++;
        }
        Console.WriteLine(failed == 0 ? "Ground field: all checks passed" : $"Ground field: {failed} failed");
        return failed == 0 ? 0 : 1;
    }

    /// <summary>Far-field magnitude with the RadiationField.Direction ground operator (physical samples only).</summary>
    static double Reference(List<MininecPulseSolver.FieldSample> real, double k, Complex er, double nx, double ny, double nz)
    {
        var (v89, h89) = NearFieldKernel.Reflection(er, nx, ny, nz);
        double phi = Math.Atan2(ny, nx), px = -Math.Sin(phi), py = Math.Cos(phi);
        Complex gx = 0, gy = 0, gz = 0;
        foreach (var s in real)
        {
            Complex cur = new(s.RealCurrent, s.ImagCurrent);
            Complex a = cur * Complex.FromPolarCoordinates(1, k * (nx * s.X + ny * s.Y + nz * s.Z));
            gx += a * s.Dx; gy += a * s.Dy; gz += a * s.Dz;
            Complex img = cur * Complex.FromPolarCoordinates(1, k * (nx * s.X + ny * s.Y - nz * s.Z));
            double d = px * s.Dx + py * s.Dy;
            gx -= img * (v89 * s.Dx + h89 * d * px); gy -= img * (v89 * s.Dy + h89 * d * py); gz += img * v89 * s.Dz;
        }
        Complex dot = nx * gx + ny * gy + nz * gz;
        Complex tx = gx - nx * dot, ty = gy - ny * dot, tz = gz - nz * dot;
        return Math.Sqrt(tx.Magnitude * tx.Magnitude + ty.Magnitude * ty.Magnitude + tz.Magnitude * tz.Magnitude);
    }
}
