﻿using System;
using System.IO;
using System.Linq;
using AntennaCalculator.Core;

internal static class MutualPairAuditTest
{
    private static void PrintPulse(string prefix,MininecPulseSolver.MutualPulseGeometry p)
    {
        Console.WriteLine($"    {prefix}: pulse={p.Index}, wires={p.WireNegative},{p.WirePositive}, junction={p.Junction}; P=({p.X:G8},{p.Y:G8},{p.Z:G8})");
        Console.WriteLine($"      EndNeg=({p.NegX:G8},{p.NegY:G8},{p.NegZ:G8}); EndPos=({p.PosX:G8},{p.PosY:G8},{p.PosZ:G8})");
        Console.WriteLine($"      Lneg={p.LenNegative:G8}, Lpos={p.LenPositive:G8}; Rneg={p.RadiusNegative:G8}, Rpos={p.RadiusPositive:G8}");
        Console.WriteLine($"      DirNeg=({p.DirNegX:G6},{p.DirNegY:G6},{p.DirNegZ:G6}); DirPos=({p.DirPosX:G6},{p.DirPosY:G6},{p.DirPosZ:G6})");
    }
    internal static void Run()
    {
        Console.WriteLine("MININEC MUTUAL PAIR AUDIT v0.3.34 — diagnostic only, kernel unchanged");
        foreach(var file in new[]{"hairpin monopol.maa","dipole_14_2MHz_free.maa","fixture_PEC_elevated_dipole.maa"})
        {
            var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples",file));
            MininecPulseSolver.MutualPairAudit? audit=null;
            var r=MininecPulseSolver.Solve(model,mutualPairObserver:a=>audit=a);
            if(audit==null)throw new Exception("Missing mutual pair callback");
            Console.WriteLine($"CASE {file}: G={model.GroundType}; f={model.FrequencyMHz:G9}; pulses={audit.Size}; Z={r.ROhm:G12}+j({r.XOhm:G12}); residual={r.RelativeResidual:E6}");
            Console.WriteLine($"  ||A-A^T||/||A||={audit.TransposeRelative:E9}; strongest directed asymmetry indices=({audit.MaxRow},{audit.MaxColumn})");
            foreach(var p in audit.Pairs)
            {
                Console.WriteLine($"  PAIR ({p.I},{p.J}): Aij=({p.AijReal:G12},{p.AijImag:G12}); Aji=({p.AjiReal:G12},{p.AjiImag:G12}); rel={p.RelativeDifference:G9}; sign-flip rel={p.SignFlipRelativeDifference:G9}; length-weighted rel={p.GeometricScaleRelativeDifference:G9}");
                PrintPulse("row",p.Row);PrintPulse("column",p.Column);
            }
        }
        Console.WriteLine("INTERPRETATION: non-symmetric collocation matrices do not necessarily violate physical reciprocity. Neither forced A=(A+A^T)/2 nor impedance fitting is performed.");
    }
}
