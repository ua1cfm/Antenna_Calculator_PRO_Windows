﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using System.Threading;
using AntennaCalculator.Core;

// This is a LOWER BOUND on kappa_inf, not an exact condition number.
internal static class HairpinConditionAudit
{
    static MaaModel Tags(MaaModel m,Func<MaaWire,int> rule)=>new MaaModel{
        Title=m.Title,FilePath=m.FilePath,FrequencyMHz=m.FrequencyMHz,
        Wires=m.Wires.Select(w=>w with {Tag=rule(w)}).ToArray(),
        Sources=m.Sources.ToArray(),Loads=m.Loads.ToArray(),Warnings=m.Warnings,
        GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord,HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded,BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,StackPlacementMode=m.StackPlacementMode};
    static double InfinityNorm(double[] re,double[] im,int n){double max=0;
        for(int i=0;i<n;i++){double sum=0;for(int j=0;j<n;j++)sum+=Complex.Abs(new Complex(re[i*n+j],im[i*n+j]));max=Math.Max(max,sum);}return max;}
    static double VectorInf(double[] re,double[] im)=>Enumerable.Range(0,re.Length).Max(i=>Complex.Abs(new Complex(re[i],im[i])));
    static double RelResidual(MininecPulseSolver.MatrixSnapshot m,double[] xr,double[] xi,double[] br,double[] bi){
        int n=m.Size;double residual=0;for(int i=0;i<n;i++){double rr=-br[i],ri=-bi[i];for(int j=0;j<n;j++){
            int q=i*n+j;rr+=m.Real[q]*xr[j]-m.Imag[q]*xi[j];ri+=m.Real[q]*xi[j]+m.Imag[q]*xr[j];}
            residual=Math.Max(residual,Math.Sqrt(rr*rr+ri*ri));}
        return residual/Math.Max(1e-300,InfinityNorm(m.Real,m.Imag,n)*VectorInf(xr,xi)+VectorInf(br,bi));}
    // Separate unscaled complex LU with partial pivoting, independent of solver's row equilibration.
    static (double[] Re,double[] Im) IndependentLu(MininecPulseSolver.MatrixSnapshot m,double[] br,double[] bi){
        int n=m.Size;var a=new Complex[n*n];var b=new Complex[n];
        for(int i=0;i<n*n;i++)a[i]=new(m.Real[i],m.Imag[i]);
        for(int i=0;i<n;i++)b[i]=new(br[i],bi[i]);
        for(int k=0;k<n;k++){
            int piv=k;double best=0;for(int i=k;i<n;i++){double z=a[i*n+k].Magnitude;if(z>best){best=z;piv=i;}}
            if(best<1e-180)throw new ArithmeticException("Independent LU singular pivot at "+k);
            if(piv!=k){for(int j=0;j<n;j++)(a[k*n+j],a[piv*n+j])=(a[piv*n+j],a[k*n+j]);(b[k],b[piv])=(b[piv],b[k]);}
            for(int i=k+1;i<n;i++){Complex factor=a[i*n+k]/a[k*n+k];a[i*n+k]=Complex.Zero;
                for(int j=k+1;j<n;j++)a[i*n+j]-=factor*a[k*n+j];b[i]-=factor*b[k];}
        }
        var x=new Complex[n];for(int i=n-1;i>=0;i--){Complex v=b[i];for(int j=i+1;j<n;j++)v-=a[i*n+j]*x[j];x[i]=v/a[i*n+i];}
        return(x.Select(z=>z.Real).ToArray(),x.Select(z=>z.Imaginary).ToArray());
    }
    static int One(string name,MaaModel model){
        try{
            MininecPulseSolver.MatrixSnapshot? snapshot=null;
            var result=MininecPulseSolver.Solve(model,frequencyMHzOverride:28.5,segmentationReferenceMHz:28.5,
                matrixSnapshotObserver:x=>snapshot=x);
            if(snapshot==null)throw new InvalidOperationException("snapshot missing");
            var m=snapshot;int n=m.Size;double norm=InfinityNorm(m.Real,m.Imag,n);double inverseLower=0;
            Console.WriteLine($"=== {name} === n={n} Zin=({result.ROhm:G12},{result.XOhm:G12}) normInf={norm:E8} residual={result.RelativeResidual:E5}");
            bool ok=true;
            for(int pattern=0;pattern<4;pattern++){
                var br=new double[n];var bi=new double[n];
                for(int i=0;i<n;i++){
                    if(pattern==0)br[i]=1;
                    else if(pattern==1)br[i]=(i%2==0?1:-1);
                    else if(pattern==2){br[i]=Math.Cos(i*1.741);bi[i]=Math.Sin(i*1.741);}
                    else if(i==n/2)br[i]=1;
                }
                var p=MininecPulseSolver.GaussianSolve(m.Real,m.Imag,br,bi,n,CancellationToken.None);
                var q=IndependentLu(m,br,bi);
                double difference=Enumerable.Range(0,n).Max(i=>Complex.Abs(new Complex(p.Real[i]-q.Re[i],p.Imag[i]-q.Im[i])));
                double relativeDifference=difference/Math.Max(1e-300,VectorInf(p.Real,p.Imag));
                double resP=RelResidual(m,p.Real,p.Imag,br,bi),resQ=RelResidual(m,q.Re,q.Im,br,bi);
                inverseLower=Math.Max(inverseLower,VectorInf(p.Real,p.Imag)/VectorInf(br,bi));
                bool pass=double.IsFinite(resP)&&double.IsFinite(resQ)&&resP<1e-7&&resQ<1e-7&&relativeDifference<1e-5;
                Console.WriteLine($" RHS{pattern}: {(pass?"PASS":"FAIL")} scaledLUres={resP:E5} unscaledLUres={resQ:E5} deltaRelative={relativeDifference:E5}");
                if(!pass)ok=false;
            }
            // For every RHS: ||A^-1|| >= ||A^-1 b||/||b||; so condition >= normA*max ratio.
            Console.WriteLine($" CONDITION_LOWER_BOUND_INF={norm*inverseLower:E8} exactCondition=NOT_COMPUTED (4 RHS samples)");
            Console.WriteLine($" RESULT {(ok?"PASS":"FAIL")} loadCount={result.LoadStamps?.Count??0} activePower={result.TotalActivePower:E8}");
            return ok&&result.LoadStamps?.Count==2&&result.TotalActivePower>0?0:1;
        }catch(Exception e){Console.WriteLine("FAIL "+e);return 1;}
    }
    public static int Run(){
        Console.WriteLine("v0.3.50 MATRIX CONDITION LOWER-BOUND + INDEPENDENT UNSCALED LU");
        Console.WriteLine("DO NOT interpret condition lower bound as exact. Independent full Aij electromagnetic quadrature NOT implemented.");
        var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        int failures=One("AUTO",m);
        failures+=One("SHORT_2",Tags(m,w=>w.Number is 2 or 4 or 5?2:w.Tag));
        failures+=One("LONG_30_SHORT_2",Tags(m,w=>w.Number is 1 or 3?30:2));
        Console.WriteLine($"FINAL {(failures==0?"PASS":"FAIL")} failures={failures}");return failures==0?0:1;
    }
}
