﻿using System;
using System.IO;
using System.Linq;
using AntennaCalculator.Core;

// Conservative geometry suitability diagnostics; never changes impedance or kernel.
internal static class HairpinMeshQualityAudit
{
    static MaaModel CopyWithTags(MaaModel m, Func<MaaWire,int> tag) => new MaaModel
    {
        Title=m.Title,FilePath=m.FilePath,FrequencyMHz=m.FrequencyMHz,
        Wires=m.Wires.Select(w=>w with {Tag=tag(w)}).ToArray(),
        Loads=m.Loads.ToArray(),Sources=m.Sources.ToArray(),Warnings=m.Warnings,
        GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord,HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded,BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,StackPlacementMode=m.StackPlacementMode
    };
    static int AutoSpans(MaaWire w,double fMHz)
    {
        // Actual automatic segment count is solver dependent; do NOT present a guess as fact.
        return 0;
    }
    static void Geometry(MaaModel m)
    {
        foreach(var w in m.Wires)
        {
            int n=w.Tag>0?w.Tag:AutoSpans(w,m.FrequencyMHz);
            string segments=n>0?n.ToString():"AUTO (not inferred)";
            string ratio=n>0?(w.LengthMetres/n/(2*w.RadiusMetres)).ToString("G8"):"N/A";
            string grade=n==0?"UNKNOWN_AUTO": w.LengthMetres/n/(2*w.RadiusMetres)<1?"INVALID_THIN_WIRE_SEGMENT":w.LengthMetres/n/(2*w.RadiusMetres)<2?"WARNING_SHORT_SEGMENT":"GEOMETRY_ONLY_OK";
            Console.WriteLine($" WIRE W{w.Number} spans={segments} length_mm={w.LengthMetres*1000:G9} diameter_mm={2*w.RadiusMetres*1000:G9} span_over_diameter={ratio} status={grade}");
        }
    }
    static string Probe(string name,MaaModel m,ref int failures)
    {
        Console.WriteLine("=== "+name+" ===");Geometry(m);
        try
        {
            var r=MininecPulseSolver.Solve(m,frequencyMHzOverride:28.5,segmentationReferenceMHz:28.5);
            bool finite=double.IsFinite(r.ROhm)&&double.IsFinite(r.XOhm);
            bool nonnegative=r.TotalActivePower>=0;
            bool matching=r.LoadStamps?.Count==m.Loads.Count;
            Console.WriteLine($" SOLVE pulses={r.PulseCount} junctions={r.JunctionCount} R={r.ROhm:G14} X={r.XOhm:G14} residual={r.RelativeResidual:E6} Psource={r.TotalActivePower:G14} loads={r.LoadStamps?.Count ?? -1} finite={finite} passive={nonnegative} loadsMatch={matching}");
            if(!finite||!nonnegative||!matching){failures++;Console.WriteLine(" FAIL NUMERICAL_OR_TOPOLOGICAL_INVARIANT");}
            if(m.Wires.Any(w=>w.Tag>0&&w.LengthMetres/w.Tag/(2*w.RadiusMetres)<1)) Console.WriteLine(" WARNING PHYSICAL_UNSUITABLE: segment shorter than conductor diameter; calculated Z not validated");
            return $"{r.PulseCount},{r.ROhm:G14},{r.XOhm:G14}";
        }
        catch(Exception ex)
        {
            failures++;Console.WriteLine($" FAIL SOLVER_REJECTED {ex.GetType().Name}: {ex.Message}");
            return "REJECTED";
        }
    }
    public static int Run()
    {
        var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        Console.WriteLine("HAIRPIN MESH QUALITY v0.3.45; UNMODIFIED SOLVER; fixed 28.5 MHz");
        Console.WriteLine("MMANA reference 39.284 - j231.814 ohm; not a tuning target");
        Console.WriteLine("Thin wire warning thresholds are conservative DIAGNOSTIC flags, not universal solver-validity proofs.");
        int failures=0;
        Probe("BASE_AUTO",m,ref failures);
        // Two independent sweeps: never interpret different topology as pure mesh convergence.
        foreach(int n in new[]{20,30,40,50,60})
        {
            var mm=CopyWithTags(m,w=>(w.Number==1||w.Number==3)?n:w.Tag);
            Probe($"LONG_ARMS_{n}_OTHERS_AUTO",mm,ref failures);
        }
        foreach(int n in new[]{2,3,4,6,8})
        {
            var mm=CopyWithTags(m,w=>n);
            Probe($"ALL_WIRES_{n}",mm,ref failures);
        }
        Console.WriteLine("CONCLUSIONS: compare only results with identical geometry, ground, source, loads AND appropriate discretization. A successful linear solve alone is NOT convergence.");
        Console.WriteLine($"FINAL {(failures==0?"PASS_WITH_GEOMETRY_WARNINGS":"FAIL")} failures={failures}");
        return failures==0?0:1;
    }
}
