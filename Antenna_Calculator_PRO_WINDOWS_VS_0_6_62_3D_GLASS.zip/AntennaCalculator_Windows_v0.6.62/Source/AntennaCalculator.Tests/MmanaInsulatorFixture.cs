﻿using System;
using System.IO;
using System.Linq;
using AntennaCalculator.Core;

public static class MmanaInsulatorFixture
{
    public static int Run()
    {
        try
        {
            string file=Path.Combine(AppContext.BaseDirectory,"Samples","_____10__103__id35734.maa");
            if(!File.Exists(file))file=Path.Combine("Samples","_____10__103__id35734.maa");
            var model=MaaParser.ParseFile(file);
            int ins=model.Wires.Count(w=>w.RadiusMetres==0);
            Console.WriteLine($"MMANA ZERO-RADIUS FIXTURE: wires={model.Wires.Count} insulators={ins} sourceW={model.Sources[0].WireNumber} ground={model.GroundType}");
            if(model.Wires.Count!=19 || ins!=9 || model.Sources.Count!=1 || model.Sources[0].WireNumber!=6 || model.GroundType!=2)
                throw new Exception("Структура контрольной модели не совпала с ожидаемой.");
            try { MininecPulseSolver.Solve(model); throw new Exception("Strict G=2 неожиданно был разрешён."); }
            catch(NotSupportedException e) when(e.Message.Contains("G=2")) { Console.WriteLine("PASS: strict real earth is not silently replaced by PEC"); }
            var result=MininecPulseSolver.Solve(model,realEarthMode:MininecPulseSolver.RealEarthMode.MmanaPecCurrentApproximation);
            Console.WriteLine($"PEC PREVIEW (NOT REAL GROUND): pulses={result.PulseCount} Zin={result.ROhm:G10}+j{result.XOhm:G10} residual={result.RelativeResidual:G5}");
            if(result.PulseCount<=0 || !double.IsFinite(result.ROhm) || !double.IsFinite(result.XOhm))throw new Exception("Invalid numeric result.");
            Console.WriteLine("PASS: insulator removal / source remap / PEC preview");
            return 0;
        }
        catch(Exception e){Console.WriteLine("FAIL: "+e);return 1;}
    }
}
