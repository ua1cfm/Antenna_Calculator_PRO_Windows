using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AntennaCalculator.Core;

/// <summary>dotnet run -- --wire-edit : MaaParser.ReplaceWireGeometry and EncodeForSave (geometry editing, 0.6.58).</summary>
internal static class WireEditTests
{
    public static int Run()
    {
        int failed = 0;
        void Check(bool ok, string what) { Console.WriteLine($"{(ok ? "OK  " : "FAIL")}  {what}"); if (!ok) failed++; }
        string text = string.Join("\r\n", new[]
        {
            "Тест редактирования", "*", "14.15", "*** Wires ***", "2",
            "0.0, -5.0, 10.0, 0.0, 5.0, 10.0, 0.001, -1",
            "2.0, -4.8, 10.0, 2.0, 4.8, 10.0, 8.0e-04, 12",
            "*** Source ***", "1, 1", "w1c, 0.0, 1.0",
            "*** Load ***", "0, 1",
            "*** Segmentation ***", "800, 80, 2.0, 2",
            "*** G/H/M/R/AzEl/X ***", "0, 0.0, 0, 50.0, 120, 60, 0.0", ""
        });
        var before = MaaParser.Parse(text);
        var changes = new Dictionary<int, MaaParser.WireGeometry> { [2] = new(2.1, -4.65, 10.0, 2.1, 4.65, 10.0, 0.0009) };
        string edited = MaaParser.ReplaceWireGeometry(text, changes);
        var after = MaaParser.Parse(edited);
        var w = after.Wires[1];
        Check(Math.Abs(w.X1 - 2.1) < 1e-12 && Math.Abs(w.Y1 + 4.65) < 1e-12 && Math.Abs(w.Y2 - 4.65) < 1e-12 && Math.Abs(w.RadiusMetres - 0.0009) < 1e-15,
              "wire 2: new coordinates and radius read back");
        Check(w.Tag == 12, "wire 2: segmentation field kept (12)");
        Check(after.Wires[0] == before.Wires[0], "wire 1 unchanged");
        string[] a = text.Split('\n'), b = edited.Split('\n');
        int diff = Enumerable.Range(0, Math.Min(a.Length, b.Length)).Count(i => a[i] != b[i]);
        Check(a.Length == b.Length && diff == 1, "exactly one line changed, line count kept");
        Check(b.All(l => l.Length == 0 || l.EndsWith('\r') || l == b[^1]), "CRLF line endings kept");
        Check(after.Sources.Count == before.Sources.Count && after.FrequencyMHz == before.FrequencyMHz, "sources and frequency unchanged");
        bool threw = false;
        try { MaaParser.ReplaceWireGeometry(text, new Dictionary<int, MaaParser.WireGeometry> { [3] = new(0, 0, 0, 1, 0, 0, 0.001) }); }
        catch (FormatException) { threw = true; }
        Check(threw, "a wire that is not in the file is rejected");
        byte[] bytes = MaaParser.EncodeForSave(edited);
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        string back = Encoding.GetEncoding(1251).GetString(bytes);
        Check(back == edited && bytes.Length == edited.Length, "saved as Windows-1251 and decoded back identically");
        Console.WriteLine(failed == 0 ? "Wire edit: all checks passed" : $"Wire edit: {failed} failed");
        return failed == 0 ? 0 : 1;
    }
}
