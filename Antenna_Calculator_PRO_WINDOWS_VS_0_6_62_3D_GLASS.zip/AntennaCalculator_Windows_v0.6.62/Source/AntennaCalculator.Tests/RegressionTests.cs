using System;
using System.Linq;
using AntennaCalculator.Core;

/// <summary>Regression checks of version 0.6.x features: dotnet run -- --regress</summary>
internal static class RegressionTests
{
    static int _failed, _skipped;
    static void Check(bool ok,string name){ Console.WriteLine((ok?"OK    ":"FAIL  ")+name); if(!ok) _failed++; }
    static void Skip(string name){ Console.WriteLine("SKIP  "+name); _skipped++; }

    static string Maa(string title,string wireHeader,string[] wires,string[] sources)=>string.Join("\r\n",new[]
    {
        title,"*","14.0","*** Wires ***",wireHeader
    }.Concat(wires).Concat(new[]{ "*** Source ***",$"{sources.Length}, 1" }).Concat(sources).Concat(new[]
    {
        "*** Load ***","0, 1","*** Segmentation ***","400, 40, 2.0, 1","*** G/H/M/R/AzEl/X ***","0, 10.0, 0, 50.0, 120, 60, 0.0",""
    }));

    public static int Run()
    {
        // 1. Make Stack through the MMANA core = the same antenna written out explicitly.
        {
            string stacked=Maa("stack","1, 2, 1, 5.0, 0.0, 0",new[]{ "-5.0, 0.0, 10.0, 5.0, 0.0, 10.0, 0.001, -1" },new[]{ "w1c, 0.0, 1.0" });
            string explicitModel=Maa("explicit","2",new[]{ "-5.0, -2.5, 10.0, 5.0, -2.5, 10.0, 0.001, -1","-5.0, 2.5, 10.0, 5.0, 2.5, 10.0, 0.001, -1" },
                                      new[]{ "w1c, 0.0, 1.0","w2c, 0.0, 1.0" });
            var (a,ea)=MmanaReferenceEngine.SolveText(stacked);
            var (b,eb)=MmanaReferenceEngine.SolveText(explicitModel);
            if(a==null || b==null) Check(false,$"Make Stack via MMANA core ({ea ?? eb})");
            else
            {
                double d=Math.Abs(a.R-b.R)+Math.Abs(a.X-b.X);
                Check(d<1e-9 && a.Pulses==b.Pulses,$"Make Stack 2×1 = explicit model: {a.R:0.000}{a.X:+0.000;-0.000}j vs {b.R:0.000}{b.X:+0.000;-0.000}j, {a.Pulses}/{b.Pulses} pulses");
            }
        }

        // 2. Parallel LU gives exactly the sequential result (same arithmetic, same pivots).
        {
            string big=Maa("lu","1",new[]{ "0.0, -10.0, 10.0, 0.0, 10.0, 10.0, 0.001, 520" },new[]{ "w1c, 0.0, 1.0" });
            bool keep=MmanaReferenceEngine.ParallelLu;
            string? gpu=Environment.GetEnvironmentVariable("ANTCALC_GPU_LU");
            Environment.SetEnvironmentVariable("ANTCALC_GPU_LU","0");
            MmanaReferenceEngine.ParallelLu=true;  var (p,_)=MmanaReferenceEngine.SolveText(big);
            MmanaReferenceEngine.ParallelLu=false; var (q,_)=MmanaReferenceEngine.SolveText(big);
            MmanaReferenceEngine.ParallelLu=keep;
            Environment.SetEnvironmentVariable("ANTCALC_GPU_LU",gpu);
            bool same=p!=null && q!=null && p.R.Equals(q.R) && p.X.Equals(q.X) && p.Currents!=null && q.Currents!=null &&
                      p.Currents.Zip(q.Currents).All(z=>z.First.CurrentRe.Equals(z.Second.CurrentRe) && z.First.CurrentIm.Equals(z.Second.CurrentIm));
            Check(same,$"parallel LU == sequential LU bit for bit ({p?.Pulses} pulses)");
        }

        // 3. GPU LU (if AntennaCudaLu64.dll + CUDA runtime are found) agrees with the CPU LU.
        {
            string big=Maa("gpu","1",new[]{ "0.0, -20.0, 10.0, 0.0, 20.0, 10.0, 0.001, 1200" },new[]{ "w1c, 0.0, 1.0" });
            string? gpu=Environment.GetEnvironmentVariable("ANTCALC_GPU_LU");
            Environment.SetEnvironmentVariable("ANTCALC_GPU_LU","0"); var (cpu,_)=MmanaReferenceEngine.SolveText(big);
            Environment.SetEnvironmentVariable("ANTCALC_GPU_LU",null); var (g,_)=MmanaReferenceEngine.SolveText(big);
            Environment.SetEnvironmentVariable("ANTCALC_GPU_LU",gpu);
            bool used=g!=null && g.Warnings.Any(w=>w.StartsWith("GPU cuSOLVER",StringComparison.Ordinal));
            if(!used) Skip("GPU LU vs CPU LU: GPU not used ("+(g?.Warnings.FirstOrDefault(w=>w.Contains("GPU")) ?? "AntennaCudaLu64.dll not found; set ANTCALC_GPU_LU_DIR to the program folder")+")");
            else
            {
                double rel=Math.Abs(new System.Numerics.Complex(g!.R-cpu!.R,g.X-cpu.X).Magnitude)/new System.Numerics.Complex(cpu.R,cpu.X).Magnitude;
                Check(rel<1e-4,$"GPU LU vs CPU LU: relative |ΔZ| {rel:E2} ({g.Warnings.First(w=>w.StartsWith("GPU",StringComparison.Ordinal))})");
            }
        }

        // 4. NanoVNA shell answer parser.
        {
            string answer="scan 1000000 3000000 3 7\r\n1000000 0.1 0.2 0.3 0.4\r\n2000000 0.5 0.6 0.7 0.8\r\n3000000 0.9 1.0 1.1 1.2\r\nch> ";
            var rows=NanoVnaShellParser.ParseScan(answer,1_000_000,3_000_000,3);
            Check(rows.Length==3 && rows[1][1]==0.5 && rows[2][4]==1.2 && NanoVnaShellParser.EndsWithPrompt(answer),"NanoVNA scan: echo skipped, 3 rows, prompt");
            string khz="1000 0.1 0.2 0.3 0.4\r\n2000 0.5 0.6 0.7 0.8\r\n3000 0.9 1.0 1.1 1.2\r\nch>";
            Check(NanoVnaShellParser.ParseScan(khz,1_000_000,3_000_000,3).Length==3,"NanoVNA scan: frequency column in kHz accepted");
            bool threw=false; try{ NanoVnaShellParser.ParseScan(answer,1_000_000,5_000_000,3); } catch(FormatException){ threw=true; }
            Check(threw,"NanoVNA scan: wrong last frequency rejected");
            threw=false; try{ NanoVnaShellParser.ParseScan(answer,1_000_000,3_000_000,4); } catch(FormatException){ threw=true; }
            Check(threw,"NanoVNA scan: too few rows rejected");
        }

        // 5. V2 binary: LiteVNA-only registers are not written for other variants; settings comparison.
        {
            var c=new LiteVnaProtocol.SweepConfig(1_000_000,30_000_000,201,4);
            bool HasReg(byte[][] cmds,byte reg)=>cmds.Any(x=>x.Length>=2 && x[0]==LiteVnaProtocol.OpWrite && x[1]==reg);
            var lite=LiteVnaProtocol.ConfigureSweep(c,true); var other=LiteVnaProtocol.ConfigureSweep(c,false);
            Check(HasReg(lite,LiteVnaProtocol.RegAverage) && HasReg(lite,LiteVnaProtocol.RegChannelSelect) &&
                  !HasReg(other,LiteVnaProtocol.RegAverage) && !HasReg(other,LiteVnaProtocol.RegChannelSelect),"V2: averaging/channel registers only for LiteVNA");
            Check(c.SameSettings(new LiteVnaProtocol.SweepConfig(1_000_000,30_000_000,201,4)) && !c.SameSettings(new LiteVnaProtocol.SweepConfig(1_000_000,30_000_000,201,8)) && !c.SameSettings(null),
                  "V2: re-configure only when the grid or averaging changes");
        }

        Console.WriteLine(_failed==0 ? $"Regression: all checks passed ({_skipped} skipped)" : $"Regression: {_failed} failed, {_skipped} skipped");
        return _failed==0 ? 0 : 1;
    }
}
