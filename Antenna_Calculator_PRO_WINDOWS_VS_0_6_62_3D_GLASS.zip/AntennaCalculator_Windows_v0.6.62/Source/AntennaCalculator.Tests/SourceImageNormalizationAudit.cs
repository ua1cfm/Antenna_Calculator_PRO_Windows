﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

// All reported watts are relative to the declared peak source amplitude.
internal static class SourceImageNormalizationAudit
{
    const double Eta=376.730313668, Speed=299792458.0;
    readonly record struct Elem(double X,double Y,double Z,Complex Mx,Complex My,Complex Mz);
    static Elem ToElem(MininecPulseSolver.FieldSample s)
    {
        Complex i=new(s.RealCurrent,s.ImagCurrent);
        return new(s.X,s.Y,s.Z,2*s.Dx*i,2*s.Dy*i,2*s.Dz*i);
    }
    static double Radiation(IReadOnlyList<Elem> a,double f,int nt,int np,bool upper)
    {
        double k=2*Math.PI*f*1e6/Speed,dt=(upper?Math.PI/2:Math.PI)/nt,dp=2*Math.PI/np,total=0;
        for(int ti=0;ti<nt;ti++)
        {
            double theta=(ti+0.5)*dt,s=Math.Sin(theta),c=Math.Cos(theta);
            for(int pi=0;pi<np;pi++)
            {
                double p=(pi+0.5)*dp,nx=s*Math.Cos(p),ny=s*Math.Sin(p),nz=c;
                Complex x=0,y=0,z=0;
                foreach(var e in a)
                {
                    Complex ph=Complex.FromPolarCoordinates(1,k*(nx*e.X+ny*e.Y+nz*e.Z));
                    x+=e.Mx*ph;y+=e.My*ph;z+=e.Mz*ph;
                }
                Complex dot=nx*x+ny*y+nz*z;
                x-=nx*dot;y-=ny*dot;z-=nz*dot;
                total+=(x.Magnitude*x.Magnitude+y.Magnitude*y.Magnitude+z.Magnitude*z.Magnitude)*s*dt*dp;
            }
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*total;
    }
    static MaaModel Monopole(char feed,int segments)
    {
        return new MaaModel {
            Title="PEC_VERTICAL_MONOPOLE_SOLVED",FilePath="diagnostic",FrequencyMHz=28.5,
            Wires=new[]{new MaaWire(1,0,0,0,0,0,2.5,0.002,segments)},
            Sources=new[]{new MaaSource(1,feed,0,0,1,"W1"+feed+"0,1")},
            Loads=Array.Empty<MaaLoad>(),Warnings=Array.Empty<string>(),GroundType=1,
            SegmentationRecord="800,80,1.1,16",ReferenceOhms=50
        };
    }
    static void Evaluate(string name,MaaModel model,MininecPulseSolver.ConductorMaterial material)
    {
        try
        {
            var r=MininecPulseSolver.Solve(model,conductor:material);
            var a=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).ToArray();
            var all=a.Select(ToElem).ToArray();
            var pos=a.Where(s=>s.Z>1e-8).Select(ToElem).ToArray();
            var neg=a.Where(s=>s.Z< -1e-8).Select(ToElem).ToArray();
            var plane=a.Where(s=>Math.Abs(s.Z)<=1e-8).Select(ToElem).ToArray();
            double upper=Radiation(all,model.FrequencyMHz,24,48,true);
            double full=Radiation(all,model.FrequencyMHz,24,48,false);
            double psource=r.TotalActivePower,pmetal=r.PhysicalConductorLossPower;
            Console.WriteLine($"CASE {name} MATERIAL {material} G={model.GroundType} f={model.FrequencyMHz:G9} pulses={r.PulseCount} residual={r.RelativeResidual:E6} Zin=({r.ROhm:G13},{r.XOhm:G13})");
            foreach(var p in r.Ports??Array.Empty<MininecPulseSolver.PortResult>())
                Console.WriteLine($"PORT W{p.WireNumber}{p.Position}{p.Offset} V={p.VoltageMagnitude:G12} I={p.CurrentMagnitude:G12} phase={p.CurrentPhaseDegrees:G12} Z=({p.ROhm:G12},{p.XOhm:G12}) P={p.ActivePower:G13} Q={p.ReactivePower:G13}");
            Console.WriteLine($"ELEMENTS plus={pos.Length} plane={plane.Length} minus={neg.Length} sum={a.Length}");
            Console.WriteLine($"POWER port={psource:G14} metal={pmetal:G14} available={psource-pmetal:G14} radiationUpper={upper:G14} radiationFull={full:G14} upper/available={upper/Math.Max(1e-30,psource-pmetal):G12} full/available={full/Math.Max(1e-30,psource-pmetal):G12} full/(2*upper)={full/Math.Max(1e-30,2*upper):G12}");
            Console.WriteLine($"POWER_COMPONENT upperPositive={Radiation(pos,model.FrequencyMHz,24,48,true):G14} upperNegative={Radiation(neg,model.FrequencyMHz,24,48,true):G14} upperPlane={Radiation(plane,model.FrequencyMHz,24,48,true):G14}");
            // Feed currents are not inferred from impedance or from mirrored moments.
            var largest=a.Where(s=>s.Z>=0).OrderByDescending(s=>Complex.Abs(new Complex(s.RealCurrent,s.ImagCurrent))).Take(3);
            foreach(var e in largest)
                Console.WriteLine($"LARGEST_CURRENT z={e.Z:G9} wires=({e.WireNeg},{e.WirePos}) I=({e.RealCurrent:G12},{e.ImagCurrent:G12}) length={2*Math.Sqrt(e.Dx*e.Dx+e.Dy*e.Dy+e.Dz*e.Dz):G9}");
        }
        catch(Exception ex) {Console.WriteLine($"CASE {name} ERROR {ex.GetType().Name}: {ex.Message}");}
    }
    internal static void Run()
    {
        Console.WriteLine("SOURCE / PEC IMAGE NORMALIZATION AUDIT v0.3.39 — unmodified matrix and radiation formula");
        Console.WriteLine("CAUTION: base-fed endpoint excitation may require a specialized PEC-ground voltage gap. Any solver rejection is a diagnostic result, not a pass.");
        foreach(int n in new[]{15,31})
        {
            Evaluate($"MONOPOLE_BASE_B_N{n}",Monopole('b',n),MininecPulseSolver.ConductorMaterial.Pec);
            Evaluate($"MONOPOLE_CENTER_C_N{n}",Monopole('c',n),MininecPulseSolver.ConductorMaterial.Pec);
        }
        var hairpin=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        Evaluate("HAIRPIN_ORIGINAL",hairpin,MininecPulseSolver.ConductorMaterial.Pec);
        Evaluate("HAIRPIN_ORIGINAL",hairpin,MininecPulseSolver.ConductorMaterial.Copper);
        Console.WriteLine("INTERPRETATION: upper hemisphere power must be compared against actual physical-source power, accounting for any duplicated mirrored excitations; free-space full-sphere power is separate. Ratios alone do not justify re-scaling currents or fields.");
    }
}
