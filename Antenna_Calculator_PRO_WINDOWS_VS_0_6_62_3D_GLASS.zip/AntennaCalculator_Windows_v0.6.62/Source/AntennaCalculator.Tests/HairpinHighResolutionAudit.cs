﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using AntennaCalculator.Core;

internal static class HairpinHighResolutionAudit
{
    private readonly record struct Sample(double F,double R,double X,double Swr,double Psource,double Prad,int Pulses,double Residual);
    private static readonly CultureInfo CI=CultureInfo.InvariantCulture;
    private static string N(double x)=>x.ToString("G12",CI);
    private static double RadiatedCoarse(MininecPulseSolver.Result result,double f)
    {
        var samples=result.FieldSamples;
        if(samples==null || samples.Count==0)return double.NaN;
        const double eta=376.730313668;
        double k=2*Math.PI*f*1e6/299792458.0;
        int nt=12,np=24;
        double dt=Math.PI/(2*nt), dp=2*Math.PI/np, integral=0;
        for(int t=0;t<nt;t++)for(int p=0;p<np;p++)
        {
            double theta=(t+0.5)*dt,phi=(p+0.5)*dp;
            double nx=Math.Sin(theta)*Math.Cos(phi),ny=Math.Sin(theta)*Math.Sin(phi),nz=Math.Cos(theta);
            Complex sx=0,sy=0,sz=0;
            foreach(var s in samples)
            {
                var phase=Complex.FromPolarCoordinates(1,k*(nx*s.X+ny*s.Y+nz*s.Z));
                var current=new Complex(s.RealCurrent,s.ImagCurrent)*phase;
                sx+=2*s.Dx*current; sy+=2*s.Dy*current; sz+=2*s.Dz*current;
            }
            Complex projection=nx*sx+ny*sy+nz*sz;
            sx-=nx*projection;sy-=ny*projection;sz-=nz*projection;
            integral+=(sx.Magnitude*sx.Magnitude+sy.Magnitude*sy.Magnitude+sz.Magnitude*sz.Magnitude)*Math.Sin(theta)*dt*dp;
        }
        return eta*k*k/(32*Math.PI*Math.PI)*integral;
    }
    private static Sample Evaluate(MaaModel model,double f,bool power=false)
    {
        var r=MininecPulseSolver.Solve(model,frequencyMHzOverride:f,segmentationReferenceMHz:28.5);
        return new Sample(f,r.ROhm,r.XOhm,r.Swr(50),r.TotalActivePower,power?RadiatedCoarse(r,f):double.NaN,r.PulseCount,r.RelativeResidual);
    }
    private static MaaModel ChangeCapacitance(MaaModel m,int wire,double factor)
    {
        var loads=m.Loads.Select(l=>l.WireNumber==wire && l.Kind==0
            ? l with { V2=l.V2*factor, Raw=l.Raw+" [sensitivity]" } : l).ToArray();
        return new MaaModel {Title=m.Title,FilePath=m.FilePath,FrequencyMHz=m.FrequencyMHz,
            Wires=m.Wires,Sources=m.Sources,Loads=loads,Warnings=m.Warnings,
            GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
            ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,
            WireHeaderRecord=m.WireHeaderRecord,HasCompactStack=m.HasCompactStack,StackExpanded=m.StackExpanded,
            BaseWireCount=m.BaseWireCount,StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
            StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
            StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,StackPlacementMode=m.StackPlacementMode};
    }
    private static void RefineBracket(MaaModel m,Sample a,Sample b,string label)
    {
        // Bisection is only valid for continuous X(f). A jump through a pole is reported separately.
        if(Math.Sign(a.X)==Math.Sign(b.X))return;
        double left=a.F,right=b.F;
        var lo=a;var hi=b;
        for(int n=0;n<18;n++)
        {
            double mid=(left+right)/2;
            var sm=Evaluate(m,mid);
            if(Math.Sign(sm.X)==Math.Sign(lo.X)){left=mid;lo=sm;}else{right=mid;hi=sm;}
        }
        double f=(left+right)/2;
        var root=Evaluate(m,f,true);
        bool likelyPole=Math.Max(Math.Abs(lo.X),Math.Abs(hi.X))>1000 &&
            Math.Abs(root.X)>Math.Min(Math.Abs(a.X),Math.Abs(b.X));
        Console.WriteLine($"{label} BRACKET {N(a.F)}..{N(b.F)} MHz refinedF={N(f)} R={N(root.R)} X={N(root.X)} " +
            $"bracketX=({N(lo.X)},{N(hi.X)}) type={(likelyPole?"POSSIBLE_POLE_NOT_RESONANCE":"ZERO_CANDIDATE_VERIFY_CONTINUITY")} " +
            $"Prad/Psource={N(root.Prad/root.Psource)}");
    }
    internal static void Run()
    {
        var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        Console.WriteLine("HAIRPIN HIGH RESOLUTION RESONANCE AUDIT v0.3.37 (kernel unchanged)");
        Console.WriteLine("f=28.40..29.60 MHz step=0.01 MHz; original MAA loads and topology; segmentation anchored to 28.5 MHz");
        Console.WriteLine("Caution: X sign reversal across a pole is NOT a zero-reactance resonance; MMANA full curve not supplied.");
        Console.WriteLine("fMHz ROhm XOhm SWR50 |Iport|_approx(1V) phaseI_deg Psource PradCoarse ratio pulses residual");
        var all=new List<Sample>();
        for(int i=0;i<=120;i++)
        {
            double f=28.4+i*0.01;
            try
            {
                bool power=(i%10==0||i==10||i==60||i==110);
                var s=Evaluate(m,f,power);
                all.Add(s);
                Complex z=new(s.R,s.X),current=Complex.One/z;
                Console.WriteLine($"SWEEP {N(f)} {N(s.R)} {N(s.X)} {N(s.Swr)} {N(current.Magnitude)} {N(current.Phase*180/Math.PI)} " +
                    $"{N(s.Psource)} {N(s.Prad)} {N(s.Prad/s.Psource)} {s.Pulses} {s.Residual:E4}");
            }
            catch(Exception ex){Console.WriteLine($"SWEEP {N(f)} FAILED {ex.GetType().Name}: {ex.Message}");}
        }
        for(int i=1;i<all.Count;i++)
            if(all[i-1].X*all[i].X<0 && all[i].F-all[i-1].F<0.015)
                try{RefineBracket(m,all[i-1],all[i],"ROOT_CHECK");}
                catch(Exception ex){Console.WriteLine($"ROOT_CHECK FAILED {ex.Message}");}
        if(all.Count>0)
        {
            var best=all.Where(s=>double.IsFinite(s.Swr)).OrderBy(s=>s.Swr).FirstOrDefault();
            Console.WriteLine($"MIN_SWR_GRID f={N(best.F)} R={N(best.R)} X={N(best.X)} SWR={N(best.Swr)}");
            Console.WriteLine("REFERENCE MMANA f=28.5MHz R=39.284 X=-231.814 Ohm (single data point only)");
        }
        Console.WriteLine("CAPACITANCE_SENSITIVITY: each capacitor varied separately; 28.5MHz and approximate zero-X bracket around 28.4..29.2MHz");
        foreach(int wire in new[]{4,5})foreach(double pct in new[]{-5.0,-1.0,0.0,1.0,5.0})
        {
            try
            {
                var changed=ChangeCapacitance(m,wire,1+pct/100);
                var at=Evaluate(changed,28.5);
                Console.WriteLine($"CAP wire=W{wire} Cfactor={N(1+pct/100)} f=28.5 R={N(at.R)} X={N(at.X)} SWR={N(at.Swr)}");
                Sample? prev=null;
                for(int j=0;j<=8;j++)
                {
                    var s=Evaluate(changed,28.4+j*0.1);
                    if(prev.HasValue && prev.Value.X*s.X<0)
                    {
                        Console.WriteLine($"CAP_BRACKET W{wire} pct={N(pct)} f={N(prev.Value.F)}..{N(s.F)} X={N(prev.Value.X)}..{N(s.X)} (zero or pole, not classified)");
                        break;
                    }
                    prev=s;
                }
            }
            catch(Exception ex){Console.WriteLine($"CAP W{wire} pct={N(pct)} FAILED: {ex.Message}");}
        }
        Console.WriteLine("Power quadrature 12x24 is coarse and only a diagnostic. Do not use its ratio as a correction factor.");
    }
}
