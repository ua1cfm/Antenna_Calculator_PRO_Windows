﻿using System;
using System.IO;
using System.Linq;
using AntennaCalculator.Core;

internal static class HairpinActualSpanAudit
{
    private static MaaModel WithTags(MaaModel m, Func<MaaWire,int> tags) => new MaaModel
    {
        Title=m.Title,FilePath=m.FilePath,FrequencyMHz=m.FrequencyMHz,
        Wires=m.Wires.Select(w=>w with { Tag=tags(w) }).ToArray(),
        Loads=m.Loads.ToArray(),Sources=m.Sources.ToArray(),Warnings=m.Warnings,
        GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord,HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded,BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,StackPlacementMode=m.StackPlacementMode
    };

    public static int Run()
    {
        var original=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        Console.WriteLine("HAIRPIN ACTUAL SPANS / SHORT-WIRE ISOLATION AUDIT v0.3.46");
        Console.WriteLine("Observed via the same ordinary-wire span algorithm as Build; matrix and UI unchanged.");
        Console.WriteLine("MMANA 28.5MHz reference 39.284 - j231.814 ohm; NEVER fitted.");
        int rejects=0, completed=0;
        // Compare auto topology with fixed minimum two spans on all three short wires.
        // Long-wire refinement is a separate dimension: physical geometry and loads unchanged.
        var cases=new (string Name,MaaModel Model)[]
        {
            ("BASE_AUTO",original),
            ("SHORT_2_LONG_AUTO",WithTags(original,w=>w.Number is 2 or 4 or 5 ? 2:w.Tag)),
            ("SHORT_3_LONG_AUTO",WithTags(original,w=>w.Number is 2 or 4 or 5 ? 3:w.Tag)),
            ("SHORT_2_LONG_20",WithTags(original,w=>w.Number is 2 or 4 or 5 ? 2:20)),
            ("SHORT_2_LONG_30",WithTags(original,w=>w.Number is 2 or 4 or 5 ? 2:30)),
            ("SHORT_2_LONG_40",WithTags(original,w=>w.Number is 2 or 4 or 5 ? 2:40)),
            ("SHORT_3_LONG_20",WithTags(original,w=>w.Number is 2 or 4 or 5 ? 3:20)),
            ("SHORT_3_LONG_30",WithTags(original,w=>w.Number is 2 or 4 or 5 ? 3:30)),
            ("SHORT_3_LONG_40",WithTags(original,w=>w.Number is 2 or 4 or 5 ? 3:40)),
            ("DIAGONAL_AUTO_OTHER_SHORT_2",WithTags(original,w=>w.Number is 2 or 5 ? 2:w.Tag)),
            ("DIAGONAL_2_OTHER_AUTO",WithTags(original,w=>w.Number==4?2:w.Tag))
        };
        foreach(var item in cases)
        {
            Console.WriteLine("=== "+item.Name+" ===");
            int below=0;int predicted=0;
            foreach(var w in item.Model.Wires)
            {
                var info=MeshSpanInspector.Inspect(item.Model,w,28.5);
                below+=info.BelowDiameter;
                predicted+=info.Spans;
                Console.WriteLine($"SPAN W{w.Number} tag={w.Tag} actualCount={info.Spans} minMm={info.MinLengthMm:G8} maxMm={info.MaxLengthMm:G8} minOverDiameter={info.MinOverDiameter:G8} belowD={info.BelowDiameter} below2D={info.BelowTwoDiameters}");
            }
            Console.WriteLine($"GEOMETRY totalPhysicalSpans={predicted} shortSpansBelowDiameter={below} advisory={(below>0?"CAUTION":"NONE")}");
            try
            {
                var r=MininecPulseSolver.Solve(item.Model,frequencyMHzOverride:28.5,segmentationReferenceMHz:28.5);
                completed++;
                bool valid=double.IsFinite(r.ROhm)&&double.IsFinite(r.XOhm)&&r.TotalActivePower>=0;
                Console.WriteLine($"SOLVE pulses={r.PulseCount} junctions={r.JunctionCount} R={r.ROhm:G14} X={r.XOhm:G14} Psrc={r.TotalActivePower:G14} residual={r.RelativeResidual:E5} loads={r.LoadStamps?.Count ?? -1} valid={valid}");
                if(!valid)rejects++;
            }
            catch(Exception e)
            {
                rejects++;
                Console.WriteLine($"REJECTED {e.GetType().Name}: {e.Message}");
            }
        }
        Console.WriteLine($"FINAL completed={completed} rejectedOrInvalid={rejects} total={cases.Length}");
        Console.WriteLine("Interpret each case independently; low matrix residual is not a mesh-convergence criterion.");
        return rejects==0?0:1;
    }
}
