﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

// Diagnostic only: no changes to MININEC matrix or displayed radiation patterns.
internal static class PecFieldRepresentationAudit
{
    private const double C=299792458.0, Eta=376.730313668;
    private readonly record struct Element(double X,double Y,double Z,Complex Mx,Complex My,Complex Mz);
    private readonly record struct Vector(Complex X,Complex Y,Complex Z)
    {
        public double Norm2=>X.Magnitude*X.Magnitude+Y.Magnitude*Y.Magnitude+Z.Magnitude*Z.Magnitude;
    }
    private static Vector Field(IReadOnlyList<Element> elements,double k,double thetaDeg,double phiDeg)
    {
        double t=thetaDeg*Math.PI/180,phi=phiDeg*Math.PI/180;
        double nx=Math.Sin(t)*Math.Cos(phi),ny=Math.Sin(t)*Math.Sin(phi),nz=Math.Cos(t);
        Complex x=0,y=0,z=0;
        foreach(var e in elements)
        {
            var phase=Complex.FromPolarCoordinates(1,k*(nx*e.X+ny*e.Y+nz*e.Z));
            x+=e.Mx*phase; y+=e.My*phase; z+=e.Mz*phase;
        }
        Complex dot=nx*x+ny*y+nz*z;
        return new(x-nx*dot,y-ny*dot,z-nz*dot);
    }
    private static double Integrate(IReadOnlyList<Element> a,double k,int nt=36,int np=72)
    {
        double dt=Math.PI/(2*nt),dp=2*Math.PI/np,acc=0;
        for(int it=0;it<nt;it++) for(int ip=0;ip<np;ip++)
        {
            double theta=(it+.5)*dt,phi=(ip+.5)*dp;
            var v=Field(a,k,theta*180/Math.PI,phi*180/Math.PI);
            acc+=v.Norm2*Math.Sin(theta)*dt*dp;
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*acc;
    }
    private static Element Convert(MininecPulseSolver.FieldSample s)
    {
        var i=new Complex(s.RealCurrent,s.ImagCurrent);
        return new(s.X,s.Y,s.Z,2*s.Dx*i,2*s.Dy*i,2*s.Dz*i);
    }
    // PEC image current moment for z=0: tangential reversed, normal retained.
    private static Element Image(Element p)=>new(p.X,p.Y,-p.Z,-p.Mx,-p.My,p.Mz);
    private static string Format(Complex z)=>$"({z.Real:G8},{z.Imaginary:G8})";
    private static string FormatVec(Vector v)=>$"Ex={Format(v.X)} Ey={Format(v.Y)} Ez={Format(v.Z)}";
    private static double Relative(Vector a,Vector b)
    {
        double n=(a.X-b.X).Magnitude*(a.X-b.X).Magnitude+
                 (a.Y-b.Y).Magnitude*(a.Y-b.Y).Magnitude+
                 (a.Z-b.Z).Magnitude*(a.Z-b.Z).Magnitude;
        return Math.Sqrt(n/Math.Max(b.Norm2,1e-40));
    }
    internal static void Run()
    {
        Console.WriteLine("PEC FIELD REPRESENTATION AUDIT v0.3.30 (no numerical corrections)");
        var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        var r=MininecPulseSolver.Solve(model);
        double k=2*Math.PI*model.FrequencyMHz*1e6/C;
        var samples=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).ToArray();
        // z=0 samples are assigned to the physical set once. The unfolded result may
        // contain additional junction pulse moments at z=0; report their count explicitly.
        const double eps=1e-8;
        var physical=samples.Where(s=>s.Z>=-eps).Select(Convert).ToArray();
        var unfolded=samples.Select(Convert).ToArray();
        var physicalWithImage=physical.Concat(physical.Select(Image)).ToArray();
        int zeros=samples.Count(s=>Math.Abs(s.Z)<=eps);
        Console.WriteLine($"f={model.FrequencyMHz:G9} MHz ground={model.GroundType}; fieldSamples={samples.Length}; physical(z>=0)={physical.Length}; mirror(z<0)={samples.Count(s=>s.Z < -eps)}; z=0={zeros}");
        Console.WriteLine("A = physical only (diagnostic, omits ground image)");
        Console.WriteLine("B = all solver physical+explicit mirrored pulse moments (as supplied)");
        Console.WriteLine("C = physical with analytical PEC reflected moments; z=0 samples may cause ambiguity");
        double pA=Integrate(physical,k),pB=Integrate(unfolded,k),pC=Integrate(physicalWithImage,k);
        double available=r.TotalActivePower-r.PhysicalConductorLossPower;
        Console.WriteLine($"Psource={r.TotalActivePower:G12}; Pmetal={r.PhysicalConductorLossPower:G12}; Pavailable={available:G12}; Zin={r.ROhm:G11}+j({r.XOhm:G11})");
        Console.WriteLine($"Prad_A={pA:G12}; Prad_B={pB:G12}; Prad_C={pC:G12}; B/C={pB/Math.Max(pC,1e-30):G10}; B/A={pB/Math.Max(pA,1e-30):G10}; C/A={pC/Math.Max(pA,1e-30):G10}");
        Console.WriteLine($"Prad_B/Pavailable={pB/Math.Max(available,1e-30):G10}; Prad_C/Pavailable={pC/Math.Max(available,1e-30):G10}");
        foreach(var direction in new[]{(theta:20.0,phi:0.0),(theta:45.0,phi:0.0),(theta:70.0,phi:90.0),(theta:88.0,phi:180.0)})
        {
            var a=Field(physical,k,direction.theta,direction.phi);
            var b=Field(unfolded,k,direction.theta,direction.phi);
            var c=Field(physicalWithImage,k,direction.theta,direction.phi);
            Console.WriteLine($"DIR theta={direction.theta:G3} phi={direction.phi:G3}: A {FormatVec(a)}; B {FormatVec(b)}; C {FormatVec(c)}; rel(B,C)={Relative(b,c):G9}");
        }
        foreach(var port in r.Ports??Array.Empty<MininecPulseSolver.PortResult>())
        {
            var pEst=.5*port.VoltageMagnitude*port.CurrentMagnitude*Math.Cos(port.CurrentPhaseDegrees*Math.PI/180);
            Console.WriteLine($"PORT W{port.WireNumber}{port.Position}{port.Offset}: |V|={port.VoltageMagnitude:G10}; |I|={port.CurrentMagnitude:G12}; phaseI={port.CurrentPhaseDegrees:G9} deg; Z=({port.ROhm:G10},{port.XOhm:G10}); Pport={port.ActivePower:G12}; PfromV_I={pEst:G12}");
        }
        Console.WriteLine("CAUTION: C uses analytic image moments and copies z=0 pulses; if B differs from C, inspect ground-connected junction moments and phase conventions before altering the kernel. The 3.9x discrepancy is not a correction factor.");
    }
}
