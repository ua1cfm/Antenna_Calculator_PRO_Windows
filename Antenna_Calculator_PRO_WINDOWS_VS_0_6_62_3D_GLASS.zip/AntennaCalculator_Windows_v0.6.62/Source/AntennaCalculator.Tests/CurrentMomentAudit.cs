﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

// Diagnostic only. Powers of separate groups contain interference and must not be summed directly.
internal static class CurrentMomentAudit
{
    const double C=299792458.0, Eta=376.730313668;
    readonly record struct Moment(double X,double Y,double Z,Complex Mx,Complex My,Complex Mz);
    readonly record struct F(Complex X,Complex Y,Complex Z)
    {
        public double Norm2=>X.Magnitude*X.Magnitude+Y.Magnitude*Y.Magnitude+Z.Magnitude*Z.Magnitude;
        public static F operator +(F a,F b)=>new(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
    }
    static Moment M(MininecPulseSolver.FieldSample s)
    {
        Complex i=new(s.RealCurrent,s.ImagCurrent);
        return new(s.X,s.Y,s.Z,2*s.Dx*i,2*s.Dy*i,2*s.Dz*i);
    }
    static F Field(IReadOnlyList<Moment> elements,double k,double theta,double phi)
    {
        double nx=Math.Sin(theta)*Math.Cos(phi),ny=Math.Sin(theta)*Math.Sin(phi),nz=Math.Cos(theta);
        Complex x=0,y=0,z=0;
        foreach(var e in elements)
        {
            Complex phase=Complex.FromPolarCoordinates(1,k*(nx*e.X+ny*e.Y+nz*e.Z));
            x+=e.Mx*phase;y+=e.My*phase;z+=e.Mz*phase;
        }
        Complex dot=nx*x+ny*y+nz*z;
        return new(x-nx*dot,y-ny*dot,z-nz*dot);
    }
    static double Integrate(IReadOnlyList<Moment> a,double k,int nt=36,int np=72)
    {
        double dt=Math.PI/(2*nt),dp=2*Math.PI/np,acc=0;
        for(int t=0;t<nt;t++)for(int p=0;p<np;p++)
        {
            double theta=(t+.5)*dt,phi=(p+.5)*dp;
            acc+=Field(a,k,theta,phi).Norm2*Math.Sin(theta)*dt*dp;
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*acc;
    }
    static double Len(MininecPulseSolver.FieldSample s)=>2*Math.Sqrt(s.Dx*s.Dx+s.Dy*s.Dy+s.Dz*s.Dz);
    static void Print(string label,MininecPulseSolver.FieldSample[] a,double k)
    {
        var m=a.Select(M).ToArray();
        double length=a.Sum(Len), moment=a.Sum(s=>new Complex(s.RealCurrent,s.ImagCurrent).Magnitude*Len(s));
        Console.WriteLine($"GROUP {label}: count={a.Length}; sumElementLength={length:G12} m; sumAbsCurrentMoment={moment:G12} A*m; isolatedPrad={Integrate(m,k):G12} W");
    }
    internal static void Run()
    {
        Console.WriteLine("MININEC CURRENT MOMENT AUDIT v0.3.31 (no kernel corrections)");
        var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        var r=MininecPulseSolver.Solve(model);
        double k=2*Math.PI*model.FrequencyMHz*1e6/C;
        var all=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).ToArray();
        const double eps=1e-8;
        var regular=all.Where(s=>s.WireNeg==s.WirePos).ToArray();
        var junction=all.Where(s=>s.WireNeg!=s.WirePos).ToArray();
        var physical=all.Where(s=>s.Z>eps).ToArray();
        var mirror=all.Where(s=>s.Z<-eps).ToArray();
        var surface=all.Where(s=>Math.Abs(s.Z)<=eps).ToArray();
        Console.WriteLine($"f={model.FrequencyMHz:G8} MHz; Z={r.ROhm:G12}+j({r.XOhm:G12}); Psource={r.TotalActivePower:G12}; residual={r.RelativeResidual:E8}");
        Console.WriteLine($"SAMPLES total={all.Length} regular={regular.Length} junction={junction.Length} positiveZ={physical.Length} negativeZ={mirror.Length} z0={surface.Length}");
        Print("ALL",all,k);Print("REGULAR",regular,k);Print("JUNCTION",junction,k);
        Print("Z_POSITIVE",physical,k);Print("Z_NEGATIVE",mirror,k);Print("Z_ZERO",surface,k);
        double pa=Integrate(all.Select(M).ToArray(),k);
        double preg=Integrate(regular.Select(M).ToArray(),k),pj=Integrate(junction.Select(M).ToArray(),k);
        double ppos=Integrate(physical.Select(M).ToArray(),k),pneg=Integrate(mirror.Select(M).ToArray(),k),pz=Integrate(surface.Select(M).ToArray(),k);
        Console.WriteLine($"INTERFERENCE regular/junction={pa-preg-pj:G12} W; pos/neg/z0={pa-ppos-pneg-pz:G12} W. Isolated group powers are NOT additive.");
        foreach(var s in junction.Take(30))
        {
            var i=new Complex(s.RealCurrent,s.ImagCurrent);
            Console.WriteLine($"JUNCTION_DETAIL wires=({s.WireNeg},{s.WirePos}); position=({s.X:G7},{s.Y:G7},{s.Z:G7}); length={Len(s):G9}; current=({i.Real:G9},{i.Imaginary:G9}); moment=({2*s.Dx*i},{2*s.Dy*i},{2*s.Dz*i})");
        }
        foreach(var port in r.Ports??Array.Empty<MininecPulseSolver.PortResult>())
            Console.WriteLine($"PORT W{port.WireNumber}{port.Position}{port.Offset}: |I|={port.CurrentMagnitude:G12}; phase={port.CurrentPhaseDegrees:G9}; |V|={port.VoltageMagnitude:G10}; P={port.ActivePower:G12}");
        Console.WriteLine("LIMITATION: WireNeg != WirePos identifies cross-wire pulse moments, not every geometrically special endpoint. Further checks require endpoint/half-moment metadata. This audit does not certify PEC or MMANA agreement.");
    }
}
