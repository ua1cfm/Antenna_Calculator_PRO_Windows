using AntennaCalculator.Core;
using System;
using System.IO;
using System.Linq;
using System.Threading;

if(args.Contains("--regress")) return RegressionTests.Run();
if(args.Contains("--ground-field")) return GroundFieldTests.Run();
if(args.Contains("--wire-edit")) return WireEditTests.Run();
if(args.Contains("--litevna")) return LiteVnaCoreTests.Run();

if(args.Contains("--solver-size-sweep")) return SolverSizeSweep.Run(args);

if(args.Contains("--mmana-matrix-parity")) return MmanaMatrixParity.Run(args);

if(args.Contains("--mmana-insulator-fixture")) return MmanaInsulatorFixture.Run();

if(args.Contains("--hairpin-junction-load")) return HairpinJunctionLoadAudit.Run();

if(args.Contains("--hairpin-physical-topology"))
{
    return HairpinPhysicalTopologyAudit.Run();
}

if(args.Contains("--hairpin-full-coefficient"))
{
    return HairpinFullCoefficientAudit.Run();
}

if(args.Contains("--hairpin-condition"))
{
    return HairpinConditionAudit.Run();
}

if(args.Contains("--hairpin-sensitivity"))
{
    return HairpinMatrixSensitivityAudit.Run();
}

if(args.Contains("--hairpin-multistage"))
{
    return HairpinMultiStageAudit.Run();
}

if(args.Contains("--hairpin-kernel-junction"))
{
    return HairpinKernelJunctionAudit.Run();
}

if(args.Contains("--hairpin-actual-spans"))
{
    return HairpinActualSpanAudit.Run();
}

if(args.Contains("--hairpin-mesh-quality"))
{
    return HairpinMeshQualityAudit.Run();
}

if(args.Contains("--hairpin-topology-audit"))
{
    return HairpinTopologyAudit.Run();
}

if(args.Contains("--ui-field-parity"))
{
    return UiFieldParityAudit.Run();
}

if(args.Contains("--three-stage-all") || args.Contains("--three-stage-basis") || args.Contains("--three-stage-power") || args.Contains("--three-stage-regression"))
{
    ThreeStageNormalizationAudit.Run(args.Contains("--three-stage-basis") ? "basis" : args.Contains("--three-stage-power") ? "power" : args.Contains("--three-stage-regression") ? "regression" : "all");
    return 0;
}

if(args.Contains("--source-power-reconciliation"))
{
    SourcePowerReconciliationAudit.Run();
    return 0;
}

if(args.Contains("--source-image-normalization"))
{
    SourceImageNormalizationAudit.Run();
    return 0;
}

if(args.Contains("--pec-power-identity"))
{
    PecPowerIdentityAudit.Run();
    return 0;
}

if(args.Contains("--hairpin-high-resolution"))
{
    HairpinHighResolutionAudit.Run();
    return 0;
}

if(args.Contains("--segmentation-convergence") || args.Contains("--hairpin-frequency-sweep"))
{
    SegmentationResonanceAudit.Run(args);
    return 0;
}

if(args.Contains("--near-wire-audit"))
{
    NearWireAudit.Run();
    return 0;
}

if(args.Contains("--mutual-pair-audit"))
{
    MutualPairAuditTest.Run();
    return 0;
}

if(args.Contains("--matrix-energy-audit"))
{
    MatrixEnergyAuditTest.Run();
    return 0;
}

if(args.Contains("--half-segment-audit"))
{
    HalfSegmentAudit.Run();
    return 0;
}

if(args.Contains("--current-moment-audit"))
{
    CurrentMomentAudit.Run();
    return 0;
}

if(args.Contains("--pec-field-representation-audit"))
{
    PecFieldRepresentationAudit.Run();
    return 0;
}

if(args.Contains("--radiation-power-audit"))
{
    RadiationPowerAudit.Run();
    return 0;
}

// Matrix-exact conductor dissipation audit. No visual field geometry approximation.
if(args.Contains("--conductor-power-audit"))
{
    var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
    Console.WriteLine("CONDUCTOR POWER AUDIT v0.3.28 — matrix-stamp and current consistency");
    Console.WriteLine($"f={model.FrequencyMHz:G9} MHz; G={model.GroundType}; M={model.MaterialCode} (not mapped to a metal)");
    foreach(var metal in new[]{MininecPulseSolver.ConductorMaterial.Pec,MininecPulseSolver.ConductorMaterial.Silver,
        MininecPulseSolver.ConductorMaterial.Copper,MininecPulseSolver.ConductorMaterial.Aluminum,
        MininecPulseSolver.ConductorMaterial.Brass,MininecPulseSolver.ConductorMaterial.StainlessSteel})
    {
        var r=MininecPulseSolver.Solve(model,conductor:metal);
        double p=r.TotalActivePower, loss=r.PhysicalConductorLossPower;
        double ratio=p>0?loss/p:double.NaN;
        bool passiveCheck=p>=0 && loss>=-1e-14 && loss<=p*(1+1e-6)+1e-14;
        Console.WriteLine($"{metal}: Zin={r.ROhm:G12}+j({r.XOhm:G12}) Ohm; " +
          $"Psrc={p:G12} W; PlossPhysical={loss:G12} W; PlossMatrixUnfolded={r.MatrixConductorLossPower:G12} W; " +
          $"Ploss/Psrc={ratio:G8}; physicalHalves={r.PhysicalConductorHalves}; " +
          $"residual={r.RelativeResidual:E5}; POWER_CHECK={(passiveCheck ? "PASS" : "FAIL")}");
    }
    Console.WriteLine("POWER_CHECK is necessary but not sufficient: radiated power integral remains unvalidated.");
    Console.WriteLine("MMANA reference: 39.284-j231.814 Ohm; no R/X adjustments are made to match it.");
    return 0;
}
// Compare material choices with full current re-solve (no post-hoc R correction).
if(args.Contains("--conductors-audit"))
{
    var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
    Console.WriteLine("CONDUCTOR MATRIX AUDIT v0.3.27: explicit materials, NOT MMANA M=4 mapping");
    Console.WriteLine($"frequency={model.FrequencyMHz:G9} MHz; ground={model.GroundType}; MAA M={model.MaterialCode}");
    foreach(var metal in new[]{MininecPulseSolver.ConductorMaterial.Pec,MininecPulseSolver.ConductorMaterial.Copper,
             MininecPulseSolver.ConductorMaterial.Aluminum,MininecPulseSolver.ConductorMaterial.Silver,
             MininecPulseSolver.ConductorMaterial.Brass,MininecPulseSolver.ConductorMaterial.StainlessSteel})
    {
        var r=MininecPulseSolver.Solve(model,conductor:metal);
        double loss=0;int used=0;
        foreach(var sample in r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>())
        {
            if(sample.Z < -1e-8) continue;
            var closest=model.Wires.Select(w=>(wire:w,dist:PointSegmentDist2(sample.X,sample.Y,sample.Z,w)))
                .OrderBy(w=>w.dist).First();
            if(closest.dist>1e-5) continue;
            double segmentLength=2*Math.Sqrt(sample.Dx*sample.Dx+sample.Dy*sample.Dy+sample.Dz*sample.Dz);
            // Diagnostic-only estimate; the matrix stamps each half pulse separately.
            var zm=MininecPulseSolver.SkinImpedancePerMetre(model.FrequencyMHz,closest.wire.RadiusMetres,metal);
            loss+=0.5*(sample.RealCurrent*sample.RealCurrent+sample.ImagCurrent*sample.ImagCurrent)
                    *zm.Real*segmentLength;
            used++;
        }
        Console.WriteLine($"{metal}: sigma={MininecPulseSolver.Conductivity(metal):G8} S/m " +
            $"Z={r.ROhm:G12}+j({r.XOhm:G12}) Ohm Psource={r.TotalActivePower:G12} W " +
            $"PlossEstimate={loss:G12} W physicalSamples={used} residual={r.RelativeResidual:E5}");
    }
    Console.WriteLine("REFERENCE ONLY MMANA: 39.284-j231.814 ohm. PEC image and far-field normalization are NOT yet validated.");
    return 0;
}
// Independent diagnostic, no changes to the impedance kernel.
// MATERIAL AUDIT: copper is an explicit scenario, NOT a claim that MMANA M=4 means copper.
if(args.Contains("--copper-material-audit"))
{
    var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
    var r=MininecPulseSolver.Solve(model);
    double f=model.FrequencyMHz*1e6, mu0=4e-7*Math.PI, sigmaCu=5.8e7;
    double delta=Math.Sqrt(2/(2*Math.PI*f*mu0*sigmaCu));
    double Rs=1/(sigmaCu*delta); // ohm/square, nonmagnetic conductor
    Console.WriteLine("MATERIAL / COPPER SKIN-LOSS AUDIT v0.3.26");
    Console.WriteLine($"MAA G={model.GroundType} M={model.MaterialCode}; wire count={model.Wires.Count}; f={model.FrequencyMHz:G9} MHz");
    Console.WriteLine("FACT: current MininecPulseSolver reads MaterialCode but does NOT stamp conductor conductivity/loss into the impedance matrix.");
    Console.WriteLine("WARNING: M=4 -> copper mapping has NOT been independently verified. Cu is a WHAT-IF scenario only.");
    Console.WriteLine($"PEC solver Zin={r.ROhm:G12} +j({r.XOhm:G12}) ohm; Psource={r.TotalActivePower:G12} W");
    Console.WriteLine($"Copper scenario sigma={sigmaCu:G8} S/m, mu_r=1, skin depth={delta*1e6:G9} um, Rs={Rs:G9} ohm/square");
    double copperLoss=0;int used=0, unmatched=0;
    foreach(var s in r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>())
    {
        // Only physical upper-half-space currents; PEC image currents must NOT be counted again.
        if(s.Z < -1e-8) continue;
        var candidates=model.Wires.Select(w=>(w,dist:PointSegmentDist2(s.X,s.Y,s.Z,w))).OrderBy(x=>x.dist).ToArray();
        var best=candidates[0];
        if(best.dist > 1e-5) {unmatched++;continue;}
        double dl=2*Math.Sqrt(s.Dx*s.Dx+s.Dy*s.Dy+s.Dz*s.Dz);
        double il2=s.RealCurrent*s.RealCurrent+s.ImagCurrent*s.ImagCurrent;
        // R' = Rs/(2*pi*a), P = 0.5*R'*length*|Ipeak|^2
        copperLoss+=0.5*il2*Rs/(2*Math.PI*best.w.RadiusMetres)*dl; used++;
    }
    Console.WriteLine($"Physical pulse count used={used}; unmatched={unmatched}; approximate P_Cu={copperLoss:G12} W");
    Console.WriteLine($"P_Cu/Psource={copperLoss/Math.Max(1e-30,r.TotalActivePower):G9}; this uses PEC currents and is a FIRST-ORDER perturbative estimate, not a copper re-solve.");
    Console.WriteLine($"MMANA reported Zin=39.284-j231.814 ohm, delta R={39.284-r.ROhm:G9}, delta X={-231.814-r.XOhm:G9} ohm");
    Console.WriteLine("No copper-loss correction to Zin or power-normalization coefficient is applied. Copper cannot be introduced into free-space eta/k radiation constants.");
    return 0;
}
static double PointSegmentDist2(double x,double y,double z,MaaWire w)
{
    double dx=w.X2-w.X1,dy=w.Y2-w.Y1,dz=w.Z2-w.Z1;
    double len=dx*dx+dy*dy+dz*dz;
    double t=Math.Clamp(((x-w.X1)*dx+(y-w.Y1)*dy+(z-w.Z1)*dz)/Math.Max(len,1e-30),0,1);
    return Math.Pow(x-w.X1-t*dx,2)+Math.Pow(y-w.Y1-t*dy,2)+Math.Pow(z-w.Z1-t*dz,2);
}


if(args.Contains("--pec-boundary-radiation-audit"))
{
    var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
    var result=MininecPulseSolver.Solve(model);
    var samples=(result.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).ToArray();
    Console.WriteLine("PEC VECTOR PARITY / BOUNDARY E-T / RADIATED POWER v0.3.25");
    Console.WriteLine($"Zin={result.ROhm:G12}+j({result.XOhm:G12}) ohm; MMANA reference=39.284-j231.814 ohm");
    Console.WriteLine($"Psource={result.TotalActivePower:G12} W; matrix residual={result.RelativeResidual:E6}");
    double k=2*Math.PI*model.FrequencyMHz*1e6/299792458.0, eta=376.730313668;
    System.Numerics.Complex I(MininecPulseSolver.FieldSample s)=>new(s.RealCurrent,s.ImagCurrent);
    System.Numerics.Complex[] Moment(MininecPulseSolver.FieldSample s) => new[]{I(s)*2*s.Dx,I(s)*2*s.Dy,I(s)*2*s.Dz};
    var upper=samples.Where(s=>s.Z>1e-7).ToArray();
    var lower=samples.Where(s=>s.Z< -1e-7).ToArray();
    double rms=0,maxerr=0; int matched=0;
    foreach(var a in upper)
    {
        var b=lower.OrderBy(s=>(s.X-a.X)*(s.X-a.X)+(s.Y-a.Y)*(s.Y-a.Y)+(s.Z+a.Z)*(s.Z+a.Z)).FirstOrDefault();
        if(b is null || Math.Abs(a.X-b.X)>1e-6 || Math.Abs(a.Y-b.Y)>1e-6 || Math.Abs(a.Z+b.Z)>1e-6) continue;
        var x=Moment(a);var y=Moment(b);
        // PEC image: tangential electrical current moment changes sign, normal retains sign.
        double diff=(x[0]+y[0]).Magnitude*(x[0]+y[0]).Magnitude+
                    (x[1]+y[1]).Magnitude*(x[1]+y[1]).Magnitude+
                    (x[2]-y[2]).Magnitude*(x[2]-y[2]).Magnitude;
        double norm=x.Sum(c=>c.Magnitude*c.Magnitude)+y.Sum(c=>c.Magnitude*c.Magnitude);
        double rel=Math.Sqrt(diff/Math.Max(norm,1e-30));
        rms+=rel*rel;maxerr=Math.Max(maxerr,rel);matched++;
    }
    Console.WriteLine($"ORIENTED IMAGE VECTOR PARITY: pairs={matched}/{upper.Length}; relative RMS={Math.Sqrt(rms/Math.Max(1,matched)):G8}, max={maxerr:G8}");
    Console.WriteLine("Expected: image current moment tangential components odd, normal component even. Pairing excludes z=0 junction moments.");
    System.Numerics.Complex[] SumE(double x,double y,double z)
    {
        var sum=new System.Numerics.Complex[3];
        foreach(var a in samples)
        {
            double rx=x-a.X,ry=y-a.Y,rz=z-a.Z;
            double r=Math.Sqrt(rx*rx+ry*ry+rz*rz);
            if(r<1e-8)continue;
            double[] n={rx/r,ry/r,rz/r};
            var p=Moment(a);
            var ndot=n[0]*p[0]+n[1]*p[1]+n[2]*p[2];
            var transverse=System.Numerics.Complex.ImaginaryOne*k/r+1/(r*r)-System.Numerics.Complex.ImaginaryOne/(k*r*r*r);
            var radial=2/(r*r)-2*System.Numerics.Complex.ImaginaryOne/(k*r*r*r);
            var factor=(eta/(4*Math.PI))*System.Numerics.Complex.Exp(-System.Numerics.Complex.ImaginaryOne*k*r);
            for(int c=0;c<3;c++)sum[c]+=factor*(transverse*(p[c]-n[c]*ndot)+radial*n[c]*ndot);
        }
        return sum;
    }
    double[] xs=samples.Where(a=>a.Z>1e-7).Select(a=>a.X).ToArray(),ys=samples.Where(a=>a.Z>1e-7).Select(a=>a.Y).ToArray();
    double span=Math.Max(0.2*2*Math.PI/k,Math.Max(xs.DefaultIfEmpty(0).Max()-xs.DefaultIfEmpty(0).Min(),ys.DefaultIfEmpty(0).Max()-ys.DefaultIfEmpty(0).Min()));
    double midx=(xs.DefaultIfEmpty(0).Min()+xs.DefaultIfEmpty(0).Max())/2,midy=(ys.DefaultIfEmpty(0).Min()+ys.DefaultIfEmpty(0).Max())/2;
    double etsum=0,etmax=0,esum=0;int probes=0;
    for(int iy=0;iy<9;iy++)for(int ix=0;ix<9;ix++)
    {
        double x=midx+(ix-4)*span/4,y=midy+(iy-4)*span/4;
        // no samples exactly at a wire; compare to full E at the same locations
        var e=SumE(x,y,0);
        double et=e[0].Magnitude*e[0].Magnitude+e[1].Magnitude*e[1].Magnitude;
        double total=et+e[2].Magnitude*e[2].Magnitude;
        etsum+=et;esum+=total;etmax=Math.Max(etmax,Math.Sqrt(et));probes++;
    }
    Console.WriteLine($"PEC z=0 probe grid: {probes} points, span={span:G7} m, tangential RMS [V/m]={Math.Sqrt(etsum/probes):G9}, tangential max [V/m]={etmax:G9}");
    Console.WriteLine($"Tangential vs total field RMS ratio={Math.Sqrt(etsum/Math.Max(esum,1e-30)):G9}; analytic image-boundary test, excludes exact wire surfaces.");
    // Upper-hemisphere far-field integral: E= j*eta*k/(4*pi*r)*sum(I*dl transverse*exp(j*k*n.r));
    // P = eta*k^2/(32*pi^2) integral(|J_transverse|^2)dOmega.
    double FarIntegral(int ntheta,int nphi)
    {
        double dt=(Math.PI/2)/ntheta,dp=2*Math.PI/nphi,total=0;
        for(int t=0;t<ntheta;t++)
        {
            double theta=(t+0.5)*dt,st=Math.Sin(theta),ct=Math.Cos(theta);
            for(int q=0;q<nphi;q++)
            {
                double phi=(q+0.5)*dp,nx=st*Math.Cos(phi),ny=st*Math.Sin(phi),nz=ct;
                System.Numerics.Complex gx=0,gy=0,gz=0;
                foreach(var a in samples)
                {
                    var phase=System.Numerics.Complex.FromPolarCoordinates(1,k*(nx*a.X+ny*a.Y+nz*a.Z));
                    var im=I(a)*phase*2;
                    gx+=im*a.Dx;gy+=im*a.Dy;gz+=im*a.Dz;
                }
                var dot=nx*gx+ny*gy+nz*gz;
                gx-=nx*dot;gy-=ny*dot;gz-=nz*dot;
                total+=(gx.Magnitude*gx.Magnitude+gy.Magnitude*gy.Magnitude+gz.Magnitude*gz.Magnitude)*st*dt*dp;
            }
        }
        return eta*k*k/(32*Math.PI*Math.PI)*total;
    }
    double p1=FarIntegral(36,72),p2=FarIntegral(72,144);
    Console.WriteLine($"UPPER HEMISPHERE P_rad: grid36x72={p1:G12} W; grid72x144={p2:G12} W; relative quadrature change={Math.Abs(p2-p1)/Math.Max(Math.Abs(p2),1e-30):G7}");
    Console.WriteLine($"Psource/Prad={result.TotalActivePower/Math.Max(p2,1e-30):G10}; difference Psource-Prad={result.TotalActivePower-p2:G12} W");
    Console.WriteLine("LIMITATIONS: dipole-element field approximation, image geometry and PEC z=0 probes; quadrature convergence alone does not verify MoM kernel or correct source normalization. No tuning to MMANA.");
    return 0;
}

// Physical audit. No fitted impedance and no modifications to the MININEC matrix.
if(args.Contains("--pec-image-kcl-power-audit"))
{
    var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
    var r=MininecPulseSolver.Solve(m);
    Console.WriteLine("PEC IMAGE / NODE CURRENT / POWER AUDIT v0.3.24");
    Console.WriteLine(PecTopologyAudit.Report(m));
    Console.WriteLine($"MMANA reference = 39.284 - j231.814 ohm; computed = {r.ROhm:G12} + j({r.XOhm:G12}) ohm");
    Console.WriteLine($"Matrix residual={r.RelativeResidual:E8}; pulse count={r.PulseCount}; junction count={r.JunctionCount}");
    double pSource=r.TotalActivePower,qSource=r.TotalReactivePower;
    double pLoads=(r.LoadStamps??Array.Empty<MininecPulseSolver.LoadStampAudit>()).Sum(x=>x.LoadPowerReal);
    double qLoads=(r.LoadStamps??Array.Empty<MininecPulseSolver.LoadStampAudit>()).Sum(x=>x.LoadPowerReactive);
    Console.WriteLine($"SOURCE complex power (0.5 V conj(I)): P={pSource:G12} W(rel), Q={qSource:G12} var(rel)");
    Console.WriteLine($"LOADS complex power (0.5 Z abs(I)^2): P={pLoads:G12} W(rel), Q={qLoads:G12} var(rel)");
    Console.WriteLine($"REMAINDER Psrc-Pload={pSource-pLoads:G12}, Qsrc-Qload={qSource-qLoads:G12} (includes radiation, stored energy and numerical/model errors)");
    Console.WriteLine($"PASSIVE CHECK: {(pSource>=-1e-10 && pLoads>=-1e-10 ? "PASS" : "FAIL")} (necessary, not sufficient)");
    foreach(var a in r.LoadStamps??Array.Empty<MininecPulseSolver.LoadStampAudit>())
        Console.WriteLine($"LOAD W{a.WireNumber}: I={a.CurrentReal:G9}+j{a.CurrentImag:G9} A(rel), P={a.LoadPowerReal:G9}, Q={a.LoadPowerReactive:G9}");
    var fs=r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>();
    var physical=fs.Where(x=>x.Z>1e-7).ToArray();
    var mirror=fs.Where(x=>x.Z< -1e-7).ToArray();
    double tol=1e-6;
    int paired=0;double errEven=0,errOdd=0,errEvenMax=0,errOddMax=0;
    foreach(var a in physical)
    {
        var b=mirror.OrderBy(x=>Math.Pow(x.X-a.X,2)+Math.Pow(x.Y-a.Y,2)+Math.Pow(x.Z+a.Z,2)).FirstOrDefault();
        if(b is null || Math.Abs(a.X-b.X)>tol || Math.Abs(a.Y-b.Y)>tol || Math.Abs(a.Z+b.Z)>tol)continue;
        // Current is oriented by the wire direction, which reverses under PEC reflection.
        // Report both parity hypotheses; neither is assumed correct a priori.
        var ia=new System.Numerics.Complex(a.RealCurrent,a.ImagCurrent);
        var ib=new System.Numerics.Complex(b.RealCurrent,b.ImagCurrent);
        double denom=Math.Max(1e-12,ia.Magnitude+ib.Magnitude);
        double even=(ia-ib).Magnitude/denom, odd=(ia+ib).Magnitude/denom;
        errEven+=even*even;errOdd+=odd*odd;errEvenMax=Math.Max(errEvenMax,even);errOddMax=Math.Max(errOddMax,odd);paired++;
    }
    Console.WriteLine($"PEC IMAGE PAIRS: physical samples={physical.Length}, mirror samples={mirror.Length}, coordinate-paired={paired}");
    Console.WriteLine($"RAW CURRENT parity (orientation-dependent): even RMS={Math.Sqrt(errEven/Math.Max(1,paired)):G8}, max={errEvenMax:G8}; odd RMS={Math.Sqrt(errOdd/Math.Max(1,paired)):G8}, max={errOddMax:G8}");
    Console.WriteLine("WARNING: raw pulse currents include wire orientation and junction pulses; parity figures are diagnostic only, not an electromagnetic boundary-condition proof.");
    foreach(var group in m.Wires.SelectMany(w=>new[]{(w.Number,End:"start",X:w.X1,Y:w.Y1,Z:w.Z1),(w.Number,End:"end",X:w.X2,Y:w.Y2,Z:w.Z2)})
        .Where(e=>Math.Abs(e.Z+m.AddHeightMetres)<1e-8)
        .GroupBy(e=>(Math.Round(e.X,7),Math.Round(e.Y,7),Math.Round(e.Z,7))))
    {
        Console.WriteLine($"GROUND NODE {group.Key}: physical terminals={string.Join(", ",group.Select(x=>$"W{x.Number}-{x.End}"))}");
        Console.WriteLine("  KCL limitation: PEC surface supplies an unmodelled return/surface current; terminal sum alone must NOT be required to be zero.");
    }
    Console.WriteLine("INFERENCE LIMIT: Psrc-Pload is NOT a measured radiated power. A calibrated far-field surface integral is needed to close the energy balance.");
    Console.WriteLine("NO KCL/PERFECT-EARTH CLAIM: this report cannot validate the PEC boundary operator without independently oriented terminal currents and surface-current accounting.");
    return 0;
}


// Optional focused Hairpin diagnostic: does NOT assert a fitted result and does NOT modify MININEC.
// Run: dotnet run --project Source/AntennaCalculator.Tests -- --hairpin-audit
if(args.Contains("--hairpin-audit"))
{
    var path=Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa");
    var m=MaaParser.ParseFile(path);
    Console.WriteLine(PecTopologyAudit.Report(m));
    const double expectedR=39.284, expectedX=-231.814;
    Console.WriteLine($"MMANA-GAL REFERENCE: f=28.5 MHz, R={expectedR:F3} ohm, X={expectedX:F3} ohm, SWR 50 ohm=29.4");
    MaaModel WithoutLoads(params int[] wires) => new MaaModel {
        Title=m.Title, FilePath=m.FilePath, FrequencyMHz=m.FrequencyMHz,
        Wires=m.Wires, Sources=m.Sources,
        Loads=m.Loads.Where(l=>!wires.Contains(l.WireNumber)).ToArray(), Warnings=m.Warnings,
        GroundType=m.GroundType, AddHeightMetres=m.AddHeightMetres, MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms, SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord, HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded, BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal, StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres, StackPlacementMode=m.StackPlacementMode
    };
    var variants=new (string Name,MaaModel Model)[] {
        ("Original: C(W5)=2.85pF; C(W4)=50.2pF",m),
        ("Remove load on W5 only",WithoutLoads(5)),
        ("Remove load on W4 only",WithoutLoads(4)),
        ("No lumped capacitors",WithoutLoads(4,5))
    };
    foreach(var (name,variant) in variants)
    {
        Console.WriteLine("CASE: "+name);
        try
        {
            var r=MininecPulseSolver.Solve(variant);
            Console.WriteLine($"  BALANCED: R={r.ROhm:G12}; X={r.XOhm:G12}; residual={r.RelativeResidual:E5}; pulses={r.PulseCount}; junctions={r.JunctionCount}");
            var old=MininecPulseSolver.Solve(variant,pecJunctionMode:MininecPulseSolver.PecJunctionMode.LegacyStar);
            Console.WriteLine($"  LEGACY:   R={old.ROhm:G12}; X={old.XOhm:G12}; residual={old.RelativeResidual:E5}; pulses={old.PulseCount}; junctions={old.JunctionCount}");
            Console.WriteLine($"  TOPOLOGY DIFF: dR={r.ROhm-old.ROhm:G10}; dX={r.XOhm-old.XOhm:G10}");
            if(ReferenceEquals(variant,m) || name.StartsWith("Original"))
                Console.WriteLine($"  Delta from MMANA: dR={r.ROhm-expectedR:+0.000;-0.000;0}; dX={r.XOhm-expectedX:+0.000;-0.000;0} ohm");
        }
        catch(Exception ex) {Console.WriteLine("  SOLVER FAILED: "+ex);}
    }
    Console.WriteLine("This diagnostic distinguishes load effects from shared PEC-node errors; it is NOT an MMANA verification certificate.");
    return 0;
}

// Independent load-stamp audit: no fitted or modified physics.
if(args.Contains("--load-stamp-audit"))
{
    var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
    Console.WriteLine(PecTopologyAudit.Report(m));
    Console.WriteLine("MMANA reference (comparison only): Z=39.284-j231.814 ohm at 28.5 MHz");
    MaaModel ReplaceLoads(MaaModel source, System.Collections.Generic.IReadOnlyList<MaaLoad> loads) => new MaaModel {
        Title=source.Title,FilePath=source.FilePath,FrequencyMHz=source.FrequencyMHz,
        Wires=source.Wires,Sources=source.Sources,Loads=loads,Warnings=source.Warnings,
        GroundType=source.GroundType,AddHeightMetres=source.AddHeightMetres,MaterialCode=source.MaterialCode,
        ReferenceOhms=source.ReferenceOhms,SegmentationRecord=source.SegmentationRecord,
        WireHeaderRecord=source.WireHeaderRecord,HasCompactStack=source.HasCompactStack,
        StackExpanded=source.StackExpanded,BaseWireCount=source.BaseWireCount,
        StackHorizontal=source.StackHorizontal,StackVertical=source.StackVertical,
        StackHorizontalSpacingMetres=source.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=source.StackVerticalSpacingMetres,StackPlacementMode=source.StackPlacementMode
    };
    void Report(string label,MaaModel model)
    {
        try {
            var result=MininecPulseSolver.Solve(model);
            Console.WriteLine($"CASE {label}: Z={result.ROhm:G12} + j({result.XOhm:G12}) ohm; residual={result.RelativeResidual:E5}");
            foreach(var a in result.LoadStamps??Array.Empty<MininecPulseSolver.LoadStampAudit>())
                Console.WriteLine($"  W{a.WireNumber}{a.Position}{a.Offset:+#;-#;0} pulse={a.PulseIndex} sign={a.PulseSign} ground={a.AtGround} sourceSamePulse={a.CoincidesWithSource} Zload=({a.ROhm:G10},{a.XOhm:G10}) stamp=({a.MatrixDeltaReal:E5},{a.MatrixDeltaImag:E5}) I=({a.CurrentReal:E5},{a.CurrentImag:E5}) Pload=({a.LoadPowerReal:E5},{a.LoadPowerReactive:E5})");
        } catch(Exception ex) { Console.WriteLine("FAILED "+label+": "+ex); }
    }
    Report("Hairpin original",m);
    Report("Hairpin no W4 capacitor",ReplaceLoads(m,m.Loads.Where(l=>l.WireNumber!=4).ToArray()));
    Report("Hairpin no W5 capacitor",ReplaceLoads(m,m.Loads.Where(l=>l.WireNumber!=5).ToArray()));
    Report("Hairpin no loads",ReplaceLoads(m,Array.Empty<MaaLoad>()));
    var dipole=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","dipole_14_2MHz_free.maa"));
    var b=MininecPulseSolver.Solve(dipole);
    var feed=dipole.Sources[0];
    // Model validation: a serial 50+j0 Ohm lumped load on the exact feed pulse
    // must shift V/I by 50 Ohm in the implemented MoM convention.
    var resistor=new MaaLoad(feed.WireNumber,feed.Position,feed.Offset,1,50,0,0,"SERIES 50 OHM TEST");
    var modified=ReplaceLoads(dipole,new[]{resistor});
    var r=MininecPulseSolver.Solve(modified);
    Console.WriteLine($"SERIES LOAD TEST: Z0=({b.ROhm:G12},{b.XOhm:G12}) Z50=({r.ROhm:G12},{r.XOhm:G12}) delta=({r.ROhm-b.ROhm:G12},{r.XOhm-b.XOhm:G12}) expected=(50,0) ohm");
    bool pass=Math.Abs(r.ROhm-b.ROhm-50)<1e-4 && Math.Abs(r.XOhm-b.XOhm)<1e-4;
    Console.WriteLine(pass?"PASS load stamp basic series-resistor invariant":"FAIL load stamp basic series-resistor invariant — CHECK SIGN/FACTOR");
    return pass?0:2;
}

int passed=0,failed=0;
void Check(string label,bool valid) { Console.WriteLine((valid?"PASS":"FAIL")+"  "+label); if(valid)passed++;else failed++; }
void Sample(string filename,int expectedWires,int expectedSources,int expectedLoads,double mhz)
{
    try {
        var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples",filename));
        Check(filename+" · wires",m.Wires.Count==expectedWires);
        Check(filename+" · sources",m.Sources.Count==expectedSources);
        Check(filename+" · loads",m.Loads.Count==expectedLoads);
        Check(filename+" · frequency",Math.Abs(m.FrequencyMHz-mhz)<1e-9);
        Check(filename+" · finite geometry",m.Wires.All(w=>double.IsFinite(w.LengthMetres)));
        if (filename=="144omni.maa") {
            Check(filename+" · source W13C",m.Sources[0].WireNumber==13 && m.Sources[0].Position=='c');
            Check(filename+" · reactive load",m.Loads[0].WireNumber==13 && Math.Abs(m.Loads[0].V2-18.0)<1e-12);
        }
        if (filename=="GP with wide C+LC match.maa") {
            Check(filename+" · real ground",m.GroundType==2);
            Check(filename+" · load W1C1",m.Loads.Any(l=>l.WireNumber==1 && l.Offset==1));
        }
    } catch(Exception ex) { Console.WriteLine("FAIL  "+filename+": "+ex); failed++; }
}
Sample("TWIND.MAA",7,1,0,435);
try
{
    var dipole=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","dipole_14_2MHz_free.maa"));
    var z=MininecPulseSolver.Solve(dipole);
    Check("MININEC dipole finite impedance",double.IsFinite(z.ROhm)&&double.IsFinite(z.XOhm));
    Check("MININEC dipole real resistance positive",z.ROhm>0);
    Check("MININEC dipole numerical kernel fixture 14.2 MHz",Math.Abs(z.ROhm-66.50464)<0.3 && Math.Abs(z.XOhm+38.67144)<0.3);
    Check("MININEC dipole relative residual",double.IsFinite(z.RelativeResidual)&&z.RelativeResidual<1e-7);
    Check("MININEC dipole sweep topology held constant",MininecPulseSolver.Solve(dipole,default,dipole.FrequencyMHz,dipole.FrequencyMHz*1.01).PulseCount==z.PulseCount);
}
catch(Exception ex){Console.WriteLine("FAIL MININEC dipole: "+ex);failed++;}
try
{
    var gp=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","GP with wide C+LC match.maa"));
    try{MininecPulseSolver.Solve(gp);Check("ground model correctly blocked",false);}
    catch(NotSupportedException){Check("ground model correctly blocked",true);}
    var stack=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","2x6el10.maa"));
    try{MininecPulseSolver.Solve(stack);Check("CombWire stack correctly blocked",false);}
    catch(NotSupportedException){Check("CombWire stack correctly blocked",true);}
}
catch(Exception ex){Console.WriteLine("FAIL solver guards: "+ex);failed++;}

Sample("144omni.maa",13,1,1,145);
Sample("GP with wide C+LC match.maa",8,1,3,27.5);
Sample("2x6el10.maa",12,2,0,28.5);
Sample("syack3el20.maa",6,2,0,14.05);
Sample("zero_frequency.maa",2,1,0,0);
try
{
    var mode1 = MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory, "Samples", "stack_mode1.maa"));
    Check("mode 1 original/above", mode1.StackExpanded && mode1.StackPlacementMode == 1 && mode1.Wires.Count == 4);
    var mode2 = MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory, "Samples", "stack_mode2.maa"));
    Check("mode 2 original/below", mode2.StackExpanded && mode2.StackPlacementMode == 2 && mode2.Wires.Count == 12);
}
catch(Exception ex) { Console.WriteLine("FAIL mode1/mode2 files: " + ex); failed++; }

void StackPlacement(int mode, double z1, double z2)
{
    string source = $"Test\n*\n14.0\n* Провода *\n1, 1, 2, 4, 6, {mode}\n0,-1,0,0,1,0,0.001,0\n*** Источ. ***\n1,1\nw1c,0,1\n*** Нагрузка ***\n0,1\n*** Автосегм ***\n100,10,2,1\n*G/H/M/R/AzEl/X*\n0,0,0,50,120,60,0";
    var model = MaaParser.Parse(source);
    Check($"stack mode {mode} z-coordinates", model.Wires.Count == 2 &&
        Math.Abs(model.Wires[0].Z1-z1)<1e-10 && Math.Abs(model.Wires[1].Z1-z2)<1e-10);
    Check($"stack mode {mode} source copies", model.Sources.Count==2 &&
        model.Sources.All(x=>Math.Abs(x.RelativeVoltage-0.5)<1e-10));
}
StackPlacement(0,-3,3);
StackPlacement(1,0,6);
StackPlacement(2,-6,0);
try { MaaParser.Parse("invalid"); Check("invalid rejected",false); }
catch(FormatException) { Check("invalid rejected",true); }

// v0.3.0: matrix regressions. Finite solutions are not MMANA accuracy certificates.
void MatrixFixture(string filename,bool shouldSolve,bool requireJunction=false)
{
    try {
        var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples",filename));
        var computed=MininecPulseSolver.Solve(model);
        Console.WriteLine($"NUMERIC | {filename} | {computed.FrequencyMHz:G8} MHz | R={computed.ROhm:G10} ohm | X={computed.XOhm:G10} ohm | n={computed.PulseCount} | residual={computed.RelativeResidual:E3} | junctions={computed.JunctionCount}");
        Check(filename+" · expected to solve",shouldSolve);
        if(shouldSolve) {
            Check(filename+" · finite R+jX",double.IsFinite(computed.ROhm)&&double.IsFinite(computed.XOhm));
            Check(filename+" · small matrix residual",double.IsFinite(computed.RelativeResidual)&&computed.RelativeResidual<1e-6);
            Check(filename+" · pulse count",computed.PulseCount>0);
            if(requireJunction)Check(filename+" · mirrored junction",computed.JunctionCount>=1);
            var other=MininecPulseSolver.Solve(model,default,model.FrequencyMHz,model.FrequencyMHz*1.005);
            Check(filename+" · fixed sweep pulse count",other.PulseCount==computed.PulseCount);
        }
    } catch(NotSupportedException ex) {
        Check(filename+" · explicit numerical guard",!shouldSolve);
        if(shouldSolve)Console.WriteLine(ex);
    } catch(Exception ex) {Console.WriteLine("FAIL  "+filename+": "+ex);failed++;}
}
MatrixFixture("fixture_stack_2x.maa",true);
MatrixFixture("fixture_PEC_monopole.maa",true,true);
MatrixFixture("fixture_PEC_elevated_dipole.maa",true);
MatrixFixture("fixture_REAL_ground_rejected.maa",false); // strict must remain strict
try {
    var groundMaa=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","fixture_REAL_ground_rejected.maa"));
    var corrected=MininecPulseSolver.Solve(groundMaa,realEarthMode:MininecPulseSolver.RealEarthMode.MmanaPecCurrentApproximation);
    Check("G2 explicit PEC-current approximation finite",double.IsFinite(corrected.ROhm)&&double.IsFinite(corrected.XOhm));
    Check("G2 approximation distinctly labeled",corrected.GroundMethod.Contains("ПРИБЛИЖЕНИЕ"));
    Check("G2 approximation small residual",corrected.RelativeResidual<1e-6);
    var raw=File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"Samples","fixture_REAL_ground_rejected.maa"));
    var pec=MaaParser.Parse(raw.Replace("2,0,0,50,120,60,0","1,0,0,50,120,60,0"));
    var pecResult=MininecPulseSolver.Solve(pec);
    Check("G2 opt-in result equals PEC image baseline",Math.Abs(pecResult.ROhm-corrected.ROhm)<1e-8 && Math.Abs(pecResult.XOhm-corrected.XOhm)<1e-8);
    var shifted=MininecPulseSolver.Solve(groundMaa,segmentationReferenceMHz:groundMaa.FrequencyMHz,
        frequencyMHzOverride:groundMaa.FrequencyMHz*1.005,
        realEarthMode:MininecPulseSolver.RealEarthMode.MmanaPecCurrentApproximation);
    Check("G2 sweep fixed pulse count",shifted.PulseCount==corrected.PulseCount);
} catch(Exception ex){Console.WriteLine("FAIL G2 opt-in: "+ex);failed++;}
try {
    var free=GroundFresnel.Calculate(14.2,1,0,45);
    Check("Fresnel no contrast TE/TM are zero",free.TE.Magnitude<1e-12&&free.TM.Magnitude<1e-12);
    var soil=GroundFresnel.Calculate(1.825,13,0.005,45);
    Check("Fresnel real earth complex reflection finite",double.IsFinite(soil.TE.Real)&&double.IsFinite(soil.TM.Imaginary)&&soil.TE.Magnitude<=1.00001&&soil.TM.Magnitude<=1.00001);
    var high=GroundFresnel.Calculate(14.2,13,1e7,45);
    Check("Fresnel PEC limit TE=-1, TM=+1",(high.TE.Real+1)<1e-3 && (1-high.TM.Real)<1e-3);
} catch(Exception ex){Console.WriteLine("FAIL Fresnel: "+ex);failed++;}
MatrixFixture("fixture_PEC_plane_wire_rejected.maa",false);
MatrixFixture("fixture_PEC_crossing_rejected.maa",false);
MatrixFixture("fixture_PEC_double_ground_rejected.maa",false);
// Hairpin has two physical wires at (0,0,0), but its excitation is on W5C,
// away from the common ground node. This is no longer rejected by the PEC
// topology guard. Finite R+jX still depends on numerical convergence.
try
{
    var hairpin=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
    Check("hairpin PEC shared ground geometry",hairpin.GroundType==1 && hairpin.Wires.Count==5);
    Check("hairpin excitation away from ground",hairpin.Sources.Count==1 && hairpin.Sources[0].WireNumber==5 && hairpin.Sources[0].Position=='c');
    Check("hairpin two loads",hairpin.Loads.Count==2);
    var hz=MininecPulseSolver.Solve(hairpin);
    Check("hairpin calculated impedance finite",double.IsFinite(hz.ROhm)&&double.IsFinite(hz.XOhm));
    Check("hairpin small matrix residual",hz.RelativeResidual<1e-5);
}
catch(Exception ex) { Console.WriteLine("FAIL hairpin PEC shared node solve: "+ex); failed++; }

try {
    var p=MininecSegmentation.Parse("200,20,2,1");
    var spans=MininecStackSegmentation.Spans(5,299.8/28.5,-1,p);
    Check("Tei taper contiguous",spans.Count>=2 && Math.Abs(spans[0].F0)<1e-12 &&
        Math.Abs(spans[^1].F1-1)<1e-12 && spans.Zip(spans.Skip(1)).All(pair=>Math.Abs(pair.First.F1-pair.Second.F0)<1e-10));
    Check("Tei baseline even uniform",MininecStackSegmentation.Spans(5,299.8/28.5,0,p).Count%2==0);
} catch(Exception ex) {Console.WriteLine("FAIL Tei: "+ex);failed++;}

// Full Beverage solve is attempted diagnostically, NOT an accuracy test.
// It may be slow and it uses PEC mirror currents, not a lossy-ground Green function.
if (args.Any(a=>a=="--beverage-preview"))
{
    try
    {
        var b=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","BEVERAGE.MAA"));
        var z=MininecPulseSolver.Solve(b,realEarthMode:MininecPulseSolver.RealEarthMode.MmanaPecCurrentApproximation);
        Console.WriteLine($"BEVERAGE PEC-APPROX | R={z.ROhm:G12} X={z.XOhm:G12} ohm | pulses={z.PulseCount} residual={z.RelativeResidual:E3} | {z.GroundMethod}");
        Console.WriteLine("WARNING: this is NOT an accurate finite-ground Beverage impedance.");
    }
    catch(Exception ex) { Console.WriteLine("BEVERAGE PEC-APPROX diagnostic: "+ex); }
}
// 0.3.2 regression: real Beverage has three-value kind=1 terminating resistance.
try
{
    var beverage=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","BEVERAGE.MAA"));
    Check("BEVERAGE real earth G=2",beverage.GroundType==2);
    Check("BEVERAGE three conductors",beverage.Wires.Count==3);
    Check("BEVERAGE physical terminating load is present",beverage.Loads.Count==1);
    Check("BEVERAGE terminating 500-ohm resistor",beverage.Loads.Any(l=>
        l.WireNumber==3 && l.Position=='e' && l.Offset==2 && l.Kind==1 &&
        Math.Abs(l.V1-500.0)<1e-9 && Math.Abs(l.V2)<1e-9));
    Check("BEVERAGE load did not trigger incomplete-data warning",!beverage.Warnings.Any(w=>
        w.Contains("неполными данными") || w.Contains("kind=1: ожидалось")));
    try { MininecPulseSolver.Solve(beverage); Check("BEVERAGE G2 strict guard",false); }
    catch(NotSupportedException) { Check("BEVERAGE G2 strict guard",true); }
}
catch(Exception ex){Console.WriteLine("FAIL BEVERAGE parser regression: "+ex);failed++;}
try
{
    // Standard kind=0 and kind=1 must coexist, with explicit malformed-row diagnostics.
    var model=MaaParser.Parse("""
Case
*
14
***Wires***
1
0,0,-2,0,0,2,0.001,-1
*** Source ***
1,1
w1c,0,1
*** Load ***
2,1
w1b,1,50,20
w1e,0,3.0,12.0,100
*** Segmentation ***
400,40,2,1
*G/H/M/R/AzEl/X*
0,0,0,50,120,60,0
""");
    Check("kind=1 three-value load parsed",model.Loads.Any(l=>l.Kind==1 && l.V1==50 && l.V2==20));
    Check("kind=0 four-value LC load parsed",model.Loads.Any(l=>l.Kind==0 && l.V1==3 && l.V2==12 && l.V3==100));
}
catch(Exception ex){Console.WriteLine("FAIL load syntax tests: "+ex);failed++;}


// A real .MAA two-source fixture must carry the phases into the pulse solver.
try
{
    var phased=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","phased_2_source_free.maa"));
    Check("phased MAA sources and 180-degree shift",phased.Sources.Count==2 &&
        phased.Sources[0].PhaseDegrees==0 && phased.Sources[1].PhaseDegrees==180);
    var phaseZ=MininecPulseSolver.Solve(phased);
    Check("phased solver emits two port impedances",phaseZ.Ports?.Count==2);
    Check("phased solver total input power nonnegative",phaseZ.TotalActivePower>=-1e-9);
    Check("phased solver residual finite",phaseZ.RelativeResidual<1e-6);
}
catch(Exception ex){Console.WriteLine("FAIL phased MAA fixture: "+ex);failed++;}

// 0.3.7: A passive two-port system can have a NEGATIVE R at one port.
// Z=[[50,40],[40,50]] is positive-definite; I=[1,-2], U=Z*I=[-30,-60].
// P1=-15, P2=+60, total P=+45 (relative units): do not clamp R1!
try
{
    var ports=MininecPulseSolver.DiagnosePorts(
        new[] {new MaaSource(1,'c',0,180,30,"fixture"),new MaaSource(2,'c',0,180,60,"fixture")},
        new[] {new System.Numerics.Complex(-30,0),new System.Numerics.Complex(-60,0)},
        new[] {new System.Numerics.Complex(1,0),new System.Numerics.Complex(-2,0)});
    Check("phased port 1 R negative, physically allowed",Math.Abs(ports.Ports[0].ROhm+30)<1e-12);
    Check("phased port 2 R positive",Math.Abs(ports.Ports[1].ROhm-30)<1e-12);
    Check("phased aggregate P positive",Math.Abs(ports.ActivePower-45)<1e-12);
    Check("phased individual P signs",ports.Ports[0].ActivePower<0&&ports.Ports[1].ActivePower>0);
}
catch(Exception ex){Console.WriteLine("FAIL multiport power test: "+ex);failed++;}

// 0.3.6: independent pivoted direct LU regression with complex-valued known solution.
// This test does not depend on MMANA antenna numerical expectations.
try
{
    const int nTest=12;
    var arT=new double[nTest*nTest];var aiT=new double[nTest*nTest];
    var truthR=new double[nTest];var truthI=new double[nTest];
    var brT=new double[nTest];var biT=new double[nTest];
    for(int i=0;i<nTest;i++)
    {
        truthR[i]=Math.Sin(0.3+i*0.2);
        truthI[i]=Math.Cos(0.4+i*0.18);
        for(int j=0;j<nTest;j++)
        {
            int q=i*nTest+j;
            arT[q]=(i==j?8:0.04*(i+j+1));
            aiT[q]=(i==j?0.8:0.013*(i-j));
            brT[i]+=arT[q]*truthR[j]-aiT[q]*truthI[j];
            biT[i]+=arT[q]*truthI[j]+aiT[q]*truthR[j];
        }
    }
    var (solR,solI)=MininecPulseSolver.GaussianSolve(arT,aiT,brT,biT,nTest,CancellationToken.None);
    double maxErr=0;
    for(int i=0;i<nTest;i++)maxErr=Math.Max(maxErr,Math.Sqrt(Math.Pow(solR[i]-truthR[i],2)+Math.Pow(solI[i]-truthI[i],2)));
    Check("direct LU complex system 12x12, maximum solution error",maxErr<1e-9);
}
catch(Exception ex) { Console.WriteLine("FAIL direct LU complex regression: "+ex);failed++; }

Console.WriteLine($"Built-in tests: Passed: {passed}; Failed: {failed}");
string[] fileArgs=args.Where(a=>a!="--beverage-preview").ToArray();
if (fileArgs.Length > 0)
{
    string folder = fileArgs[0];
    if (!Directory.Exists(folder))
    {
        Console.WriteLine("MAA folder not found: " + folder);
        return 2;
    }
    int ok = 0, errors = 0, stacks = 0;
    foreach (var file in Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories)
        .Where(x => x.EndsWith(".maa", StringComparison.OrdinalIgnoreCase)))
    {
        try
        {
            var m = MaaParser.ParseFile(file);
            ok++;
            if (m.HasCompactStack) stacks++;
            Console.WriteLine($"OK | {Path.GetFileName(file)} | {m.Wires.Count} wires | {m.Sources.Count} sources | {m.Warnings.Count} warnings");
        }
        catch (Exception ex)
        {
            errors++;
            Console.WriteLine($"ERROR | {Path.GetFileName(file)} | {ex.Message}");
        }
    }
    Console.WriteLine($"Batch: parsed={ok} rejected={errors} stacks={stacks}");
    if (errors > 0) failed++;
}
// v0.3.4 independent algebraic regression for COMPLEX restarted GMRES.
// Known complex x is multiplied by a non-Hermitian diagonally dominant A;
// the test requires the iterative solution to recover x without guessing Zin.
try
{
    const int n=420; // exceeds the previous 360-pulse ceiling
    var ar=new double[n*n];var ai=new double[n*n];
    var xr=new double[n];var xi=new double[n];
    var br=new double[n];var bi=new double[n];
    for(int j=0;j<n;j++){xr[j]=Math.Sin(0.031*j)+0.12;xi[j]=Math.Cos(0.047*j)-0.20;}
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            int idx=i*n+j;
            double re=i==j?12.0+i*0.001:0.0007*((i+j)%13-6);
            double im=i==j?1.2:0.0004*((i*3-j*2)%17);
            ar[idx]=re;ai[idx]=im;
            br[i]+=re*xr[j]-im*xi[j];
            bi[i]+=re*xi[j]+im*xr[j];
        }
    }
    var solved=MininecPulseSolver.GmresSolve(ar,ai,br,bi,n,CancellationToken.None);
    double maxError=0;
    for(int i=0;i<n;i++)maxError=Math.Max(maxError,Math.Sqrt(
        Math.Pow(solved.Real[i]-xr[i],2)+Math.Pow(solved.Imag[i]-xi[i],2)));
    Check("GMRES 420x420 non-Hermitian complex known solution",maxError<1e-6);
    Check("GMRES nonzero iteration count",solved.Iterations>0&&solved.Iterations<384);
    Console.WriteLine($"GMRES synthetic | dimension={n} | iterations={solved.Iterations} | max error={maxError:E4}");
    using var canceled=new CancellationTokenSource();canceled.Cancel();
    try
    {
        MininecPulseSolver.GmresSolve(ar,ai,br,bi,n,canceled.Token);
        Check("GMRES cancellation",false);
    }
    catch(OperationCanceledException){Check("GMRES cancellation",true);}
}
catch(Exception ex){Console.WriteLine("FAIL GMRES 0.3.5 test: "+ex);failed++;}


// v0.3.5: block-preconditioned GMRES on a strongly coupled complex wire-like matrix.
try
{
    const int n=448;
    var ar=new double[n*n];var ai=new double[n*n];
    var xr=new double[n];var xi=new double[n];
    var br=new double[n];var bi=new double[n];
    for(int j=0;j<n;j++){xr[j]=Math.Sin(j*0.013)+0.10;xi[j]=Math.Cos(j*0.023)-0.15;}
    for(int i=0;i<n;i++)
        for(int j=Math.Max(0,i-13);j<Math.Min(n,i+14);j++)
        {
            double re=i==j?2.0:Math.Abs(i-j)==1?-0.955:Math.Abs(i-j)==13?0.025:0;
            double im=i==j?0.06:i==j+1?0.035:i+1==j?-0.03:0;
            int at=i*n+j;
            ar[at]=re;ai[at]=im;
            br[i]+=re*xr[j]-im*xi[j];
            bi[i]+=re*xi[j]+im*xr[j];
        }
    var z=MininecPulseSolver.GmresSolve(ar,ai,br,bi,n,CancellationToken.None);
    double maxError=0;
    for(int i=0;i<n;i++)maxError=Math.Max(maxError,
        Math.Sqrt(Math.Pow(z.Real[i]-xr[i],2)+Math.Pow(z.Imag[i]-xi[i],2)));
    Check("GMRES BlockLU64 coupled 448x448 solution",maxError<2e-5);
    Check("GMRES BlockLU64 iteration count",z.Iterations>0&&z.Iterations<1152);
    Console.WriteLine($"GMRES coupled matrix | iterations={z.Iterations} | max error={maxError:E3}");
}
catch(Exception ex){Console.WriteLine("FAIL GMRES BlockLU64 coupled matrix: "+ex);failed++;}

return failed==0 ? 0 : 1;
