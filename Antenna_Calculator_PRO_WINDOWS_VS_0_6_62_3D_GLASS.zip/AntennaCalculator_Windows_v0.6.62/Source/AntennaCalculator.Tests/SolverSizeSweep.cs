using AntennaCalculator.Core;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;

// v0.3.76: solver scaling experiment. Geometry is held constant, only segment count changes.
// Uses a cancellation at snapshot boundary to ensure that exactly ONE solve per captured matrix follows.
internal static class SolverSizeSweep
{
    private static readonly CultureInfo Inv=CultureInfo.InvariantCulture;
    private static string F(double v)=>v.ToString("E8",Inv);
    private static double Residual(MininecPulseSolver.MatrixSnapshot a,double[] xr,double[] xi)
    {
        int n=a.Size; double sum=0, bs=0;
        for(int i=0;i<n;i++)
        {
            double rr=-a.RhsReal[i],ri=-a.RhsImag[i];
            for(int j=0;j<n;j++)
            {
                int k=i*n+j;
                rr+=a.Real[k]*xr[j]-a.Imag[k]*xi[j];
                ri+=a.Real[k]*xi[j]+a.Imag[k]*xr[j];
            }
            sum+=rr*rr+ri*ri;
            bs+=a.RhsReal[i]*a.RhsReal[i]+a.RhsImag[i]*a.RhsImag[i];
        }
        return Math.Sqrt(sum/Math.Max(1e-300,bs));
    }
    private static string Read(string[] a,string f,string d)
    {
        int ix=Array.IndexOf(a,f);return ix>=0&&ix+1<a.Length?a[ix+1]:d;
    }
    private static string ModelText(int segments) =>
        $"PEC_monopole_{2*segments-1} - MININEC mesh convergence / solver sweep\n"+
        "*\n28.5\n***Wires***\n1\n"+
        $"0,0,0,0,0,2.63,0.0005,{segments}\n"+
        "***Source***\n1,1\nw1b,0,1\n***Load***\n0,1\n"+
        "***Segmentation***\n200,20,2,1\n*G/H/M/R/AzEl/X*\n1,0,0,50,120,60,0\n";
    public static int Run(string[] args)
    {
        string dest=Path.GetFullPath(Read(args,"--export-dir","solver_sweep_output"));
        Directory.CreateDirectory(dest);
        int[] count;
        try {count=Read(args,"--segments","201,401,801").Split(',').Select(x=>int.Parse(x,Inv)).ToArray();}
        catch(Exception e){Console.Error.WriteLine("Bad --segments: "+e.Message);return 2;}
        if(count.Length==0||count.Any(x=>x<2||x>1800)){Console.Error.WriteLine("segments must be 2..1800");return 2;}
        string csv=Path.Combine(dest,"solver_sweep.csv"), log=Path.Combine(dest,"solver_sweep.txt");
        using var sw=new StreamWriter(csv,false,new System.Text.UTF8Encoding(false));
        using var lw=new StreamWriter(log,false,new System.Text.UTF8Encoding(false));
        sw.WriteLine("segments,pulses,LU_residual,FGMRES_residual,current_relative_delta,FGMRES_iterations,status");
        Console.WriteLine("MININEC controlled mesh/solver sweep; MMANA parity NOT VERIFIED");
        bool allPass=true;
        foreach(int seg in count)
        {
            string file=Path.Combine(dest,$"fixture_PEC_monopole_{2*seg-1}.maa");
            File.WriteAllText(file,ModelText(seg));
            string label=$"segments={seg}";int n=0; string status="";
            double luRes=double.NaN,itRes=double.NaN,delta=double.NaN;
            int iters=0;
            try
            {
                using var cts=new CancellationTokenSource();
                MininecPulseSolver.MatrixSnapshot? snap=null;
                var model=MaaParser.ParseFile(file);
                try
                {
                    MininecPulseSolver.Solve(model,ct:cts.Token,
                        realEarthMode:MininecPulseSolver.RealEarthMode.MmanaPecCurrentApproximation,
                        matrixSnapshotObserver:m=>{snap=m;cts.Cancel();});
                    throw new InvalidOperationException("Expected cancellation after matrix capture");
                }
                catch(OperationCanceledException) when(snap!=null) { }
                if(snap==null)throw new InvalidOperationException("matrix snapshot not captured");
                var a=snap;n=a.Size;
                // Direct LU limited to 900 unknowns: O(N^3), large memory/time.
                (double[] Real,double[] Imag)? lu=null;
                if(n<=900)
                {
                    var sol=MininecPulseSolver.GaussianSolve(a.Real,a.Imag,a.RhsReal,a.RhsImag,n,CancellationToken.None);
                    lu=(sol.Real,sol.Imag);luRes=Residual(a,sol.Real,sol.Imag);
                }
                try
                {
                    var sol=MininecPulseSolver.GmresSolve(a.Real,a.Imag,a.RhsReal,a.RhsImag,n,CancellationToken.None);
                    itRes=Residual(a,sol.Real,sol.Imag);iters=sol.Iterations;
                    if(lu.HasValue)
                    {
                        double diff=0,bs=0;
                        for(int i=0;i<n;i++)
                        {
                            double dr=sol.Real[i]-lu.Value.Real[i],di=sol.Imag[i]-lu.Value.Imag[i];
                            diff+=dr*dr+di*di;
                            bs+=lu.Value.Real[i]*lu.Value.Real[i]+lu.Value.Imag[i]*lu.Value.Imag[i];
                        }
                        delta=Math.Sqrt(diff/Math.Max(1e-300,bs));
                    }
                    bool ok=itRes<2e-7 && (!lu.HasValue || (luRes<1e-7 && delta<2e-4));
                    status=ok?"PASS":"FAIL_RESIDUAL";
                }
                catch(Exception e) {status="FGMRES_FAIL: "+e.Message.Replace(',', ';').Replace('\n',' ');}
            }
            catch(Exception e) {status="ERROR: "+e.Message.Replace(',', ';').Replace('\n',' ');}
            allPass &= status=="PASS";
            string line=$"{label}; n={n}; LU={F(luRes)}; FGMRES={F(itRes)}; current_delta={F(delta)}; iters={iters}; {status}";
            Console.WriteLine(line);lw.WriteLine(line);lw.Flush();
            sw.WriteLine($"{seg},{n},{F(luRes)},{F(itRes)},{F(delta)},{iters},\"{status.Replace("\"","\"\"")}\"");sw.Flush();
        }
        lw.WriteLine("MMANA numerical comparison NOT PERFORMED. A varying mesh also changes the physics discretization, not only solver size.");
        Console.WriteLine("Summary: "+(allPass?"PASS":"SOME FAILURES")+"; CSV: "+csv);
        return allPass?0:1;
    }
}
