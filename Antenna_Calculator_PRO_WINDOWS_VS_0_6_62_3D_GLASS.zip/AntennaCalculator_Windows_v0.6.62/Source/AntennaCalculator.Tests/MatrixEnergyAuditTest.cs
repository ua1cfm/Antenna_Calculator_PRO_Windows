﻿using System;
using System.IO;
using AntennaCalculator.Core;

internal static class MatrixEnergyAuditTest
{
    internal static void Run()
    {
        var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        Console.WriteLine("MININEC MATRIX ENERGY / RECIPROCITY AUDIT v0.3.33");
        Console.WriteLine("CAUTION: kernel matrix is NOT an impedance matrix in ohms. No equivalence of quadratic forms and radiated watts is assumed.");
        foreach(var material in new[]{MininecPulseSolver.ConductorMaterial.Pec,
                    MininecPulseSolver.ConductorMaterial.Copper,
                    MininecPulseSolver.ConductorMaterial.Aluminum})
        {
            MininecPulseSolver.MatrixEnergyAudit? a=null;
            var r=MininecPulseSolver.Solve(model,conductor:material,matrixEnergyObserver:x=>a=x);
            if(a==null) throw new Exception("Missing matrix energy diagnostic callback");
            Console.WriteLine($"CASE {material}: f={model.FrequencyMHz:G9} MHz; G={model.GroundType}; Z={r.ROhm:G13}+j({r.XOhm:G13}); pulses={a.Size}; residual={r.RelativeResidual:E7}");
            Console.WriteLine($"  RECIPROCITY kernel: relative||A-A^T||={a.KernelTransposeRelative:E9}; relative||A-A^H||={a.KernelAdjointRelative:E9}");
            Console.WriteLine($"  RECIPROCITY loaded: relative||A-A^T||={a.LoadedTransposeRelative:E9}; relative||A-A^H||={a.LoadedAdjointRelative:E9}; maxEntryAsymNormalized={a.MaxOffDiagonalAsymmetry:E9} at ({a.MaxAsymmetryRow},{a.MaxAsymmetryColumn})");
            Console.WriteLine($"  ALGEBRA I^H*b=({a.SourceQuadraticReal:G14},{a.SourceQuadraticImag:G14}); I^H*A*I=({a.MatrixQuadraticReal:G14},{a.MatrixQuadraticImag:G14}); relativeDifference={a.QuadraticDifferenceRelative:E9}");
            Console.WriteLine($"  KERNEL I^H*A_kernel*I=({a.MatrixRadiationQuadraticReal:G14},{a.MatrixRadiationQuadraticImag:G14}) INTERNAL UNITS; not physical radiation power");
            Console.WriteLine($"  PORT Psource={a.PortActivePower:G14} W(relative); PmetalPhysical={a.StampedConductorPower:G14}; PloadActive={a.StampedLoadsActivePower:G14}; RHSnorm={a.DirectSourceVoltageNorm:G14}");
            Console.WriteLine($"  Hermitian-part diagonal minimum (real raw coefficient, NOT a passivity certificate)={a.MinimumHermitianDiagonalReal:G14}");
        }
        Console.WriteLine("MMANA Hairpin reference 39.284-j231.814 ohm. No change to matrix kernel or material mapping; compare trends and defects, NOT fitted factors.");
    }
}
