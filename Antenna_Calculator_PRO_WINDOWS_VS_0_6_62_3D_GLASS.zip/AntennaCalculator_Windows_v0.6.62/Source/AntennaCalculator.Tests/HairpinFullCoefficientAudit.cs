﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

internal static class HairpinFullCoefficientAudit
{
    static MaaModel Tags(MaaModel m,Func<MaaWire,int> rule)=>new MaaModel{
        Title=m.Title,FilePath=m.FilePath,FrequencyMHz=m.FrequencyMHz,
        Wires=m.Wires.Select(w=>w with {Tag=rule(w)}).ToArray(),
        Sources=m.Sources.ToArray(),Loads=m.Loads.ToArray(),Warnings=m.Warnings,
        GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord,HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded,BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,StackPlacementMode=m.StackPlacementMode};
    static int One(string label,MaaModel model)
    {
        var readings=new List<MininecPulseSolver.FullCoefficientCheck>();
        try
        {
            var result=MininecPulseSolver.Solve(model,frequencyMHzOverride:28.5,segmentationReferenceMHz:28.5,
                fullCoefficientObserver:readings.Add);
            Console.WriteLine($"=== {label} === pulses={result.PulseCount} Zin=({result.ROhm:G12},{result.XOhm:G12}) residual={result.RelativeResidual:E6} loads={result.LoadStamps?.Count??0}");
            int faults=0;
            foreach(var group in readings.GroupBy(x=>(x.Row,x.Column)))
            {
                double prev=double.PositiveInfinity;
                foreach(var v in group.OrderBy(x=>x.Steps))
                {
                    Complex original=new(v.BaseReal,v.BaseImag);
                    Complex calculated=new(v.IndependentReal,v.IndependentImag);
                    double relative=(calculated-original).Magnitude/Math.Max(1e-12,original.Magnitude);
                    double norm=Math.Max(1e-12,original.Magnitude);
                    double drift=double.IsInfinity(prev)?double.NaN:(calculated-new Complex(group.First(x=>x.Steps==v.Steps/4).IndependentReal,group.First(x=>x.Steps==v.Steps/4).IndependentImag)).Magnitude/norm;
                    Console.WriteLine($" PAIR ({v.Row},{v.Column}) N={v.Steps} A0=({v.BaseReal:G12},{v.BaseImag:G12}) Amid=({v.IndependentReal:G12},{v.IndependentImag:G12}) vector=({v.VectorReal:G12},{v.VectorImag:G12}) scalar=({v.ScalarReal:G12},{v.ScalarImag:G12}) relative={relative:E7} refinement={drift:E7}");
                    if(original.Magnitude < 1e-9 || !double.IsFinite(relative))faults++;
                    if(v.Steps == 1024 && relative > 1e-4)faults++;
                    if(v.Steps == 1024 && double.IsFinite(drift) && drift > 1e-4)faults++;
                    prev=relative;
                }
            }
            bool ok=faults==0&&readings.Count>=9&&result.LoadStamps?.Count==2&&result.TotalActivePower>0&&result.RelativeResidual<1e-7;
            Console.WriteLine($" MODEL {(ok?"PASS":"FAIL")} checks={readings.Count} faults={faults}");
            return ok?0:1;
        }
        catch(Exception e){Console.WriteLine("FAIL "+e);return 1;}
    }
    public static int Run()
    {
        Console.WriteLine("v0.3.51.2 FULL MATRIX COEFFICIENT / COMPOSITE MIDPOINT AUDIT");
        Console.WriteLine("Independent integration method, SAME underlying MININEC potential/kernel model; NOT independent physical derivation.");
        var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        int failures=One("AUTO",m);
        failures+=One("SHORT_2",Tags(m,w=>w.Number is 2 or 4 or 5?2:w.Tag));
        failures+=One("LONG_30_SHORT_2",Tags(m,w=>w.Number is 1 or 3?30:2));
        Console.WriteLine($"FINAL {(failures==0?"PASS":"FAIL")} failures={failures}");
        return failures==0?0:1;
    }
}
