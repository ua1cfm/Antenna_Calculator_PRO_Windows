﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Numerics;
using AntennaCalculator.Core;

// v0.3.49 multi-step sensitivity/consistency audit. No tuning, no core changes without opt-in.
internal static class HairpinMatrixSensitivityAudit
{
    static MaaModel Tags(MaaModel m,Func<MaaWire,int> rule)=>new MaaModel{
        Title=m.Title,FilePath=m.FilePath,FrequencyMHz=m.FrequencyMHz,
        Wires=m.Wires.Select(w=>w with {Tag=rule(w)}).ToArray(),
        Sources=m.Sources.ToArray(),Loads=m.Loads.ToArray(),Warnings=m.Warnings,
        GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord,HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded,BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,StackPlacementMode=m.StackPlacementMode};

    static MininecPulseSolver.Result Solve(MaaModel m,
        Action<MininecPulseSolver.MutualPairAudit>? callback=null,
        MininecPulseSolver.MatrixElementProbe? probe=null)=>
        MininecPulseSolver.Solve(m,frequencyMHzOverride:28.5,
           segmentationReferenceMHz:28.5,mutualPairObserver:callback,matrixElementProbe:probe);
    static Complex Z(MininecPulseSolver.Result r)=>new(r.ROhm,r.XOhm);
    static bool Good(MininecPulseSolver.Result r)=>double.IsFinite(r.ROhm)&&
        double.IsFinite(r.XOhm)&&r.TotalActivePower>0&&r.RelativeResidual<1e-7&&r.LoadStamps?.Count==2;
    static int One(string id,MaaModel model)
    {
        int errors=0;MininecPulseSolver.MutualPairAudit? audit=null;
        Console.WriteLine("=== "+id+" ===");
        try
        {
            // STEP 1: exact baseline and pair identification from the unmodified matrix.
            var baseline=Solve(model,p=>audit=p);
            if(audit==null)throw new InvalidOperationException("No matrix observer data");
            bool pass=Good(baseline);if(!pass)errors++;
            Console.WriteLine($"STEP1 {(pass?"PASS":"FAIL")} pulses={baseline.PulseCount} Zin={Z(baseline)} residual={baseline.RelativeResidual:E5} sourcePower={baseline.TotalActivePower:E8} loads={baseline.LoadStamps?.Count??0} transposeNorm={audit.TransposeRelative:E6}");
            var chosen=audit.Pairs.OrderByDescending(x=>Complex.Abs(
                new Complex(x.AijReal-x.AjiReal,x.AijImag-x.AjiImag))).Take(3).ToArray();
            if(chosen.Length==0)throw new InvalidOperationException("No selected matrix pairs");
            // STEP 2: local derivative in complex Zin for single directed Aij stamps.
            foreach(var pair in chosen)
            {
                Console.WriteLine($"PAIR ({pair.I},{pair.J}) Aij={pair.AijReal:G12}+j({pair.AijImag:G12}) Aji={pair.AjiReal:G12}+j({pair.AjiImag:G12}) junction={pair.Row.Junction||pair.Column.Junction}");
                foreach(double eps in new[]{0.001,0.01})
                {
                    var plus=Solve(model,probe:new(pair.I,pair.J,eps,0));
                    var minus=Solve(model,probe:new(pair.I,pair.J,-eps,0));
                    var dz=(Z(plus)-Z(minus))/(2*eps);
                    var nonLinear=Complex.Abs((Z(plus)+Z(minus))*0.5-Z(baseline));
                    bool ok=Good(plus)&&Good(minus)&&double.IsFinite(dz.Real)&&double.IsFinite(dz.Imaginary);
                    Console.WriteLine($"STEP2 {(ok?"PASS":"FAIL")} index=({pair.I},{pair.J}) eps={eps:G6} Zplus={Z(plus)} Zminus={Z(minus)} sensitivity_dZ_dRelative={dz} evenErrorOhm={nonLinear:G9}");
                    if(!ok)errors++;
                }
                // STEP 3: perturb the transposed element by the same percentage.
                var reverse=Solve(model,probe:new(pair.J,pair.I,0.001,0));
                var forward=Solve(model,probe:new(pair.I,pair.J,0.001,0));
                Console.WriteLine($"STEP3 reverse-vs-forward pair=({pair.I},{pair.J}) deltaZforward={Z(forward)-Z(baseline)} deltaZreverse={Z(reverse)-Z(baseline)} (not a reciprocity assertion)");
                if(!Good(reverse))errors++;
            }
            // STEP 4: unchanged repeatability, loads and source diagnostics.
            var repeated=Solve(model);
            double drift=Complex.Abs(Z(repeated)-Z(baseline));
            bool stable=Good(repeated)&&drift<1e-8;
            Console.WriteLine($"STEP4 {(stable?"PASS":"FAIL")} repeatDriftOhm={drift:E7} referenceMMANA=39.284-j231.814 (comparison only; not fitted)");
            if(!stable)errors++;
        }catch(Exception ex){errors++;Console.WriteLine("FAIL "+ex.GetType().Name+": "+ex.Message);}
        return errors;
    }
    public static int Run()
    {
        Console.WriteLine("v0.3.49 MULTI-STEP MATRIX SENSITIVITY / SOURCE-POWER TEST");
        Console.WriteLine("IMPORTANT: relative perturbation is an artificial diagnostic of sensitivity, NOT a physical correction.");
        Console.WriteLine("Full Aij is read from the actual MININEC solver; independent full-coefficient quadrature is not implemented.");
        var hair=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        int failures=0;
        failures+=One("HAIRPIN_AUTO",hair);
        failures+=One("HAIRPIN_SHORT_2",Tags(hair,w=>w.Number is 2 or 4 or 5?2:w.Tag));
        failures+=One("HAIRPIN_LONG_30_SHORT_2",Tags(hair,w=>w.Number is 1 or 3?30:2));
        // Separate existing independent physical power audit with explicit run status.
        Console.WriteLine("STEP5 regression: run 04_UI_FIELD_PARITY_WINDOWS.bat separately to check dipole, monopole and Hairpin energy balance.");
        Console.WriteLine($"FINAL {(failures==0?"PASS":"FAIL")} failures={failures} cases=3");
        return failures==0?0:1;
    }
}
