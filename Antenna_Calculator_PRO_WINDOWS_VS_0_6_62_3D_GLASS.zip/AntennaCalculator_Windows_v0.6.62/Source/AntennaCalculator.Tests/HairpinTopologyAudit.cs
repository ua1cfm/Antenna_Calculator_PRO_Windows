﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using AntennaCalculator.Core;

// Diagnostic only: no modification of solver, loads, or fields.
internal static class HairpinTopologyAudit
{
    static MaaModel Copy(MaaModel m, MaaWire[]? wires=null, MaaLoad[]? loads=null, MaaSource[]? sources=null) => new MaaModel {
        Title=m.Title, FilePath=m.FilePath, FrequencyMHz=m.FrequencyMHz, Wires=wires??m.Wires.ToArray(),
        Loads=loads??m.Loads.ToArray(), Sources=sources??m.Sources.ToArray(), Warnings=m.Warnings,
        GroundType=m.GroundType, AddHeightMetres=m.AddHeightMetres, MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms, SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord, HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded, BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal, StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres, StackPlacementMode=m.StackPlacementMode
    };
    static MininecPulseSolver.Result RunCase(string name,MaaModel m,double f=28.5)
    {
        var r=MininecPulseSolver.Solve(m,frequencyMHzOverride:f,segmentationReferenceMHz:28.5);
        Console.WriteLine($"CASE {name} f={f:G9} R={r.ROhm:G13} X={r.XOhm:G13} SWR={r.Swr(50):G9} pulses={r.PulseCount} junctions={r.JunctionCount} residual={r.RelativeResidual:E5}");
        foreach(var a in r.LoadStamps??Array.Empty<MininecPulseSolver.LoadStampAudit>())
            Console.WriteLine($"  LOAD W{a.WireNumber}{a.Position}{a.Offset} pulse={a.PulseIndex} sign={a.PulseSign} ground={a.AtGround} sourceCoincident={a.CoincidesWithSource} Z=({a.ROhm:G10},{a.XOhm:G10}) I=({a.CurrentReal:G10},{a.CurrentImag:G10}) P=({a.LoadPowerReal:G10},{a.LoadPowerReactive:G10})");
        foreach(var pt in r.Ports??Array.Empty<MininecPulseSolver.PortResult>())
            Console.WriteLine($"  PORT {pt}");
        return r;
    }
    public static int Run()
    {
        var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        Console.WriteLine("HAIRPIN TOPOLOGY / LOAD / TRUE SEGMENTATION v0.3.44; no solver changes");
        Console.WriteLine("MMANA reference @28.5MHz: R=39.284 X=-231.814 Ohm; conductor code M=4 is not mapped automatically");
        foreach(var w in m.Wires)Console.WriteLine($"WIRE W{w.Number} length={w.LengthMetres:G10} radius={w.RadiusMetres:G10} tag={w.Tag} endpoints=({w.X1},{w.Y1},{w.Z1})->({w.X2},{w.Y2},{w.Z2})");
        foreach(var l in m.Loads)Console.WriteLine($"MAA_LOAD W{l.WireNumber}{l.Position}{l.Offset} kind={l.Kind} values={l.V1},{l.V2},{l.V3}");
        foreach(var a in m.Sources)Console.WriteLine($"MAA_SOURCE W{a.WireNumber}{a.Position}{a.Offset} V={a.RelativeVoltage} phase={a.PhaseDegrees}");
        int fail=0;
        var basic=RunCase("BASE",m);
        if(basic.LoadStamps==null||basic.LoadStamps.Count!=m.Loads.Count) {Console.WriteLine("FAIL LOAD_COUNT");fail++;}else Console.WriteLine("PASS LOAD_COUNT");
        if(basic.LoadStamps!=null && basic.LoadStamps.Select(x=>x.PulseIndex).Distinct().Count()!=m.Loads.Count){Console.WriteLine("FAIL LOAD_PULSE_COLLISION");fail++;} else Console.WriteLine("PASS LOAD_PULSE_DISTINCT");
        if(!double.IsFinite(basic.ROhm)||!double.IsFinite(basic.XOhm)){Console.WriteLine("FAIL BASE_FINITE");fail++;}
        // Independently remove each capacitor. This exposes coupling with the feed and mutual current.
        foreach(int w in new[]{4,5})RunCase("WITHOUT_W"+w,Copy(m,loads:m.Loads.Where(x=>x.WireNumber!=w).ToArray()));
        foreach(int w in new[]{4,5}) foreach(double d in new[]{-.01,.01}) {
            var ls=m.Loads.Select(x=>x.WireNumber==w&&x.Kind==0?x with {V2=x.V2*(1+d)}:x).ToArray();
            RunCase($"C_W{w}_{d*100:+0;-0}%",Copy(m,loads:ls));
        }
        // Radius and discretization are varied as independent MODEL changes, never R/X fitting.
        foreach(double factor in new[]{.95,1.05})RunCase($"RADIUS_{factor:G3}",Copy(m,wires:m.Wires.Select(x=>x with {RadiusMetres=x.RadiusMetres*factor}).ToArray()));
        // Positive MMANA tags specify an EXPLICIT number of physical spans. Negative
        // tags smaller than -3 select automatic coarse segmentation instead.
        // The v0.3.43 test mistakenly used -20/-40/-80 and therefore never changed
        // the actual segmentation. Test this explicitly rather than reporting PASS.
        foreach (bool longOnly in new[]{false,true}) {
            int previousCount=-1;
            double prevR=double.NaN, prevX=double.NaN;
            int[] levels=longOnly?new[]{20,40,60}:new[]{4,8,12};
            foreach (int n in levels) {
                var wires=m.Wires.Select(w => (longOnly && w.Number!=1 && w.Number!=3)
                    ? w : w with {Tag=n}).ToArray();
                var mm=Copy(m,wires:wires);
                var mode=longOnly?"LONG_ARMS":"ALL_WIRES";
                try {
                    var r=RunCase($"SEGMENT_{mode}_POS_{n}",mm);
                    bool countAdvanced=previousCount<0 || r.PulseCount>previousCount;
                    bool finite=double.IsFinite(r.ROhm)&&double.IsFinite(r.XOhm);
                    Console.WriteLine($"SEGMENT_CHECK mode={mode} positiveTag={n} pulses={r.PulseCount} " +
                        $"countAdvanced={countAdvanced} finite={finite} " +
                        $"deltaR={(r.ROhm-prevR):G12} deltaX={(r.XOhm-prevX):G12}");
                    if (!countAdvanced || !finite) {Console.WriteLine($"FAIL SEGMENT_CHECK {mode} tag={n}");fail++;}
                    else Console.WriteLine($"PASS SEGMENT_CHECK {mode} tag={n}");
                    previousCount=r.PulseCount;prevR=r.ROhm;prevX=r.XOhm;
                } catch(Exception e) {
                    Console.WriteLine($"FAIL SEGMENT_DIAGNOSTIC_FAILURE mode={mode} n={n} {e.GetType().Name}: {e.Message}");fail++;
                }
            }
        }
        Console.WriteLine("CAUTION: very short physical spans compared with 10 mm wire diameter violate the thin-wire discretization assumptions; a changing R/X is not by itself convergence.");
        Console.WriteLine($"FINAL {(fail==0?"PASS":"FAIL")} failures={fail}; reference impedance is informational, never fitted");
        return fail==0?0:1;
    }
}
