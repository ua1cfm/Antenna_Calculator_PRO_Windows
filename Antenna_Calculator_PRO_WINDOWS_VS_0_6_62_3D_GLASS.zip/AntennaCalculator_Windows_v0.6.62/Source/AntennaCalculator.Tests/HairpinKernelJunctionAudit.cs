﻿using System;
using System.IO;
using System.Linq;
using AntennaCalculator.Core;

// Checks assembled matrix entries, junction geometry and actual mesh dependencies.
// A is a collocation matrix, NOT a symmetric port-impedance matrix.
internal static class HairpinKernelJunctionAudit
{
    static MaaModel Tags(MaaModel m,Func<MaaWire,int> rule)=>new MaaModel {
        Title=m.Title,FilePath=m.FilePath,FrequencyMHz=m.FrequencyMHz,
        Wires=m.Wires.Select(w=>w with { Tag=rule(w) }).ToArray(),
        Sources=m.Sources.ToArray(),Loads=m.Loads.ToArray(),Warnings=m.Warnings,
        GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord,HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded,BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,StackPlacementMode=m.StackPlacementMode
    };
    static double Dist(MininecPulseSolver.MutualPulseGeometry a,MininecPulseSolver.MutualPulseGeometry b)
    { double x=a.X-b.X,y=a.Y-b.Y,z=a.Z-b.Z;return Math.Sqrt(x*x+y*y+z*z); }
    static string PairCategory(MininecPulseSolver.MutualPairEntry p)
    {
        if(p.Row.Junction||p.Column.Junction)return "JUNCTION_INVOLVED";
        return "ORDINARY";
    }
    public static int Run()
    {
        Console.WriteLine("v0.3.47 HAIRPIN KERNEL / JUNCTION AUDIT; original matrix and far-field UNCHANGED");
        Console.WriteLine("IMPORTANT: Aij is a normalized collocation coefficient, not Ohms. Aij != Aji alone does not violate reciprocity.");
        var original=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        var variations=new (string Name,MaaModel Model)[] {
            ("BASE_AUTO",original),
            ("SHORT_W2_W4_W5_2",Tags(original,w=>w.Number is 2 or 4 or 5?2:w.Tag)),
            ("SHORT_W2_W4_W5_3",Tags(original,w=>w.Number is 2 or 4 or 5?3:w.Tag)),
            ("LONG_ARMS_20_SHORT_2",Tags(original,w=>w.Number is 1 or 3?20:2)),
            ("LONG_ARMS_30_SHORT_2",Tags(original,w=>w.Number is 1 or 3?30:2)),
            ("LONG_ARMS_40_SHORT_2",Tags(original,w=>w.Number is 1 or 3?40:2))
        };
        int failures=0;
        foreach(var v in variations)
        {
            Console.WriteLine("=== "+v.Name+" ===");
            foreach(var w in v.Model.Wires)
            {
                var g=MeshSpanInspector.Inspect(v.Model,w,28.5);
                Console.WriteLine($"WIRE W{w.Number} actualSpans={g.Spans} minLengthMm={g.MinLengthMm:G9} minLenOverD={g.MinOverDiameter:G9} belowDiameter={g.BelowDiameter}");
            }
            MininecPulseSolver.MutualPairAudit? audit=null;
            try
            {
                var r=MininecPulseSolver.Solve(v.Model,frequencyMHzOverride:28.5,
                    segmentationReferenceMHz:28.5,mutualPairObserver:a=>audit=a);
                if(audit==null)throw new InvalidOperationException("Matrix observer callback absent");
                bool ok=double.IsFinite(r.ROhm)&&double.IsFinite(r.XOhm)&&r.TotalActivePower>0
                    &&r.LoadStamps?.Count==2 &&audit.Size==r.PulseCount;
                if(!ok)failures++;
                Console.WriteLine($"{(ok?"PASS":"FAIL")} SOLVE pulses={r.PulseCount} junctions={r.JunctionCount} R={r.ROhm:G14} X={r.XOhm:G14} Psrc={r.TotalActivePower:G14} loss={r.PhysicalConductorLossPower:G14} residual={r.RelativeResidual:E6} loads={r.LoadStamps?.Count??-1}");
                Console.WriteLine($"MATRIX transposeRelative={audit.TransposeRelative:E9} selectedPairs={audit.Pairs.Count} maxRow={audit.MaxRow} maxColumn={audit.MaxColumn}");
                foreach(var pair in audit.Pairs.Take(13))
                {
                    var a=pair.Row;var b=pair.Column;
                    double rowLength=a.LenNegative+a.LenPositive,colLength=b.LenNegative+b.LenPositive;
                    double diameter=2*Math.Max(Math.Max(a.RadiusNegative,a.RadiusPositive),Math.Max(b.RadiusNegative,b.RadiusPositive));
                    Console.WriteLine($"PAIR ({pair.I},{pair.J}) type={PairCategory(pair)} dCentersMm={1000*Dist(a,b):G8} maxDiameterMm={1000*diameter:G8} LrowMm={1000*rowLength:G8} LcolMm={1000*colLength:G8} relativeAsym={pair.RelativeDifference:G9} signFlip={pair.SignFlipRelativeDifference:G9} lengthWeighted={pair.GeometricScaleRelativeDifference:G9}");
                    Console.WriteLine($"  Aij={pair.AijReal:G14}+j({pair.AijImag:G14}) Aji={pair.AjiReal:G14}+j({pair.AjiImag:G14}) rowWires={a.WireNegative}/{a.WirePositive} colWires={b.WireNegative}/{b.WirePositive}");
                }
            }
            catch(Exception ex){failures++;Console.WriteLine($"FAIL REJECTED {ex.GetType().Name}: {ex.Message}");}
        }
        Console.WriteLine($"FINAL {(failures==0?"PASS":"FAIL")} failures={failures} cases={variations.Length}");
        Console.WriteLine("No matrix coefficient is symmetrized, reweighted or tuned to MMANA. Large asymmetry is a diagnosis, not itself a proof of wrong physics.");
        return failures==0?0:1;
    }
}
