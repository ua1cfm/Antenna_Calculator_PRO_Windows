﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

// Independent far-zone calculations; no change to the MININEC solver.
internal static class PecPowerIdentityAudit
{
    private const double Eta = 376.730313668;
    private const double C = 299792458.0;
    private readonly record struct E(double X,double Y,double Z,Complex Mx,Complex My,Complex Mz);
    private static E Convert(MininecPulseSolver.FieldSample s)
    {
        Complex i=new(s.RealCurrent,s.ImagCurrent);
        return new E(s.X,s.Y,s.Z,2*s.Dx*i,2*s.Dy*i,2*s.Dz*i);
    }
    private static E Image(E a)=>new(a.X,a.Y,-a.Z,-a.Mx,-a.My,a.Mz);
    private static double Integrate(IReadOnlyList<E> elements,double frequencyMHz,int nt,int np,bool upper)
    {
        double k=2*Math.PI*frequencyMHz*1e6/C;
        double dt=(upper?Math.PI/2:Math.PI)/nt,dp=2*Math.PI/np,sum=0;
        for(int ti=0;ti<nt;ti++)
        {
            double t=(ti+.5)*dt,st=Math.Sin(t),ct=Math.Cos(t);
            for(int pi=0;pi<np;pi++)
            {
                double ph=(pi+.5)*dp,nx=st*Math.Cos(ph),ny=st*Math.Sin(ph),nz=ct;
                Complex x=0,y=0,z=0;
                foreach(E e in elements)
                {
                    Complex phase=Complex.FromPolarCoordinates(1,k*(e.X*nx+e.Y*ny+e.Z*nz));
                    x+=e.Mx*phase;y+=e.My*phase;z+=e.Mz*phase;
                }
                Complex dot=nx*x+ny*y+nz*z;
                x-=nx*dot;y-=ny*dot;z-=nz*dot;
                sum+=(x.Magnitude*x.Magnitude+y.Magnitude*y.Magnitude+z.Magnitude*z.Magnitude)*st*dt*dp;
            }
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*sum;
    }
    private static double Rel(double a,double b)=>a==0?double.NaN:(b-a)/a;
    private static void ShortMonopoleFixture()
    {
        // Uniform elementary current dl at the PEC surface; image of vertical current is equal.
        // Free-space Hertzian power = eta*k^2*|I*dl|^2/(12*pi).
        // PEC vertical monopole above ground = 2 * free-space Hertzian power at the SAME current.
        const double f=28.5, peakI=1.0;
        double k=2*Math.PI*f*1e6/C, l=(C/(f*1e6))/100;
        E real=new(0,0,0,0,0,new Complex(peakI*l,0));
        var free=new[]{real}; var image=new[]{real,Image(real)};
        double freeAnalytic=Eta*k*k*l*l/(12*Math.PI);
        double monopoleAnalytic=2*freeAnalytic;
        double freeNumeric=Integrate(free,f,48,96,false);
        double imageUpper=Integrate(image,f,48,96,true);
        Console.WriteLine($"HORTZIAN_FIXTURE freeAnalytic={freeAnalytic:G14} freeNumeric={freeNumeric:G14} relative={Rel(freeAnalytic,freeNumeric):E6}");
        Console.WriteLine($"PEC_SHORT_MONO analyticUpper={monopoleAnalytic:G14} numericUpper={imageUpper:G14} relative={Rel(monopoleAnalytic,imageUpper):E6} expectedPecToFree=2 measured={imageUpper/freeNumeric:G12}");
        Console.WriteLine($"PEC_SHORT_MONO_CHECK={(Math.Abs(Rel(monopoleAnalytic,imageUpper))<1e-4?"PASS":"FAIL")}");
    }
    private static void Hairpin(MininecPulseSolver.ConductorMaterial conductor)
    {
        var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        var r=MininecPulseSolver.Solve(model,conductor:conductor);
        var samples=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).ToArray();
        const double eps=1e-8;
        var phys=samples.Where(s=>s.Z>eps).Select(Convert).ToArray();
        var plane=samples.Where(s=>Math.Abs(s.Z)<=eps).Select(Convert).ToArray();
        var mirrored=samples.Where(s=>s.Z< -eps).Select(Convert).ToArray();
        var unfolded=samples.Select(Convert).ToArray();
        var physical=phys.Concat(plane).ToArray();
        var analyticOnly=physical.Concat(physical.Select(Image)).ToArray();
        // Avoid automatically duplicating z=0 contributions in an alternative diagnostic model.
        var analyticNonPlane=phys.Concat(phys.Select(Image)).Concat(plane).ToArray();
        double f=model.FrequencyMHz;
        double ps=r.TotalActivePower,loss=r.PhysicalConductorLossPower;
        double pPhysical=Integrate(physical,f,36,72,true);
        double pUnfolded=Integrate(unfolded,f,36,72,true);
        double pAnalyticAll=Integrate(analyticOnly,f,36,72,true);
        double pAnalyticNoDoublePlane=Integrate(analyticNonPlane,f,36,72,true);
        double pMirror=Integrate(mirrored,f,36,72,true);
        double pUnfoldedFine=Integrate(unfolded,f,48,96,true);
        Console.WriteLine($"CASE {conductor}: Zin={r.ROhm:G12}+j({r.XOhm:G12}) Psource={ps:G12} Pmetal={loss:G12} available={ps-loss:G12} residual={r.RelativeResidual:E6}");
        Console.WriteLine($"COUNT physicalAbove={phys.Length} onPlane={plane.Length} mirrorBelow={mirrored.Length} all={samples.Length}");
        Console.WriteLine($"POWERS physicalOnlyUpper={pPhysical:G14} mirrorOnlyUpper={pMirror:G14} unfoldedUpper={pUnfolded:G14} analyticDuplicatePlaneUpper={pAnalyticAll:G14} analyticSinglePlaneUpper={pAnalyticNoDoublePlane:G14}");
        Console.WriteLine($"INTERFERENCE unfoldedMinusIsolated={(pUnfolded-pPhysical-pMirror):G14} unfoldedOverAvailable={pUnfolded/Math.Max(ps-loss,1e-30):G12} analyticSingleOverAvailable={pAnalyticNoDoublePlane/Math.Max(ps-loss,1e-30):G12}");
        Console.WriteLine($"CONVERGENCE 36x72={pUnfolded:G14} 48x96={pUnfoldedFine:G14} relDiff={Rel(pUnfolded,pUnfoldedFine):E6}");
        Console.WriteLine("CAUTION: z=0 junction moments can contain half-segments on both sides of the plane. Assigning an entire center-at-zero pulse to one side is not a complete physical split.");
    }
    internal static void Run()
    {
        Console.WriteLine("PEC POWER IDENTITY / FEED AUDIT v0.3.38, diagnostic only, unmodified solver");
        ShortMonopoleFixture();
        foreach(var c in new[]{MininecPulseSolver.ConductorMaterial.Pec,MininecPulseSolver.ConductorMaterial.Copper}) Hairpin(c);
        Console.WriteLine("INTERPRETATION: The exact elementary monopole fixture tests the PEC image radiation factor. Hairpin remains a separately solved current distribution; equal power ratios do not by themselves prove the missing physical factor. No renormalization or R/X fitting is applied.");
    }
}
