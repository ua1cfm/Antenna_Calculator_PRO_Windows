﻿using System;
using System.Linq;
using System.Numerics;
using System.IO;
using AntennaCalculator.Core;

// Separate, deterministic far-field integral. Independent of the MININEC matrix.
internal static class RadiationPowerAudit
{
    private const double C=299792458.0;
    private const double Eta=376.730313668;
    private readonly record struct Element(double X,double Y,double Z,Complex Mx,Complex My,Complex Mz);

    // Each Element.M is an electric-current moment I_peak * dl, units A*m.
    private static double Integrate(Element[] a, double fMHz,int nt,int np,bool upperOnly)
    {
        double k=2*Math.PI*fMHz*1e6/C;
        double tmax=upperOnly?Math.PI/2:Math.PI;
        double dt=tmax/nt,dp=2*Math.PI/np,integral=0;
        for(int i=0;i<nt;i++)
        {
            double t=(i+0.5)*dt,st=Math.Sin(t),ct=Math.Cos(t);
            for(int j=0;j<np;j++)
            {
                double phi=(j+0.5)*dp,nx=st*Math.Cos(phi),ny=st*Math.Sin(phi),nz=ct;
                Complex x=0,y=0,z=0;
                foreach(var q in a)
                {
                    var phase=Complex.FromPolarCoordinates(1,k*(nx*q.X+ny*q.Y+nz*q.Z));
                    x+=q.Mx*phase;y+=q.My*phase;z+=q.Mz*phase;
                }
                Complex nd=nx*x+ny*y+nz*z;
                x-=nx*nd;y-=ny*nd;z-=nz*nd;
                integral+=(x.Magnitude*x.Magnitude+y.Magnitude*y.Magnitude+z.Magnitude*z.Magnitude)*st*dt*dp;
            }
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*integral;
    }
    internal static void Run()
    {
        Console.WriteLine("RADIATION POWER NORMALIZATION AUDIT v0.3.29");
        const double fMHz=28.5, lambda=C/(fMHz*1e6);
        const double peakCurrent=1.0;
        // Ideal Hertzian dipole: uniform current over length l, exact far-field Rrad=eta*k^2*l^2/(6*pi).
        double l=lambda/100;
        Element[] h={new Element(0,0,0,0,0,new Complex(peakCurrent*l,0))};
        double analytic=Eta*Math.Pow(2*Math.PI/lambda,2)*l*l/(12*Math.PI)*peakCurrent*peakCurrent;
        double h1=Integrate(h,fMHz,36,72,false),h2=Integrate(h,fMHz,72,144,false);
        double radResistance=2*h2/(peakCurrent*peakCurrent);
        double referenceR=Eta*Math.Pow(2*Math.PI*l/lambda,2)/(6*Math.PI);
        Console.WriteLine($"HERTZIAN DIPOLE: l/lambda={l/lambda:G7}; analytic Prad={analytic:G12} W; quadrature36x72={h1:G12}; quadrature72x144={h2:G12}; Rrad numeric={radResistance:G10} ohm; Rrad analytic={referenceR:G10} ohm; relError={(h2-analytic)/analytic:G8}");
        Console.WriteLine($"HERTZIAN CHECK: {(Math.Abs(h2-analytic)/analytic < 0.002 ? "PASS":"FAIL")}");

        // Standing sinusoidal current on thin, center-fed 0.5-lambda dipole, I(z)=I0*cos(k*z).
        // Reference ~73.13 ohm is an approximate textbook thin-wire value, not an exact MoM benchmark.
        foreach(int n in new[]{40,160})
        {
            double dl=0.5*lambda/n,k=2*Math.PI/lambda;
            var el=Enumerable.Range(0,n).Select(i=>{
                double z=-lambda/4+(i+0.5)*dl;
                return new Element(0,0,z,0,0,new Complex(peakCurrent*Math.Cos(k*z)*dl,0));
            }).ToArray();
            double p=Integrate(el,fMHz,72,144,false);
            Console.WriteLine($"HALF-WAVE SINUSOID n={n}: Prad={p:G12} W, Rrad={2*p:G10} ohm, reference approximately 73.13 ohm");
        }
        var model=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        foreach(var metal in new[]{MininecPulseSolver.ConductorMaterial.Pec,MininecPulseSolver.ConductorMaterial.Copper,MininecPulseSolver.ConductorMaterial.Aluminum})
        {
            var r=MininecPulseSolver.Solve(model,conductor:metal);
            var elems=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).Select(s=>{
                Complex I=new(s.RealCurrent,s.ImagCurrent);
                return new Element(s.X,s.Y,s.Z,2*s.Dx*I,2*s.Dy*I,2*s.Dz*I);
            }).ToArray();
            double p36=Integrate(elems,model.FrequencyMHz,36,72,true);
            double p72=Integrate(elems,model.FrequencyMHz,72,144,true);
            double psrc=r.TotalActivePower,loss=r.PhysicalConductorLossPower;
            double rem=psrc-loss;
            Console.WriteLine($"HAIRPIN {metal}: Zin={r.ROhm:G12}+j({r.XOhm:G12}) ohm; Psrc={psrc:G12} W; PlossPhysical={loss:G12} W; residualPower=Psrc-Ploss={rem:G12} W; Prad36x72={p36:G12} W; Prad72x144={p72:G12} W; Prad/(Psrc-Ploss)={(rem>0?p72/rem:double.NaN):G10}; mismatch=Psrc-Ploss-Prad={rem-p72:G12} W; quadratureRelative={Math.Abs(p72-p36)/Math.Max(p72,1e-30):G8}");
        }
        Console.WriteLine("INTERPRETATION: analytic Hertzian test isolates the radiation-integral prefactor; the half-wave current profile tests numerical integration. Neither validates the MININEC currents, PEC images or conductor-loss stamps. No fitted factors.");
    }
}
