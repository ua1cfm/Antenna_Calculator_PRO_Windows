﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using AntennaCalculator.Core;

// Three independent, repeatable checks. DO NOT modify physics on the basis of ratios alone.
internal static class ThreeStageNormalizationAudit
{
    const double C=299792458.0, Eta=376.730313668;
    internal static void Run(string stage)
    {
        Console.WriteLine("THREE-STAGE PHYSICAL BASIS / SOURCE AUDIT v0.3.41");
        Console.WriteLine("Original matrix and UI unchanged. Candidate half-moment is a DIAGNOSTIC ALTERNATIVE, not a released field correction.");
        if(stage=="all" || stage=="basis") Basis();
        if(stage=="all" || stage=="power") Power();
        if(stage=="all" || stage=="regression") Regression();
    }
    static MaaModel Fixture(int ground,int n)
    {
        var wire=ground==1?new MaaWire(1,0,0,0,0,0,2.5,.002,n):new MaaWire(1,0,0,-2.5,0,0,2.5,.002,2*n);
        return new MaaModel{Title="FIXTURE",FilePath="fixture",FrequencyMHz=28.5,Wires=new[]{wire},
            Sources=new[]{new MaaSource(1,ground==1?'b':'c',0,0,1,"fixture")},
            Loads=Array.Empty<MaaLoad>(),Warnings=Array.Empty<string>(),GroundType=ground,
            SegmentationRecord="800,80,1.1,16",ReferenceOhms=50};
    }
    static MaaModel Hairpin() => MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
    static double P(MininecPulseSolver.Result r,double f,bool upper,double momentScale,int nt=32,int np=64)
    {
        var a=r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>();
        double k=2*Math.PI*f*1e6/C,dt=(upper?Math.PI/2:Math.PI)/nt,dp=2*Math.PI/np,sum=0;
        for(int it=0;it<nt;it++)
        {
            double th=(it+.5)*dt,s=Math.Sin(th),c=Math.Cos(th);
            for(int ip=0;ip<np;ip++)
            {
                double phi=(ip+.5)*dp,nx=s*Math.Cos(phi),ny=s*Math.Sin(phi),nz=c;
                Complex x=0,y=0,z=0;
                foreach(var e in a)
                {
                    Complex amp=new Complex(e.RealCurrent,e.ImagCurrent)*momentScale;
                    Complex phase=Complex.FromPolarCoordinates(1,k*(nx*e.X+ny*e.Y+nz*e.Z));
                    x+=2*e.Dx*amp*phase;y+=2*e.Dy*amp*phase;z+=2*e.Dz*amp*phase;
                }
                Complex dot=nx*x+ny*y+nz*z;
                x-=nx*dot;y-=ny*dot;z-=nz*dot;
                sum+=(x.Magnitude*x.Magnitude+y.Magnitude*y.Magnitude+z.Magnitude*z.Magnitude)*s*dt*dp;
            }
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*sum;
    }
    static void Inspect(string title,MaaModel model,MininecPulseSolver.ConductorMaterial metal,int nt=32,int np=64)
    {
        try
        {
            var r=MininecPulseSolver.Solve(model,conductor:metal);
            double src=r.TotalActivePower,loss=r.PhysicalConductorLossPower,available=src-loss;
            double raw=P(r,model.FrequencyMHz,model.GroundType==1,1,nt,np);
            double half=P(r,model.FrequencyMHz,model.GroundType==1,.5,nt,np);
            var ss=r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>();
            double fullMoment=ss.Sum(t=>2*Math.Sqrt(t.Dx*t.Dx+t.Dy*t.Dy+t.Dz*t.Dz)*Complex.Abs(new Complex(t.RealCurrent,t.ImagCurrent)));
            Console.WriteLine($"CASE {title} fMHz={model.FrequencyMHz:G9} G={model.GroundType} metal={metal} pulses={r.PulseCount} Zin={r.ROhm:G12}+j({r.XOhm:G12}) residual={r.RelativeResidual:E5}");
            Console.WriteLine($"  PORT Psrc={src:G14} Ploss={loss:G14} Pavailable={available:G14} |I|={(r.Ports?.FirstOrDefault()?.CurrentMagnitude??double.NaN):G12}");
            Console.WriteLine($"  BASIS fullMomentAbsSum={fullMoment:G13} fieldPowerRaw={raw:G14} fieldPowerHalfBasis={half:G14} raw/available={raw/available:G12} half/available={half/available:G12}");
            Console.WriteLine($"  ENERGY rawResidual={available-raw:G14} halfResidual={available-half:G14} (candidate only; NOT passivity proof)");
        }
        catch(Exception e){ Console.WriteLine($"CASE {title} ERROR {e.GetType().Name}: {e.Message}"); }
    }
    static void Basis()
    {
        Console.WriteLine("=== STEP 1: CURRENT BASIS AND RADIATED-POWER ALTERNATIVES ===");
        Inspect("FREE_DIPOLE_N30",Fixture(0,15),MininecPulseSolver.ConductorMaterial.Pec);
        Inspect("PEC_MONO_N15",Fixture(1,15),MininecPulseSolver.ConductorMaterial.Pec);
        Inspect("HAIRPIN_PEC",Hairpin(),MininecPulseSolver.ConductorMaterial.Pec);
        Console.WriteLine("CHECK: 0.5 current moment yields 0.25 power by construction, NOT evidence of correct normalization.");
    }
    static void Power()
    {
        Console.WriteLine("=== STEP 2: INDEPENDENT PORT POWER AND QUADRATURE ===");
        foreach(var m in new[]{Fixture(0,15),Fixture(0,31),Fixture(1,15),Fixture(1,31),Hairpin()})
        {
            var r=MininecPulseSolver.Solve(m);
            var port=r.Ports?.FirstOrDefault();
            if(port==null){Console.WriteLine("NO PORT");continue;}
            var zi=new Complex(r.ROhm,r.XOhm);
            double fromZ=.5*port.VoltageMagnitude*port.VoltageMagnitude*zi.Real/(zi.Magnitude*zi.Magnitude);
            double fromPort=port.ActivePower;
            double p1=P(r,m.FrequencyMHz,m.GroundType==1,1,24,48);
            double p2=P(r,m.FrequencyMHz,m.GroundType==1,1,48,96);
            Console.WriteLine($"PORT_CHECK G={m.GroundType} wires={m.Wires.Count} pulses={r.PulseCount} portPower={fromPort:G14} PfromZ={fromZ:G14} rel={(fromZ-fromPort)/Math.Max(1e-30,Math.Abs(fromPort)):E5} prad24={p1:G14} prad48={p2:G14} quadratureRel={(p2-p1)/Math.Max(1e-30,p2):E5}");
        }
        Console.WriteLine("NOTE: physical port power .5*Re(V*conj(I)) computed separately from Z; complex convention verified from source ports.");
    }
    static MaaModel AtFrequency(MaaModel m,double frequency) => new MaaModel
    {
        Title=m.Title,FilePath=m.FilePath,FrequencyMHz=frequency,Wires=m.Wires,Sources=m.Sources,
        Loads=m.Loads,Warnings=m.Warnings,GroundType=m.GroundType,AddHeightMetres=m.AddHeightMetres,
        MaterialCode=m.MaterialCode,ReferenceOhms=m.ReferenceOhms,SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord,HasCompactStack=m.HasCompactStack,StackExpanded=m.StackExpanded,
        BaseWireCount=m.BaseWireCount,StackHorizontal=m.StackHorizontal,StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres,StackPlacementMode=m.StackPlacementMode
    };
    static void Regression()
    {
        Console.WriteLine("=== STEP 3: REGRESSIONS + HAIRPIN NEAR RESONANCE ===");
        foreach(int n in new[]{15,31})
        {
            Inspect($"FREE_DIPOLE_N{2*n}",Fixture(0,n),MininecPulseSolver.ConductorMaterial.Pec,24,48);
            Inspect($"PEC_MONO_N{n}",Fixture(1,n),MininecPulseSolver.ConductorMaterial.Pec,24,48);
        }
        var hair=Hairpin();
        foreach(double f in new[]{28.5,28.70,28.752875,28.8})
        {
            var atF=AtFrequency(hair,f);
            Inspect($"HAIRPIN_PEC_{f:G9}",atF,MininecPulseSolver.ConductorMaterial.Pec,24,48);
        }
        Inspect("HAIRPIN_COPPER",hair,MininecPulseSolver.ConductorMaterial.Copper,24,48);
        Console.WriteLine("NEXT: only if independent analytical basis/function derivation confirms a factor, alter moment construction and repeat ALL physics regression tests.");
    }
}
