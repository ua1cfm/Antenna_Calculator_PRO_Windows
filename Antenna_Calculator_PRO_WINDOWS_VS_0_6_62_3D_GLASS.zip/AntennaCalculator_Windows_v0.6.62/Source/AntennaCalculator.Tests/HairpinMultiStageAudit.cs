﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

// Three logically linked, diagnostic-only stages. No alteration of the electromagnetic solver.
internal static class HairpinMultiStageAudit
{
    static MaaModel Tags(MaaModel m, Func<MaaWire,int> rule) => new MaaModel {
        Title=m.Title, FilePath=m.FilePath, FrequencyMHz=m.FrequencyMHz,
        Wires=m.Wires.Select(w=>w with { Tag=rule(w) }).ToArray(),
        Sources=m.Sources.ToArray(), Loads=m.Loads.ToArray(), Warnings=m.Warnings,
        GroundType=m.GroundType, AddHeightMetres=m.AddHeightMetres, MaterialCode=m.MaterialCode,
        ReferenceOhms=m.ReferenceOhms, SegmentationRecord=m.SegmentationRecord,
        WireHeaderRecord=m.WireHeaderRecord, HasCompactStack=m.HasCompactStack,
        StackExpanded=m.StackExpanded, BaseWireCount=m.BaseWireCount,
        StackHorizontal=m.StackHorizontal, StackVertical=m.StackVertical,
        StackHorizontalSpacingMetres=m.StackHorizontalSpacingMetres,
        StackVerticalSpacingMetres=m.StackVerticalSpacingMetres, StackPlacementMode=m.StackPlacementMode
    };
    readonly record struct V(double X,double Y,double Z)
    {
        public static V operator +(V a,V b)=>new(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
        public static V operator -(V a,V b)=>new(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
        public static V operator *(V a,double x)=>new(a.X*x,a.Y*x,a.Z*x);
        public double Norm()=>Math.Sqrt(X*X+Y*Y+Z*Z);
    }
    static V Point(MininecPulseSolver.MutualPulseGeometry g)=>new(g.X,g.Y,g.Z);
    static V End(MininecPulseSolver.MutualPulseGeometry g,bool pos)=> pos?new(g.PosX,g.PosY,g.PosZ):new(g.NegX,g.NegY,g.NegZ);
    // Two independently implemented 1D integrations of a REGULARIZED FREE-SPACE Green function.
    // This is NOT the full MININEC A_ij coefficient: it excludes scalar-gradient derivatives,
    // kernel's elliptic treatment of connected thick wires, and basis/collocation weights.
    static Complex Green(V obs,V start,V finish,double radius,double k,int segments,bool simpson)
    {
        V vec=finish-start;double len=vec.Norm();if(len<=0)return Complex.Zero;
        Complex F(double t){V q=start+vec*t-obs;double r=Math.Sqrt(q.X*q.X+q.Y*q.Y+q.Z*q.Z+radius*radius);return new Complex(Math.Cos(k*r)/r,-Math.Sin(k*r)/r);}
        if(simpson){int n=segments%2==0?segments:segments+1;Complex sum=F(0)+F(1);for(int i=1;i<n;i++)sum+=(i%2==0?2:4)*F((double)i/n);return len*sum/(3*n);}
        else {Complex sum=Complex.Zero;for(int i=0;i<segments;i++)sum+=F((i+0.5)/segments);return len*sum/segments;}
    }
    static double Rel(Complex a,Complex b)=>(a-b).Magnitude/Math.Max(1e-14,b.Magnitude);
    static void Quadrature(string id,MininecPulseSolver.MutualPairEntry p,double k)
    {
        var row=p.Row;var col=p.Column;
        V obs=Point(row),start=Point(col),end=End(col,true);
        double rad=Math.Max(1e-8,col.RadiusPositive);
        var reference=Green(obs,start,end,rad,k,4096,true);
        Console.WriteLine($"QUADRATURE {id} pair=({p.I},{p.J}) sourceHalf=POS radiusMm={1000*rad:G7} reference=({reference.Real:G12},{reference.Imaginary:G12})");
        foreach(int n in new[]{16,32,64,128,256,512}){
            var a=Green(obs,start,end,rad,k,n,true);
            var b=Green(obs,start,end,rad,k,n,false);
            Console.WriteLine($"  N={n} simpsonRel={Rel(a,reference):E6} midpointRel={Rel(b,reference):E6} agreementRel={Rel(a,b):E6}");
        }
        Console.WriteLine($"  NOTE regularized 1D Green integral only, NOT a direct numerical reference for Aij={p.AijReal:G9}+j({p.AijImag:G9})");
    }
    static void RunOne(string name,MaaModel m,out int failures)
    {
        failures=0;Console.WriteLine("=== "+name+" ===");
        MininecPulseSolver.MutualPairAudit? pairs=null;
        try{
            var r=MininecPulseSolver.Solve(m,frequencyMHzOverride:28.5,segmentationReferenceMHz:28.5,mutualPairObserver:x=>pairs=x);
            if(pairs==null)throw new Exception("Missing observer");
            bool pass=double.IsFinite(r.ROhm)&&double.IsFinite(r.XOhm)&&r.TotalActivePower>0&&r.LoadStamps?.Count==2;
            if(!pass)failures++;
            Console.WriteLine($"STAGE2 {(pass?"PASS":"FAIL")} pulses={r.PulseCount} junction={r.JunctionCount} Zin=({r.ROhm:G12},{r.XOhm:G12}) Psource={r.TotalActivePower:G12} residual={r.RelativeResidual:E5} loads={r.LoadStamps?.Count??0} transposeNorm={pairs.TransposeRelative:E6}");
            var ranked=pairs.Pairs.OrderByDescending(p=>(new Complex(p.AijReal-p.AjiReal,p.AijImag-p.AjiImag)).Magnitude).Take(6).ToArray();
            foreach(var p in ranked)Console.WriteLine($"  COEFFICIENT pair=({p.I},{p.J}) deltaAbs={(new Complex(p.AijReal-p.AjiReal,p.AijImag-p.AjiImag)).Magnitude:G10} rel={p.RelativeDifference:G9} junction={p.Row.Junction||p.Column.Junction}");
            Console.WriteLine("STAGE3 matrix-pair ranking is diagnostic; collocation matrix need not be symmetric");
            foreach(var p in ranked.Take(2))Quadrature(name,p,2*Math.PI*28.5e6/299792458.0);
        }catch(Exception ex){failures++;Console.WriteLine("FAIL "+ex.GetType().Name+": "+ex.Message);}
    }
    public static int Run()
    {
        Console.WriteLine("HAIRPIN MULTI-STAGE KERNEL AUDIT v0.3.48 (ORIGINAL solver unchanged)");
        Console.WriteLine("STAGE1: independent composite Simpson vs midpoint quadrature for regularized Green integrals");
        Console.WriteLine("STAGE2: actual MININEC matrix coefficient rankings and Zin over controlled meshes");
        Console.WriteLine("STAGE3: regression assertions for solver residual, source power and load count");
        Console.WriteLine("IMPORTANT: quadrature is NOT a replacement or exact equivalent of MININEC vector+scalar potential coefficient");
        var m=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        var cases=new (string,MaaModel)[]{
            ("BASE_AUTO",m),
            ("SHORT_ALL_2",Tags(m,w=>w.Number is 2 or 4 or 5?2:w.Tag)),
            ("SHORT_ALL_3",Tags(m,w=>w.Number is 2 or 4 or 5?3:w.Tag)),
            ("ARMS_20_SHORT_2",Tags(m,w=>w.Number is 1 or 3?20:2)),
            ("ARMS_30_SHORT_2",Tags(m,w=>w.Number is 1 or 3?30:2)),
            ("ARMS_40_SHORT_2",Tags(m,w=>w.Number is 1 or 3?40:2))
        };
        int failures=0;foreach(var c in cases){RunOne(c.Item1,c.Item2,out var f);failures+=f;}
        Console.WriteLine($"FINAL {(failures==0?"PASS":"FAIL")} failures={failures} cases={cases.Length}");
        return failures==0?0:1;
    }
}
