﻿using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Collections.Generic;
using AntennaCalculator.Core;

// v0.3.40: no kernel change and no post-hoc fitted radiated field.
internal static class SourcePowerReconciliationAudit
{
    const double Eta=376.730313668, Speed=299792458.0;
    readonly record struct Elem(double X,double Y,double Z,Complex Mx,Complex My,Complex Mz);
    static Elem ToElem(MininecPulseSolver.FieldSample s)
    {
        Complex i=new(s.RealCurrent,s.ImagCurrent);
        return new(s.X,s.Y,s.Z,2*s.Dx*i,2*s.Dy*i,2*s.Dz*i);
    }
    static double Radiation(IReadOnlyList<Elem> a,double f,int nt,int np,bool upper)
    {
        double k=2*Math.PI*f*1e6/Speed,dt=(upper?Math.PI/2:Math.PI)/nt,dp=2*Math.PI/np,total=0;
        for(int ti=0;ti<nt;ti++)
        {
            double theta=(ti+0.5)*dt,s=Math.Sin(theta),c=Math.Cos(theta);
            for(int pi=0;pi<np;pi++)
            {
                double p=(pi+0.5)*dp,nx=s*Math.Cos(p),ny=s*Math.Sin(p),nz=c;
                Complex x=0,y=0,z=0;
                foreach(var e in a)
                {
                    Complex ph=Complex.FromPolarCoordinates(1,k*(nx*e.X+ny*e.Y+nz*e.Z));
                    x+=e.Mx*ph;y+=e.My*ph;z+=e.Mz*ph;
                }
                Complex dot=nx*x+ny*y+nz*z;
                x-=nx*dot;y-=ny*dot;z-=nz*dot;
                total+=(x.Magnitude*x.Magnitude+y.Magnitude*y.Magnitude+z.Magnitude*z.Magnitude)*s*dt*dp;
            }
        }
        return Eta*k*k/(32*Math.PI*Math.PI)*total;
    }

    static MaaModel Fixture(string label,int ground,int segments,char feed,double radius=0.002)
    {
        // PEC: quarterwave monopole with physical base at z=0.
        // Free: comparable dipole of twice the length centered at z=0.
        var wire=ground==1
            ?new MaaWire(1,0,0,0,0,0,2.5,radius,segments)
            :new MaaWire(1,0,0,-2.5,0,0,2.5,radius,segments*2);
        return new MaaModel {Title=label,FilePath="diagnostic",FrequencyMHz=28.5,
            Wires=new[]{wire},Sources=new[]{new MaaSource(1,feed,0,0,1,"W1"+feed+"0,1")},
            Loads=Array.Empty<MaaLoad>(),Warnings=Array.Empty<string>(),GroundType=ground,
            SegmentationRecord="800,80,1.1,16",ReferenceOhms=50};
    }
    static void Case(string label,MaaModel model,MininecPulseSolver.ConductorMaterial metal)
    {
        try
        {
            var r=MininecPulseSolver.Solve(model,conductor:metal);
            var elems=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).Select(ToElem).ToArray();
            var phys=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).Where(s=>s.Z>1e-8).Select(ToElem).ToArray();
            var mirr=(r.FieldSamples??Array.Empty<MininecPulseSolver.FieldSample>()).Where(s=>s.Z< -1e-8).Select(ToElem).ToArray();
            double p=r.TotalActivePower,loss=r.PhysicalConductorLossPower;
            double radiation=Radiation(elems,model.FrequencyMHz,36,72,model.GroundType==1);
            double pradFree=Radiation(elems,model.FrequencyMHz,36,72,false);
            Console.WriteLine($"CASE {label} G={model.GroundType} conductor={metal} pulses={r.PulseCount} Zin={r.ROhm:G14}+j({r.XOhm:G14}) residual={r.RelativeResidual:E5}");
            foreach(var port in r.Ports??Array.Empty<MininecPulseSolver.PortResult>())
                Console.WriteLine($"  PORT V={port.VoltageMagnitude:G13} I={port.CurrentMagnitude:G13} phase={port.CurrentPhaseDegrees:G13} P={port.ActivePower:G14}");
            Console.WriteLine($"  POWER Psrc={p:G14} Pmetal={loss:G14} Pavailable={p-loss:G14} PradPhysicalDomain={radiation:G14} Pfull={pradFree:G14} ratio={radiation/Math.Max(1e-30,p-loss):G14}");
            Console.WriteLine($"  COMPONENT Pplus={Radiation(phys,model.FrequencyMHz,24,48,true):G14} Pminus={Radiation(mirr,model.FrequencyMHz,24,48,true):G14}");
            Console.WriteLine($"  SOURCE_CHECK Vin/I vs Z: {Complex.Abs(new Complex(r.ROhm,r.XOhm)):G13} ohm; IMPORTANT: Psrc is calculated from ONE declared physical source, never from both image copies.");
        }
        catch(Exception e) {Console.WriteLine($"CASE {label} ERROR {e.GetType().Name}: {e.Message}");}
    }
    internal static void Run()
    {
        Console.WriteLine("SOURCE POWER RECONCILIATION v0.3.40 — diagnostic, ORIGINAL kernel/field untouched");
        Console.WriteLine("Free-space full-sphere and PEC upper-hemisphere powers, both derived from SOLVED current distributions.");
        foreach(int n in new[]{15,31})
        {
            Case($"FREE_DIPOLE_CENTER_N{2*n}",Fixture("FREE_DIPOLE",0,n,'c'),MininecPulseSolver.ConductorMaterial.Pec);
            Case($"PEC_MONOPOLE_BASE_N{n}",Fixture("PEC_MONO",1,n,'b'),MininecPulseSolver.ConductorMaterial.Pec);
            Case($"PEC_MONOPOLE_CENTER_N{n}",Fixture("PEC_MONO",1,n,'c'),MininecPulseSolver.ConductorMaterial.Pec);
        }
        var path=Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa");
        var hairpin=MaaParser.ParseFile(path);
        Case("HAIRPIN_PEC",hairpin,MininecPulseSolver.ConductorMaterial.Pec);
        Case("HAIRPIN_COPPER",hairpin,MininecPulseSolver.ConductorMaterial.Copper);
        Console.WriteLine("INTERPRETATION: A roughly fourfold ratio on simple solved free dipole as well as PEC mono would implicate the general matrix-current/radiation convention; only on PEC would implicate PEC unfolding/port equivalence.");
        Console.WriteLine("DO NOT divide fields by two or scale impedance without establishing the mathematical basis from an independent formulation.");
    }
}
