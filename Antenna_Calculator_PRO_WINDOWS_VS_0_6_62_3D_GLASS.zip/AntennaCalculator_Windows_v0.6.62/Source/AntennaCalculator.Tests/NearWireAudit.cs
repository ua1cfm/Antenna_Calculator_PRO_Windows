﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using AntennaCalculator.Core;

internal static class NearWireAudit
{
    private static MaaWire W(int id,double x1,double y1,double z1,double x2,double y2,double z2,double radius)
        =>new(id,x1,y1,z1,x2,y2,z2,radius,-1);
    private static MaaModel Fixture(string title,IReadOnlyList<MaaWire> wires,int ground,int segments)
        =>new MaaModel
        {
            Title=title,FilePath=title,FrequencyMHz=28.5,Wires=wires,
            Sources=new[]{new MaaSource(1,'c',0,0,1,"w1c,0,1")},
            Loads=Array.Empty<MaaLoad>(),Warnings=Array.Empty<string>(),
            GroundType=ground,ReferenceOhms=50,MaterialCode=0,
            SegmentationRecord=$"200,{segments},2,1"
        };
    private static (double Norm,double PairMax,double PairMin,double Separation) Observe(MininecPulseSolver.MutualPairAudit audit)
    {
        double top=audit.Pairs.Count==0?double.NaN:audit.Pairs.Max(x=>x.RelativeDifference);
        double lo=audit.Pairs.Count==0?double.NaN:audit.Pairs.Min(x=>x.RelativeDifference);
        double distance=double.NaN;
        if(audit.Pairs.Count>0)
        {
            var p=audit.Pairs[0];
            distance=Math.Sqrt(Math.Pow(p.Row.X-p.Column.X,2)+Math.Pow(p.Row.Y-p.Column.Y,2)+Math.Pow(p.Row.Z-p.Column.Z,2));
        }
        return(audit.TransposeRelative,top,lo,distance);
    }
    private static void Case(string name,int ground,double radius,int segments,bool verbose=false)
    {
        // Two 0.7-m conductors with a 30-mm closest spacing; the angle and
        // continuity cases deliberately change the relative segment geometry.
        const double length=0.7, d=0.03;
        IReadOnlyList<MaaWire> wires = name switch
        {
            "PARALLEL"=>new[]{W(1,0,0,ground==1?0.15:0,0,0,(ground==1?0.15:0)+length,radius),
                               W(2,d,0,ground==1?0.15:0,d,0,(ground==1?0.15:0)+length,radius)},
            "ANGLED_45"=>new[]{W(1,0,0,ground==1?0.15:0,0,0,(ground==1?0.15:0)+length,radius),
                                W(2,d,0,ground==1?0.15:0,d+length/Math.Sqrt(2),0,(ground==1?0.15:0)+length/Math.Sqrt(2),radius)},
            "CONNECTED_45"=>new[]{W(1,0,0,ground==1?0.15:0,0,0,(ground==1?0.15:0)+length,radius),
                                   W(2,0,0,(ground==1?0.15:0)+length,length/Math.Sqrt(2),0,(ground==1?0.15:0)+length+length/Math.Sqrt(2),radius)},
            _=>throw new ArgumentException(name)
        };
        var model=Fixture(name,wires,ground,segments);
        MininecPulseSolver.MutualPairAudit? audit=null;
        try
        {
            var result=MininecPulseSolver.Solve(model,mutualPairObserver:a=>audit=a);
            if(audit==null)throw new InvalidOperationException("Matrix observation missing");
            var m=Observe(audit);
            double minLen=double.PositiveInfinity;
            foreach(var p in audit.Pairs)
                minLen=Math.Min(minLen,Math.Min(p.Row.LenNegative+p.Row.LenPositive,p.Column.LenNegative+p.Column.LenPositive));
            double nominal=length/Math.Max(1,segments);
            Console.WriteLine($"CASE={name} G={ground} radius={radius:G7}m wireDiameter={2*radius:G7}m segRequest={segments} nominalLen/diam={nominal/(2*radius):G5} pulses={audit.Size} Zin=({result.ROhm:G11},{result.XOhm:G11}) Ohm residual={result.RelativeResidual:E5} normAsym={m.Norm:E7} selectedPairMax={m.PairMax:E7} minSelectedLength/diam={minLen/(2*radius):G6}");
            if(verbose)
                foreach(var x in audit.Pairs.Take(4))
                    Console.WriteLine($"  PAIR ({x.I},{x.J}) Aij={x.AijReal:G9}+j{x.AijImag:G9} Aji={x.AjiReal:G9}+j{x.AjiImag:G9} rel={x.RelativeDifference:G7} junctionRow={x.Row.Junction} junctionColumn={x.Column.Junction}");
        }
        catch(Exception ex)
        {
            Console.WriteLine($"CASE={name} G={ground} radius={radius:G7} segRequest={segments} NOT_SOLVED {ex.GetType().Name}: {ex.Message}");
        }
    }
    internal static void Run()
    {
        Console.WriteLine("NEAR-WIRE KERNEL AUDIT v0.3.35 — original kernel, no calibration");
        Console.WriteLine("Segments and radii are varied independently. Non-symmetric collocation does NOT alone prove reciprocity violation.");
        foreach(string name in new[]{"PARALLEL","ANGLED_45","CONNECTED_45"})
            foreach(int ground in new[]{0,1})
                foreach(double radius in new[]{0.001,0.005})
                    foreach(int segments in new[]{10,20,40})
                        Case(name,ground,radius,segments,segments==20&&radius==0.005);
        var hairpin=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        MininecPulseSolver.MutualPairAudit? ha=null;
        var hr=MininecPulseSolver.Solve(hairpin,mutualPairObserver:a=>ha=a);
        Console.WriteLine($"REFERENCE_HAIRPIN f=28.5 G={hairpin.GroundType} Zin={hr.ROhm:G12}+j({hr.XOhm:G12}) ||A-A^T||/||A||={ha?.TransposeRelative:E7}");
        Console.WriteLine("IMPORTANT: high length/diameter violations, crossed axes, junctions and nearby surfaces challenge thin-wire assumptions; numerical convergence is not physical validation.");
    }
}
