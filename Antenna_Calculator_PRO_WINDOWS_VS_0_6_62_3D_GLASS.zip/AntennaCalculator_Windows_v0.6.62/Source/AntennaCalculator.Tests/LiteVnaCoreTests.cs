using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using AntennaCalculator.Core;

/// <summary>Hardware-free checks of the LiteVNA core: dotnet run -- --litevna</summary>
internal static class LiteVnaCoreTests
{
    static int _failed;
    static void Check(bool ok,string name){ Console.WriteLine((ok?"OK   ":"FAIL ")+name); if(!ok) _failed++; }

    public static int Run()
    {
        // command encoding
        Check(LiteVnaProtocol.Write8(LiteVnaProtocol.RegSweepStartHz,1_000_000).SequenceEqual(new byte[]{0x23,0x00,0x40,0x42,0x0f,0,0,0,0,0}),"WRITE8 start 1 MHz");
        Check(LiteVnaProtocol.ReadFifo(64).SequenceEqual(new byte[]{0x18,0x30,64}),"READFIFO 64");
        Check(LiteVnaProtocol.Write2(LiteVnaProtocol.RegSweepPoints,201).SequenceEqual(new byte[]{0x21,0x20,201,0}),"WRITE2 points 201");
        var cfg=new LiteVnaProtocol.SweepConfig(1_000_000,30_000_000,201);
        Check(cfg.StepHz==145_000 && cfg.ActualStopHz==30_000_000,"step 145 kHz, stop 30 MHz");

        // FIFO record
        var rec=new byte[32];
        BitConverter.GetBytes(1000).CopyTo(rec,0); BitConverter.GetBytes(0).CopyTo(rec,4);
        BitConverter.GetBytes(-500).CopyTo(rec,8); BitConverter.GetBytes(250).CopyTo(rec,12);
        BitConverter.GetBytes(100).CopyTo(rec,16); BitConverter.GetBytes(-100).CopyTo(rec,20);
        BitConverter.GetBytes((ushort)7).CopyTo(rec,24);
        var v=LiteVnaProtocol.ParseRawValue(rec);
        Check(v.FrequencyIndex==7 && (v.S11()-new Complex(-0.5,0.25)).Magnitude<1e-15,"FIFO record decode");

        // sweep assembly: starts mid-sweep, an overtaking new sweep, completion from a single scan
        LiteVnaProtocol.RawValue R(int idx,int tag)=>new(1,0,tag,0,0,0,idx);
        var stream=new List<LiteVnaProtocol.RawValue>();
        for(int i=6;i<11;i++) stream.Add(R(i,1));
        for(int i=0;i<7;i++) stream.Add(R(i,2));
        for(int i=0;i<11;i++) stream.Add(R(i,3));
        var asm=new LiteVnaProtocol.SweepAssembler(11);
        foreach(var r in stream) if(asm.Feed(r)) break;
        var result=asm.Result();
        Check(result.All(r=>r.Rev0Re==3) && result.Select(r=>r.FrequencyIndex).SequenceEqual(Enumerable.Range(0,11)),"sweep assembly from one coherent scan");

        // OSL with a random error model
        var rnd=new Random(3); double worst=0;
        for(int t=0;t<2000;t++)
        {
            var ed=new Complex(rnd.NextDouble()*.4-.2,rnd.NextDouble()*.4-.2);
            var es=new Complex(rnd.NextDouble()*.6-.3,rnd.NextDouble()*.6-.3);
            var er=Complex.FromPolarCoordinates(.3+rnd.NextDouble()*1.2,rnd.NextDouble()*6-3);
            Complex M(Complex g)=>ed+er*g/(Complex.One-es*g);
            for(int k=0;k<5;k++)
            {
                var g=Complex.FromPolarCoordinates(rnd.NextDouble()*.99,rnd.NextDouble()*6.2-3.1);
                worst=Math.Max(worst,(VnaCalibration.CorrectS11(M(g),M(1),M(-1),M(0))-g).Magnitude);
            }
        }
        Check(worst<1e-12,$"OSL correction exact (max error {worst:E1})");

        // full one-path calibration with a synthetic six-term analyzer, linear in frequency
        {
            var r=new Random(11);
            Complex Rc(double m)=>new(r.NextDouble()*2*m-m,r.NextDouble()*2*m-m);
            Complex ed0=Rc(.2),ed1=Rc(.05),es0=Rc(.3),es1=Rc(.05),er0=Complex.FromPolarCoordinates(.8,.4),er1=Rc(.1),
                    ex0=Rc(.01),ex1=Rc(.002),et0=Complex.FromPolarCoordinates(.9,-.7),et1=Rc(.1),el0=Rc(.2),el1=Rc(.05);
            VnaErrorTerms T(double f){ double u=(f-1e6)/9e6; return new(f,ed0+ed1*u,es0+es1*u,er0+er1*u,ex0+ex1*u,et0+et1*u,el0+el1*u); }
            (Complex,Complex) Meas(double f,Complex s11,Complex s21,Complex s12,Complex s22)
            {
                var t=T(f); var d=s11*s22-s21*s12; var den=Complex.One-t.Es*s11-t.El*s22+t.Es*t.El*d;
                return (t.Ed+t.Er*(s11-t.El*d)/den,t.Ex+t.Et*s21/den);
            }
            VnaSweep Std(Func<double,(Complex,Complex)> m,int n)
                =>new VnaSweep{ Points=Enumerable.Range(0,n).Select(i=>{ double f=1e6+i*9e6/(n-1); var (a,b)=m(f); return new VnaPoint(f,a,b,true); }).ToList() };
            var cal=new VnaCalibration
            {
                Open=Std(f=>Meas(f,1,0,0,0),101), Short=Std(f=>Meas(f,-1,0,0,0),101),
                Load=Std(f=>Meas(f,0,0,0,0),101), Thru=Std(f=>Meas(f,0,1,1,0),101), Name="test", Comment="cable", PortExtensionPs=0,
                StartHz=1_000_000, StopHz=10_000_000, Points=101
            };
            Check(cal.IsComplete,"full calibration complete (4 standards)");
            var dut=Std(f=>Meas(f,Complex.FromPolarCoordinates(.5,f*1e-7),Complex.FromPolarCoordinates(2,-f*1e-7),0,0),101);
            var corr=cal.Apply(dut,false,out var mode);
            double w=0;
            for(int i=0;i<101;i++){ double f=dut.Points[i].FrequencyHz; w=Math.Max(w,(corr.Points[i].S11-Complex.FromPolarCoordinates(.5,f*1e-7)).Magnitude); w=Math.Max(w,(corr.Points[i].S21-Complex.FromPolarCoordinates(2,-f*1e-7)).Magnitude); }
            Check(mode==VnaCalibration.ApplyMode.Exact && w<1e-12,$"full calibration exact on the same grid (max error {w:E1})");
            var dut2=Std(f=>Meas(f,Complex.FromPolarCoordinates(.3,1),0,0,0),37);
            var corr2=cal.Apply(dut2,true,out var mode2);
            double w2=corr2.Points.Max(p=>(p.S11-Complex.FromPolarCoordinates(.3,1)).Magnitude);
            Check(mode2==VnaCalibration.ApplyMode.Interpolated && w2<1e-3,$"interpolated calibration on another grid (max error {w2:E1})");
            cal.Apply(dut2,false,out var mode3);
            Check(mode3==VnaCalibration.ApplyMode.None,"no interpolation unless allowed");
            string fc=Path.Combine(Path.GetTempPath(),"litevna_test.vnacal");
            cal.Save(fc); var back=VnaCalibration.LoadFile(fc);
            Check(back.IsComplete && back.Name=="test" && back.Comment=="cable" && back.Points==101 && back.StopHz==10_000_000,"calibration file round trip");
        }

        // Touchstone round trip
        var pts=Enumerable.Range(0,21).Select(i=>new VnaPoint(1e6+i*1e5,Complex.FromPolarCoordinates(.3+.01*i,.1*i),Complex.FromPolarCoordinates(.9,-.2*i),true)).ToList();
        var sweep=new VnaSweep{ Points=pts, Calibrated=true, Source="test" };
        string f1=Path.Combine(Path.GetTempPath(),"litevna_test.s1p"), f2=Path.Combine(Path.GetTempPath(),"litevna_test.s2p");
        File.WriteAllText(f1,TouchstoneFile.WriteS1p(sweep,new[]{"test"}));
        File.WriteAllText(f2,TouchstoneFile.WriteS2p(sweep,new[]{"test"}));
        var b1=TouchstoneFile.Read(f1); var b2=TouchstoneFile.Read(f2);
        Check(b1.Points.Count==21 && b1.Points.Zip(pts).All(z=>(z.First.S11-z.Second.S11).Magnitude<1e-10 && Math.Abs(z.First.FrequencyHz-z.Second.FrequencyHz)<1e-3),".s1p round trip");
        Check(b2.HasS21 && b2.Points.Zip(pts).All(z=>(z.First.S21-z.Second.S21).Magnitude<1e-10),".s2p round trip (S21)");

        // metrics
        var z50=VnaMath.Impedance(Complex.Zero,50);
        Check(Math.Abs(z50.Real-50)<1e-12 && Math.Abs(VnaMath.Swr(new Complex(1.0/3,0))-2)<1e-12,"Z(Γ=0)=50 Ω, SWR(|Γ|=1/3)=2");

        Console.WriteLine(_failed==0?"LiteVNA core: all checks passed":$"LiteVNA core: {_failed} failed");
        return _failed==0?0:1;
    }
}
