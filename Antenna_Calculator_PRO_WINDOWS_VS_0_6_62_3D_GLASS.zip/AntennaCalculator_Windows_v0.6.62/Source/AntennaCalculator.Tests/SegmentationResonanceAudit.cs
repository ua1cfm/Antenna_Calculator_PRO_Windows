﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AntennaCalculator.Core;

internal static class SegmentationResonanceAudit
{
    static MaaWire Wire(int id,double x1,double y1,double z1,double x2,double y2,double z2,double r,int n)
        =>new(id,x1,y1,z1,x2,y2,z2,r,n);
    static MaaModel Fixture(string geometry,int g,double r,int segments)
    {
        const double length=0.7, d=0.03;
        double z=g==1?0.15:0;
        var wires=geometry switch
        {
            "PARALLEL"=>new[]{Wire(1,0,0,z,0,0,z+length,r,segments),Wire(2,d,0,z,d,0,z+length,r,segments)},
            "ANGLED_45"=>new[]{Wire(1,0,0,z,0,0,z+length,r,segments),Wire(2,d,0,z,d+length/Math.Sqrt(2),0,z+length/Math.Sqrt(2),r,segments)},
            "CONNECTED_45"=>new[]{Wire(1,0,0,z,0,0,z+length,r,segments),Wire(2,0,0,z+length,length/Math.Sqrt(2),0,z+length+length/Math.Sqrt(2),r,segments)},
            _=>throw new ArgumentException(geometry)
        };
        return new MaaModel {Title=geometry,FilePath=geometry,FrequencyMHz=28.5,Wires=wires,
            Sources=new[]{new MaaSource(1,'c',0,0,1,"w1c,0,1")},Loads=Array.Empty<MaaLoad>(),Warnings=Array.Empty<string>(),
            GroundType=g,ReferenceOhms=50,SegmentationRecord="800,80,1.1,16"};
    }
    static void Convergence()
    {
        Console.WriteLine("SEGMENTATION CONVERGENCE v0.3.36: positive wire tags force actual physical segmentation");
        Console.WriteLine("fields: geometry ground radius nPerWire pulses expectedPhysicalSegments Zin residual matrixAsym trueSegmentLength/diameter");
        foreach(var shape in new[]{"PARALLEL","ANGLED_45","CONNECTED_45"})
        foreach(var g in new[]{0,1})
        foreach(var r in new[]{0.001,0.005})
        foreach(var n in new[]{10,20,40,80})
        {
            try
            {
                var m=Fixture(shape,g,r,n);
                MininecPulseSolver.MutualPairAudit? audit=null;
                var result=MininecPulseSolver.Solve(m,mutualPairObserver:x=>audit=x);
                int physical=n*m.Wires.Count;
                Console.WriteLine($"GRID {shape} G={g} radius={r:G4} segPerWire={n} physicalSegments={physical} totalPulses={result.PulseCount} " +
                    $"Z={result.ROhm:G12}+j({result.XOhm:G12}) residual={result.RelativeResidual:E4} asym={audit?.TransposeRelative:E7} " +
                    $"segLen/diam={(0.7/n)/(2*r):G6} " + (result.PulseCount!=(g==0?(shape=="CONNECTED_45"?physical-1:physical-2):(shape=="CONNECTED_45"?2*(physical-1):2*(physical-2)))?"CHECK_PULSE_COUNT":"OK"));
            }
            catch(Exception ex) { Console.WriteLine($"GRID {shape} G={g} radius={r:G4} n={n} FAILED {ex.GetType().Name}: {ex.Message}"); }
        }
    }
    static void HairpinFrequency()
    {
        var input=MaaParser.ParseFile(Path.Combine(AppContext.BaseDirectory,"Samples","hairpin monopol.maa"));
        Console.WriteLine("HAIRPIN FREQUENCY SWEEP v0.3.36 (original loads, source and geometry unchanged)");
        Console.WriteLine("NOTE: feed capacitor reactance and distributed currents both change with frequency; reference segmentation held fixed at 28.5 MHz");
        Console.WriteLine("fMHz ROhm XOhm SWR50 pulses residual");
        var fs=Enumerable.Range(0,25).Select(i=>23.0+i*0.5).ToArray();
        var values=new List<(double f,double r,double x,double swr)>();
        foreach(double f in fs)
        {
            try
            {
                var v=MininecPulseSolver.Solve(input,frequencyMHzOverride:f,segmentationReferenceMHz:28.5);
                values.Add((f,v.ROhm,v.XOhm,v.Swr(50)));
                Console.WriteLine($"SWEEP {f:F3} {v.ROhm:G12} {v.XOhm:G12} {v.Swr(50):G11} {v.PulseCount} {v.RelativeResidual:E4}");
            }
            catch(Exception ex) {Console.WriteLine($"SWEEP {f:F3} FAILED {ex.GetType().Name}: {ex.Message}");}
        }
        for(int i=1;i<values.Count;i++)
        {
            var a=values[i-1];var b=values[i];
            if(a.x==0||b.x==0||Math.Sign(a.x)!=Math.Sign(b.x))
            {
                double x0=a.x==b.x?a.f:a.f+(b.f-a.f)*(-a.x)/(b.x-a.x);
                Console.WriteLine($"X_ZERO_BRACKET f=[{a.f:G6},{b.f:G6}] MHz linearEstimate={x0:G9} MHz (INTERPOLATION ONLY)");
            }
        }
        if(values.Count>0)
        {
            var min=values.Where(x=>double.IsFinite(x.swr)).OrderBy(x=>x.swr).FirstOrDefault();
            Console.WriteLine($"MIN_SWR_GRID f={min.f:G8} SWR={min.swr:G11} R={min.r:G10} X={min.x:G10}");
        }
        Console.WriteLine("REFERENCE MMANA at 28.5 MHz R=39.284 X=-231.814; frequency of MMANA resonance is UNKNOWN: compare full MMANA frequency sweep before attributing error to detuning.");
    }
    public static void Run(string[] args)
    {
        bool convergence=args.Contains("--segmentation-convergence");
        bool sweep=args.Contains("--hairpin-frequency-sweep");
        if(convergence)Convergence();
        if(sweep)HairpinFrequency();
    }
}
