# v0.3.60.1

Исправлены два синтаксических дефекта `if/else` в `MainWindow.xaml.cs` (бывшие строки 287 и 336). Вызовы `SmithView.SetReferenceOhms`, `SetPoint`, `SetTrace` помещены в блоки `{ ... }`. Формулы, Smith Chart, Z-buffer и остальные исходники не менялись.

Компиляция под Windows/.NET в среде подготовки не выполнялась.
