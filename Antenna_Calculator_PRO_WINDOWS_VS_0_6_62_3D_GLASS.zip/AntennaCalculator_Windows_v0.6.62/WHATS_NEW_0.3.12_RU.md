Версия 0.3.12: исправлены CS8131 и CS8506 в FieldMapView.cs, метод HsvToRgb. Другие функции не изменены. Требуется сборка в Visual Studio.
