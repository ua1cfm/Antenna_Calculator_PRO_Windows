# 0.6.35.1 — CUDA 13.4 / Visual Studio 2026

В `Cuda/BUILD_CUDA_FIELD_WIN64.bat` добавлен параметр MSVC `/Zc:preprocessor` для корректной компиляции CCCL/Thrust в CUDA 13.4. CUDA-ядро E/H/S, формулы импеданса и визуализация не изменялись.

Откройте x64 Developer Command Prompt и выполните `Cuda\BUILD_CUDA_FIELD_WIN64.bat`, затем пересоберите WPF Release x64.

Проверка ограничена анализом исходного кода: CUDA-компилятор под Windows здесь недоступен.
