@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Hairpin resonance audit 28.40..29.60 MHz, capacitor sensitivity. This may take several minutes.
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-high-resolution > "HAIRPIN_HIGH_RESOLUTION_REPORT.txt" 2>&1
if errorlevel 1 (
  echo ERROR: build or calculation failed. See HAIRPIN_HIGH_RESOLUTION_REPORT.txt
) else (
  echo Done: HAIRPIN_HIGH_RESOLUTION_REPORT.txt
)
pause
