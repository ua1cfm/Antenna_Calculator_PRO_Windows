# v0.6.0 — Make Stack MMANA core integration

Fixed the exact routing bug: compact Make Stack models were rejected by `MmanaReferenceEngine.SolveText` and silently computed by a different approximate MININEC engine. Now wires, excitation pulses and capacitor loads are cloned by MaaParser and passed to the MMANA-reference engine before segmentation. With the supplied model: 24 wires, 2 sources, 2 C=94 pF loads. C reactance at 21.25 MHz = -79.68 ohms **at each load**, not at feed.

The matrix for real earth (G=2) in this reference engine still uses MMANA's perfect-ground current approximation. No numerical agreement with user's MMANA-GAL output can be claimed until Windows build/run. Do not change impedance by fitting to the target. On failure core may still fall back to existing MININEC in batch/UI; errors need monitoring. No Visual Studio/.NET runtime available here to execute measurements.
