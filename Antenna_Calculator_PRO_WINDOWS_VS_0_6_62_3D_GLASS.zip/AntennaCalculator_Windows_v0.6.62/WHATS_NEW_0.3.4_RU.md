# Antenna Calculator PRO Windows 0.3.4 — C# Access Fix

Дата: 14.10.2026. Основа: экспериментальная версия 0.3.3 LARGE MATRIX GMRES.

## Исправлено

В 0.3.3 проект `AntennaCalculator.Wpf` вызывал `MininecSegmentation.Parse`, хотя тип `MininecSegmentation` был объявлен `internal` внутри другой сборки `AntennaCalculator.Core`. Поэтому Visual Studio сообщала: **«MininecSegmentation недоступен из-за его уровня защиты» (CS0122)**.

Изменения в `Source/AntennaCalculator.Core/MininecSegmentation.cs`:

- `internal static class MininecSegmentation` → `public static class MininecSegmentation`;
- `internal readonly record struct Parameters` → `public readonly record struct Parameters`;
- `internal static Parameters Parse(...)` → `public static Parameters Parse(...)`.

Вспомогательные методы сегментации и `Span` оставлены `internal`: их не требуется раскрывать интерфейсу. Код GMRES, электромагнитная матрица, сегментация и физические алгоритмы **не изменялись**.

## Проверка в Visual Studio

1. Распакуйте архив в **новую** папку, например `C:\AntennaCalculator_Windows_v0.3.4`.
2. Откройте `AntennaCalculator.Windows.sln`.
3. `Сборка` → `Пересобрать решение` (Rebuild Solution).
4. Нажмите F5 **только после успешной компиляции**. На вопрос «Запустить последний успешный вариант?» отвечайте **Нет**.
5. Альтернатива: запустите `VERIFY_ACCESS_FIX_WINDOWS.bat`. Он собирает ядро и WPF, затем запускает тесты.

Если возникнут другие сообщения, сохраните **полный список ошибок** из `View → Error List`, выбрав фильтр `Build`.

## Статус

Сделаны статический анализ видимости C#-типов, проверка изменений и целостности ZIP. Среда без .NET SDK: фактическая сборка Visual Studio и прогон GMRES **не подтверждены**.

Режим G=2 по-прежнему является только явным PEC-приближением входного импеданса: потери реального грунта в матрице не учитываются.
