@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Starting legacy three-stage audit...
call RUN_ALL_THREE_STAGES_WINDOWS.bat
echo Starting UI parity audit...
call 04_UI_FIELD_PARITY_WINDOWS.bat
