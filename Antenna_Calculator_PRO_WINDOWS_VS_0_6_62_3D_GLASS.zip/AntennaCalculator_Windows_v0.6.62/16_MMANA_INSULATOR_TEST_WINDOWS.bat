@echo off
setlocal
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -- --mmana-insulator-fixture > "MMANA_INSULATOR_REPORT.txt" 2>&1
type "MMANA_INSULATOR_REPORT.txt"
pause
