# v0.6.44 — 2D near-field section geometry and zoom

- XZ/YZ and XY sections now sample the same transverse plane as the overlaid antenna, instead of an undisclosed offset >= 0.6 lambda.
- Wheel zoom works in all 2D field planes, resampling field phasors rather than enlarging bitmap pixels.
- Existing far-field 3D radiation pattern, solver, source currents and phases are untouched.
- Near-field fringes are not a far-field directional diagram and must not be compared pixel-for-pixel with the 3D DN. Ground reflections in the 2D approximate short-current-element near-field solver remain an open fidelity limitation.

## Testing
Static source and XML checks, archive CRC. Windows compile / physical numerical validation require local Visual Studio.
