@echo off
rem CUDA 13.x multi-GPU fatbin: Turing, Ampere, Ada, Hopper, Blackwell.
rem PTX compute_75 provides JIT forward compatibility where supported.
rem Environment CUDA_GENCODE may override the default list.
if defined CUDA_GENCODE exit /b 0
set "CUDA_GENCODE=-gencode=arch=compute_75,code=sm_75 -gencode=arch=compute_80,code=sm_80 -gencode=arch=compute_86,code=sm_86 -gencode=arch=compute_89,code=sm_89 -gencode=arch=compute_90,code=sm_90 -gencode=arch=compute_100,code=sm_100 -gencode=arch=compute_120,code=sm_120 -gencode=arch=compute_75,code=compute_75"
exit /b 0
