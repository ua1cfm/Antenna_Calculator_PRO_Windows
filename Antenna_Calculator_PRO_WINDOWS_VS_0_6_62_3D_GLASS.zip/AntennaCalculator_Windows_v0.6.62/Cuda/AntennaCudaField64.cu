#include <cuda_runtime.h>
#include <thrust/complex.h>
#include <cmath>
using C = thrust::complex<double>;
struct Sample { double x,y,z,dx,dy,dz,ir,ii; };
__global__ void field_kernel(const Sample* sm,int count,double k,double lambda,int n,double cx,double cy,double cz,double span,double* out,int first,int last) {
 int i=first+blockIdx.x*blockDim.x+threadIdx.x; if(i>=last)return;
 int ix=i%n,iy=(i/n)%n,iz=i/(n*n);
 double x=cx+((double)ix/(n-1)-0.5)*span,y=cy+((double)iy/(n-1)-0.5)*span,z=cz+((double)iz/(n-1)-0.5)*span;
 C ex(0,0),ey(0,0),ez(0,0),hx(0,0),hy(0,0),hz(0,0); const C J(0,1);
 for(int a=0;a<count;a++) {
  Sample t=sm[a];double rx=x-t.x,ry=y-t.y,rz=z-t.z;
  double seg=sqrt(t.dx*t.dx+t.dy*t.dy+t.dz*t.dz);
  double cut=fmax(1e-6*lambda,0.25*seg);
  double r=fmax(sqrt(rx*rx+ry*ry+rz*rz),cut),ux=rx/r,uy=ry/r,uz=rz/r;
  double ud=ux*t.dx+uy*t.dy+uz*t.dz;
  C q=C(0,-1)/(k*r),ft=C(1,0)+q+q*q,fr=2.0*(q+q*q);
  C g=C(t.ir,t.ii)*thrust::exp(C(0,-k*r))/(4.0*3.14159265358979323846*r);
  C ef=C(0,-376.730313668*k)*g;
  ex+=ef*((t.dx-ux*ud)*ft+ux*ud*fr);
  ey+=ef*((t.dy-uy*ud)*ft+uy*ud*fr);
  ez+=ef*((t.dz-uz*ud)*ft+uz*ud*fr);
  C hf=C(0,-k)*g*(C(1,0)+q);
  hx+=hf*(uy*t.dz-uz*t.dy);hy+=hf*(uz*t.dx-ux*t.dz);hz+=hf*(ux*t.dy-uy*t.dx);
 }
 C e[6]={ex,ey,ez,hx,hy,hz};
 for(int j=0;j<6;j++){out[(size_t)i*13+2*j]=e[j].real();out[(size_t)i*13+2*j+1]=e[j].imag();}
 double sx=0.5*(ey*thrust::conj(hz)-ez*thrust::conj(hy)).real();
 double sy=0.5*(ez*thrust::conj(hx)-ex*thrust::conj(hz)).real();
 double sz=0.5*(ex*thrust::conj(hy)-ey*thrust::conj(hx)).real();
 double dx=x-cx,dy=y-cy,dz=z-cz,norm=sqrt(dx*dx+dy*dy+dz*dz);
 out[(size_t)i*13+12]=norm>1e-12?fmax(0.,(sx*dx+sy*dy+sz*dz)/norm):0.;
}
extern "C" __declspec(dllexport) int __cdecl antenna_field_sample(const double* raw,int count,double frequency,int n,double cx,double cy,double cz,double span,double* output){
 if(!raw||!output||count<1||count>200000||frequency<=0||n<16||n>256||span<=0)return -1;
 int devices=0;if(cudaGetDeviceCount(&devices)!=cudaSuccess||devices<1)return -2;
 Sample *ds=nullptr;double *do_=nullptr;size_t nb=(size_t)count*sizeof(Sample),ob=(size_t)n*n*n*13*sizeof(double);
 cudaError_t er=cudaMalloc((void**)&ds,nb);if(er!=cudaSuccess)return -3;
 er=cudaMalloc((void**)&do_,ob);if(er!=cudaSuccess){cudaFree(ds);return -4;}
 er=cudaMemcpy(ds,raw,nb,cudaMemcpyHostToDevice);
 if(er==cudaSuccess){
   // Work is split into launches of about 1e8 voxel×segment interactions each: a single launch over the
   // whole 192³ grid in double precision can exceed the Windows display-driver timeout (TDR, ~2 s).
   double lam=299.792458/frequency;int total=n*n*n;
   long long chunk=100000000LL/(count>0?count:1); if(chunk<4096)chunk=4096; if(chunk>total)chunk=total;
   for(long long first=0;first<total && er==cudaSuccess;first+=chunk){
     int last=(int)((first+chunk<total)?first+chunk:total), len=last-(int)first;
     field_kernel<<<(len+127)/128,128>>>(ds,count,2*3.14159265358979323846/lam,lam,n,cx,cy,cz,span,do_,(int)first,last);
     er=cudaGetLastError();
     if(er==cudaSuccess)er=cudaDeviceSynchronize();
   }
 }
 if(er==cudaSuccess)er=cudaMemcpy(output,do_,ob,cudaMemcpyDeviceToHost);
 cudaFree(do_);cudaFree(ds);return er==cudaSuccess?0:(int)er;
}


// ---------------------------------------------------------------------------------------------------------------
// 0.6.47: same kernel as NearFieldKernel.Add (C#). Samples: x,y,z,dx,dy,dz,ir,ii,flags (flags bit 2 = grounded pulse).
// G = 2: image samples (z < 0) are weighted by the ground-reflection operator of the 3D pattern (MININEC v89/h89,
// Fresnel coefficients of εr, σ) for the direction from the image to the observation point. G = 0/1: as is.
struct SampleEx { double x,y,z,dx,dy,dz,ir,ii,flags; };
__device__ void add_sample(const SampleEx& t,double x,double y,double z,double k,double lambda,int ground,C er,
                           C& ex,C& ey,C& ez,C& hx,C& hy,C& hz){
  C cur(t.ir,t.ii);
  double rx=x-t.x,ry=y-t.y,rz=z-t.z,dist=sqrt(rx*rx+ry*ry+rz*rz);
  bool image=ground!=0 && t.z<-1e-9, grounded=(((int)t.flags)&2)!=0;
  C mx,my,mz;
  if(image && ground==2 && !grounded && dist>0){
    double dxr=-t.dx,dyr=-t.dy,dzr=t.dz,nx=rx/dist,ny=ry/dist,nz=rz/dist;
    double rho=sqrt(nx*nx+ny*ny),ct=fmin(1.0,fmax(0.0,nz));
    C one(1,0),z45=one/thrust::sqrt(er),w67=thrust::sqrt(one-z45*z45*(rho*rho));
    C v89=(ct-w67*z45)/(ct+w67*z45), h89=(w67-z45*ct)/(w67+z45*ct)-v89;
    double phi=atan2(ny,nx),px=-sin(phi),py=cos(phi),d=px*dxr+py*dyr;
    mx=-cur*(v89*dxr+h89*(d*px)); my=-cur*(v89*dyr+h89*(d*py)); mz=cur*v89*dzr;
  } else { mx=cur*t.dx; my=cur*t.dy; mz=cur*t.dz; }
  double seg=sqrt(t.dx*t.dx+t.dy*t.dy+t.dz*t.dz);
  double r=fmax(dist,fmax(1e-6*lambda,0.25*seg)),ux=rx/r,uy=ry/r,uz=rz/r;
  C um=ux*mx+uy*my+uz*mz;
  C q=C(0,-1)/(k*r),ft=C(1,0)+q+q*q,fr=2.0*(q+q*q);
  C g=thrust::exp(C(0,-k*r))/(4.0*3.14159265358979323846*r);
  C ef=C(0,-376.730313668*k)*g;
  ex+=ef*((mx-ux*um)*ft+ux*um*fr); ey+=ef*((my-uy*um)*ft+uy*um*fr); ez+=ef*((mz-uz*um)*ft+uz*um*fr);
  C hf=C(0,-k)*g*(C(1,0)+q);
  hx+=hf*(uy*mz-uz*my); hy+=hf*(uz*mx-ux*mz); hz+=hf*(ux*my-uy*mx);
}
__global__ void field_kernel_ex(const SampleEx* sm,int count,double k,double lambda,int n,double cx,double cy,double cz,double span,
                                int ground,double erRe,double erIm,double* out,int first,int last){
  int i=first+blockIdx.x*blockDim.x+threadIdx.x; if(i>=last)return;
  int ix=i%n,iy=(i/n)%n,iz=i/(n*n);
  double x=cx+((double)ix/(n-1)-0.5)*span,y=cy+((double)iy/(n-1)-0.5)*span,z=cz+((double)iz/(n-1)-0.5)*span;
  C ex(0,0),ey(0,0),ez(0,0),hx(0,0),hy(0,0),hz(0,0); C er(erRe,erIm);
  for(int a=0;a<count;a++) add_sample(sm[a],x,y,z,k,lambda,ground,er,ex,ey,ez,hx,hy,hz);
  C e[6]={ex,ey,ez,hx,hy,hz};
  for(int j=0;j<6;j++){out[(size_t)i*13+2*j]=e[j].real();out[(size_t)i*13+2*j+1]=e[j].imag();}
  double sx=0.5*(ey*thrust::conj(hz)-ez*thrust::conj(hy)).real();
  double sy=0.5*(ez*thrust::conj(hx)-ex*thrust::conj(hz)).real();
  double sz=0.5*(ex*thrust::conj(hy)-ey*thrust::conj(hx)).real();
  double dx=x-cx,dy=y-cy,dz=z-cz,norm=sqrt(dx*dx+dy*dy+dz*dz);
  out[(size_t)i*13+12]=norm>1e-12?fmax(0.,(sx*dx+sy*dy+sz*dz)/norm):0.;
}
extern "C" __declspec(dllexport) int __cdecl antenna_field_sample_ex(const double* raw,int count,double frequency,int n,
    double cx,double cy,double cz,double span,int ground,double epsR,double sigma,double* output){
 if(!raw||!output||count<1||count>200000||frequency<=0||n<16||n>256||span<=0)return -1;
 int devices=0;if(cudaGetDeviceCount(&devices)!=cudaSuccess||devices<1)return -2;
 SampleEx *ds=nullptr;double *do_=nullptr;size_t nb=(size_t)count*sizeof(SampleEx),ob=(size_t)n*n*n*13*sizeof(double);
 cudaError_t er=cudaMalloc((void**)&ds,nb);if(er!=cudaSuccess)return -3;
 er=cudaMalloc((void**)&do_,ob);if(er!=cudaSuccess){cudaFree(ds);return -4;}
 er=cudaMemcpy(ds,raw,nb,cudaMemcpyHostToDevice);
 double erIm=-sigma/(2*3.14159265358979323846*frequency*1e6*8.8541878128e-12);
 if(er==cudaSuccess){
   double lam=299.792458/frequency;int total=n*n*n;
   long long chunk=60000000LL/(count>0?count:1); if(chunk<4096)chunk=4096; if(chunk>total)chunk=total;   // no TDR timeout
   for(long long first=0;first<total && er==cudaSuccess;first+=chunk){
     int last=(int)((first+chunk<total)?first+chunk:total),len=last-(int)first;
     field_kernel_ex<<<(len+127)/128,128>>>(ds,count,2*3.14159265358979323846/lam,lam,n,cx,cy,cz,span,ground,epsR,erIm,do_,(int)first,last);
     er=cudaGetLastError(); if(er==cudaSuccess)er=cudaDeviceSynchronize();
   }
 }
 if(er==cudaSuccess)er=cudaMemcpy(output,do_,ob,cudaMemcpyDeviceToHost);
 cudaFree(do_);cudaFree(ds);return er==cudaSuccess?0:(int)er;
}
