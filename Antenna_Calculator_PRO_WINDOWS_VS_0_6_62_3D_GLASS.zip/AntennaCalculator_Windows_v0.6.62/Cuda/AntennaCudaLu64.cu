// Optional FP32 complex LU for the MMANA impedance matrix via NVIDIA cuSOLVER.
// Persistent state: one cuSOLVER handle and device buffers are kept between calls and released by
// antenna_cuda_lu_release() (called once when the program exits).
//
// antenna_cuda_lu_factor(n, a): a = interleaved (re, im) ROW-major n×n matrix A. Row-major A is column-major Aᵀ,
//   so the buffer is copied unchanged and Aᵀ is factored (Cgetrf); no transposed host copy is needed.
// antenna_cuda_lu_solve_factored(n, b, x): solves A·x = b with the stored factors: Cgetrs with op = T,
//   because (Aᵀ)ᵀ = A. Used repeatedly by the caller for iterative refinement.
// Return codes: 0 success; negative invalid arguments / not factored; positive CUDA or cuSOLVER failures.
#include <cuda_runtime.h>
#include <cusolverDn.h>
#include <cuComplex.h>
#include <cstddef>

static cusolverDnHandle_t g_handle = nullptr;
static cuFloatComplex* g_a = nullptr;      // factors of Aᵀ
static cuFloatComplex* g_b = nullptr;      // right-hand side / solution
static cuFloatComplex* g_work = nullptr;
static int* g_pivots = nullptr;
static int* g_info = nullptr;
static int g_capacity = 0;                 // allocated n
static int g_workSize = 0;                 // allocated workspace (elements)
static int g_factoredN = 0;                // 0 = no valid factors

static void free_buffers()
{
    if (g_work) cudaFree(g_work);
    if (g_info) cudaFree(g_info);
    if (g_pivots) cudaFree(g_pivots);
    if (g_b) cudaFree(g_b);
    if (g_a) cudaFree(g_a);
    g_work = nullptr; g_info = nullptr; g_pivots = nullptr; g_b = nullptr; g_a = nullptr;
    g_capacity = 0; g_workSize = 0; g_factoredN = 0;
}

extern "C" __declspec(dllexport) void __cdecl antenna_cuda_lu_release()
{
    free_buffers();
    if (g_handle) { cusolverDnDestroy(g_handle); g_handle = nullptr; }
}

extern "C" __declspec(dllexport) int __cdecl antenna_cuda_lu_factor(int n, const float* a)
{
    if (n < 1 || n > 16000 || !a) return -1;
    g_factoredN = 0;
    if (!g_handle)
    {
        int devices = 0;
        if (cudaGetDeviceCount(&devices) != cudaSuccess || devices < 1) return 1;
        if (cusolverDnCreate(&g_handle) != CUSOLVER_STATUS_SUCCESS) { g_handle = nullptr; return 2; }
    }
    const size_t elements = size_t(n) * size_t(n);
    if (n > g_capacity)
    {
        free_buffers();
        if (cudaMalloc(reinterpret_cast<void**>(&g_a), elements * sizeof(cuFloatComplex)) != cudaSuccess ||
            cudaMalloc(reinterpret_cast<void**>(&g_b), size_t(n) * sizeof(cuFloatComplex)) != cudaSuccess ||
            cudaMalloc(reinterpret_cast<void**>(&g_pivots), size_t(n) * sizeof(int)) != cudaSuccess ||
            cudaMalloc(reinterpret_cast<void**>(&g_info), sizeof(int)) != cudaSuccess)
        { free_buffers(); return 3; }
        g_capacity = n;
    }
    // cuFloatComplex is {float x, y}: the interleaved host buffer has exactly this layout.
    if (cudaMemcpy(g_a, a, elements * sizeof(cuFloatComplex), cudaMemcpyHostToDevice) != cudaSuccess) return 4;
    int work = 0;
    if (cusolverDnCgetrf_bufferSize(g_handle, n, n, g_a, n, &work) != CUSOLVER_STATUS_SUCCESS || work < 1) return 5;
    if (work > g_workSize)
    {
        if (g_work) { cudaFree(g_work); g_work = nullptr; g_workSize = 0; }
        if (cudaMalloc(reinterpret_cast<void**>(&g_work), size_t(work) * sizeof(cuFloatComplex)) != cudaSuccess) return 6;
        g_workSize = work;
    }
    if (cusolverDnCgetrf(g_handle, n, n, g_a, n, g_work, g_pivots, g_info) != CUSOLVER_STATUS_SUCCESS) return 7;
    int info = 0;
    if (cudaMemcpy(&info, g_info, sizeof(int), cudaMemcpyDeviceToHost) != cudaSuccess) return 8;
    if (info != 0) return 9;        // singular U(i,i) = 0
    g_factoredN = n;
    return 0;
}

extern "C" __declspec(dllexport) int __cdecl antenna_cuda_lu_solve_factored(int n, const float* b, float* x)
{
    if (!b || !x) return -1;
    if (!g_handle || g_factoredN != n) return -2;
    if (cudaMemcpy(g_b, b, size_t(n) * sizeof(cuFloatComplex), cudaMemcpyHostToDevice) != cudaSuccess) return 10;
    if (cusolverDnCgetrs(g_handle, CUBLAS_OP_T, n, 1, g_a, n, g_pivots, g_b, n, g_info) != CUSOLVER_STATUS_SUCCESS) return 11;
    int info = 0;
    if (cudaMemcpy(&info, g_info, sizeof(int), cudaMemcpyDeviceToHost) != cudaSuccess || info != 0) return 12;
    if (cudaMemcpy(x, g_b, size_t(n) * sizeof(cuFloatComplex), cudaMemcpyDeviceToHost) != cudaSuccess) return 13;
    return 0;
}
