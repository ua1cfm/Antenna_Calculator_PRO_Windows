@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
where nvcc >nul 2>nul
if errorlevel 1 (echo ERROR: nvcc not found & exit /b 1)
where cl >nul 2>nul
if errorlevel 1 (echo ERROR: use x64 Native Tools Command Prompt & exit /b 1)
if not exist bin mkdir bin
call "%~dp0CUDA_ARCH_FLAGS.bat"
echo Building CUDA multi-architecture module...
nvcc -m64 -O3 -std=c++17 %CUDA_GENCODE% -shared -Xcompiler "/MD /EHsc /Zc:preprocessor" -o "bin\AntennaCudaField64.dll" AntennaCudaField64.cu -lcudart
if errorlevel 1 (echo ERROR: Field kernel build failed & exit /b 1)
echo CUDA FIELD BUILD OK: bin\AntennaCudaField64.dll
