@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Antenna Calculator PRO - Build All CUDA x64

rem Multi-architecture CUDA 13.x build. No particular GPU is required on build PC.
call "%~dp0CUDA_ARCH_FLAGS.bat"

echo ==========================================================
echo  Antenna Calculator PRO - ALL 4 CUDA DLLs
 echo  Architectures: sm_75/80/86/89/90/100/120 plus PTX compute_75
echo ==========================================================
where nvcc >nul 2>nul
if errorlevel 1 goto NO_NVCC
where cl >nul 2>nul
if errorlevel 1 goto NO_CL
if not exist "bin" mkdir "bin"

call :BUILD "Matrix/Vector" "BUILD_CUDA_WIN64.bat" "AntennaCuda64.dll"
if errorlevel 1 goto FAILED
call :BUILD "GPU LU / cuSOLVER" "BUILD_CUDA_LU_WIN64.bat" "AntennaCudaLu64.dll"
if errorlevel 1 goto FAILED
call :BUILD "CUDA Volume" "BUILD_CUDA_VOLUME_WIN64.bat" "AntennaCudaVolume64.dll"
if errorlevel 1 goto FAILED
call :BUILD "CUDA Field E/H/S" "BUILD_CUDA_FIELD_WIN64.bat" "AntennaCudaField64.dll"
if errorlevel 1 goto FAILED

echo.
echo ==========================================================
echo  SUCCESS: all 4 CUDA DLLs built
 echo ==========================================================
dir /b "bin\AntennaCuda64.dll" "bin\AntennaCudaLu64.dll" "bin\AntennaCudaVolume64.dll" "bin\AntennaCudaField64.dll"
echo.
echo Next: Visual Studio - Release / x64 - Rebuild Solution.
pause
exit /b 0

:BUILD
echo.
echo ----------------------------------------------------------
echo BUILD: %~1
 echo Script: %~2
 echo Output: %~3
echo ----------------------------------------------------------
if not exist "%~2" (
  echo ERROR: missing build script "%~2"
  exit /b 1
)
rem Remove stale DLL: prevents a previous successful build from masking a failure.
if exist "bin\%~3" (
  del /q "bin\%~3"
  if exist "bin\%~3" (
    echo ERROR: cannot remove stale "bin\%~3". Close the app and retry.
    exit /b 1
  )
)
call "%~2"
if errorlevel 1 (
  echo ERROR: %~1 build script failed.
  exit /b 1
)
if not exist "bin\%~3" (
  echo ERROR: expected DLL "bin\%~3" is missing.
  exit /b 1
)
echo OK: %~3
exit /b 0

:NO_NVCC
echo ERROR: nvcc not found. Install / initialize CUDA Toolkit.
goto FAILED
:NO_CL
echo ERROR: cl.exe not found. Run in x64 Native Tools Command Prompt.
goto FAILED
:FAILED
echo.
echo BUILD FAILED. Review the last error above.
pause
exit /b 1
