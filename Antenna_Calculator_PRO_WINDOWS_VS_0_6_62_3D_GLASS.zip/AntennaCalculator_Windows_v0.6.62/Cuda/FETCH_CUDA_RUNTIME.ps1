<#
  Fallback when no CUDA Toolkit is installed on the build machine: downloads NVIDIA's official
  redistributable wheels from PyPI (win_amd64) and extracts the DLLs into Cuda\bin\runtime.
  The CUDA major version MUST match the toolkit that built AntennaCudaLu64.dll (see bin\runtime\CUDA_VERSION.txt).
  Usage:  powershell -ExecutionPolicy Bypass -File FETCH_CUDA_RUNTIME.ps1 -CudaMajor 12
          powershell -ExecutionPolicy Bypass -File FETCH_CUDA_RUNTIME.ps1 -CudaMajor 13
  Package names on PyPI: CUDA 12 — nvidia-*-cu12; CUDA 13 — nvidia-*-cu13 (override with -Packages if NVIDIA renames them).
#>
param(
  [ValidateSet(12,13)][int]$CudaMajor = 12,
  [string[]]$Packages
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$out  = Join-Path $here 'bin\runtime'
New-Item -ItemType Directory -Force -Path $out | Out-Null
if (-not $Packages) {
  $s = "cu$CudaMajor"
  $Packages = @("nvidia-cusolver-$s","nvidia-cublas-$s","nvidia-cusparse-$s","nvidia-nvjitlink-$s","nvidia-cuda-runtime-$s")
}
$tmp = Join-Path $env:TEMP ("antcalc_cuda_" + [guid]::NewGuid())
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem
foreach ($p in $Packages) {
  Write-Host "PyPI: $p"
  $meta = Invoke-RestMethod "https://pypi.org/pypi/$p/json"
  $wheel = $meta.urls | Where-Object { $_.filename -like '*win_amd64.whl' } | Select-Object -First 1
  if (-not $wheel) { throw "No Windows x64 wheel for $p ($($meta.info.version))" }
  $file = Join-Path $tmp $wheel.filename
  Invoke-WebRequest $wheel.url -OutFile $file
  $zip = [System.IO.Compression.ZipFile]::OpenRead($file)
  try {
    foreach ($e in $zip.Entries | Where-Object { $_.Name -like '*.dll' }) {
      $dst = Join-Path $out $e.Name
      [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dst, $true)
      Write-Host "  $($e.Name)"
    }
  } finally { $zip.Dispose() }
}
"PyPI wheels, CUDA $CudaMajor (versions: see wheel names above)" | Set-Content (Join-Path $out 'CUDA_VERSION.txt')
Remove-Item -Recurse -Force $tmp
Write-Host "Done: $out. Rebuild the solution; the DLLs are copied next to the EXE."
