#include <cuda_runtime.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static thread_local char g_lastCudaError[256] = "none";
static void capture_cuda_error(const char* stage, cudaError_t err) {
    snprintf(g_lastCudaError, sizeof(g_lastCudaError), "%s: cudaError_t=%d (%s)", stage, (int)err, cudaGetErrorString(err));
}
extern "C" __declspec(dllexport) const char* __cdecl antenna_cuda_last_error() { return g_lastCudaError; }

// The native renderer is a completely optional visualization backend.
// Input is a variable n^3 scalar field normalised by P96 on the managed side.
struct Vec { float x,y,z; };
__device__ __forceinline__ Vec add(Vec a, Vec b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
__device__ __forceinline__ Vec scale(Vec a,float t){return {a.x*t,a.y*t,a.z*t};}
__device__ __forceinline__ float sample(const float* v,int n,Vec p){
    float xx=(p.x+1.f)*.5f*(n-1), yy=(p.y+1.f)*.5f*(n-1), zz=(p.z+1.f)*.5f*(n-1);
    int i=max(0,min(n-2,(int)floorf(xx))),j=max(0,min(n-2,(int)floorf(yy))),k=max(0,min(n-2,(int)floorf(zz)));
    float u=xx-i,w=zz-k,t=yy-j;
    int o=k*n*n+j*n+i;
    float c00=v[o]*(1-u)+v[o+1]*u;
    float c10=v[o+n]*(1-u)+v[o+n+1]*u;
    float c01=v[o+n*n]*(1-u)+v[o+n*n+1]*u;
    float c11=v[o+n*n+n]*(1-u)+v[o+n*n+n+1]*u;
    return (c00*(1-t)+c10*t)*(1-w)+(c01*(1-t)+c11*t)*w;
}
__device__ __forceinline__ bool slab(float o,float d,float &a,float &b){
    if(fabsf(d)<1e-8f)return fabsf(o)<1.f;
    float t0=(-1.f-o)/d,t1=(1.f-o)/d;
    if(t0>t1){float tmp=t0;t0=t1;t1=tmp;}
    a=fmaxf(a,t0);b=fminf(b,t1);return b>a;
}
// Rainbow palette of the 3D radiation pattern: hue = (1 - t)*270 deg, full saturation and brightness
// (violet -> blue -> cyan -> green -> yellow -> orange -> red). Identical to FieldVolumeView.Rainbow (CPU, legend).
__device__ __forceinline__ void palette(float t,float &r,float &g,float &b){
    float h=(1.f-fminf(1.f,fmaxf(0.f,t)))*270.f;
    float x=1.f-fabsf(fmodf(h/60.f,2.f)-1.f);
    r=0.f;g=0.f;b=0.f;
    if(h<60.f){r=1.f;g=x;} else if(h<120.f){r=x;g=1.f;}
    else if(h<180.f){g=1.f;b=x;} else if(h<240.f){g=x;b=1.f;}
    else {r=x;b=1.f;}
    r*=255.f; g*=255.f; b*=255.f;
}
// Palette of the glass shells (as in 0.6.53): nine vivid stops, identical to FieldVolumeView.Vivid.
__device__ __forceinline__ void palette_vivid(float t,float &r,float &g,float &b){
    const float cr[]={8.f,16.f,5.f,0.f,0.f,30.f,255.f,255.f,220.f};
    const float cg[]={10.f,55.f,130.f,220.f,235.f,255.f,238.f,135.f,24.f};
    const float cb[]={85.f,230.f,255.f,255.f,80.f,0.f,0.f,0.f,30.f};
    float q=fminf(1.f,fmaxf(0.f,t))*8.f;
    int i=min(7,(int)q);float a=q-i;
    r=cr[i]+a*(cr[i+1]-cr[i]);g=cg[i]+a*(cg[i+1]-cg[i]);b=cb[i]+a*(cb[i+1]-cb[i]);
}
// Rendering style (identical formulas in FieldVolumeView.RenderVolume, the CPU fallback).
struct Style { int mode; int db; float dbFactor; float density; float gradRef; float inv; };
#define DB_RANGE 30.0f
#define REFERENCE_STEP (2.0f/128.0f)
__device__ __forceinline__ float smoothstep_(float a,float b,float x){ if(x<=a)return 0.f; if(x>=b)return 1.f; x=(x-a)/(b-a); return x*x*(3.f-2.f*x); }
__device__ __forceinline__ float to_scale(float rel,const Style& st){
    if(!st.db) return fminf(1.f,fmaxf(0.f,rel));
    float db=st.dbFactor*log10f(fmaxf(rel,1e-12f));
    return fminf(1.f,fmaxf(0.f,(db+DB_RANGE)/DB_RANGE));
}
__device__ __forceinline__ float opacity_at(float c,const Style& st){
    if(st.mode==1){
        float s=smoothstep_(st.db?0.40f:0.12f,1.f,c);
        return (st.db?0.16f:0.10f)*st.density*powf(s,st.db?2.2f:1.6f);
    }
    if(st.mode==3) return 0.30f*st.density*smoothstep_(0.05f,0.25f,c)*(0.3f+0.7f*c);   // glass: strong field denser
    const float lvDb[3]={1.f/3.f,2.f/3.f,0.9f}, lvLin[3]={0.20f,0.45f,0.80f}, strength[3]={0.16f,0.34f,0.70f};
    float a=0.f;
    for(int i=0;i<3;i++){ float d=(c-(st.db?lvDb[i]:lvLin[i]))/0.03f; a=fmaxf(a,strength[i]*st.density*expf(-d*d)); }
    return a;
}
// Rays start on the VIEWER side (dir points from the scene towards the viewer) and go front to back.
__global__ void march2(const float* volume,int n,float az,float el,float zoom,int size,int steps,Style st,uchar4* out){
    int ix=blockIdx.x*blockDim.x+threadIdx.x,iy=blockIdx.y*blockDim.y+threadIdx.y;
    if(ix>=size||iy>=size)return;
    float ca=cosf(az),sa=sinf(az),ce=cosf(el),se=sinf(el);
    Vec right={ca,-sa,0.f},up={sa*se,ca*se,ce},dir={-sa*ce,-ca*ce,se};
    float sc=2.45f/zoom;
    float a=((ix+.5f)/size-.5f)*sc,b=(.5f-(iy+.5f)/size)*sc;
    Vec pos=add(scale(right,a),scale(up,b));
    float t0=-1e10f,t1=1e10f;
    if(!slab(pos.x,dir.x,t0,t1)||!slab(pos.y,dir.y,t0,t1)||!slab(pos.z,dir.z,t0,t1)||t1<=t0){
        out[iy*size+ix]=make_uchar4(0,0,0,255);return;
    }
    float dt=(t1-t0)/steps, stepFactor=dt/REFERENCE_STEP, h=2.f/(n-1);
    float rr=0,gg=0,bb=0,alpha=0,best=0,bestDepth=0,lum=0;
    for(int s=0;s<steps;s++){
        float t=t1-(s+.5f)*dt;
        Vec p=add(pos,scale(dir,t));
        float rel=sample(volume,n,p)*st.inv;
        if(rel<=0.f)continue;
        float c=to_scale(rel,st), depth=(s+.5f)/steps;
        if(st.mode==2){ if(c>best){best=c;bestDepth=depth;} continue; }
        if(st.mode==1 && c>best) best=c;                         // volume: colour of the ray maximum (as MIP)
        float aRef=opacity_at(c,st);
        if(aRef<1e-5f)continue;
        float opa=1.f-powf(1.f-fminf(aRef,.999f),stepFactor);
        Vec px={fminf(1.f,p.x+h),p.y,p.z}, mx={fmaxf(-1.f,p.x-h),p.y,p.z};
        Vec py={p.x,fminf(1.f,p.y+h),p.z}, my={p.x,fmaxf(-1.f,p.y-h),p.z};
        Vec pz={p.x,p.y,fminf(1.f,p.z+h)}, mz={p.x,p.y,fmaxf(-1.f,p.z-h)};
        float gx=sample(volume,n,px)-sample(volume,n,mx), gy=sample(volume,n,py)-sample(volume,n,my), gz=sample(volume,n,pz)-sample(volume,n,mz);
        gx*=st.inv; gy*=st.inv; gz*=st.inv;
        float gl=sqrtf(gx*gx+gy*gy+gz*gz);
        float facing=gl>1e-12f?fabsf((gx*dir.x+gy*dir.y+gz*dir.z)/gl):1.f;
        if(st.mode==0) opa*=0.10f+0.90f*(1.f-facing)*(1.f-facing);
        else if(st.mode==3){ float e=1.f-facing; opa*=fminf(1.f,gl/st.gradRef)*(0.03f+0.97f*e*e*e); }   // glass
        else if(st.db) opa*=0.35f+0.65f*fminf(1.f,gl/st.gradRef);
        float w=(1.f-alpha)*opa; if(w<=0.f)continue;
        if(st.mode==1){ lum+=w*(1.f-0.25f*depth); alpha+=w; continue; }   // no early exit: maximum may lie further
        float r,g,bl, light;
        if(st.mode==3){ palette(c,r,g,bl); light=(0.75f+0.25f*facing)*(1.f-0.25f*depth); }        // glass: rainbow, soft light
        else { palette_vivid(c,r,g,bl); light=(0.45f+0.55f*facing)*(1.f-0.55f*depth); }          // shells as in 0.6.53
        rr+=w*r*light; gg+=w*g*light; bb+=w*bl*light; alpha+=w;
        if(alpha>.995f)break;
    }
    if(st.mode==1){
        if(best<=0.02f){out[iy*size+ix]=make_uchar4(0,0,0,255);return;}
        float bright=(0.40f+0.60f*powf(fminf(1.f,lum),0.6f))*smoothstep_(0.02f,0.15f,best);
        float r,g,bl; palette(best,r,g,bl);
        rr=r*bright; gg=g*bright; bb=bl*bright;
    }
    if(st.mode==2){
        if(best<=0.02f){out[iy*size+ix]=make_uchar4(0,0,0,255);return;}
        float r,g,bl; palette(best,r,g,bl); float light=1.f-0.35f*bestDepth;
        rr=r*light; gg=g*light; bb=bl*light;
    }
    out[iy*size+ix]=make_uchar4((unsigned char)fminf(255.f,bb),(unsigned char)fminf(255.f,gg),(unsigned char)fminf(255.f,rr),255);
}

// Persistent device buffers: the volume is uploaded only when its revision (or size) changes.
static float* g_volume=nullptr; static int g_n=0; static int g_revision=-2147483647;
static uchar4* g_pixels=nullptr; static size_t g_pixelBytes=0;
static int ensure_buffers(const float* input,int n,int revision,int size){
    size_t nv=(size_t)n*n*n*sizeof(float), ni=(size_t)size*size*sizeof(uchar4);
    cudaError_t err;
    if(n!=g_n){
        if(g_volume){cudaFree(g_volume);g_volume=nullptr;}
        err=cudaMalloc((void**)&g_volume,nv); if(err!=cudaSuccess){g_n=0;capture_cuda_error("cudaMalloc(volume)",err);return -3;}
        g_n=n; g_revision=-2147483647;
    }
    if(ni>g_pixelBytes){
        if(g_pixels){cudaFree(g_pixels);g_pixels=nullptr;g_pixelBytes=0;}
        err=cudaMalloc((void**)&g_pixels,ni); if(err!=cudaSuccess){capture_cuda_error("cudaMalloc(pixels)",err);return -4;}
        g_pixelBytes=ni;
    }
    if(revision<0 || revision!=g_revision){
        err=cudaMemcpy(g_volume,input,nv,cudaMemcpyHostToDevice);
        if(err!=cudaSuccess){g_revision=-2147483647;capture_cuda_error("cudaMemcpy(H2D)",err);return -5;}
        g_revision=revision;
    }
    return 0;
}
static int render_common(const float* input,int n,int revision,float az,float el,float zoom,int size,int steps,Style st,unsigned char* output){
    if(!input||!output||n<16||n>256||size<32||size>2048||steps<8||steps>2048||st.mode<0||st.mode>3)return -1;
    strcpy(g_lastCudaError,"none");
    int count=0; cudaError_t init=cudaGetDeviceCount(&count);
    if(init!=cudaSuccess){capture_cuda_error("cudaGetDeviceCount",init);return -2;}
    if(count<1){strcpy(g_lastCudaError,"No CUDA GPUs found");return -2;}
    int e=ensure_buffers(input,n,revision,size); if(e!=0)return e;
    dim3 block(16,16),grid((size+15)/16,(size+15)/16);
    march2<<<grid,block>>>(g_volume,n,az,el,zoom,size,steps,st,g_pixels);
    cudaError_t err=cudaGetLastError();
    if(err!=cudaSuccess){capture_cuda_error("cudaGetLastError(kernel launch)",err);return -6;}
    err=cudaDeviceSynchronize();
    if(err!=cudaSuccess){capture_cuda_error("cudaDeviceSynchronize(kernel)",err);return -7;}
    err=cudaMemcpy(output,g_pixels,(size_t)size*size*sizeof(uchar4),cudaMemcpyDeviceToHost);
    if(err!=cudaSuccess){capture_cuda_error("cudaMemcpy(D2H)",err);return -8;}
    return 0;
}
// 0.6.39 API. input = field / P96 (already normalised), revision identifies the volume contents.
extern "C" __declspec(dllexport) int __cdecl antenna_volume_render_ex(const float* input,int n,int revision,float az,float el,float zoom,
    int size,int steps,int mode,int db,float dbFactor,float density,float gradRef,unsigned char* output){
    Style st{mode,db,dbFactor>0?dbFactor:20.f,density>0?density:1.f,gradRef>0?gradRef:1.f,1.f};
    return render_common(input,n,revision,az,el,zoom,size,steps,st,output);
}
// Compatibility with 0.6.23–0.6.38 callers: volume style, linear scale, corrected ray order.
extern "C" __declspec(dllexport) int __cdecl antenna_volume_render(const float* input,int n,float reference,float az,float el,float zoom,int size,int steps,unsigned char* output){
    if(!(reference>0))return -1;
    Style st{1,0,20.f,1.f,1.f,1.f/reference};
    return render_common(input,n,-1,az,el,zoom,size,steps,st,output);
}
extern "C" __declspec(dllexport) void __cdecl antenna_volume_release(){
    if(g_pixels){cudaFree(g_pixels);g_pixels=nullptr;g_pixelBytes=0;}
    if(g_volume){cudaFree(g_volume);g_volume=nullptr;g_n=0;g_revision=-2147483647;}
}

// Returns CUDA runtime error string for the last error on the calling host thread.
extern "C" __declspec(dllexport) const char* __cdecl antenna_cuda_error_string(int errorCode){
    // Negative application stage code; details require stage-specific log or cudaGetLastError.
    switch(errorCode){
        case -1:return "invalid renderer arguments";
        case -2:return "no CUDA GPU or driver initialization failed";
        case -3:return "CUDA volume allocation failed";
        case -4:return "CUDA pixel allocation failed";
        case -5:return "volume upload (host to device) failed";
        case -6:return "CUDA kernel launch failed: check GPU architecture and nvcc flags";
        case -7:return "CUDA kernel execution/synchronization failed";
        case -8:return "CUDA download (device to host) failed";
        default:return "unknown CUDA renderer error";
    }
}

// Colour-scheme revision of the kernel (0.6.55: rainbow palette of the 3D pattern). The C# wrapper uses the GPU only
// when this export exists and is at least 655; otherwise it renders on the CPU with the same palette.
extern "C" __declspec(dllexport) int __cdecl antenna_volume_style_version(){ return 657; }
