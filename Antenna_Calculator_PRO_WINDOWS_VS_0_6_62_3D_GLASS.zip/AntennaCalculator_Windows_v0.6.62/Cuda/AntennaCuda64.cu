// Optional CUDA FP64 backend for dense MININEC matrix-vector products.
// Original code. Requires CUDA Toolkit with cuBLAS. All arrays row-major on host.
#include <cuda_runtime.h>
#include <cublas_v2.h>
#include <cuComplex.h>
#include <vector>
#include <new>
#include <cstdint>
#include <cmath>

struct Context {
    int n;
    cuDoubleComplex* dA = nullptr;
    cuDoubleComplex* dx = nullptr;
    cuDoubleComplex* dy = nullptr;
    cublasHandle_t handle = nullptr;
};

static void release(Context* c) {
    if (!c) return;
    if (c->dy) cudaFree(c->dy);
    if (c->dx) cudaFree(c->dx);
    if (c->dA) cudaFree(c->dA);
    if (c->handle) cublasDestroy(c->handle);
    delete c;
}

extern "C" __declspec(dllexport) void __cdecl antenna_cuda_destroy(void* p) {
    release(static_cast<Context*>(p));
}

extern "C" __declspec(dllexport) void* __cdecl antenna_cuda_create(
    int n, const double* real, const double* imag) {
    if (n <= 0 || n > 20000 || !real || !imag) return nullptr;
    int devices = 0;
    if (cudaGetDeviceCount(&devices) != cudaSuccess || devices < 1) return nullptr;
    Context* c = nullptr;
    try { c = new Context{}; } catch (...) { return nullptr; }
    c->n = n;
    if (cublasCreate(&c->handle) != CUBLAS_STATUS_SUCCESS) { release(c); return nullptr; }
    const size_t count = size_t(n)*size_t(n);
    if (cudaMalloc(reinterpret_cast<void**>(&c->dA),count*sizeof(cuDoubleComplex))!=cudaSuccess ||
        cudaMalloc(reinterpret_cast<void**>(&c->dx),size_t(n)*sizeof(cuDoubleComplex))!=cudaSuccess ||
        cudaMalloc(reinterpret_cast<void**>(&c->dy),size_t(n)*sizeof(cuDoubleComplex))!=cudaSuccess) {
        release(c); return nullptr;
    }
    // cuBLAS column-major; transpose layout once on host when uploading.
    try {
        std::vector<cuDoubleComplex> block(size_t(n)*size_t(64));
        for (int col=0;col<n;col+=64) {
            const int width = (n-col<64 ? n-col : 64);
            for (int j=0;j<width;j++)
                for (int row=0;row<n;row++) {
                    const size_t host = size_t(row)*size_t(n)+size_t(col+j);
                    block[size_t(j)*size_t(n)+size_t(row)] = make_cuDoubleComplex(real[host],imag[host]);
                }
            if (cudaMemcpy(c->dA+size_t(col)*size_t(n), block.data(),
                size_t(n)*size_t(width)*sizeof(cuDoubleComplex),cudaMemcpyHostToDevice)!=cudaSuccess) {
                release(c); return nullptr;
            }
        }
    } catch (...) {release(c);return nullptr;}
    return c;
}

extern "C" __declspec(dllexport) int __cdecl antenna_cuda_matvec(
    void* ptr,const double* input,const int n,double* output) {
    Context* c=static_cast<Context*>(ptr);
    if(!c || !input || !output || n!=c->n) return 0;
    const size_t bytes=size_t(n)*sizeof(cuDoubleComplex);
    if(cudaMemcpy(c->dx,input,bytes,cudaMemcpyHostToDevice)!=cudaSuccess)return 0;
    const cuDoubleComplex alpha=make_cuDoubleComplex(1.0,0.0);
    const cuDoubleComplex beta=make_cuDoubleComplex(0.0,0.0);
    if(cublasZgemv(c->handle,CUBLAS_OP_N,n,n,&alpha,c->dA,n,c->dx,1,&beta,c->dy,1)!=CUBLAS_STATUS_SUCCESS)return 0;
    if(cudaMemcpy(output,c->dy,bytes,cudaMemcpyDeviceToHost)!=cudaSuccess)return 0;
    return 1;
}
