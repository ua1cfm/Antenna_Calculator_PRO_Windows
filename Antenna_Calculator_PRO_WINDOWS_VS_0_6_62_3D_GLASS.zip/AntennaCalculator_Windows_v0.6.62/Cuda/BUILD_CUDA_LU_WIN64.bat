@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo === MMANA GPU LU (cuSOLVER) - CUDA x64 runtime bundling v0.6.31 ===
where nvcc >nul 2>nul || (echo ERROR: nvcc not found & exit /b 1)
where cl >nul 2>nul || (echo ERROR: run x64 Native Tools Command Prompt & exit /b 1)
if not defined CUDA_PATH (echo ERROR: CUDA_PATH is not set & exit /b 1)
if not exist "bin" mkdir "bin"
if not exist "bin\runtime" mkdir "bin\runtime"
set "CUDA_DLL_BIN=%CUDA_PATH%\bin\x64"
if not exist "%CUDA_DLL_BIN%\" (echo ERROR: CUDA x64 folder not found: "%CUDA_DLL_BIN%" & exit /b 1)
echo CUDA x64 DLL source: "%CUDA_DLL_BIN%"
echo === Compiling AntennaCudaLu64.dll ===
call "%~dp0CUDA_ARCH_FLAGS.bat"
echo Building CUDA multi-architecture module...
nvcc -m64 -std=c++17 -O3 %CUDA_GENCODE% -shared -cudart static -Xcompiler "/MD /EHsc" -o "bin\AntennaCudaLu64.dll" "AntennaCudaLu64.cu" -lcusolver -lcublas
if errorlevel 1 (echo ERROR: Compilation failed & exit /b 1)
echo BUILD OK: bin\AntennaCudaLu64.dll
echo === Enumerating exact DLL filenames and copying ===
call :CopyFamily "cusolver64_*.dll" required
if errorlevel 1 exit /b 1
call :CopyFamily "cublas64_*.dll" required
if errorlevel 1 exit /b 1
call :CopyFamily "cublasLt64_*.dll" optional
if errorlevel 1 exit /b 1
call :CopyFamily "cusparse64_*.dll" optional
if errorlevel 1 exit /b 1
call :CopyFamily "nvJitLink*.dll" optional
if errorlevel 1 exit /b 1
call :CopyFamily "cudart64_*.dll" optional
if errorlevel 1 exit /b 1
echo === Copied CUDA DLLs ===
dir /b "bin\runtime\*.dll"
where dumpbin >nul 2>nul
if not errorlevel 1 (
  echo === Imported DLL names of AntennaCudaLu64.dll ===
  dumpbin /nologo /dependents "bin\AntennaCudaLu64.dll" | findstr /i "cusolver cublas cusparse nvjitlink cudart"
)
echo CUDA LU RUNTIME BUNDLE OK
nvcc --version | findstr /i "release" > "bin\runtime\CUDA_VERSION.txt"
echo Rebuild WPF Release x64 to copy CUDA DLLs to the EXE directory.
exit /b 0

:CopyFamily
rem FOR /F reads actual filenames returned by DIR; never iterate bare wildcard patterns.
set "FAMILY=%~1"
set "REQUIRED=%~2"
set /a FILE_COUNT=0
for /f "delims=" %%F in ('dir /b /a-d "%CUDA_DLL_BIN%\%FAMILY%" 2^>nul') do (
  echo Copying %%F
  copy /y "%CUDA_DLL_BIN%\%%F" "bin\runtime\%%F" >nul
  if errorlevel 1 (echo ERROR: failed copying %%F & exit /b 1)
  set /a FILE_COUNT+=1 >nul
)
if %FILE_COUNT% EQU 0 (
  if /i "%REQUIRED%"=="required" (
    echo ERROR: missing required %FAMILY% in "%CUDA_DLL_BIN%"
    exit /b 1
  )
  echo NOTE: optional %FAMILY% not found
) else (
  echo OK: %FAMILY% - %FILE_COUNT% files copied
)
exit /b 0
