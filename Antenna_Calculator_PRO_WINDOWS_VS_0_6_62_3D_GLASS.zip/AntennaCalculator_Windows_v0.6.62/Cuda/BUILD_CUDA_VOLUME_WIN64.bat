@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
where nvcc >nul 2>nul
if errorlevel 1 (echo ERROR: CUDA Toolkit nvcc not found. & pause & exit /b 1)
where cl >nul 2>nul
if errorlevel 1 (echo ERROR: Use x64 Native Tools Command Prompt for VS. & pause & exit /b 1)
if not exist bin mkdir bin
call "%~dp0CUDA_ARCH_FLAGS.bat"
echo Building CUDA multi-architecture module...
nvcc -m64 -O3 -std=c++17 %CUDA_GENCODE% -shared -Xcompiler "/MD /EHsc" -o "bin\AntennaCudaVolume64.dll" AntennaCudaVolume64.cu -lcudart
if errorlevel 1 (echo CUDA BUILD FAILED & pause & exit /b 1)
echo CUDA VOLUME BUILD OK: bin\AntennaCudaVolume64.dll
where dumpbin >nul 2>nul
if not errorlevel 1 (
 dumpbin /nologo /exports "bin\AntennaCudaVolume64.dll" | findstr /c:"antenna_volume_render_ex" >nul
 if errorlevel 1 (echo ERROR: export antenna_volume_render_ex is missing & pause & exit /b 1)
 echo Export antenna_volume_render_ex: OK
)
if not exist "bin\runtime" mkdir "bin\runtime"
rem dir /b gives the exact DLL names (a mask inside quotes is not expanded reliably by FOR).
if defined CUDA_PATH (
 for %%D in ("%CUDA_PATH%\bin" "%CUDA_PATH%\bin\x64") do (
  for /f "delims=" %%F in ('dir /b /a-d "%%~D\cudart64_*.dll" 2^>nul') do copy /y "%%~D\%%F" "bin\runtime\" >nul && echo   runtime: %%F
 )
)
echo Rebuild WPF Release x64. Check CUDA status on EM view.
pause
