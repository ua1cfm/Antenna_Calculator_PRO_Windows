@echo off
setlocal
cd /d "%~dp0"
echo Antenna Calculator CUDA backend build for NVIDIA RTX 50 (Blackwell, sm_120)
where nvcc >nul 2>nul
if errorlevel 1 (
  echo ERROR: nvcc missing from PATH.
  goto :failed
)
where cl >nul 2>nul
if errorlevel 1 (
  echo ERROR: MSVC cl.exe missing. Use x64 Native Tools or Developer Command Prompt.
  goto :failed
)
if not exist bin mkdir bin
call "%~dp0CUDA_ARCH_FLAGS.bat"
echo Building CUDA multi-architecture module...
nvcc -m64 %CUDA_GENCODE% -std=c++17 -O3 -shared -Xcompiler "/MD /EHsc" -o "bin\AntennaCuda64.dll" "AntennaCuda64.cu" -lcublas -lcudart
if errorlevel 1 goto :failed
echo.
echo SUCCESS: %~dp0bin\AntennaCuda64.dll
exit /b 0
:failed
echo.
echo CUDA DLL BUILD FAILED, exit code %errorlevel%
exit /b 1
