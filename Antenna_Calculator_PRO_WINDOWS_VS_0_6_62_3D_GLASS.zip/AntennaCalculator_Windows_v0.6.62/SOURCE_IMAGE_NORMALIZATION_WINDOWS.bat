@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --source-image-normalization > "SOURCE_IMAGE_NORMALIZATION_REPORT.txt" 2>&1
if errorlevel 1 (echo TEST/BUILD FAILED. See SOURCE_IMAGE_NORMALIZATION_REPORT.txt) else (echo Done: SOURCE_IMAGE_NORMALIZATION_REPORT.txt)
pause
