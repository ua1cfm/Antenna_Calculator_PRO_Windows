@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --three-stage-basis > "01_CURRENT_BASIS_REPORT.txt" 2>&1
if errorlevel 1 (echo BUILD/TEST FAILED: 01_CURRENT_BASIS_REPORT.txt) else (echo TEST COMPLETE: 01_CURRENT_BASIS_REPORT.txt)
pause
