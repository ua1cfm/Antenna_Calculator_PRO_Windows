@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --source-power-reconciliation > "SOURCE_POWER_RECONCILIATION_REPORT.txt" 2>&1
if errorlevel 1 (echo BUILD/TEST FAILED. See SOURCE_POWER_RECONCILIATION_REPORT.txt) else (echo Done: SOURCE_POWER_RECONCILIATION_REPORT.txt)
pause
