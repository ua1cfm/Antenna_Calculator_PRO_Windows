@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-actual-spans > "HAIRPIN_ACTUAL_SPANS_REPORT.txt" 2>&1
if errorlevel 1 (echo TEST FAILED or geometry/solver rejection. See HAIRPIN_ACTUAL_SPANS_REPORT.txt) else (echo TEST COMPLETE. See HAIRPIN_ACTUAL_SPANS_REPORT.txt)
pause
