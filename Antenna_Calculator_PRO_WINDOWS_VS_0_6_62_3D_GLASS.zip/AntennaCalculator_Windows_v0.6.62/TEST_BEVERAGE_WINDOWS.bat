@echo off
setlocal
cd /d "%~dp0"
echo =======================================================
echo BEVERAGE PEC-APPROX ONLY (NOT REAL GROUND IMPEDANCE)
echo This test may take many minutes and a lot of CPU/RAM.
echo The main application Stop button is NOT available here.
echo Close this console / Ctrl+C to stop the test.
echo =======================================================
choice /C YN /M "Run the full example Beverage test"
if errorlevel 2 exit /b 0
set "LOG=%~dp0WINDOWS_BEVERAGE_TEST_0.3.7.txt"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" --configuration Release -- --beverage-preview > "%LOG%" 2>&1
echo.
type "%LOG%"
echo.
echo Saved to "%LOG%"
pause
endlocal
