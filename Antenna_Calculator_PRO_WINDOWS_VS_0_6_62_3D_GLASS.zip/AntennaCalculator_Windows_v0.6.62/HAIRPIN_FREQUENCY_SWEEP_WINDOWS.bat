@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Running --hairpin-frequency-sweep ...
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-frequency-sweep > "HAIRPIN_FREQUENCY_SWEEP_REPORT.txt" 2>&1
type "HAIRPIN_FREQUENCY_SWEEP_REPORT.txt"
echo.
echo Report: HAIRPIN_FREQUENCY_SWEEP_REPORT.txt
pause
