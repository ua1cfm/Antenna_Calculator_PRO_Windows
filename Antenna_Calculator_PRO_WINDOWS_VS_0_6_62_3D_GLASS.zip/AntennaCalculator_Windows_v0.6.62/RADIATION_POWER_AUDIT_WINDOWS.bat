@echo off
setlocal
cd /d "%~dp0"
set DOTNET_CLI_TELEMETRY_OPTOUT=1
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" --configuration Release -- --radiation-power-audit > "RADIATION_POWER_AUDIT_REPORT.txt" 2>&1
type "RADIATION_POWER_AUDIT_REPORT.txt"
echo.
echo Report: RADIATION_POWER_AUDIT_REPORT.txt
pause
