@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --three-stage-all > "RUN_ALL_THREE_STAGES_REPORT.txt" 2>&1
if errorlevel 1 (echo BUILD/TEST FAILED: RUN_ALL_THREE_STAGES_REPORT.txt) else (echo TEST COMPLETE: RUN_ALL_THREE_STAGES_REPORT.txt)
pause
