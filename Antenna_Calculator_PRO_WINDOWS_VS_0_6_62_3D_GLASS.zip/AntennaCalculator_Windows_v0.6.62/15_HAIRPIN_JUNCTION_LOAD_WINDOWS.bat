@echo off
setlocal
cd /d "%~dp0"
set "REPORT=%~dp0HAIRPIN_JUNCTION_LOAD_REPORT.txt"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-junction-load > "%REPORT%" 2>&1
set "RESULT=%ERRORLEVEL%"
type "%REPORT%"
echo.
echo Report: %REPORT%
echo Exit code: %RESULT%
pause
exit /b %RESULT%
