# v0.3.75 — LU / FGMRES comparison fixture

Добавлен контрольный монополь PEC с 201 геометрическими сегментами (`fixture_PEC_monopole_401.maa`). По схеме импульсов этого решателя ожидается 401 импульс; фактическое `n` всегда печатается из снимка матрицы.

Никакой подстановки измеренного импеданса нет. Исходная геометрия и источник копируются из `fixture_PEC_monopole.maa`, меняется только число сегментов 21→201. Это **контроль вычислительного решателя**, не эталон физической точности MININEC или MMANA.

Запуск из корня: `RUN_LU_FGMRES_401.bat` либо

```powershell
dotnet run --project .\Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj -c Release -- --mmana-matrix-parity --model ".\Samples\fixture_PEC_monopole_401.maa" --export-dir ".\parity_output_401"
```

Сравнить `LU residual`, `FGMRES residual`, `current delta` в `parity_output_401/results.txt`. Если FGMRES упадёт, тест запишет `FGMRES failed` и вернёт ошибку, не будет считать его успешным. Для оценки физической точности требуется независимый расчёт MMANA.
