# Windows 0.4.11 — экспорт геометрии в CST Studio Suite 2026 и Fairbeam

Основа: 0.4.10.

Кнопка «Экспорт геометрии ▾» теперь открывает меню:
- CSV — таблица проводов (как раньше);
- CST Studio Suite 2026 — макрос .bas;
- Fairbeam — дизайн .design.json.

Форматы — как у конвертера UA1CFM «MAA → CST Studio Suite 2026 / Fairbeam» v0.3.1
(github.com/ua1cfm/MAA_to_CST_STUDIO_BAS_converter):
- координаты и радиусы: метры MAA → мм; частоты: МГц → ГГц; диапазон f0·(1 ± 5 %);
- CST: единицы mm / GHz, Solver.FrequencyRange, частотный решатель, для каждого проводника
  Polygon3D + Wire (CurveWire, материал PEC) в папке maa_wires; существующая геометрия не удаляется;
- Fairbeam: schema fairbeam.design/1, wire-примитивы в мм, материал copper (metal), boundaries MUR,
  end_criteria_db −40, mesh auto 20 ячеек на длину волны, far field на рабочей частоте,
  ports и resistors пустые.

Только геометрия: источники, нагрузки, земля, потери и сегментация MMANA не переносятся.

Отличие от внешнего конвертера: комбинированные (ступенчатые) провода с отрицательным радиусом не
отвергаются, а разбиваются на отрезки с настоящими радиусами функцией CombWire из ядра MMANA
(MmanaReferenceEngine.ExpandCombWires). Пример: 3EL20 → 15 проводников, радиусы 10/12,5/15/12,5/10 мм.
Провода с радиусом 0 (изоляторы MMANA) не экспортируются. Комбинированные провода вместе с Make Stack —
пока сообщение об ошибке.

Расчёт и CUDA не менялись.
