# v0.3.79.1 — CUDA build fix RTX 5070

Исправлено в Cuda/BUILD_CUDA_WIN64.bat: nvcc -m64 -arch=sm_120 (Blackwell RTX 5070); проверка наличия cl.exe и nvcc.exe, чёткий код ошибки.

В Cuda/AntennaCuda64.cu заменено `new(std::nothrow) Context{}` на обычное исключение-безопасное выделение в try/catch. Заголовок `<new>` уже был в предыдущей версии — ошибка не была вызвана его отсутствием.

Собирать в **x64 Native Tools Command Prompt for VS 2026** из корня проекта командой `Cuda\BUILD_CUDA_WIN64.bat`.

CUDA Toolkit и GPU в среде подготовки отсутствуют, сборка DLL на Windows не проверена. Ядро MININEC и C# не менялись. Исходная версия 0.3.79 сохраняется отдельно.
