# 0.6.32 — исправление ошибки копирования AntennaCuda64.dll

Исправлена безусловная ссылка на отсутствующую `Cuda\bin\AntennaCuda64.dll` в `Source/AntennaCalculator.Wpf/AntennaCalculator.Wpf.csproj`. Эта библиотека — отдельный модуль матрично-векторных операций (`CudaDenseMatVec`), не GPU LU (`AntennaCudaLu64.dll`) и не CUDA-рендер (`AntennaCudaVolume64.dll`). Теперь WPF копирует её только если она реально собрана.

Для полного комплекта CUDA запустите в **x64 Native Tools Command Prompt** все соответствующие сценарии:

```bat
cd /d "C:\Users\ua1cf\source\repos\AntennaCalculator_Windows_v0.6.32\Cuda"
BUILD_CUDA_LU_WIN64.bat
BUILD_CUDA_VOLUME_WIN64.bat
BUILD_CUDA_WIN64.bat
```

После этого пересоберите Visual Studio Release / x64. Если `BUILD_CUDA_WIN64.bat` не выполнен, проект теперь всё равно может собраться и использовать CPU-резерв для CUDA matvec.

Предупреждения о неиспользуемых полях `MmanaReferenceEngine.FLG/S/X` и возможной null-ссылке не являются причиной MSBuild-ошибки копирования, их следует разбирать отдельно по файлу/строке.

Примечание: ZIP проверен на структуру и XML; компиляция на Windows с CUDA не выполнялась в данной среде.
