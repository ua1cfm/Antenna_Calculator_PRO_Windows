# v0.5.8 — VNA protocol selection (experimental)

Добавлены AUTO, LiteVNA64 (V2 binary), NanoVNA V2 (V2 binary), NanoVNA H/H4 (text shell).
AUTO последовательно пытается V2 и NanoVNA Shell по ответу прибора. Для NanoVNA Shell используется `scan start stop points 7`, проверяются количество точек и диапазон частот. На некоторых прошивках команда может отсутствовать; тогда будет показана ошибка без подмены измерений. Совместимость и калибровка должны проверяться физическим прибором.

MININEC/MMANA, CUDA и визуализация поля не изменены.
