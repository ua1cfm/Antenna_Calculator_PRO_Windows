@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --three-stage-regression > "03_HAIRPIN_REGRESSION_REPORT.txt" 2>&1
if errorlevel 1 (echo BUILD/TEST FAILED: 03_HAIRPIN_REGRESSION_REPORT.txt) else (echo TEST COMPLETE: 03_HAIRPIN_REGRESSION_REPORT.txt)
pause
