@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-sensitivity > "HAIRPIN_MATRIX_SENSITIVITY_REPORT.txt" 2>&1
if errorlevel 1 (echo FAILED. Check HAIRPIN_MATRIX_SENSITIVITY_REPORT.txt) else (echo COMPLETE. Check HAIRPIN_MATRIX_SENSITIVITY_REPORT.txt)
pause
