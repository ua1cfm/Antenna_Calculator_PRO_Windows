@echo off
setlocal
cd /d "%~dp0"
set "REPORT=%~dp0HAIRPIN_FULL_COEFFICIENT_REPORT.txt"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-full-coefficient > "%REPORT%" 2>&1
type "%REPORT%"
echo.
echo Report: %REPORT%
pause
