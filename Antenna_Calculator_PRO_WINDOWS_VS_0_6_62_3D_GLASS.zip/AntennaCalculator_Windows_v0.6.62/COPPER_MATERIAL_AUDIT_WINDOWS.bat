@echo off
cd /d "%~dp0"
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "LOG=%~dp0COPPER_MATERIAL_AUDIT_REPORT.txt"
echo Copper material audit v0.3.26 > "%LOG%"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --copper-material-audit >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LOG%"
echo.
echo Report: %LOG%
pause
exit /b %RC%
