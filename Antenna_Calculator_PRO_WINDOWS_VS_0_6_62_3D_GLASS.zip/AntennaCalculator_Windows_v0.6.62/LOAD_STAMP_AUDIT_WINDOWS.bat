@echo off
cd /d "%~dp0"
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "LOG=%~dp0LOAD_STAMP_AUDIT_REPORT.txt"
echo Load Stamp Audit v0.3.23 > "%LOG%"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --load-stamp-audit >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LOG%"
echo.
echo Report: %LOG%
pause
exit /b %RC%
