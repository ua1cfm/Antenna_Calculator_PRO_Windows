@echo off
setlocal
set "ANTENNA_CUDA_MODE=AUTO"
echo CUDA mode: %ANTENNA_CUDA_MODE%
echo Start the WPF application from Visual Studio in this environment, or press a key to build and start it now.
pause
dotnet run --project "Source\AntennaCalculator.Wpf\AntennaCalculator.Wpf.csproj" -c Release
pause
