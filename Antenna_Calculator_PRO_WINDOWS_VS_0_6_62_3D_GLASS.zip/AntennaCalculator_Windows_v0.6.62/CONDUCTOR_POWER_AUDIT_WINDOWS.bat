@echo off
setlocal
cd /d "%~dp0"
set DOTNET_CLI_TELEMETRY_OPTOUT=1
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" --configuration Release -- --conductor-power-audit > "CONDUCTOR_POWER_AUDIT_REPORT.txt" 2>&1
type "CONDUCTOR_POWER_AUDIT_REPORT.txt"
echo.
echo Report: CONDUCTOR_POWER_AUDIT_REPORT.txt
pause
