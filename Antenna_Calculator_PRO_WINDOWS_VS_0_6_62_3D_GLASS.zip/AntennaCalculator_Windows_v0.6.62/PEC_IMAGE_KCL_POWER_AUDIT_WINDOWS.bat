@echo off
cd /d "%~dp0"
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "LOG=%~dp0PEC_IMAGE_KCL_POWER_AUDIT_REPORT.txt"
echo PEC IMAGE KCL POWER AUDIT v0.3.24 > "%LOG%"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --pec-image-kcl-power-audit >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LOG%"
echo.
echo Report: %LOG%
pause
exit /b %RC%
