# 0.6.26 CUDA launch diagnostics and architecture

- CUDA build selects sm architecture using nvidia-smi (or CUDA_ARCH override).
- Reports actual cudaError_t and cudaGetErrorString for stages -2 to -8.
- Rebuild DLL with Cuda\BUILD_CUDA_VOLUME_WIN64.bat before WPF build.
- CPU fallback retained.
