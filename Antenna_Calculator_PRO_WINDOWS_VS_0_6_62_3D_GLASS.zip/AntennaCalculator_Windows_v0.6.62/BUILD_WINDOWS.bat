@echo off
setlocal
cd /d "%~dp0"
echo Antenna Calculator PRO - Windows Preview v0.3.7
where dotnet >nul 2>nul
if errorlevel 1 (
 echo ERROR: .NET 8 SDK not found. Install it via Visual Studio Installer.
 pause
 exit /b 1
)
dotnet build "AntennaCalculator.Windows.sln" --configuration Release
if errorlevel 1 (
 echo BUILD FAILED
 pause
 exit /b 1
)
echo.
echo Running MMANA parser and MININEC numerical smoke tests...
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" --configuration Release --no-build
if errorlevel 1 (
 echo TESTS FAILED
 pause
 exit /b 1
)
echo.
echo Start Windows application...
start "" "Source\AntennaCalculator.Wpf\bin\Release\net8.0-windows\AntennaCalculator.Windows.exe"
endlocal
