@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --three-stage-power > "02_PORT_POWER_REPORT.txt" 2>&1
if errorlevel 1 (echo BUILD/TEST FAILED: 02_PORT_POWER_REPORT.txt) else (echo TEST COMPLETE: 02_PORT_POWER_REPORT.txt)
pause
