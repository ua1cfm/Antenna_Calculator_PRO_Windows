@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet run --project "Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --hairpin-kernel-junction > "HAIRPIN_KERNEL_JUNCTION_REPORT.txt" 2>&1
if errorlevel 1 (echo TEST FAILED. See HAIRPIN_KERNEL_JUNCTION_REPORT.txt) else (echo TEST COMPLETE. See HAIRPIN_KERNEL_JUNCTION_REPORT.txt)
pause
