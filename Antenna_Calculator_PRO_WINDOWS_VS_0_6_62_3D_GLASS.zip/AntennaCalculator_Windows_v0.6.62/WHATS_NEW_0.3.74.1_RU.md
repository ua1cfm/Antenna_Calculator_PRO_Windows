# Исправление v0.3.74.1

Исправлена ошибка CS1529 в Source/AntennaCalculator.Tests/Program.cs: вызов --mmana-matrix-parity перенесён после using. Математический алгоритм и тесты не изменялись. Компиляция .NET SDK здесь не выполнялась.
