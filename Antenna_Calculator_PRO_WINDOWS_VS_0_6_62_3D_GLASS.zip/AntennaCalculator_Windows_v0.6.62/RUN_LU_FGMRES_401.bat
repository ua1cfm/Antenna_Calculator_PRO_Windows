@echo off
cd /d "%~dp0"
dotnet run --project ".\Source\AntennaCalculator.Tests\AntennaCalculator.Tests.csproj" -c Release -- --mmana-matrix-parity --model ".\Samples\fixture_PEC_monopole_401.maa" --export-dir ".\parity_output_401"
echo.
if exist "parity_output_401\results.txt" type "parity_output_401\results.txt"
pause
